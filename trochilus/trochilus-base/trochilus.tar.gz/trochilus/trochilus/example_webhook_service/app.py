#  Copyright 2022 Troila
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.

import sys

import flask
from oslo_config import cfg
from oslo_log import log as logging
from oslo_serialization import jsonutils
import webob

from trochilus.common import service as trochilus_service

LOG = logging.getLogger(__name__)


def setup_app(argv=None):
    if argv is None:
        argv = sys.argv
    trochilus_service.prepare_service(argv)
    cfg.CONF.log_opt_values(LOG, logging.INFO)

    agent_server = WebhookServer()
    return agent_server.app


class WebhookServer(object):

    def __init__(self):
        self.app = flask.Flask(__name__)
        self.app.add_url_rule(
            rule=cfg.CONF.webhook_settings.target_path,
            view_func=self.receive_post_event,
            methods=['POST'])
        self.app.add_url_rule(
            rule=cfg.CONF.webhook_settings.target_path,
            view_func=self.receive_put_event,
            methods=['PUT'])

    def receive_post_event(self):
        payload = jsonutils.loads(flask.request.data)
        LOG.info("receive_post_event, payload: %s", payload)
        LOG.info("The auth token: %s",
                 flask.request.headers.get("X-Auth-Token"))
        return webob.Response(json={})

    def receive_put_event(self):
        payload = jsonutils.loads(flask.request.data)
        LOG.info("receive_put_event, payload: %s", payload)
        LOG.info("The auth token: %s",
                 flask.request.headers.get("X-Auth-Token"))
        return webob.Response(json={})
