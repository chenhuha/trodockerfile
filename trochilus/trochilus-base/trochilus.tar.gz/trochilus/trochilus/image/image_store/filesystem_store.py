#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import errno
import os
import urllib

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import excutils
from oslo_utils.secretutils import md5
from pecan import response

from trochilus.common import exceptions
from trochilus.image.image_store.base_store import BaseStore
from trochilus.image import utils

LOG = logging.getLogger(__name__)

CONF = cfg.CONF


class FilesystemStore(BaseStore):

    def __init__(self, store_datadir=None):
        super().__init__()
        self.size_cap = CONF.image_settings.image_size_cap
        self.chunk_size = CONF.image_settings.filesystem_store_chunk_size
        self.store_datadir = store_datadir
        if not self.store_datadir:
            self.store_datadir = CONF.image_settings.filesystem_store_datadir

    def add(self, image_id, image_file, image_size=0):
        filepath = os.path.join(self.store_datadir,
                                str(image_id))

        if os.path.exists(filepath):
            raise exceptions.ImageDuplicate(image=filepath)
        bytes_written = 0
        checksum = md5(usedforsecurity=False)
        try:
            with open(filepath, 'wb') as f:
                for buf in utils.chunkreadable(
                    utils.LimitingReader(
                        image_file,
                        self.size_cap),
                        self.chunk_size):
                    bytes_written += len(buf)
                    checksum.update(buf)
                    if self.thin_provision and not any(buf):
                        f.truncate(bytes_written)
                        f.seek(0, os.SEEK_END)
                    else:
                        f.write(buf)
        except IOError as e:
            if e.errno != errno.EACCES:
                self.delete_partial(filepath, image_id)
            errors = {
                errno.EFBIG: exceptions.StorageFull(),
                errno.ENOSPC: exceptions.StorageFull(),
                errno.EACCES: exceptions.StorageWriteDenied()
            }
            raise errors.get(e.errno, e)
        except Exception:
            with excutils.save_and_reraise_exception():
                self.delete_partial(filepath, image_id)

        checksum_hex = checksum.hexdigest()

        return ('file://%s' % filepath, bytes_written, checksum_hex)

    def delete(self, location, image_id=None):
        loc = urllib.parse.urlparse(location)
        fn = loc.path
        if os.path.exists(fn):
            try:
                LOG.debug("Deleting image at %(fn)s", {'fn': fn})
                os.unlink(fn)
            except OSError as e:
                raise exceptions.ImageFileDeleteFaild(image=fn) from e
        else:
            raise exceptions.ImageFileNotFound(image=fn)

    def download(self, location, image_id=None):
        loc = urllib.parse.urlparse(location)
        file_path = loc.path

        if os.path.exists(file_path):
            chunked_file = ChunkedFiles(file_path, chunk_size=self.chunk_size)

            response.app_iter = iter(chunked_file)
            response.headers['Content-Type'] = "application/octet-stream"
            response.headers['Content-Disposition'] = \
                'attachment;filename="%s"' \
                % os.path.basename(file_path)

        else:
            raise exceptions.ImageFileNotFound(image=file_path)

    def delete_partial(self, filepath, image_id):
        try:
            os.unlink(filepath)
        except Exception as e:
            msg = ("Unable to remove partial image "
                   "data for image %(id)s: %(e)s"
                   ) % dict(id=image_id, e=e)
            LOG.error(msg)


class ChunkedFiles(object):
    def __init__(self, filepath, chunk_size=4096):
        self.filepath = filepath
        self.chunk_size = chunk_size

    def __iter__(self):
        """Return an iterator over the image file."""
        with open(self.filepath, 'rb') as fp:
            while True:
                chunk = fp.read(self.chunk_size)
                if not chunk:
                    break
                yield chunk
