#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import math

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils.secretutils import md5
from oslo_utils import units
from pecan import response

from trochilus.common import exceptions
from trochilus.image.image_store.base_store import BaseStore
from trochilus.image import utils

try:
    import rados
    import rbd
except ImportError:
    rados = None
    rbd = None

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class RbdStore(BaseStore):
    """RBD image

    RBD image location example:
    rbd://fsid/pool/image/snap
    """

    def __init__(self) -> None:
        super().__init__()
        self.connect_timeout = CONF.image_settings.rbd_store_conn_timeout
        self.config_file = CONF.image_settings.rbd_store_config_file
        self.user = CONF.image_settings.rbd_store_user
        self.pool = CONF.image_settings.rbd_store_pool
        self.chunk_size = CONF.image_settings.rbd_store_chunk_size * units.Mi
        self.resize_amount = self.chunk_size
        self.snap = "snap"
        self.fsid = None
        self.size = 0

    def add(self, image_id, image_file, image_size=0):
        checksum = md5(usedforsecurity=False)
        with rados.Rados(conffile=self.config_file,
                         rados_id=self.user) as cluster:
            self.fsid = cluster.get_fsid()

            with cluster.open_ioctx(self.pool) as ioctx:
                LOG.debug('creating image %s with size %d',
                          image_id, image_size)
                librbd = rbd.RBD()

                # Used to set the size of objects in ceph by chunk
                order = int(math.log(self.chunk_size, 2))
                try:
                    librbd.create(ioctx, image_id,
                                  image_size, order=order)
                except rbd.ImageExists as e:
                    raise exceptions.ImageDuplicate(image=image_id) from e

                try:
                    with rbd.Image(ioctx, image_id) as image:
                        bytes_written = 0
                        offset = 0

                        for buf in utils.chunkreadable(
                                image_file, self.chunk_size):
                            chunk_length = len(buf)
                            self.size = self._resize_on_write(
                                image, image_size, bytes_written, chunk_length)
                            bytes_written += chunk_length
                            if not (self.thin_provision and not any(buf)):
                                image.write(buf, offset)
                            offset += chunk_length
                            checksum.update(buf)

                        # Lets trim the image in case we overshoot with resize
                        if image_size == 0:
                            image.resize(bytes_written)

                        checksum_hex = checksum.hexdigest()

                        image.create_snap(self.snap)
                        image.protect_snap(self.snap)

                except rbd.NoSpace as e:
                    LOG.error("Failed to store image %s "
                              "insufficient space available", image_id)
                    try:
                        self.delete(None, image_id=image_id)
                    except exceptions.NotFound:
                        pass
                    raise exceptions.StorageFull() from e
                except Exception as e:
                    LOG.error("Failed to store image %s "
                              "Store Exception %s", image_id, e)
                    try:
                        self.delete(None, image_id=image_id)
                    except exceptions.NotFound:
                        pass
                    raise e

        return ('rbd://%s/%s/%s/%s' % (
            self.fsid, self.pool, image_id, self.snap),
            bytes_written, checksum_hex)

    def delete(self, image_location, image_id=None):
        """Delete RBD image and snapshot."""
        with rados.Rados(conffile=self.config_file,
                         rados_id=self.user) as cluster:

            with cluster.open_ioctx(self.pool) as ioctx:
                try:
                    with rbd.Image(ioctx, image_id) as image:
                        try:
                            if self._snapshot_has_external_reference(
                                    image, self.snap):
                                raise rbd.ImageBusy(
                                    "Image snapshot has external "
                                    "references.")

                            try:
                                image.unprotect_snap(self.snap)
                            except rbd.InvalidArgument:
                                LOG.debug(
                                    "Snapshot %s is unprotected already",
                                    self.snap)
                            image.remove_snap(self.snap)
                        except rbd.ImageNotFound as e:
                            LOG.debug("Snap Operating Exception %s "
                                      "Snapshot does not exist.", e)
                        except rbd.ImageBusy as e:
                            LOG.warning("Snap Operating Exception %s "
                                        "Snapshot is in use.", e)
                            raise exceptions.InUseByStore()
                    rbd.RBD().remove(ioctx, image_id)
                except rbd.ImageHasSnapshots as e:
                    raise exceptions.HasSnapshot() from e
                except rbd.ImageBusy as e:
                    raise exceptions.InUseByStore() from e
                except rbd.ImageNotFound as e:
                    raise exceptions.ImageFileNotFound(image=image_id) from e

    def download(self, image_location=None, image_id=None):
        response.app_iter = iter(ImageIterator(image_id=image_id))
        response.headers['Content-Type'] = "application/octet-stream"
        response.headers['Content-Disposition'] \
            = 'attachment;filename="%s"' % image_id

    def _resize_on_write(self, image, image_size, bytes_written, chunk_length):
        """Handle the rbd resize when needed."""
        if image_size != 0 or self.size >= bytes_written + chunk_length:
            return self.size
        new_size = self.size + self.resize_amount
        LOG.debug("resizing image to %s KiB", (new_size / units.Ki))
        image.resize(new_size)
        self.resize_amount = min(self.resize_amount * 2, 8 * units.Gi)
        return new_size

    def _snapshot_has_external_reference(self, image, snapshot_name):
        """Returns True if snapshot has external reference else False."""
        image.set_snap(snapshot_name)
        has_references = bool(image.list_children())
        image.set_snap(None)
        return has_references


class ImageIterator(RbdStore):
    def __init__(self, image_id):
        self.image_id = image_id
        super().__init__()

    def __iter__(self):
        try:
            with rados.Rados(conffile=self.config_file,
                             rados_id=self.user) as conn:
                with conn.open_ioctx(self.pool) as ioctx:
                    with rbd.Image(ioctx, self.image_id) as image:
                        size = image.size()
                        bytes_left = size
                        while bytes_left > 0:
                            length = min(self.chunk_size, bytes_left)
                            data = image.read(size - bytes_left, length)
                            bytes_left -= len(data)
                            yield data
                        return
        except rbd.ImageNotFound as e:
            raise exceptions.ImageFileNotFound(image=self.image_id) from e
