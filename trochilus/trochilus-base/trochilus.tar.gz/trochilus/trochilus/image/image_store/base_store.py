#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg

CONF = cfg.CONF


class BaseStore:
    def __init__(self) -> None:
        """Initialize the Store"""
        self.thin_provision = CONF.image_settings.rbd_store_thin_provisioning

    def add(self, image_id, image_file, image_size=0):
        """Stores an image file."""
        raise NotImplementedError

    def delete(self, image_location, image_id=None):
        """Find the image by location and delete it."""
        raise NotImplementedError
