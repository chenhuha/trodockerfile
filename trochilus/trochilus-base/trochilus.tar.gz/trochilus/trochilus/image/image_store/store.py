#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg
from trochilus.image.image_store.filesystem_store import FilesystemStore
from trochilus.image.image_store.rbd_store import RbdStore


CONF = cfg.CONF
STORES = {
    "rbd": RbdStore,
    "filesystem": FilesystemStore
}


class Store:

    def __init__(self) -> None:
        self.enabled_store = CONF.image_settings.enabled_image_store
        self.class_store = STORES.get(self.enabled_store)

    @property
    def store(self):
        return self.class_store()


def get_story():
    return Store().store
