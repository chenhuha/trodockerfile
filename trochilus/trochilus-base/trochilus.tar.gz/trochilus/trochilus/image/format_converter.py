# Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import urllib.parse

from oslo_concurrency import processutils
from oslo_log import log as logging
from trochilus.common import exceptions

LOG = logging.getLogger(__name__)


def convert_qcow2_to_raw(qcow2_path):
    # Get raw image path
    if qcow2_path.endswith('.qcow2'):
        raw_path = urllib.parse.urlparse(
            qcow2_path[:len(qcow2_path) - 6] + '.raw').path
    else:
        raw_path = urllib.parse.urlparse(qcow2_path + '.raw').path
    # execute cmd
    cmd = ['qemu-img', 'convert', '-O', 'raw', '-f', 'qcow2', qcow2_path,
           raw_path]
    stdout, stderr = processutils.execute(*cmd)
    if stderr:
        LOG.error('Failed to convert image from qcow2 to raw2. qcow2_path is '
                  '%s, execution cmd is %s, execution error result is %s',
                  qcow2_path, cmd, stderr)
        raise exceptions.ImageConvertFailed
    return raw_path
