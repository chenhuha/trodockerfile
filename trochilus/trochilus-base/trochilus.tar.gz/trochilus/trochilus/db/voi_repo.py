#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from trochilus.common import constants
from trochilus.db import base_repo
from trochilus.db import models
from trochilus.db import nic_repo


class ImageRepository(base_repo.BaseRepository):

    model_class = models.VOIImage


class VMRepository(base_repo.BaseRepository):

    model_class = models.VOIVM

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.nic_repo = nic_repo.NicRepository()

    def get(self, session, **filters):
        """Retrieves an entity from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entity should be retrieved.
        :returns: trochilus.db.base_models.TrochilusBase
        """
        db_vm = super().get(session, **filters)
        if db_vm:
            db_vm.nics = self.nic_repo.get_all(
                session, pagination_helper=False, **{"owner_id": db_vm.id})[0]
        return db_vm

    def get_all(self, session, pagination_helper=None, **filters):
        db_vms, links = super().get_all(session, pagination_helper, **filters)
        for db_vm in db_vms:
            db_vm.nics = self.nic_repo.get_all(
                session, pagination_helper=False, **{"owner_id": db_vm.id})[0]
        return db_vms, links

    def get_all_ing_status_vms(self, session, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        query = query.filter(
            self.model_class.status.contains('ing'))
        return query.all()

    def update(self, session, id, expected_status=None, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expected_status:
                query = query.filter_by(status=expected_status)
            return query.update(model_kwargs)


class VolumeRepository(base_repo.BaseRepository):

    model_class = models.VOIVolume


class ShareTemplateVolumeRepository(base_repo.BaseRepository):

    model_class = models.VOIShareTemplateVolume

    def get_all(self, session, pagination_helper=None, lock=False, **filters):
        query = session.query(self.model_class).filter(
            self.model_class.status != constants.DELETED).filter_by(**filters)
        if lock:
            query = query.with_for_update()
        if pagination_helper:
            model_list, links = pagination_helper.apply(
                query, self.model_class)
        else:
            links = None
            model_list = query.all()

        return model_list, links

    def update(self, session, id, expected_status=None, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expected_status:
                query = query.filter_by(status=expected_status)
            return query.update(model_kwargs)


class CDDriverRepository(base_repo.BaseRepository):

    model_class = models.VOICDDriver
