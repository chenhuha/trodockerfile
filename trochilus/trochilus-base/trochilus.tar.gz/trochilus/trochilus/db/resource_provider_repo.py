# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from oslo_config import cfg
from sqlalchemy import or_
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import base_repo
from trochilus.db import models

CONF = cfg.CONF


class ResourceProviderRepository(base_repo.BaseRepository):

    model_class = models.ResourceProvider

    def get(self, session, lock=False, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        if lock:
            query = query.with_for_update()
        return query.first()

    def update(self, session, id, expected_generation=None, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expected_generation:
                query = query.filter_by(generation=expected_generation)
            return query.update(model_kwargs)

    def increase_generation(self, session, id):
        with session.begin(subtransactions=True):
            return session.query(self.model_class).filter_by(id=id).update(
                {self.model_class.generation: self.model_class.generation + 1})


class ResourceAllocationRepository(base_repo.BaseRepository):

    model_class = models.ResourceAllocation

    def __init__(self):
        self.res_provider_repo = ResourceProviderRepository()
        self.agent_repo = agent_repo.AgentRepository()

    def create_batch(self, session, res_provider_id, consumer_id,
                     res_use_dict):
        create_list = [
            {'consumer_id': consumer_id,
             'resource_provider_id': res_provider_id,
             'used': used,
             'resource_class_id': res_class_id}
            for res_class_id, used in res_use_dict.items()]
        return super().create_batch(session, create_list)

    def delete_batch(self, session, consumer_id=None, alloc_ids=None):
        query = session.query(self.model_class)
        if consumer_id:
            query = query.filter_by(consumer_id=consumer_id)
        if alloc_ids:
            conditions = [self.model_class.id == alloc_id
                          for alloc_id in alloc_ids]
            query = query.filter(or_(*conditions))
        with session.begin(subtransactions=True):
            query.delete()

    def update(self, session, res_provider_id, consumer_id, res_use_dict):
        with session.begin(subtransactions=True):
            self.delete_batch(session, consumer_id=consumer_id)
            self.create_batch(session, res_provider_id,
                              consumer_id, res_use_dict)

    def delete_allocations(self, consumer_id, agent_obj=None):
        with db_api.get_lock_session() as lock_session:
            if not agent_obj:
                agent_obj = self.agent_repo.get(
                    lock_session, hostname=CONF.agent_settings.hostname)
            res_provider_id = agent_obj.resource_provider.id
            allocs, _ = self.get_all(lock_session, consumer_id=consumer_id,
                                     resource_provider_id=res_provider_id)
            if allocs:
                self.res_provider_repo.increase_generation(
                    lock_session, res_provider_id)
                self.delete_batch(lock_session,
                                  alloc_ids=[alloc.id for alloc in allocs])

    def update_allocations(self, consumer_id, res_use_dict):
        with db_api.get_lock_session() as lock_session:
            alloc = self.get(lock_session, consumer_id=consumer_id)
            if alloc:
                self.res_provider_repo.increase_generation(
                    lock_session, alloc.resource_provider_id)
                self.update(lock_session, alloc.resource_provider_id,
                            consumer_id, res_use_dict)
