#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


import sqlalchemy as sa
from sqlalchemy import orm

from oslo_config import cfg
from oslo_db.sqlalchemy import models
from trochilus.api.v1.types import agent
from trochilus.api.v1.types import client_device
from trochilus.api.v1.types import image
from trochilus.api.v1.types import nic
from trochilus.api.v1.types import snapshot
from trochilus.api.v1.types import snapshot_group
from trochilus.api.v1.types import subnet
from trochilus.api.v1.types import virtual_machine as vm
from trochilus.api.v1.types import voi
from trochilus.api.v1.types import volume
from trochilus.api.v1.types import vpc
from trochilus.db import base_models
from trochilus.db import constants
from trochilus.db import sqlalchemytypes

CONF = cfg.CONF


class Agent(base_models.Base, base_models.IdMixin,
            base_models.DescriptionMixin):

    __tablename__ = "agent"

    __v1_wsme__ = agent.AgentResponse

    hostname = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         nullable=False, unique=True)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=True)
    heartbeat_timestamp = sa.Column(sqlalchemytypes.TruncatedDateTime,
                                    nullable=True)
    mgmt_ip = sa.Column(sqlalchemytypes.IPAddress(), nullable=False)
    api_version = sa.Column(sa.String(8), nullable=False)
    total_memory = sa.Column(sa.BigInteger(), nullable=True)
    free_memory = sa.Column(sa.BigInteger(), nullable=True)
    cpu_used_ratio = sa.Column(sa.Float(), nullable=True)
    sys_disk_size = sa.Column(sa.BigInteger(), nullable=True)
    sys_disk_used_size = sa.Column(sa.BigInteger(), nullable=True)
    system = sa.Column(sa.String(20), nullable=True)
    version = sa.Column(sa.Float(), nullable=True)
    cpu_thread = sa.Column(sa.Integer(), nullable=True)
    cpu_socket = sa.Column(sa.Integer(), nullable=True)
    cpu_MHZ = sa.Column(sa.String(10), nullable=True)
    cpu_core = sa.Column(sa.Integer(), nullable=True)
    stepping = sa.Column(sa.Integer(), nullable=True)
    model = sa.Column(sa.String(255), nullable=True)
    boot_time = sa.Column(sa.DateTime(), nullable=True)
    L2_cache = sa.Column(sa.String(20), nullable=True)
    L3_cache = sa.Column(sa.String(20), nullable=True)
    role = sa.Column(sqlalchemytypes.JsonEncodedList(),
                     default=[],
                     nullable=True)
    disk_names = sa.Column(sa.String(160), nullable=True)
    net_pci_info = sa.Column(sqlalchemytypes.JsonEncodedList(),
                             default=[],
                             nullable=True)
    host_username = sa.Column(sa.String(20), nullable=True)
    host_password = sa.Column(sa.String(20), nullable=True)
    ipmi_address = sa.Column(sa.String(34), nullable=True)
    ipmi_username = sa.Column(sa.String(20), nullable=True)
    ipmi_password = sa.Column(sa.String(20), nullable=True)
    ipmi_vendor = sa.Column(sa.String(20), nullable=True)


class Image(base_models.Base, base_models.DescriptionMixin,
            base_models.NameMixin, base_models.IdMixin,
            models.TimestampMixin, base_models.ProjectMixin,
            base_models.UserMixin):
    """Represents an image in the datastore."""
    __tablename__ = 'image'

    __v1_wsme__ = image.ImageResponse

    disk_format = sa.Column(sa.String(20), nullable=True)
    size = sa.Column(sa.BigInteger(), nullable=True)
    virtual_size = sa.Column(sa.BigInteger(), nullable=True)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)
    checksum = sa.Column(sa.String(32), nullable=True)
    # Because metadata is a built-in property of the database model
    # metadata_ is used
    # ref https://docs.sqlalchemy.org/en/14/core/metadata.html
    metadata_ = sa.Column("metadata", sqlalchemytypes.JsonEncodedDict(),
                          default={},
                          nullable=True)
    tags = sa.Column(sqlalchemytypes.JsonEncodedList(),
                     default=[],
                     nullable=True)
    location = sa.Column(sa.String(1024), nullable=True)


class Vpc(base_models.Base, base_models.IdMixin,
          base_models.DescriptionMixin, base_models.ProjectMixin,
          base_models.NameMixin, base_models.UserMixin,
          models.TimestampMixin):

    __tablename__ = "vpc"

    __v1_wsme__ = vpc.VpcResponse

    vlan_id = sa.Column(sa.Integer(), nullable=True)
    type = sa.Column(sa.String(16), nullable=False)
    physical = sa.Column(sa.String(16), nullable=False)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)


class VpcNodeMapping(base_models.Base):

    __tablename__ = "vpc_node_mapping"

    __v1_wsme__ = vpc.VpcNodeMappingResponse

    __table_args__ = (
        sa.PrimaryKeyConstraint('vpc_id', 'agent_id'),
        {},
    )

    vpc_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                       sa.ForeignKey('vpc.id', ondelete='CASCADE'),
                       nullable=False)
    agent_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('agent.id', ondelete='CASCADE'),
                         index=True,
                         nullable=False)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)

    vpc = orm.relationship(Vpc,
                           uselist=False,
                           backref=orm.backref('vpc_node_mappings'))
    agent = orm.relationship(Agent,
                             uselist=False,
                             backref=orm.backref('vpc_node_mapping'))


class Subnet(base_models.Base, base_models.IdMixin,
             base_models.DescriptionMixin, base_models.ProjectMixin,
             base_models.NameMixin, base_models.UserMixin,
             models.TimestampMixin):

    __tablename__ = "subnet"

    __v1_wsme__ = subnet.SubnetResponse

    vpc_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                       sa.ForeignKey('vpc.id'), nullable=False)
    cidr = sa.Column(sqlalchemytypes.CIDR(), nullable=False)
    gateway = sa.Column(sqlalchemytypes.IPAddress(), nullable=True)
    enable_dhcp = sa.Column(sa.Boolean, nullable=False)

    vpc = orm.relationship(
        Vpc, uselist=False, load_on_pending=True,
        backref=orm.backref('subnets', lazy='subquery', uselist=True))


class DnsNameServer(base_models.Base):

    __tablename__ = "dns_nameserver"

    __table_args__ = (
        sa.PrimaryKeyConstraint('subnet_id', 'ip_address'),
        {},
    )

    subnet_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                          sa.ForeignKey('subnet.id', ondelete='CASCADE'),
                          nullable=False,)
    ip_address = sa.Column(sqlalchemytypes.IPAddress(), nullable=False)
    order = sa.Column(sa.Integer, default=0)

    subnet = orm.relationship(
        Subnet, uselist=False, load_on_pending=True,
        backref=orm.backref('dns_nameservers', lazy='subquery',
                            uselist=True, cascade='delete'))


class AddressPool(base_models.Base, base_models.IdMixin):

    __tablename__ = "address_pool"

    subnet_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                          sa.ForeignKey('subnet.id', ondelete='CASCADE'),
                          nullable=False, index=True)
    start_ip = sa.Column(sqlalchemytypes.IPAddress(), nullable=False)
    end_ip = sa.Column(sqlalchemytypes.IPAddress(), nullable=False)

    subnet = orm.relationship(
        Subnet, uselist=False, load_on_pending=True,
        backref=orm.backref('address_pools', lazy='subquery', uselist=True,
                            cascade='delete'))


class Nic(base_models.Base, base_models.IdMixin,
          base_models.DescriptionMixin, base_models.ProjectMixin,
          base_models.NameMixin, base_models.UserMixin,
          models.TimestampMixin):

    __tablename__ = "nic"

    __v1_wsme__ = nic.NicResponse

    vpc_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                       sa.ForeignKey('vpc.id'), nullable=False)
    mac_address = sa.Column(sqlalchemytypes.MACAddress(), nullable=False,
                            unique=True)
    # This colume can not build foreign key constraint, otherwise update
    # hostname will be failed because of foreign key constraint
    hostname = sa.Column(sa.String(constants.UUID_FIELD_SIZE), nullable=True)
    owner_type = sa.Column(sa.String(10), nullable=False)
    owner_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE), nullable=True)
    auto_delete = sa.Column(sa.Boolean, default=False)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)

    vpc = orm.relationship(
        Vpc, uselist=False, load_on_pending=True,
        backref=orm.backref('nics', lazy='subquery', uselist=True))

    agent = orm.relationship(
        Agent, uselist=False, load_on_pending=True,
        primaryjoin='Agent.hostname == foreign(Nic.hostname)',
        backref=orm.backref(
            'nics', lazy='subquery',
            primaryjoin='Agent.hostname == foreign(Nic.hostname)',
            uselist=True))


class AddressAllocation(base_models.Base):

    __tablename__ = "address_allocation"
    __table_args__ = (sa.PrimaryKeyConstraint('subnet_id', 'ip_address'),)

    nic_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                       sa.ForeignKey('nic.id', ondelete='CASCADE'),
                       index=True, nullable=False)
    subnet_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                          sa.ForeignKey('subnet.id'))
    ip_address = sa.Column(sqlalchemytypes.IPAddress(), nullable=False)

    nic = orm.relationship(
        Nic, uselist=False, load_on_pending=True,
        backref=orm.backref('ip_addresses', lazy='subquery', uselist=True,
                            cascade='delete'))

    subnet = orm.relationship(
        Subnet, uselist=False, load_on_pending=True,
        backref=orm.backref('alloc_ip_addresses', lazy='subquery',
                            uselist=True))


class DhcpNodeMapping(base_models.Base):

    __tablename__ = "dhcp_node_mapping"

    __table_args__ = (
        sa.PrimaryKeyConstraint('hostname'),
        {},
    )

    hostname = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('agent.hostname', ondelete='CASCADE'),
                         nullable=False)
    index = sa.Column(sa.Integer, nullable=False, unique=True)

    agent = orm.relationship(
        Agent, uselist=False, load_on_pending=True,
        backref=orm.backref('dhcp', lazy='subquery', uselist=False,
                            cascade='delete'))


class Volume(base_models.Base, base_models.IdMixin,
             base_models.NameMixin, base_models.DescriptionMixin,
             base_models.ProjectMixin, base_models.UserMixin,
             models.TimestampMixin):

    __tablename__ = "volume"

    __v1_wsme__ = volume.VolumeResponse

    size = sa.Column(sa.Integer)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE))
    bootable = sa.Column(sa.Boolean, default=False)
    backend = sa.Column(sa.String(255))
    hostname = sa.Column(sa.String(255))
    image_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('image.id'), nullable=True)
    snapshot_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                            sa.ForeignKey('snapshot.id'), nullable=True)
    volume_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                          sa.ForeignKey('volume.id'), nullable=True)
    auto_delete = sa.Column(sa.Boolean, default=False)


class VirtualMachine(base_models.Base, base_models.IdMixin,
                     base_models.DescriptionMixin, base_models.ProjectMixin,
                     base_models.NameMixin, base_models.UserMixin,
                     models.TimestampMixin):

    __tablename__ = "virtual_machine"
    __v1_wsme__ = vm.VirtualMachineResponse

    vcpu = sa.Column(sa.Integer(), nullable=False)
    vnc_address = sa.Column(sa.String(34), nullable=True)
    memory_mb = sa.Column(sa.Integer(), nullable=False)
    root_disk_gb = sa.Column(sa.Integer(), nullable=True)
    spice_address = sa.Column(sa.String(34), nullable=True)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=True)
    metadata_ = sa.Column("metadata", sqlalchemytypes.JsonEncodedDict(),
                          default={},
                          nullable=True)
    tags = sa.Column(sqlalchemytypes.JsonEncodedList(),
                     default=[],
                     nullable=True)
    agent_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('agent.id'), nullable=False)
    image_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE))

    agent = orm.relationship(
        Agent, load_on_pending=True,
        backref=orm.backref('virtual_machines', uselist=False))

    nics = orm.relationship(
        Nic, uselist=True, load_on_pending=True,
        primaryjoin='VirtualMachine.id == foreign(Nic.owner_id)',
        backref=orm.backref(
            'vm', lazy='subquery',
            primaryjoin='VirtualMachine.id == foreign(Nic.owner_id)',
            uselist=False))

    @property
    def guest_name(self):
        # Command 'virsh list' display name
        return CONF.vm_settings.vm_name_template % self.id


class VMVolumeMapping(base_models.Base, base_models.IdMixin,
                      models.TimestampMixin):

    __tablename__ = "vm_volume_mapping"

    volume_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                          sa.ForeignKey('volume.id'), nullable=False)
    virtual_machine_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                                   sa.ForeignKey('virtual_machine.id'),
                                   nullable=True)
    attached_index = sa.Column(sa.Integer(), nullable=True)
    attach_status = sa.Column(
        sa.String(constants.STATUS_FIELD_SIZE), nullable=False)
    vm = orm.relationship(
        VirtualMachine, backref=orm.backref('vm_volume_mapping'),
        primaryjoin='and_('
        'VMVolumeMapping.virtual_machine_id == VirtualMachine.id,'
        'VMVolumeMapping.attach_status != "detached")')
    volume = orm.relationship(
        Volume, backref=orm.backref('vm_volume_mapping'),
        primaryjoin='and_('
        'VMVolumeMapping.volume_id == Volume.id,'
        'VMVolumeMapping.attach_status != "detached")')


class VMNicMapping(base_models.Base, base_models.IdMixin,
                   models.TimestampMixin):

    __tablename__ = "vm_nic_mapping"

    nic_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                       sa.ForeignKey('nic.id'), nullable=False)
    virtual_machine_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                                   sa.ForeignKey('virtual_machine.id'),
                                   nullable=True)
    nic = orm.relationship(
        Nic, backref=orm.backref('vm_nic_mapping'),
        uselist=True)
    vm = orm.relationship(
        VirtualMachine, backref=orm.backref('vm_nic_mapping'),
        uselist=False)


class SnapshotGroup(base_models.Base, base_models.IdMixin,
                    base_models.NameMixin, base_models.DescriptionMixin,
                    base_models.ProjectMixin, base_models.UserMixin,
                    models.TimestampMixin):

    __tablename__ = 'snapshot_group'

    __v1_wsme__ = snapshot_group.SnapshotGroupResponse

    size = sa.Column(sa.Integer(), nullable=True)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE))
    current = sa.Column(sa.Boolean, default=False)
    previous = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('snapshot_group.id'),
                         nullable=True)
    virtual_machine_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                                   sa.ForeignKey('virtual_machine.id'),
                                   nullable=True)
    vm = orm.relationship(
        VirtualMachine, backref=orm.backref('snapshot_group'),
        primaryjoin='and_('
        'SnapshotGroup.virtual_machine_id == VirtualMachine.id,'
        'SnapshotGroup.status != "deleted")')


class Snapshot(base_models.Base, base_models.IdMixin,
               base_models.NameMixin, base_models.DescriptionMixin,
               base_models.ProjectMixin, base_models.UserMixin,
               models.TimestampMixin):
    """Represents a snapshot in the datastore."""

    __tablename__ = 'snapshot'

    __v1_wsme__ = snapshot.SnapshotResponse

    size = sa.Column(sa.Integer(), nullable=True)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE))
    volume_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                          sa.ForeignKey('volume.id'),
                          nullable=True)
    current = sa.Column(sa.Boolean, default=False)
    previous = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         nullable=True)
    volume = orm.relationship(Volume, backref="snapshot",
                              foreign_keys=volume_id,
                              primaryjoin='and_('
                              'Snapshot.volume_id == Volume.id,'
                              'Snapshot.status != "deleted")')
    snapshot_group_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                                  sa.ForeignKey('snapshot_group.id'),
                                  nullable=True)
    snapshot_group = orm.relationship(
        SnapshotGroup, backref=orm.backref('snapshot'),
        primaryjoin='and_('
        'Snapshot.snapshot_group_id == SnapshotGroup.id,'
        'Snapshot.status != "deleted")')


class ClientDevice(base_models.Base, base_models.IdMixin):

    __tablename__ = "client_device"
    __v1_wsme__ = client_device.ClientDeviceResponse

    vpc_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                       nullable=False)
    mac = sa.Column(sa.String(constants.MAC_ADDR_FIELD_SIZE),
                    primary_key=True)
    ip = sa.Column(sa.String(constants.IP_ADDR_FIELD_SIZE),
                   nullable=True)
    last_update = sa.Column(sa.DateTime, nullable=True)


class VOIImage(base_models.Base, base_models.IdMixin,
               base_models.NameMixin, base_models.DescriptionMixin,
               base_models.ProjectMixin, base_models.UserMixin,
               models.TimestampMixin):

    """Represents a VOI image in the datastore."""

    __tablename__ = 'voi_image'

    __v1_wsme__ = voi.VOIImageResponse

    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)
    checksum = sa.Column(sa.String(32), nullable=True)
    location = sa.Column(sa.String(1024), nullable=True)
    size = sa.Column(sa.BigInteger(), nullable=True)
    virtual_size = sa.Column(sa.BigInteger(), nullable=True)
    disk_format = sa.Column(sa.String(20), nullable=True)


class VOIVM(base_models.Base, base_models.IdMixin,
            base_models.NameMixin, base_models.DescriptionMixin,
            base_models.ProjectMixin, base_models.UserMixin,
            models.TimestampMixin):

    """Represents a VOI VM in the datastore."""

    __tablename__ = 'voi_vm'

    __v1_wsme__ = voi.VOIVMResponse

    image_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('voi_image.id'), nullable=True)
    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)
    vcpu = sa.Column(sa.Integer(), nullable=False)
    memory_mb = sa.Column(sa.Integer(), nullable=False)
    root_disk_gb = sa.Column(sa.Integer(), nullable=True)
    vnc_address = sa.Column(sa.String(34), nullable=True)
    spice_address = sa.Column(sa.String(34), nullable=True)
    agent_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('agent.id'), nullable=False)
    metadata_ = sa.Column("metadata", sqlalchemytypes.JsonEncodedDict(),
                          default={},
                          nullable=True)

    image = orm.relationship(
        VOIImage, uselist=False, load_on_pending=True,
        backref=orm.backref('voi_vm', lazy='subquery', uselist=True))
    agent = orm.relationship(
        Agent, uselist=False, load_on_pending=True,
        backref=orm.backref('agent', lazy='subquery', uselist=True))

    @property
    def guest_name(self):
        # Command 'virsh list' display name
        return CONF.voi_setting.vm_name_template % self.id


class VOIVolume(base_models.Base, base_models.IdMixin,
                models.TimestampMixin):

    """Represents a VOI volume in the datastore."""

    __tablename__ = 'voi_volume'

    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)
    size = sa.Column(sa.Integer(), nullable=False)
    index = sa.Column(sa.Integer(), nullable=False)
    vm_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                      sa.ForeignKey('voi_vm.id'), nullable=False)
    vm = orm.relationship(
        VOIVM, uselist=False, load_on_pending=True,
        backref=orm.backref('disks', lazy='subquery', uselist=True),
        primaryjoin='and_('
        'VOIVolume.vm_id == VOIVM.id,'
        'VOIVolume.status != "deleted")')


class VOIShareTemplateVolume(base_models.Base, base_models.IdMixin,
                             models.TimestampMixin):

    """Represents a VOI share template volume in the datastore."""

    __tablename__ = 'voi_share_template_volume'

    __v1_wsme__ = voi.ShareTemplateDiskResponse

    status = sa.Column(sa.String(constants.STATUS_FIELD_SIZE), nullable=False)
    size = sa.Column(sa.Integer(), nullable=False)
    index = sa.Column(sa.Integer(), nullable=True)
    vm_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                      sa.ForeignKey('voi_vm.id'), nullable=True)
    vm = orm.relationship(
        VOIVM, uselist=False, load_on_pending=True,
        backref=orm.backref('share_template_disks', lazy='subquery',
                            uselist=True),
        primaryjoin='and_('
        'VOIShareTemplateVolume.vm_id == VOIVM.id,'
        'VOIShareTemplateVolume.status != "deleted")')


class VOICDDriver(base_models.Base, base_models.IdMixin,
                  models.TimestampMixin):

    """Represents a VOI CD driver in the datastore."""

    __tablename__ = 'voi_cd_driver'

    image_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('voi_image.id'), nullable=True)
    vm_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                      sa.ForeignKey('voi_vm.id'), nullable=False)
    is_sys = sa.Column(sa.Boolean, nullable=False, default=False)
    vm = orm.relationship(
        VOIVM, uselist=False, load_on_pending=True,
        backref=orm.backref('cd_drivers', lazy='subquery', uselist=True))


class Network(base_models.Base, base_models.IdMixin):
    """Represents a network in the datastore."""

    __tablename__ = 'network'

    agent_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('agent.id'), nullable=False)
    nic_name = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         nullable=False)
    agent = orm.relationship(
        Agent, load_on_pending=True,
        backref=orm.backref('network', uselist=True))

    status = sa.Column(sa.Integer(), nullable=True)
    ip_addresses = sa.Column(sqlalchemytypes.JsonEncodedList(),
                             default=[],
                             nullable=True)
    subnet_mask = sa.Column(sa.String(constants.IP_ADDR_FIELD_SIZE),
                            nullable=True)
    gateway = sa.Column(sa.String(constants.IP_ADDR_FIELD_SIZE),
                        nullable=True)
    speed = sa.Column(sa.Integer(), nullable=True)
    vlan = sa.Column(sa.String(34), nullable=True)
    bond_name = sa.Column(sa.String(35), nullable=True)
    role = sa.Column(sa.String(5), nullable=True)
    type = sa.Column(sa.String(10), nullable=True)

    def to_dict(self, calling_classes=None, recurse=False, **kwargs):
        """Converts a database model to a dictionary."""
        result = super().to_dict(calling_classes, recurse, **kwargs)
        result['ip_addresses'] = self.ip_addresses
        return result


class ResourceProvider(base_models.Base, base_models.IdMixin,
                       models.TimestampMixin):

    __tablename__ = "resource_provider"

    generation = sa.Column(sa.Integer, nullable=False, default=0)
    agent_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                         sa.ForeignKey('agent.id', ondelete='CASCADE'),
                         unique=True,
                         nullable=False)
    reserved_cpu = sa.Column(sa.Integer, nullable=False)
    reserved_memory_mb = sa.Column(sa.Integer, nullable=False)
    cpu_ratio = sa.Column(sa.Float, nullable=False)
    memory_ratio = sa.Column(sa.Float, nullable=False)

    agent = orm.relationship(Agent, uselist=False,
                             backref=orm.backref('resource_provider',
                                                 uselist=False,
                                                 cascade='delete'))


class ResourceAllocation(base_models.Base, base_models.IdMixin,
                         models.TimestampMixin):

    __tablename__ = "resource_allocation"

    consumer_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                            index=True,
                            nullable=False)
    resource_provider_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE),
                                     sa.ForeignKey('resource_provider.id',
                                                   ondelete='CASCADE'),
                                     index=True,
                                     nullable=False)
    resource_class_id = sa.Column(sa.Integer, nullable=False)
    used = sa.Column(sa.Integer, nullable=False, default=0)

    resource_provider = orm.relationship(ResourceProvider, uselist=False,
                                         backref=orm.backref(
                                             'resource_allocations',
                                             uselist=True,
                                             cascade='delete'))
