#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from oslo_config import cfg

CONF = cfg.CONF


class PhysicalRepository(object):

    def __init__(self):
        # self.physical_objs = [
        #     {
        #         'name': 'phy1',
        #         'vlan_ranges': [
        #             {'min': 2, 'max': 20},
        #             {'min': 100, 'max': 200}]
        #     }
        # ]
        self.physical_objs = self._init_pyhsical_objects()

    def _init_pyhsical_objects(self):
        # TODO(yangjianfeng) Add some check codes, check whether the config
        # value is valid
        physical_objs = []
        for flat_physical in CONF.network_settings.support_flat_physicals:
            physical_objs.append(
                {'name': flat_physical,
                 'support_flat': True,
                 'vlan_ranges': []})

        for vlan_range in CONF.network_settings.physical_vlan_ranges:
            name = vlan_range.split(':')[0]
            vlan_range = {'min': int(vlan_range.split(':')[1]),
                          'max': int(vlan_range.split(':')[2])}
            for physical in physical_objs:
                if physical['name'] == name:
                    physical['vlan_ranges'].append(vlan_range)
                    break
            else:
                phy_dict = {'name': name, 'vlan_ranges': [vlan_range],
                            'support_flat': False}
                physical_objs.append(phy_dict)
        return physical_objs

    def get_one(self, physical_name):
        for phy_obj in self.physical_objs:
            if physical_name == phy_obj['name']:
                return phy_obj
        return None

    def get_all(self):
        return self.physical_objs

    def allocate_vlan_id(self, physical, exclude_vlans=None):
        if not exclude_vlans:
            exclude_vlans = []
        vlan_ranges = self.get_one(physical)['vlan_ranges']
        for vlan_range in vlan_ranges:
            for vlan_id in range(vlan_range['min'], vlan_range['max']):
                if vlan_id not in exclude_vlans:
                    return vlan_id
        return None

    def verify_vlan_id(self, physical, vlan_id):
        vlan_ranges = self.get_one(physical)['vlan_ranges']
        for vlan_range in vlan_ranges:
            if vlan_range['min'] <= vlan_id <= vlan_range['max']:
                return True
        return False
