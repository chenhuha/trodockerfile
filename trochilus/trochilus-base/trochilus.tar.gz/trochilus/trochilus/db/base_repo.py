# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
from trochilus.common import constants


class BaseRepository(object):
    model_class = None

    def count(self, session, **filters):
        """Retrieves a count of entities from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entities should be retrieved.
        :returns: int
        """
        return session.query(self.model_class).filter_by(**filters).count()

    def create(self, session, **model_kwargs):
        """Base create method for a database entity.

        :param session: A Sql Alchemy database session.
        :param model_kwargs: Attributes of the model to insert.
        :returns: trochilus.db.base_models.TrochilusBase
        """
        with session.begin(subtransactions=True):
            model = self.model_class(**model_kwargs)
            session.add(model)
        return model

    def create_batch(self, session, models_list: list):
        """Batch create method for multiple database entities.

        :param session: A Sql Alchemy database session.
        :param models_list: List of the model to insert.
        :returns: [trochilus.db.base_models.TrochilusBase]
        """
        models = [self.model_class(**m) for m in models_list]
        with session.begin(subtransactions=True):
            session.add_all(models)
        return models

    def delete(self, session, **filters):
        """Deletes an entity from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entity should be deleted.
        :returns: None
        :raises: sqlalchemy.orm.exc.NoResultFound
        """
        model = session.query(self.model_class).filter_by(**filters).one()
        with session.begin(subtransactions=True):
            session.delete(model)
            session.flush()

    def delete_batch(self, session, ids=None):
        """Batch deletes by entity ids."""
        ids = ids or []
        for id in ids:
            self.delete(session, id=id)

    def update(self, session, id, **model_kwargs):
        """Updates an entity in the database.

        :param session: A Sql Alchemy database session.
        :param model_kwargs: Entity attributes that should be updates.
        :returns: trochilus.db.base_models.TrochilusBase
        """
        with session.begin(subtransactions=True):
            session.query(self.model_class).filter_by(
                id=id).update(model_kwargs)

    def get(self, session, **filters):
        """Retrieves an entity from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entity should be retrieved.
        :returns: trochilus.db.base_models.TrochilusBase
        """
        query = session.query(self.model_class)
        if hasattr(self.model_class, 'status'):
            query = query.filter(self.model_class.status != constants.DELETED)
        return query.filter_by(**filters).first()

    def get_all(self, session, pagination_helper=None, **filters):
        """Retrieves a list of entities from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entities should be retrieved.
        :returns: [trochilus.db.base_models.TrochilusBase]
        """
        query = session.query(self.model_class)
        if hasattr(self.model_class, 'status'):
            query = query.filter(self.model_class.status != constants.DELETED)
        query = query.filter_by(**filters)

        if pagination_helper:
            model_list, links = pagination_helper.apply(
                query, self.model_class)
        else:
            links = None
            model_list = query.all()

        return model_list, links

    def exists(self, session, id):
        """Determines whether an entity exists in the database by its id.

        :param session: A Sql Alchemy database session.
        :param id: id of entity to check for existence.
        :returns: trochilus.db.base_models.TrochilusBase
        """
        return bool(session.query(self.model_class).filter_by(id=id).first())


def update_relation_for_delete(lock_session,
                               db_repo,
                               deleted_obj):
    """Support update relation for snapshot or snapshotgroup delete"""
    modify_current = False
    if deleted_obj.current:
        modify_current = True

    # Get all previous
    previous_objs, _ = db_repo.get_all(
        lock_session, previous=deleted_obj.id)

    is_end = not bool(previous_objs)
    is_head = not bool(deleted_obj.previous)

    if is_head and is_end:
        # It means this obj have no previous and next.
        # We do nothing
        pass
    elif is_head:
        # It means this obj is head and have next or multiple next.
        for previous_obj in previous_objs:
            db_repo.update(
                lock_session, previous_obj.id, **{"previous": None})
    elif is_end:
        # It means this obj is end.
        if modify_current:
            db_repo.update(
                lock_session, deleted_obj.previous, **{"current": True})
    else:
        # If not head nor end.
        for previous_obj in previous_objs:
            db_repo.update(
                lock_session, previous_obj.id,
                **{"previous": deleted_obj.previous})
        if modify_current:
            db_repo.update(
                lock_session, deleted_obj.previous, **{"current": True})
