# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import datetime
import re

from oslo_db.sqlalchemy import models
from oslo_utils import uuidutils
import sqlalchemy as sa
from sqlalchemy.ext import declarative

from trochilus.db import constants


class TrochilusBase(models.ModelBase):
    """Base class for Trochilus Models."""

    @classmethod
    def _name(cls):
        """Returns class name in a more human readable form."""
        # Split the class name up by capitalized words
        return ' '.join(re.findall('[A-Z][^A-Z]*', cls.__name__))

    def to_dict(self, calling_classes=None, recurse=False, **kwargs):
        """Converts a database model to a dictionary."""
        calling_classes = calling_classes or []
        ret = {}
        for attr, value in self.__dict__.items():
            if attr.startswith('_') or not kwargs.get(attr, True):
                continue
            if attr == 'tags':
                # tags is a list, it doesn't need recurse
                ret[attr] = value
                continue
            if attr == 'role':
                # role is a list, it doesn't need recurse
                ret[attr] = value
                continue
            if attr == 'net_pci_info':
                # net_pci_info is a list, it doesn't need recurse
                ret[attr] = value
                continue
            if isinstance(value, datetime.datetime):
                ret[attr] = value
                continue
            if isinstance(value, bytes):
                ret[attr] = value.decode()
                continue
            if recurse:
                if isinstance(getattr(self, attr), list):
                    ret[attr] = []
                    for item in value:
                        if isinstance(item, TrochilusBase):
                            if type(self) not in calling_classes:
                                ret[attr].append(
                                    item.to_dict(calling_classes=(
                                        calling_classes + [type(self)]),
                                        recurse=recurse))
                            else:
                                # TODO(rm_work): Is the idea that if this list
                                # contains ANY TrochilusBase, that all of them
                                # are database models, and we may as well quit?
                                # Or, were we supposed to append a `None` for
                                # each one? I assume the former?
                                ret[attr] = None
                                break
                        else:
                            ret[attr].append(item)
                elif isinstance(getattr(self, attr), TrochilusBase):
                    if type(self) not in calling_classes:
                        ret[attr] = value.to_dict(
                            calling_classes=calling_classes + [type(self)],
                            recurse=recurse)
                    else:
                        ret[attr] = None
                else:
                    ret[attr] = value
            else:
                if isinstance(getattr(self, attr), TrochilusBase):
                    ret[attr] = None
                elif isinstance(getattr(self, attr), list):
                    ret[attr] = []
                else:
                    ret[attr] = value

        return ret

    def __iter__(self):
        self._i = iter(sa.orm.object_mapper(self).columns)
        return self

    def next(self):
        n = next(self._i).name
        return n, getattr(self, n)

    __next__ = next

    def __repr__(self):
        """sqlalchemy based automatic __repr__ method."""
        items = ['%s=%r' % (col.name, getattr(self, col.name))
                 for col in self.__table__.columns]
        return "<%s.%s[object at %x] {%s}>" % (self.__class__.__module__,
                                               self.__class__.__name__,
                                               id(self), ', '.join(items))


Base = declarative.declarative_base(cls=TrochilusBase)


class DescriptionMixin(object):
    """Mixin to add to classes that have a description."""
    description = sa.Column(sa.String(
        constants.DESCRIPTION_FIELD_SIZE), nullable=True)


class IdMixin(object):
    """Id mixin, add to subclasses that have an id."""
    id = sa.Column(sa.String(constants.UUID_FIELD_SIZE), primary_key=True,
                   default=uuidutils.generate_uuid)


class ProjectMixin(object):
    """Tenant mixin, add to subclasses that have a project."""
    project_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE))


class UserMixin(object):
    """User mixin, add to subclasses that have a user."""
    user_id = sa.Column(sa.String(constants.UUID_FIELD_SIZE))


class NameMixin(object):
    """Name mixin to add to classes which need a name."""
    name = sa.Column(sa.String(constants.NAME_FIELD_SIZE), nullable=True)
