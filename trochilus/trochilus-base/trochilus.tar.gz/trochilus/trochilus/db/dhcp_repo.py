# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import random

from oslo_log import log as logging
from trochilus.agent.agent_client import agent_rest_driver
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import base_repo
from trochilus.db import models
from trochilus.db import nic_repo
from trochilus.db import subnet_repo
from trochilus.db import vpc_repo

LOG = logging.getLogger(__name__)


class DhcpNodeMappingRepository(base_repo.BaseRepository):

    model_class = models.DhcpNodeMapping

    def __init__(self):
        self.vpc_repo = vpc_repo.VpcRepository()
        self.subnet_repo = subnet_repo.SubnetRepository()
        self.nic_repo = nic_repo.NicRepository()
        self.ip_alloc_repo = nic_repo.AddressAllocRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()

    def get_all(self, session, pagination_helper=None, lock=False, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        if lock:
            query = query.with_for_update()
        if pagination_helper:
            model_list, links = pagination_helper.apply(
                query, self.model_class)
        else:
            links = None
            model_list = query.all()

        return model_list, links

    def need_to_handle_dhcp(self, session, enable_dhcp, subnet):
        create_dhcp_nics = False
        delete_dhcp_nics = False
        add_dhcp_ips = False
        delete_dhcp_ips = False
        if enable_dhcp is not None:
            if enable_dhcp:
                create_dhcp_nics, existing_dhcp_subnet = \
                    self._need_to_create_dhcp_nic(session, subnet)
                add_dhcp_ips = existing_dhcp_subnet or (not create_dhcp_nics)
            else:
                delete_dhcp_nics = self._need_to_delete_dhcp_nic(session,
                                                                 subnet)
                delete_dhcp_ips = not delete_dhcp_nics
        return (create_dhcp_nics, delete_dhcp_nics,
                add_dhcp_ips, delete_dhcp_ips)

    def _need_to_create_dhcp_nic(self, session, subnet):
        # Exist other subnet of this vpc that enables dhcp
        existing_dhcp_subnet = False
        db_subnets, _ = self.subnet_repo.get_all(session, vpc_id=subnet.vpc_id)
        if not db_subnets:
            return False, existing_dhcp_subnet
        for db_subnet in db_subnets:
            if db_subnet.enable_dhcp and db_subnet.id != subnet.id:
                existing_dhcp_subnet = True
                # Get dhcp nics of this vpc
                dhcp_nics, _ = self.nic_repo.get_all(
                    session, vpc_id=subnet.vpc_id,
                    owner_type=constants.NIC_OF_DHCP)
                if not dhcp_nics:
                    # This case maybe happen, all available ip of ip pool of
                    # subnet are used by vm nic and no available ip to create
                    # dhcp nic
                    return True, existing_dhcp_subnet
                # This case maybe happen, most available ip of ip pool of
                # subnet are used by vm nic and no enough available ip to
                # create a few dhcp nics. Or cidr of subnet is small, for
                # example, 192.168.0.0/30, the available ip of pool is
                # 192.168.0.2-192.168.0.2， just one available ip can be
                # used to create dhcp nic
                if len(dhcp_nics) < \
                        self.get_expected_dhcp_agents_num(session):
                    return True, existing_dhcp_subnet
                return False, existing_dhcp_subnet
        # First subnet enables dhcp
        return True, existing_dhcp_subnet

    def _need_to_delete_dhcp_nic(self, session, subnet):
        db_subnets, _ = self.subnet_repo.get_all(session, vpc_id=subnet.vpc_id)
        if not db_subnets:
            return True
        for db_subnet in db_subnets:
            if db_subnet.enable_dhcp and db_subnet.id != subnet.id:
                return False
        # Last subnet disables dhcp
        return True

    def notify_dhcp_agent_for_vm(self, vm_id, create_vm=False,
                                 delete_vm=False):
        session = db_api.get_session()
        nics, _ = self.nic_repo.get_all(session, owner_id=vm_id,
                                        owner_type=constants.NIC_OF_VDI_VM)
        if nics and (create_vm or delete_vm):
            self.notify_dhcp_agent_if_need(constants.UPDATE_NIC,
                                           nics[0].vpc_id,
                                           nics=nics,
                                           add_dhcp_ips=create_vm,
                                           delete_dhcp_ips=delete_vm)

    def notify_dhcp_agent_if_need(self, action, vpc_id, nics=None,
                                  create_dhcp_nics=False,
                                  delete_dhcp_nics=False,
                                  add_dhcp_ips=False,
                                  delete_dhcp_ips=False,
                                  update_dhcp_dns=False):
        session = db_api.get_session()
        if create_dhcp_nics:
            # Now dhcp process is stopped, start dhcp process
            # Notify agents to start dhcp process
            dhcp_nics, _ = self.nic_repo.get_all(
                session, vpc_id=vpc_id, owner_type=constants.NIC_OF_DHCP)
            agents = [dhcp_nic.agent for dhcp_nic in dhcp_nics]
            for agent in agents:
                self.agent_client.create_dhcp(
                    agent, **{'vpc_id': vpc_id, 'action': action})
        elif delete_dhcp_nics:
            # Now dhcp process is running, stop dhcp process
            # Notify agents to stop dhcp process and delete dhcp nic
            agents = self._get_all_dhcp_agents(session)
            if agents:
                for agent in agents:
                    self.agent_client.delete_dhcp(
                        agent, **{'vpc_id': vpc_id, 'action': action})
        elif add_dhcp_ips or delete_dhcp_ips or update_dhcp_dns:
            # Dhcp process is running, just update dhcp config file
            if action in constants.DHCP_FOR_NIC and nics:
                # Get subnets with enable dhcp
                subnets = self._get_subnets_with_dhcp(session, vpc_id)
                if not subnets:
                    return
                subnet_ids = [subnet.id for subnet in subnets]
                for nic in nics:
                    for alloc in nic.ip_addresses:
                        if alloc.subnet_id in subnet_ids:
                            # Dhcp process is running, just
                            # update dhcp config file
                            agents = self._get_all_dhcp_agents(session)
                            if agents:
                                for agent in agents:
                                    self.agent_client.update_dhcp(
                                        agent, **{'vpc_id': vpc_id,
                                                  'nic_id': nic.id,
                                                  'action': action})
                            break
            else:
                agents = self._get_all_dhcp_agents(session)
                if agents:
                    for agent in agents:
                        self.agent_client.update_dhcp(
                            agent, **{'vpc_id': vpc_id, 'action': action})

    def _get_subnets_with_dhcp(self, session, vpc_id):
        db_vpc = self.vpc_repo.get(session, id=vpc_id)
        return [db_subnet for db_subnet in db_vpc.subnets
                if db_subnet.enable_dhcp]

    def _get_all_dhcp_agents(self, session):
        dhcp_node_mappings, _ = self.get_all(session)
        return [mapping.agent for mapping in dhcp_node_mappings
                if mapping.agent.status == constants.AGENT_UP]

    def _get_candidate_dhcp_agents(self, session):
        agents, _ = self.agent_repo.get_all(session)
        return agents

    def create_dhcp_nics(self, lock_session, subnet):
        # Get dhcp node mapping
        dhcp_node_mappings, _ = self.get_all(lock_session)
        if dhcp_node_mappings:
            # It has been decided to which agent enables dhcp
            agents = [mapping.agent for mapping in dhcp_node_mappings]
            # If an agent has dhcp nic of this vpc， not create dhcp nic
            dhcp_nics, _ = self.nic_repo.get_all(
                lock_session, vpc_id=subnet.vpc_id,
                owner_type=constants.NIC_OF_DHCP)
            if dhcp_nics:
                hostnames = set(dhcp_nic.hostname for dhcp_nic in dhcp_nics)
                agents = [agent for agent in agents
                          if agent.hostname not in hostnames]
        else:
            # Choose agents to create dhcp nic
            candidate_agents = self._get_candidate_dhcp_agents(lock_session)
            expected_num = self.get_expected_dhcp_agents_num(lock_session)
            if expected_num >= len(candidate_agents):
                agents = candidate_agents
            else:
                random_indexs = random.sample(range(0, len(candidate_agents)),
                                              expected_num)
                agents = [candidate_agents[index] for index in random_indexs]
        # Create dhcp nics
        dhcp_nic_ids = []
        for agent in agents:
            param_for_create = {'auto_delete': False,
                                'ip_addresses': [{'subnet_id': subnet.id}],
                                'status': constants.DOWN,
                                'owner_type': constants.NIC_OF_DHCP,
                                'hostname': agent.hostname}
            try:
                dhcp_nic_id = self.nic_repo.do_create_nic(
                    lock_session, [subnet], param_for_create)
                dhcp_nic_ids.append(dhcp_nic_id)
            except exceptions.IpExhausted:
                # If the subnet cidr has few available IPs, such as
                # 192.168.1.0/30, the subnet IP pool is 192.168.1.2 to
                # 192.168.1.2. The ip of the dhcp nic uses the ip of pool.
                # It is possible to create an unexpected number of nics.
                LOG.warn('The available ip in the subnet %s assigned to '
                         'all dhcp nics is not enough', subnet.id)
                break
        return dhcp_nic_ids

    def delete_dhcp_nics(self, lock_session, vpc_id):
        self.nic_repo.delete_batch(lock_session,
                                   vpc_id=vpc_id,
                                   owner_type=constants.NIC_OF_DHCP)

    def add_dhcp_ips(self, lock_session, subnet):
        dhcp_nics, _ = self.nic_repo.get_all(
            lock_session, vpc_id=subnet.vpc_id,
            owner_type=constants.NIC_OF_DHCP)
        if not dhcp_nics:
            return

        # If dhcp nic has ip of this subnet, do not add dhcp ip of this subnet
        eligible_dhcp_nics = []
        for dhcp_nic in dhcp_nics:
            for alloc in dhcp_nic.ip_addresses:
                if alloc.subnet_id == subnet.id:
                    break
            else:
                eligible_dhcp_nics.append(dhcp_nic)
        if not eligible_dhcp_nics:
            return

        # Generate ips according to the amount of dhcp nic
        ip_allocs, _ = self.ip_alloc_repo.get_all(lock_session,
                                                  lock=True,
                                                  subnet_id=subnet.id)
        existing_ips = [ip_alloc.ip_address for ip_alloc in ip_allocs]
        generated_ips = []
        expect_ip_num = len(eligible_dhcp_nics)
        for i in range(expect_ip_num):
            try:
                generated_ips = self.nic_repo.generate_ips(
                    existing_ips, subnet, ip_count=expect_ip_num - i)
                break
            except exceptions.IpExhausted:
                # If the subnet cidr has few available IPs, such as
                # 192.168.1.0/30, the subnet IP pool is 192.168.1.2 to
                # 192.168.1.2. The ip of the dhcp nic uses the ip of
                # pool. It is possible to add dhcp ip to an unexpected
                # number of nics.
                LOG.warn('add_dhcp_ips method can not generate %s ip, expected'
                         'ip num: %s for dhcp nic %s', expect_ip_num - i,
                         expect_ip_num, [dhcp_nic.id for dhcp_nic
                                         in eligible_dhcp_nics])
                if i == expect_ip_num - 1:
                    raise

        # Add ip to dhcp nic
        ip_allocs_for_create = [{'subnet_id': subnet.id,
                                 'ip_address': gen_ip,
                                 'nic_id': eligible_dhcp_nics[index].id}
                                for index, gen_ip
                                in enumerate(generated_ips)]
        self.ip_alloc_repo.create_batch(lock_session,
                                        ip_allocs_for_create)

    def delete_dhcp_ips(self, lock_session, vpc_id, subnet_id):
        # Get dhcp nics
        dhcp_nics, _ = self.nic_repo.get_all(lock_session,
                                             vpc_id=vpc_id,
                                             owner_type=constants.NIC_OF_DHCP)
        if not dhcp_nics:
            return
        # Get ips to Delete
        ip_allocs, _ = self.ip_alloc_repo.get_all(lock_session,
                                                  subnet_id=subnet_id,
                                                  nic_ids=[dhcp_nic.id
                                                           for dhcp_nic
                                                           in dhcp_nics])
        delete_keys = [(ip_alloc.ip_address,
                        ip_alloc.subnet_id)
                       for ip_alloc in ip_allocs]
        self.ip_alloc_repo.delete_batch(lock_session, delete_keys)

    def add_dhcp_agent_info(self, hostname):
        with db_api.get_lock_session() as lock_session:
            dhcp_node_mappings, _ = self.get_all(lock_session, lock=True)
            expected_num = self.get_expected_dhcp_agents_num(lock_session)
            if len(dhcp_node_mappings) >= expected_num:
                return None
            # Insert dhcp node mapping
            existing_indexes = set(mapping.index for mapping
                                   in dhcp_node_mappings)
            for index in range(expected_num):
                if index not in existing_indexes:
                    self.create(lock_session, hostname=hostname,
                                index=index)
                    break
            # Create dhcp nic
            vpcs, _ = self.vpc_repo.get_all(lock_session)
            create_dhcp_nic_ids = []
            for vpc in vpcs:
                subnets = []
                subnet_id_dict = []
                for subnet in vpc.subnets:
                    if subnet.enable_dhcp:
                        subnets.append(subnet)
                        subnet_id_dict.append({'subnet_id': subnet.id})
                if subnets:
                    param_for_create_nic = {
                        'auto_delete': False,
                        'ip_addresses': subnet_id_dict,
                        'status': constants.DOWN,
                        'owner_type': constants.NIC_OF_DHCP,
                        'hostname': hostname}
                    dhcp_nic_id = self.nic_repo.do_create_nic(
                        lock_session, subnets, param_for_create_nic)
                    if dhcp_nic_id:
                        create_dhcp_nic_ids.append(dhcp_nic_id)
            return create_dhcp_nic_ids
        return None

    def delete_dhcp_agent_infos(self, invalid_hostnames):
        with db_api.get_lock_session() as lock_session:
            for hostname in invalid_hostnames:
                # Delete dhcp node mapping
                self.delete(lock_session, hostname=hostname)
                # Delete dhcp nics
                self.nic_repo.delete_batch(lock_session,
                                           hostname=hostname,
                                           owner_type=constants.NIC_OF_DHCP)

    def get_expected_dhcp_agents_num(self, session):
        available_agents, _ = self.agent_repo.get_all(session)
        return 3 if len(available_agents) >= 3 else len(available_agents)
