#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from alembic import op
import sqlalchemy as sa

from trochilus.db import constants

"""initial

Revision ID: 688df6c818c1
Revises: None
Create Date: 2021-12-09 13:17:46.683504

"""

# revision identifiers, used by Alembic.
revision = '688df6c818c1'
down_revision = None


def upgrade():
    op.create_table(
        'agent',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'hostname',
            sa.String(constants.HOSTNAME_FIELD_SIZE), nullable=False),
        sa.Column(
            'status', sa.String(constants.STATUS_FIELD_SIZE), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('hostname'),
    )
    op.create_table(
        'image',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'name', sa.String(constants.NAME_FIELD_SIZE), nullable=True),
        sa.Column(
            'checksum', sa.String(255), nullable=True),
        sa.Column(
            'format', sa.String(16), nullable=True),
        sa.Column(
            'project_id', sa.String(constants.PROJECT_ID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'user_id', sa.String(constants.USER_ID_FELD_SIZE),
            nullable=True),
        sa.Column(
            'status', sa.String(constants.STATUS_FIELD_SIZE), nullable=True),
        sa.Column(
            'created_at', sa.DateTime(), nullable=True),
        sa.Column(
            'updated_at', sa.DateTime(), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_table(
        'flavor',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'project_id', sa.String(constants.PROJECT_ID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'user_id', sa.String(constants.USER_ID_FELD_SIZE),
            nullable=True),
        sa.Column(
            'name', sa.String(constants.NAME_FIELD_SIZE), nullable=True),
        sa.Column(
            'vcpu', sa.Integer(), nullable=False),
        sa.Column(
            'mem', sa.Integer(), nullable=False),
        sa.Column(
            'disk', sa.Integer(), nullable=False),
        sa.Column(
            'created_at', sa.DateTime(), nullable=True),
        sa.Column(
            'updated_at', sa.DateTime(), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_table(
        'virtual_machine',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'name', sa.String(constants.NAME_FIELD_SIZE), nullable=True),
        sa.Column(
            'project_id', sa.String(constants.PROJECT_ID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'user_id', sa.String(constants.USER_ID_FELD_SIZE),
            nullable=True),
        sa.Column(
            'agent_id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'flavor_id', sa.String(constants.UUID_FIELD_SIZE),
            nullable=False),
        sa.Column(
            'image_id', sa.String(constants.UUID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'created_at', sa.DateTime(), nullable=True),
        sa.Column(
            'updated_at', sa.DateTime(), nullable=True),
        sa.Column(
            'status', sa.String(constants.STATUS_FIELD_SIZE), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['agent_id'], ['agent.id']),
        sa.ForeignKeyConstraint(['image_id'], ['image.id']),
        sa.ForeignKeyConstraint(['flavor_id'], ['flavor.id']),
    )
    op.create_table(
        'vpc',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'name', sa.String(constants.NAME_FIELD_SIZE), nullable=True),
        sa.Column(
            'project_id', sa.String(constants.PROJECT_ID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'user_id', sa.String(constants.USER_ID_FELD_SIZE),
            nullable=True),
        sa.Column('type', sa.String(16), nullable=False),
        sa.Column(
            'vlan_id', sa.Integer(), nullable=True),
        sa.Column(
            'created_at', sa.DateTime(), nullable=True),
        sa.Column(
            'updated_at', sa.DateTime(), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_table(
        'subnet',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'name', sa.String(constants.NAME_FIELD_SIZE), nullable=True),
        sa.Column(
            'project_id', sa.String(constants.PROJECT_ID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'user_id', sa.String(constants.USER_ID_FELD_SIZE),
            nullable=True),
        sa.Column(
            'vpc_id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'ip_version', sa.Integer(), server_default='4', nullable=False),
        sa.Column(
            'cidr', sa.String(constants.IP_ADDR_FIELD_SIZE), nullable=False),
        sa.Column(
            'gateway', sa.String(constants.IP_ADDR_FIELD_SIZE), nullable=True),
        sa.Column(
            'created_at', sa.DateTime(), nullable=True),
        sa.Column(
            'updated_at', sa.DateTime(), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['vpc_id'], ['vpc.id'])
    )
    op.create_table(
        'nic',
        sa.Column(
            'id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'name', sa.String(constants.NAME_FIELD_SIZE), nullable=True),
        sa.Column(
            'project_id', sa.String(constants.PROJECT_ID_FIELD_SIZE),
            nullable=True),
        sa.Column(
            'user_id', sa.String(constants.USER_ID_FELD_SIZE),
            nullable=True),
        sa.Column(
            'vpc_id', sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'mac_address',
            sa.String(constants.MAC_ADDR_FIELD_SIZE), nullable=False),
        sa.Column(
            'created_at', sa.DateTime(), nullable=True),
        sa.Column(
            'updated_at', sa.DateTime(), nullable=True),
        sa.Column(
            'description', sa.String(constants.DESCRIPTION_FIELD_SIZE),
            nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['vpc_id'], ['vpc.id'])
    )
    op.create_table(
        'address_allocation',
        sa.Column(
            'nic_id',
            sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'subnet_id',
            sa.String(constants.UUID_FIELD_SIZE), nullable=False),
        sa.Column(
            'ip_address',
            sa.String(constants.IP_ADDR_FIELD_SIZE), nullable=False),
        sa.PrimaryKeyConstraint('subnet_id', 'ip_address'),
        sa.ForeignKeyConstraint(['nic_id'], ['nic.id']),
        sa.ForeignKeyConstraint(['subnet_id'], ['subnet.id']),
    )
