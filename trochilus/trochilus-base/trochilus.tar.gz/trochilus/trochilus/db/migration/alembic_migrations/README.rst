The migrations in the alembic/versions contain the migrations.

Before running this migration ensure that the database trochilus exists.

To run migrations you must first be in the trochilus/db/migration directory.

To migrate to the most current version run:
$ trochilus-db-manage upgrade head
