#  Copyright 2021 Troila
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.

from alembic import op
import sqlalchemy as sa

from trochilus.db import constants

"""extent agent db

Revision ID: b3d81b45cca4
Revises: 688df6c818c1
Create Date: 2021-12-21 14:21:45.421712

"""

# revision identifiers, used by Alembic.
revision = 'b3d81b45cca4'
down_revision = '688df6c818c1'


def upgrade():
    op.add_column(
        'agent', sa.Column('heartbeat_timestamp',
                           sa.DateTime(), nullable=True))
    op.add_column(
        'agent', sa.Column('mgmt_ip', sa.String(constants.IP_ADDR_FIELD_SIZE),
                           nullable=False))
    op.add_column(
        'agent', sa.Column('api_version', sa.String(8), nullable=False))
