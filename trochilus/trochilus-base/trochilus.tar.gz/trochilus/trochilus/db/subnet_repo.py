# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import netaddr

from oslo_log import log as logging

from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import base_repo
from trochilus.db import models


LOG = logging.getLogger(__name__)


class SubnetRepository(base_repo.BaseRepository):

    model_class = models.Subnet

    def get_all(self, session, pagination_helper=None, ids=None, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        if ids:
            query = query.filter(self.model_class.id.in_(ids))

        if pagination_helper:
            model_list, links = pagination_helper.apply(
                query, self.model_class)
        else:
            links = None
            model_list = query.all()

        return model_list, links

    def validate_ip_invalid_in_subnet(self, addr, cidr, name):
        """Validate whether the ip is invalid on the subnet."""
        net = netaddr.IPNetwork(cidr)
        # If IP not in the cidr valid range of subnet,
        # or if IP is Broadcast address or the Network address,
        # both throws an exceptions.
        if (addr not in net or addr in (net.network, net[-1])):
            raise exceptions.IPaddressNotInCidr(name=name,
                                                addr=addr,
                                                cidr=cidr)

    def validate_ip_version(self, addr, ip_version, name):
        """Check IP filed of a subnet match specified ip version."""
        if addr.version != ip_version:
            raise exceptions.IPVersionConflict(name=name,
                                               addr=addr,
                                               ip_version=ip_version)

    def validate_cidr(self, cur_subnet, existing_subnets):
        """Validate whether the param of a cidr is invalid."""
        # Validate cidr format
        try:
            # Rectify the CIDR format
            new_cidr = netaddr.IPNetwork(cur_subnet['cidr']).cidr
        except Exception as e:
            raise exceptions.InvalidAddressFormat(
                name='cidr', addr=cur_subnet['cidr']) from e

        # Validate the ip version of cidr
        self.validate_ip_version(new_cidr, constants.IP_VERSION_4, 'cidr')

        new_cidr_prefixlen = netaddr.IPNetwork(new_cidr).prefixlen
        if new_cidr_prefixlen > constants.MAXIMUM_PREFIXLEN or \
                new_cidr_prefixlen < constants.MINIMUM_PREFIXLEN:
            raise exceptions.InvalidPrefixlen(
                prefixlen=new_cidr_prefixlen,
                maximum=constants.MAXIMUM_PREFIXLEN,
                minimum=constants.MINIMUM_PREFIXLEN)

        # Check the cidr of the same vpc to avoid overlapping
        if existing_subnets:
            for existing_subnet in existing_subnets:
                old_cidr = netaddr.IPNetwork(existing_subnet.get('cidr'))
                if new_cidr in old_cidr or old_cidr in new_cidr:
                    raise exceptions.CidrConflict(cidr=new_cidr,
                                                  vpc=cur_subnet['vpc_id'])
        return "%s" % new_cidr

    def allocate_gateway(self, cidr):
        """Allocate the gateway ip from the cidr in subnet."""
        # If not input the gateway ip address then use
        # the second ip address in the cidr ranges
        # as the default gateway ip
        return str(netaddr.IPNetwork(cidr).network + 1)

    def validate_address_pools(self, address_pools, cidr):
        """Validate whether the param of address_pools is invalid."""
        ip_range_pools = self._pools_to_ip_range(address_pools)

        subnet = netaddr.IPNetwork(cidr)
        if subnet.version == constants.IP_VERSION_4:
            if subnet.prefixlen <= 30:
                subnet_first_ip = netaddr.IPAddress(subnet.first + 1)
                # last address is broadcast in v4
                subnet_last_ip = netaddr.IPAddress(subnet.last - 1)
            else:
                subnet_first_ip = netaddr.IPAddress(subnet.first)
                subnet_last_ip = netaddr.IPAddress(subnet.last)
        else:  # IPv6 case
            subnet_first_ip = netaddr.IPAddress(subnet.first + 1)
            subnet_last_ip = netaddr.IPAddress(subnet.last)

        LOG.debug("Performing IP validity checks on allocation pools")
        ip_sets = []
        for ip_pool in ip_range_pools:
            start_ip = netaddr.IPAddress(ip_pool.first, ip_pool.version)
            end_ip = netaddr.IPAddress(ip_pool.last, ip_pool.version)
            if (start_ip.version != subnet.version or
                    end_ip.version != subnet.version):
                LOG.info("Specified IP addresses do not match "
                         "the subnet IP version")
                raise exceptions.InvalidAddressPool(pool=ip_pool)
            if start_ip < subnet_first_ip or end_ip > subnet_last_ip:
                LOG.info("Found pool larger than subnet "
                         "CIDR:%(start)s - %(end)s",
                         {'start': start_ip, 'end': end_ip})
                raise exceptions.OutOfBoundsAddressPool(
                    pool=ip_pool,
                    subnet_cidr=cidr)
            # Valid allocation pool
            # Create an IPSet for it for easily verifying overlaps
            ip_sets.append(netaddr.IPSet(ip_pool.cidrs()))

        LOG.debug("Checking for overlaps among allocation pools "
                  "and gateway ip")
        ip_ranges = ip_range_pools[:]

        # Use integer cursors as an efficient way for implementing
        # comparison and avoiding comparing the same pair twice
        for l_cursor in range(len(ip_sets)):
            for r_cursor in range(l_cursor + 1, len(ip_sets)):
                if ip_sets[l_cursor] & ip_sets[r_cursor]:
                    l_range = ip_ranges[l_cursor]
                    r_range = ip_ranges[r_cursor]
                    LOG.info("Found overlapping ranges: %(l_range)s and "
                             "%(r_range)s",
                             {'l_range': l_range, 'r_range': r_range})
                    raise exceptions.OverlappingAddressPools(
                        pool_1=l_range,
                        pool_2=r_range,
                        subnet_cidr=cidr)

    def validate_gw_out_of_pools(self, gateway_ip, address_pools):
        ip_range_pools = self._pools_to_ip_range(address_pools)
        for pool_range in ip_range_pools:
            if netaddr.IPAddress(gateway_ip) in pool_range:
                raise exceptions.GatewayConflictWithAddressPools(
                    pool=pool_range,
                    ip_address=gateway_ip)

    @staticmethod
    def _pools_to_ip_range(address_pools):
        ip_range_pools = []
        for ip_pool in address_pools:
            try:
                ip_range_pools.append(netaddr.IPRange(ip_pool['start_ip'],
                                                      ip_pool['end_ip']))
            except netaddr.AddrFormatError as e:
                LOG.info("Found invalid IP address in pool: "
                         "%(start)s - %(end)s:",
                         {'start': ip_pool['start_ip'],
                          'end': ip_pool['end_ip']})
                raise exceptions.InvalidAllocationPool(pool=ip_pool) from e
        return ip_range_pools

    @staticmethod
    def generate_pools(cidr, gateway_ip):
        """Create IP allocation pools for a specified subnet

        The Neutron API defines a subnet's allocation pools as a list of
        IPRange objects for defining the pool range.
        """
        # Auto allocate the pool around gateway_ip
        net = netaddr.IPNetwork(cidr)
        ip_version = net.version
        first = netaddr.IPAddress(net.first, ip_version)
        last = netaddr.IPAddress(net.last, ip_version)
        if first == last:
            # handle single address subnet case
            return [{'start_ip': first.format(),
                     'end_ip': last.format()}]
        if ip_version == constants.IP_VERSION_4:
            if net.prefixlen <= 30:
                first_ip = first + 1
                # last address is broadcast in v4
                last_ip = last - (ip_version == 4)
            else:
                first_ip = first
                last_ip = last
        else:  # IPv6 case
            first_ip = first + 1
            last_ip = last
        ipset = netaddr.IPSet(netaddr.IPRange(first_ip, last_ip))
        if gateway_ip:
            ipset.remove(netaddr.IPAddress(gateway_ip, ip_version))
        address_pools = []
        for ip_range in list(ipset.iter_ipranges()):
            address_pools.append({'start_ip': ip_range._start.format(),
                                  'end_ip': ip_range._end.format()})
        return address_pools

    @staticmethod
    def validate_dns(dns_nameservers):
        for dns_nameserver in dns_nameservers:
            if not netaddr.valid_ipv4(dns_nameserver):
                raise exceptions.InvalidRequest(
                    msg='dns_nameservers has invalid ip')


class AddressPoolRepository(base_repo.BaseRepository):

    model_class = models.AddressPool


class DnsNameServerRepository(base_repo.BaseRepository):

    model_class = models.DnsNameServer

    def delete_batch(self, session, subnet_id):
        query = session.query(self.model_class).filter(
            self.model_class.subnet_id == subnet_id)
        with session.begin(subtransactions=True):
            query.delete()
