# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import random

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import timeutils

from trochilus.common import constants
from trochilus.db import api as db_api
from trochilus.db import base_repo
from trochilus.db import models

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class AgentRepository(base_repo.BaseRepository):

    model_class = models.Agent

    def _assert_agent_status(self, agent_obj):
        if agent_obj.status == constants.AGENT_DOWN:
            return agent_obj
        time_server_now = timeutils.utcnow()
        diff = abs(timeutils.delta_seconds(
            time_server_now, agent_obj.heartbeat_timestamp))
        threshold = CONF.api_settings.agent_down_time
        if diff > threshold:
            with db_api.get_lock_session() as lock_session:
                LOG.debug("The agent %(agent_id)s's heartbeat timestamp "
                          "interval more than %(threshold)s, set the agent's "
                          "status to DOWN.", {'agent_id': agent_obj.id,
                                              'threshold': threshold})
                self.update(lock_session, agent_obj.id,
                            **{'status': constants.AGENT_DOWN})
            agent_obj.update({'status': constants.AGENT_DOWN})
        return agent_obj

    def get(self, session, **filters):
        """Retrieves an entity from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entity should be retrieved.
        :returns: trochilus.db.models.Agent
        """
        agent_obj = session.query(self.model_class).filter_by(
            **filters).first()
        if not agent_obj:
            return agent_obj
        return self._assert_agent_status(agent_obj)

    def get_all(self, session, pagination_helper=None, **filters):
        """Retrieves a list of entities from the database.

        :param session: A Sql Alchemy database session.
        :param filters: Filters to decide which entities should be retrieved.
        :returns: [trochilus.db.models.Agent]
        """
        exclude_agents = filters.pop('exclude_agents', None)
        agent_objs = session.query(self.model_class).filter_by(**filters)
        if not agent_objs:
            return agent_objs, None

        if exclude_agents:
            agent_objs = agent_objs.filter(
                self.model_class.hostname.notin_(exclude_agents))

        if pagination_helper:
            model_list, links = pagination_helper.apply(
                agent_objs, self.model_class)
        else:
            links = None
            model_list = agent_objs.all()

        return [self._assert_agent_status(agent_obj)
                for agent_obj in model_list], links

    def get_agent_by_hostname(self, session, hostname):
        return self.get(session, hostname=hostname)

    def is_agent_up(self, agent):
        return agent.status == constants.AGENT_UP

    def get_agent_randomly(self, session):
        agent_all = self.get_all(session,
                                 status=constants.AGENT_UP)[0]
        agent = None
        if agent_all:
            agent = random.choice(agent_all)

        return agent
