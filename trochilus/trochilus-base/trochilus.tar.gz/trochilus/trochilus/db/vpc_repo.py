# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from trochilus.common import constants
from trochilus.db import base_repo
from trochilus.db import models


class VpcRepository(base_repo.BaseRepository):

    model_class = models.Vpc

    def get_all(self, session, pagination_helper=None, ids=None, **filters):
        query = session.query(self.model_class).filter(
            models.Vpc.status != constants.DELETED).filter_by(**filters)
        if ids:
            query = query.filter(self.model_class.id.in_(ids))
        if pagination_helper:
            vpcs, vpc_links = pagination_helper.apply(
                query, self.model_class)
        else:
            vpcs = query.all()
            vpc_links = None
        return vpcs, vpc_links

    def update(self, session, id, expected_status=None, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expected_status:
                query = query.filter_by(status=expected_status)
            return query.update(model_kwargs)


class VpcNodeMappingRepository(base_repo.BaseRepository):

    model_class = models.VpcNodeMapping

    def update(self, session, vpc_id, agent_id, **model_kwargs):
        with session.begin(subtransactions=True):
            param_dict = {}
            if vpc_id:
                param_dict['vpc_id'] = vpc_id
            if agent_id:
                param_dict['agent_id'] = agent_id
            session.query(self.model_class).filter_by(
                **param_dict).update(model_kwargs)

    def delete(self, session, **filters):
        model = session.query(self.model_class).filter_by(**filters).first()
        if model:
            with session.begin(subtransactions=True):
                session.delete(model)
                session.flush()
