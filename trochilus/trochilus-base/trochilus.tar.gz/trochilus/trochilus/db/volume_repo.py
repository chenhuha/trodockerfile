# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from trochilus.db import base_repo
from trochilus.db import models


class VolumeRepository(base_repo.BaseRepository):

    model_class = models.Volume

    def create(self, session, **model_kwargs):
        if model_kwargs.get("image_id"):
            model_kwargs["bootable"] = True
        with session.begin(subtransactions=True):
            model = self.model_class(**model_kwargs)
            session.add(model)
        return model

    def update_vm_volume(self, session, id, expected_status, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expected_status:
                query = query.filter_by(status=expected_status)
            return query.update(model_kwargs)
