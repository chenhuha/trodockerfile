# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from oslo_log import log as logging
from trochilus.common import exceptions

from trochilus.common import constants
from trochilus.db import base_repo
from trochilus.db import models

LOG = logging.getLogger(__name__)


class ImageRepository(base_repo.BaseRepository):

    model_class = models.Image

    def get(self, session, id, **filters):
        """Retrieves an image from the database."""
        show_deleted = filters.pop('show_deleted', False)
        if not show_deleted:
            image = session.query(self.model_class).filter(
                self.model_class.status != constants.DELETED).filter_by(
                id=id, **filters).first()
        else:
            image = session.query(self.model_class).filter_by(
                id=id, **filters).first()
        if not image:
            LOG.debug('%(name)s %(id)s not found',
                      {'name': self.model_class._name(), 'id': id})
            raise exceptions.NotFound(
                resource=self.model_class._name(), id=id)
        return image
