# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from oslo_log import log as logging
from trochilus.common import exceptions

from trochilus.common import constants
from trochilus.db import base_repo
from trochilus.db import models

LOG = logging.getLogger(__name__)


class VirtualMachineRepository(base_repo.BaseRepository):

    model_class = models.VirtualMachine

    def get(self, session, id, **filters):
        """Retrieves an virtual_machine from the database."""
        vm = session.query(self.model_class).filter(
            self.model_class.status != constants.DELETED).filter_by(
            id=id, **filters).first()
        if not vm:
            LOG.debug('%(name)s %(id)s not found',
                      {'name': self.model_class._name(), 'id': id})
            raise exceptions.NotFound(
                resource=self.model_class._name(), id=id)
        return vm

    def update(self, session, id, expected_status=None, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expected_status:
                query = query.filter_by(status=expected_status)
            return query.update(model_kwargs)

    def get_all_ing_status_vms(self, session, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        query = query.filter(
            self.model_class.status.contains('ing'))
        return query.all()
