# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


import copy
import itertools
import random

import netaddr

from oslo_config import cfg
from oslo_db import exception as db_exceptions
from oslo_log import log as logging
from sqlalchemy import and_
from sqlalchemy import or_
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import api as db_api
from trochilus.db import base_repo
from trochilus.db import models
from trochilus.db import subnet_repo
from trochilus.db import vpc_repo


CONF = cfg.CONF
LOG = logging.getLogger(__name__)

MAX_WIN = 1000
MULTIPLIER = 100
MAX_WIN_MULTI = MAX_WIN * MULTIPLIER


class NicRepository(base_repo.BaseRepository):

    model_class = models.Nic

    def __init__(self):
        self.ip_alloc_repo = AddressAllocRepository()
        self.vpc_repo = vpc_repo.VpcRepository()
        self.subnet_repo = subnet_repo.SubnetRepository()

    def get_all(self, session, pagination_helper=None, ids=None,
                lock=False, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        if ids:
            query = query.filter(self.model_class.id.in_(ids))
        if lock:
            query = query.with_for_update()
        if pagination_helper:
            model_list, links = pagination_helper.apply(
                query, self.model_class)
        else:
            links = None
            model_list = query.all()

        return model_list, links

    def update(self, session, id, expect_owner_type=None,
               expected_status=None, **model_kwargs):
        with session.begin(subtransactions=True):
            query = session.query(self.model_class).filter_by(id=id)
            if expect_owner_type:
                query = query.filter_by(owner_type=expect_owner_type)
            if expected_status:
                query = query.filter_by(status=expected_status)
            return query.update(model_kwargs)

    def delete(self, session, **filters):
        model = session.query(self.model_class).filter_by(**filters).first()
        if model:
            with session.begin(subtransactions=True):
                session.delete(model)
                session.flush()
        return model

    def delete_batch(self, session, vpc_id=None,
                     owner_type=None, hostname=None):
        query = session.query(self.model_class)
        if vpc_id:
            query = query.filter_by(vpc_id=vpc_id)
        if owner_type:
            query = query.filter_by(owner_type=owner_type)
        if hostname:
            query = query.filter_by(hostname=hostname)
        with session.begin(subtransactions=True):
            query.delete()

    def create_nic(self, session, db_subnets, nic):
        with db_api.get_lock_session() as lock_session:
            return self.do_create_nic(lock_session, db_subnets, nic)

    def do_create_nic(self, lock_session, db_subnets, nic):
        # Calculate the number of ip and mac that need to be generated and
        # collect the ip or mac specified by the request parameter
        req_mac = nic.get('mac_address')
        subnet_req_ips = {}
        subnet_gen_ip_count = {}
        for address in nic.get('ip_addresses'):
            subnet_id = address['subnet_id']
            if address.get('ip_address'):
                if not subnet_req_ips.get(subnet_id):
                    subnet_req_ips[subnet_id] = set()
                req_ips = subnet_req_ips.get(subnet_id)
                req_ips.add(address['ip_address'])
            else:
                if subnet_gen_ip_count.get(subnet_id):
                    subnet_gen_ip_count[subnet_id] += 1
                else:
                    subnet_gen_ip_count[subnet_id] = 1

        # Generate address and fill in nic
        copy_nic = self._fill_generated_address(
            lock_session, db_subnets, nic,
            req_mac, subnet_req_ips, subnet_gen_ip_count)

        try:
            # Build nic parameter for inserting db
            ip_addresses = copy_nic.pop('ip_addresses')
            copy_nic['vpc_id'] = db_subnets[0].vpc_id
            copy_nic['status'] = constants.DOWN
            if 'owner_type' not in copy_nic:
                copy_nic['owner_type'] = constants.NIC_OF_RESERVE
            # If nic is deleted with the vm, auto_delete is True.
            if not copy_nic.get('auto_delete'):
                copy_nic['auto_delete'] = False
            if not copy_nic.get('status'):
                copy_nic['status'] = constants.DOWN
            db_nic = self.create(lock_session, **copy_nic)
            # Build ip allocation parameter for inserting db
            ip_allocs_for_create = []
            for address in ip_addresses:
                address['nic_id'] = db_nic.id
                ip_allocs_for_create.append(address)
            self.ip_alloc_repo.create_batch(lock_session,
                                            ip_allocs_for_create)
            return db_nic.id
        except db_exceptions.DBDuplicateEntry:
            LOG.error('duplicate ip or mac when creating nics '
                      'with nic paremeter %s', copy_nic)
            raise

    def _fill_generated_address(self, session, subnets, nic,
                                req_mac, subnet_req_ips,
                                subnet_gen_ip_count):
        generated_mac = None
        # Get all existing macs
        existing_macs = self._get_all_macs(session)
        if req_mac:
            # Check if the existing mac and the requested mac are duplicated
            duplicated_macs = existing_macs & set([req_mac])
            if duplicated_macs:
                raise exceptions.AddressExist(name='mac',
                                              addr=duplicated_macs)
        else:
            # Generate mac
            # _generate_macs method refers from openstack:
            # neutron/db/db_base_plugin_common.py
            generated_mac = self._generate_macs(existing_macs)[0]

        subnet_generated_ips = {}
        for subnet in subnets:
            # Get existing ips in subnet
            existing_ips = self._get_ips_in_subnet(session, subnet.id)
            # Check if the existing ip and the requested ip are duplicated
            req_ips = subnet_req_ips.get(subnet.id)
            if req_ips:
                duplicated_ips = existing_ips & req_ips
                if duplicated_ips:
                    raise exceptions.AddressExist(name='ip',
                                                  addr=duplicated_ips)
            # Generate ip
            gen_ip_count = subnet_gen_ip_count.get(subnet.id)
            if gen_ip_count:
                # _generate_ips method refers from openstack:
                # neutron/ipam/drivers/neutrondb_ipam/driver.py
                subnet_generated_ips[subnet.id] = self.generate_ips(
                    existing_ips, subnet, ip_count=gen_ip_count)

        # The original nics can not be updated, so that know
        # which ip or mac is missing from the nic
        copy_nic = copy.deepcopy(nic)
        # fill mac
        copy_nic['mac_address'] = req_mac or generated_mac
        # fill ips
        subnet_ip_index = {}
        for address in copy_nic.get('ip_addresses'):
            if not address.get('ip_address'):
                subnet_id = address['subnet_id']
                if subnet_id not in subnet_ip_index:
                    subnet_ip_index[subnet_id] = 0
                ip_index = subnet_ip_index[subnet_id]
                address['ip_address'] = \
                    subnet_generated_ips[subnet_id][ip_index]
                subnet_ip_index[subnet_id] += 1
        return copy_nic

    def _get_ips_in_subnet(self, session, subnet_id):
        ip_allocations, _ = self.ip_alloc_repo.get_all(session,
                                                       subnet_id=subnet_id,
                                                       lock=True)
        return set(ip_alloc.ip_address for ip_alloc in ip_allocations)

    def _get_all_macs(self, session):
        nics, _ = self.get_all(session, lock=True)
        return set(nic.mac_address for nic in nics)

    def _generate_macs(self, existing_macs, mac_count=1):
        mac_maker = self._random_mac_generator()
        generated_macs = []
        while len(generated_macs) < mac_count:
            mac = next(mac_maker)
            if mac not in existing_macs:
                generated_macs.append(mac)
        return generated_macs

    @staticmethod
    def _random_mac_generator():
        """Generates random mac addresses from a specified base format.

        The first 3 octets of each MAC address will remain unchanged.
        If the 4th octet is not 00, it will also be used. The others
        will be randomly generated.

        :param base_mac: Base mac address represented by an array of
                         6 strings.
        :returns: A mac address string generator.
        """
        base_mac = CONF.network_settings.base_mac.split(':')
        fixed = list(base_mac[0:3])
        to_generate = 3
        if base_mac[3] != '00':
            fixed = list(base_mac[0:4])
            to_generate = 2
        beginning = ':'.join(fixed) + ':'

        form = '{}' + ':'.join('{:02x}' for _ in range(to_generate))
        max_macs = 2 ** (to_generate * 8)
        seen = set()
        while len(seen) < max_macs:
            numbers = [random.getrandbits(8) for _ in range(to_generate)]
            mac = form.format(beginning, *numbers)
            if mac in seen:
                continue
            seen.add(mac)
            yield mac

    @staticmethod
    def generate_ips(existing_ips, subnet,
                     prefer_continuous=False, ip_count=1):
        """Generate a set of IPs from the set of available addresses."""
        allocated_ips = []
        requested_num_addresses = ip_count

        # It is better not to use 'netaddr.IPSet.add',
        # because _compact_single_network in 'IPSet.add'
        # is quite time consuming.
        ip_allocations = netaddr.IPSet(
            [netaddr.IPAddress(existing_ip)
             for existing_ip in existing_ips])

        for ip_pool in subnet.address_pools:
            ip_set = netaddr.IPSet()
            ip_set.add(netaddr.IPRange(ip_pool.start_ip, ip_pool.end_ip))
            av_set = ip_set.difference(ip_allocations)
            if av_set.size == 0:
                continue

            if av_set.size < requested_num_addresses:
                # All addresses of the address pool are allocated
                # for the first time and the remaining addresses
                # will be allocated in the next address pools.
                allocated_num_addresses = av_set.size
            else:
                # All expected addresses can be assigned in this loop.
                allocated_num_addresses = requested_num_addresses

            if prefer_continuous:
                allocated_ip_pool = list(itertools.islice(
                    av_set, allocated_num_addresses))
                allocated_ips.extend([str(allocated_ip)
                                      for allocated_ip in allocated_ip_pool])

                requested_num_addresses -= allocated_num_addresses
                if requested_num_addresses:
                    # More addresses need to be allocated in the next loop.
                    continue
                return allocated_ips

            window = min(av_set.size, MAX_WIN)

            # NOTE(gryf): If there is more than one address, make the window
            # bigger, so that are chances to fulfill demanded amount of IPs.
            if allocated_num_addresses > 1:
                window = min(av_set.size,
                             allocated_num_addresses * MULTIPLIER,
                             MAX_WIN_MULTI)

            if window < allocated_num_addresses:
                continue
            # Maximize randomness by using the random module's built in
            # sampling function
            av_ips = list(itertools.islice(av_set, 0, window))
            allocated_ip_pool = random.sample(av_ips,
                                              allocated_num_addresses)
            allocated_ips.extend([str(allocated_ip)
                                  for allocated_ip in allocated_ip_pool])

            requested_num_addresses -= allocated_num_addresses
            if requested_num_addresses:
                # More addresses need to be allocated in the next loop.
                continue

            return allocated_ips
        raise exceptions.IpExhausted(subnet_id=subnet.id)

    def update_nic(self, session, ip_addresses, db_nic, db_subnets, nic):
        try:
            with db_api.get_lock_session() as lock_session:
                # Update in nic table
                if any(['name' in nic, 'description' in nic,
                        'hostname' in nic, 'owner_id' in nic,
                        'owner_type' in nic]):
                    self.update(lock_session, db_nic.id, **nic)
                # Insert or delete in address_allocation table
                if ip_addresses:
                    # Add new ips
                    db_ips = set()
                    for address in db_nic.ip_addresses:
                        db_ips.add((address.ip_address, address.subnet_id))
                    request_ips = set((address['ip_address'],
                                       address['subnet_id'])
                                      for address in ip_addresses)
                    create_ips = request_ips.difference(db_ips)
                    if create_ips:
                        ip_allocs_for_create = [{'subnet_id': subnet_id,
                                                 'ip_address': ip,
                                                 'nic_id': db_nic.id}
                                                for ip, subnet_id
                                                in create_ips]
                        self.ip_alloc_repo.create_batch(lock_session,
                                                        ip_allocs_for_create)
                    # Delete old ips
                    delete_keys = [(db_ip_address.ip_address,
                                    db_ip_address.subnet_id)
                                   for db_ip_address in db_nic.ip_addresses if
                                   (db_ip_address.ip_address,
                                    db_ip_address.subnet_id)
                                   not in request_ips]
                    if delete_keys:
                        self.ip_alloc_repo.delete_batch(lock_session,
                                                        delete_keys)
            session.expire_all()

        except db_exceptions.DBDuplicateEntry as e:
            LOG.error('Update nic %s failed, because duplicated ip', db_nic.id)
            # Collect ip in request parameter
            subnet_req_ips = {}
            for address in ip_addresses:
                subnet_id = address['subnet_id']
                if not subnet_req_ips.get(subnet_id):
                    subnet_req_ips[subnet_id] = set()
                req_ips = subnet_req_ips.get(subnet_id)
                req_ips.add(address['ip_address'])
            # Find out which ip is duplicated
            for db_subnet in db_subnets:
                # Get existing ip and mac
                existing_ips = self._get_ips_in_subnet(session, db_subnet.id)
                req_ips = subnet_req_ips.get(db_subnet.id)
                duplicated_ip = req_ips & existing_ips
                if duplicated_ip:
                    raise exceptions.AddressExist(name='ip',
                                                  addr=duplicated_ip) from e
            LOG.error('Duplicated ip is not found. The request'
                      'parameters are %s', nic)
            raise e

    def get_subnets(self, session, subnet_ids):
        db_subnets, _ = self.subnet_repo.get_all(session,
                                                 ids=list(subnet_ids))
        if len(db_subnets) < len(subnet_ids):
            existing_ids = set(db_subnet.id for db_subnet in db_subnets)
            raise exceptions.NotFound(resource='subnet',
                                      id=subnet_ids.difference(existing_ids))
        return db_subnets

    @staticmethod
    def validate_ips(ip_addresses, subnets, owner_type):
        subnet_cidr = {}
        subnet_ip_range = {}
        for subnet in subnets:
            subnet_cidr[subnet.id] = netaddr.IPNetwork(subnet.cidr)
            subnet_ip_range[subnet.id] = [(netaddr.IPRange(pool.start_ip,
                                                           pool.end_ip),
                                           pool.id)
                                          for pool in subnet.address_pools]
        for ip_address in ip_addresses:
            ip = ip_address.get('ip_address')
            if not ip:
                continue
            subnet_id = ip_address['subnet_id']
            # Validate ip format
            if not netaddr.valid_ipv4(ip):
                raise exceptions.InvalidAddressFormat(name='ip', addr=ip)
            # If voi vm or dhcp, check if ip is in the cidr of subnet
            if owner_type in (constants.NIC_OF_VOI_VM, constants.NIC_OF_DHCP):
                if netaddr.IPAddress(ip) not in subnet_cidr[subnet_id]:
                    raise exceptions.IPaddressNotInCidr(
                        name='ip', addr=ip, cidr=subnet_cidr[subnet_id])
            # If owner_type is None or vdi vm , check if ip is in
            # the ip pool of subnet
            elif (not owner_type) or owner_type == constants.NIC_OF_VDI_VM:
                for ip_range, pool_id in subnet_ip_range[subnet_id]:
                    if netaddr.IPAddress(ip) in ip_range:
                        break
                else:
                    raise exceptions.OutOfBoundsAddressPool(
                        pool=pool_id, subnet_cidr=subnet_cidr[subnet_id])

    def validate_create_nic_for_vm(self, lock_session, ip_addresses,
                                   vm_id, owner_type=constants.NIC_OF_VDI_VM):
        """validate and create nic for creating vm"""
        # Get subnets
        db_subnets = self.get_subnets(lock_session,
                                      set(req_subnet_ip_dict['subnet_id']
                                          for req_subnet_ip_dict
                                          in ip_addresses))
        # Validate ip
        self.validate_ips(ip_addresses, db_subnets, constants.NIC_OF_VDI_VM)
        # Create nic for creating vm
        created_nic_ids = []
        id_subnets = {db_subnet.id: db_subnet for db_subnet in db_subnets}
        for ip_address in ip_addresses:
            subnet_id = ip_address['subnet_id']
            param_for_create = {'auto_delete': True,
                                'ip_addresses': [{'subnet_id': subnet_id}],
                                'status': constants.DOWN,
                                'owner_id': vm_id,
                                'owner_type': owner_type}
            if ip_address.get('ip_address'):
                param_for_create['ip_addresses'][0]['ip_address'] = \
                    ip_address.get('ip_address')
            created_nic_ids.append(self.do_create_nic(
                lock_session, [id_subnets[subnet_id]], param_for_create))
        return created_nic_ids

    def validate_attach_nics(self, lock_session, nic_ids, vm_id,
                             owner_type=constants.NIC_OF_VDI_VM):
        """validate and attach nic for creating vm"""
        db_nics, _ = self.get_all(lock_session, ids=nic_ids)
        # Check if nic exists
        if len(db_nics) < len(nic_ids):
            existing_nic_ids = set(db_nic.id for db_nic in db_nics)
            noexistant_nic_ids = set(nic_ids).difference(existing_nic_ids)
            raise exceptions.NotFound(resource='nic', id=noexistant_nic_ids)
        for db_nic in db_nics:
            # Check if the status of nic is conflict
            if self.update(lock_session, db_nic.id,
                           expected_status=constants.DOWN,
                           **{'status': constants.PREPARE_ATTACH,
                              'owner_id': vm_id,
                              'owner_type': owner_type}) < 1:
                raise exceptions.NicStatusConflict(nic_id=db_nic.id,
                                                   action='attach',
                                                   status=db_nic.status)


class AddressAllocRepository(base_repo.BaseRepository):

    model_class = models.AddressAllocation

    def delete_batch(self, session, ip_subnet_tuples):
        query = session.query(self.model_class)
        conditions = [and_(self.model_class.subnet_id == subnet_id,
                           self.model_class.ip_address == ip_address)
                      for ip_address, subnet_id in ip_subnet_tuples]
        query = query.filter(or_(*conditions))
        with session.begin(subtransactions=True):
            query.delete()

    def get_all(self, session, pagination_helper=None, lock=False,
                nic_ids=None, **filters):
        query = session.query(self.model_class).filter_by(**filters)
        if nic_ids:
            query = query.filter(self.model_class.nic_id.in_(nic_ids))
        if lock:
            query = query.with_for_update()
        if pagination_helper:
            model_list, links = pagination_helper.apply(
                query, self.model_class)
        else:
            links = None
            model_list = query.all()

        return model_list, links
