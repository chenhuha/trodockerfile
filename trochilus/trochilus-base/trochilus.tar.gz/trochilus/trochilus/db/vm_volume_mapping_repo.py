# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import base_repo
from trochilus.db import models
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import volume_repo


class VMVolumeMappingRepository(base_repo.BaseRepository):

    def __init__(self) -> None:
        super().__init__()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.volume_repo = volume_repo.VolumeRepository()

    model_class = models.VMVolumeMapping

    def validate_create_volume_attachment(self, session, volume_attach_dict):
        """Prepare volume info, validate volume info and create volume"""
        volume_id = volume_attach_dict.get("volume_id")
        virtual_machind_id = volume_attach_dict.get("virtual_machine_id")

        # Check Volume status
        db_volume = self.volume_repo.get(session, id=volume_id)
        if not db_volume:
            msg = ("No volume found with id %s" % volume_id)
            raise exceptions.NotFound(msg=msg)
        vol_status = db_volume.status
        if vol_status not in [constants.AVAILABLE, constants.PREPARE_CREATE,
                              constants.PREPARE_CLONE]:
            raise exceptions.VolumeInvalidState(
                volume_id=db_volume.id,
                state=vol_status,
                method="attach_volume")

        # Check VM status
        db_vm = self.vm_repo.get(session, id=virtual_machind_id)
        vm_status = db_vm.status
        if vm_status not in constants.CAN_ATTACH_DETACH_VOLUME_STATUS:
            raise exceptions.VMInvalidState(
                vm_id=db_vm.id, state=vm_status, method="attach_volume")

        volume_attach_dict['attach_status'] = constants.PREPARE_ATTACH
        db_vvm = self.create(session, **volume_attach_dict)

        return db_vvm
