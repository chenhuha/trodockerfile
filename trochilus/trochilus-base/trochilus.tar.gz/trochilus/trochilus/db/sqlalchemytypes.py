#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""Custom SQLAlchemy types."""

import netaddr
from oslo_db.sqlalchemy import types as odsa_types
from sqlalchemy import types
from trochilus.i18n import _


class IPAddress(types.TypeDecorator):

    impl = types.String(64)

    cache_ok = True

    def process_bind_param(self, value, dialect):
        try:
            netaddr.IPAddress(value)
        except netaddr.core.AddrFormatError as e:
            raise AttributeError(
                _("Receive an invalid ip address: %s.") % value) from e
        return value


class CIDR(types.TypeDecorator):

    impl = types.String(64)

    cache_ok = True

    def process_bind_param(self, value, dialect):
        try:
            netaddr.IPNetwork(value)
        except netaddr.core.AddrFormatError as e:
            raise AttributeError(_("Receive an invalid "
                                   "cidr: %s.") % value) from e
        return value


class MACAddress(types.TypeDecorator):

    impl = types.String(64)

    cache_ok = True

    def process_bind_param(self, value, dialect):
        try:
            netaddr.EUI(value)
        except netaddr.core.AddrFormatError as e:
            raise AttributeError(_("Receive an invalid MAC "
                                   "address: %s.") % value) from e
        return value


class TruncatedDateTime(types.TypeDecorator):
    """Truncates microseconds.

    Use this for datetime fields so we don't have to worry about DB-specific
    behavior when it comes to rounding/truncating microseconds off of
    timestamps.
    """

    impl = types.DateTime

    cache_ok = True

    def process_bind_param(self, value, dialect):
        return value.replace(microsecond=0) if value else value

    process_result_value = process_bind_param


class JsonEncodedDict(odsa_types.JsonEncodedType):

    type = dict
    cache_ok = True


class JsonEncodedList(odsa_types.JsonEncodedType):

    type = list
    cache_ok = True
