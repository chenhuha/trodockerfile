#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import random

from oslo_config import cfg
from oslo_log import log as logging
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import resource_provider_repo as rp_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.scheduler.filters import filter_handler
from trochilus.scheduler.weights import weight_handler


CONF = cfg.CONF
LOG = logging.getLogger('__name__')


class SchedulerManager:

    def __init__(self):
        self.res_provider_repo = rp_repo.ResourceProviderRepository()
        self.res_alloc_repo = rp_repo.ResourceAllocationRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.host_manager = HostManager()

    def select_destination(self, lock_session, spec):
        agents, _ = self.agent_repo.get_all(lock_session)
        if not agents:
            LOG.info('There is no agent in db')
            return None

        # During selecting destination, the available resource of host
        # may be changed by other process or thread, so retry
        select_retries = 50
        while select_retries:
            select_retries -= 1

            # Get hosts with enough available resources
            hosts = self._get_allocation_candidates(agents, spec)
            if not hosts:
                LOG.info('When selecting destination, there is no hosts that '
                         'has enough resource, schedule spec is: %s',
                         repr(spec))
                raise exceptions.ScheduleVmFailed(
                    reason='there is no hosts that has enough resource')

            # Filter hosts by filter, sort hosts by weight
            hosts = self._get_sorted_hosts(spec, hosts)
            if not hosts:
                LOG.info('When selecting destination, there is no host that '
                         'meets the conditions of filter, schedule spec is: '
                         '%s', repr(spec))
                raise exceptions.ScheduleVmFailed(
                    reason='there is no host that meets the conditions of '
                           'filter')

            # Occupy resources on the selected_host host
            selected_host = hosts[0]
            res_provider = selected_host.res_provider
            if self.res_provider_repo.update(
                    db_api.get_session(),
                    res_provider.id,
                    expected_generation=res_provider.generation,
                    **{'generation': res_provider.generation + 1}) > 0:
                self.res_alloc_repo.create_batch(
                    lock_session, res_provider.id, spec.vm_id,
                    {constants.VCPU_CLASS_ID: spec.vcpu,
                     constants.MEMORY_CLASS_ID: spec.memory_mb})
                return selected_host.agent

        LOG.error('During scheduling, the available resource of selected host '
                  'is changed by other process or thread, so retry but retry '
                  'num exhaust')
        return None

    def _get_allocation_candidates(self, agents, spec):
        hosts = []
        # The lock_session is not used here because need to query the latest
        session = db_api.get_session()
        for agent in agents:
            res_provider = self.res_provider_repo.get(session,
                                                      agent_id=agent.id)
            cpu_ratio = res_provider.cpu_ratio
            reserved_cpu = res_provider.reserved_cpu
            memory_ratio = res_provider.memory_ratio
            reserved_memory_mb = res_provider.reserved_memory_mb

            if agent.cpu_thread > reserved_cpu:
                total_vcpu = (agent.cpu_thread - reserved_cpu) * cpu_ratio
            else:
                total_vcpu = 0
            agent_total_memory_mb = agent.total_memory / (1024 * 1024)
            if agent_total_memory_mb > reserved_memory_mb:
                total_memory_mb = \
                    (agent_total_memory_mb - reserved_memory_mb) * memory_ratio
            else:
                total_memory_mb = 0
            used_vcpu, used_memory_mb = self._get_used_vcpu_and_memory(
                res_provider)
            free_vcpu = total_vcpu - used_vcpu
            free_memory_mb = total_memory_mb - used_memory_mb

            if free_vcpu < spec.vcpu or free_memory_mb < spec.memory_mb:
                continue

            host = Host()
            host.total_vcpu = total_vcpu
            host.total_memory_mb = total_memory_mb
            host.free_vcpu = free_vcpu
            host.free_memory_mb = free_memory_mb
            host.agent = agent
            host.res_provider = res_provider
            hosts.append(host)
        return hosts

    def _get_used_vcpu_and_memory(self, res_provider):
        used_vcpu = 0
        used_memory_mb = 0
        if res_provider.resource_allocations:
            for res_alloc in res_provider.resource_allocations:
                if res_alloc.resource_class_id == constants.VCPU_CLASS_ID:
                    used_vcpu += res_alloc.used
                elif res_alloc.resource_class_id == constants.MEMORY_CLASS_ID:
                    used_memory_mb += res_alloc.used
        return used_vcpu, used_memory_mb

    def _get_sorted_hosts(self, spec_obj, hosts, index=0):
        # Returns a list of HostState objects that match the required
        # scheduling constraints for the request spec object and have been
        # sorted according to the weighers.
        filtered_hosts = self.host_manager.get_filtered_hosts(hosts,
                                                              spec_obj, index)

        LOG.debug("Filtered %(hosts)s", {'hosts': filtered_hosts})

        if not filtered_hosts:
            return []

        weighed_hosts = self.host_manager.get_weighed_hosts(
            filtered_hosts, spec_obj)

        # Log the weighed hosts before stripping off the wrapper class so that
        # the weight value gets logged.
        LOG.debug("Weighed %(hosts)s", {'hosts': weighed_hosts})
        # Strip off the WeighedHost wrapper class...
        weighed_hosts = [h.obj for h in weighed_hosts]

        # We randomize the first element in the returned list to alleviate
        # congestion where the same host is consistently selected among
        # numerous potential hosts for similar request specs.
        host_subset_size = CONF.scheduler_settings.host_subset_size
        if host_subset_size < len(weighed_hosts):
            weighed_subset = weighed_hosts[0:host_subset_size]
        else:
            weighed_subset = weighed_hosts

        chosen_host = random.choice(weighed_subset)
        weighed_hosts.remove(chosen_host)
        return [chosen_host] + weighed_hosts


class HostManager:

    def __init__(self):
        self.filter_handler = filter_handler.BaseFilterHandler()
        self.weight_handler = weight_handler.BaseWeightHandler()
        filter_classes = self.filter_handler.get_matching_classes(
            CONF.scheduler_settings.available_filters)
        self.filter_cls_map = {cls.__name__: cls for cls in filter_classes}
        self.filter_obj_map = {}
        self.enabled_filters = self._choose_host_filters(
            CONF.scheduler_settings.enabled_filters)
        weigher_classes = self.weight_handler.get_matching_classes(
            CONF.scheduler_settings.weight_classes)
        self.weighers = [cls() for cls in weigher_classes]

    def get_weighed_hosts(self, hosts, spec_obj):
        """Weigh the hosts."""
        return self.weight_handler.get_weighed_objects(self.weighers,
                                                       hosts, spec_obj)

    def get_filtered_hosts(self, hosts, spec_obj, index=0):
        """Filter hosts and return only ones passing all filters."""

        def _strip_ignore_hosts(hosts, hosts_to_ignore):
            ignored_hosts = []
            for agent_id in hosts_to_ignore:
                for index, host in enumerate(hosts):
                    if host.agent.id == agent_id:
                        del hosts[index]
                        ignored_hosts.append(agent_id)
            ignored_hosts_str = ', '.join(ignored_hosts)
            LOG.info('Host filter ignoring hosts: %s', ignored_hosts_str)

        ignored_hosts = spec_obj.ignored_hosts or []
        if ignored_hosts:
            _strip_ignore_hosts(hosts, ignored_hosts)
            if not hosts:
                return []
        return self.filter_handler.get_filtered_objects(self.enabled_filters,
                                                        hosts, spec_obj, index)

    def _choose_host_filters(self, filter_cls_names):
        # Since the caller may specify which filters to use we need
        # to have an authoritative list of what is permissible. This
        # function checks the filter names against a predefined set
        # of acceptable filters.
        if not isinstance(filter_cls_names, (list, tuple)):
            filter_cls_names = [filter_cls_names]

        good_filters = []
        bad_filters = []
        for filter_name in filter_cls_names:
            if filter_name not in self.filter_obj_map:
                if filter_name not in self.filter_cls_map:
                    bad_filters.append(filter_name)
                    continue
                filter_cls = self.filter_cls_map[filter_name]
                self.filter_obj_map[filter_name] = filter_cls()
            good_filters.append(self.filter_obj_map[filter_name])
        if bad_filters:
            raise exceptions.NotFound(resource='schedulerHostFilter',
                                      id=", ".join(bad_filters))
        return good_filters


class Host(object):

    def __init__(self):
        self.total_memory_mb = 0
        self.total_vcpu = 0
        self.free_memory_mb = 0
        self.free_vcpu = 0
        self.res_provider = None
        self.agent = None


class ScheduleSpec(object):

    def __init__(self):
        self.vpcs = 0
        self.memory_mb = 0
        self.vm_id = None
        self.ignored_hosts = None
        self.scheduler_hints = None
