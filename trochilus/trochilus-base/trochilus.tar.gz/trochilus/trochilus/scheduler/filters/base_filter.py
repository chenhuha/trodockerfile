#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

# Reference from openstack nova/filters.py
class BaseFilter(object):
    """Base class for all filter classes."""

    def _filter_one(self, obj, spec_obj):
        # Return True if it passes the filter, False otherwise.
        # Override this in a subclass.
        return True

    def filter_all(self, filter_obj_list, spec_obj):
        """Yield objects that pass the filter.

        Can be overridden in a subclass, if you need to base filtering
        decisions on all objects.  Otherwise, one can just override
        _filter_one() to filter a single object.
        """
        for obj in filter_obj_list:
            if self._filter_one(obj, spec_obj):
                yield obj

    # Set to true in a subclass if a filter only needs to be run once
    # for each request rather than for each instance
    run_filter_once_per_request = False

    def run_filter_for_index(self, index):
        # Return True if the filter needs to be run for the "index-th"
        # instance in a request.  Only need to override this if a filter
        # needs anything other than "first only" or "all" behaviour.
        if self.run_filter_once_per_request and index > 0:
            return False
        return True


# Reference from openstack nova/scheduler/filters/__init__.py
class BaseHostFilter(BaseFilter):
    """Base class for host filters."""

    # This is set to True if this filter should be run for rebuild.
    # For example, with rebuild, we need to ask the scheduler if the
    # existing host is still legit for a rebuild with the new image and
    # other parameters. We care about running policy filters (i.e.
    # ImagePropertiesFilter) but not things that check usage on the
    # existing compute node, etc.
    RUN_ON_REBUILD = False

    def _filter_one(self, obj, spec):
        """Return True if the object passes the filter, otherwise False."""
        if not self.RUN_ON_REBUILD and self._is_rebuild(spec):
            # If we don't filter, default to passing the host.
            return True
        # We are either a rebuild filter, in which case we always run,
        # or this request is not rebuild in which case all filters
        # should run.
        return self.host_passes(obj, spec)

    @staticmethod
    def _is_rebuild(spec_obj):
        """Returns True if request is for a rebuild.

        :param spec_obj: An objects.RequestSpec to examine (or None).
        """
        if not spec_obj:
            return False
        if not spec_obj.scheduler_hints:
            return False
        check_type = spec_obj.scheduler_hints.get('_check_type')
        return check_type == ['rebuild']

    def host_passes(self, host_state, filter_properties):
        # Return True if the HostState passes the filter, otherwise False.
        # Override this in a subclass.
        raise NotImplementedError()
