#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from trochilus.common import constants
from trochilus.scheduler.filters import base_filter


class AgentStatusFilter(base_filter.BaseHostFilter):
    """Filter on active agent"""

    # Filter once per request
    run_filter_once_per_request = True

    def host_passes(self, host, spec_obj):
        """Returns True for only active agent."""
        return host.agent.status and host.agent.status == constants.AGENT_UP
