#   Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import abc

from oslo_log import log as logging

LOG = logging.getLogger(__name__)


# Reference from openstack nova/weights.py
class BaseWeigher(object):

    """Base class for pluggable weighers.

    The attributes maxval and minval can be specified to set up the maximum
    and minimum values for the weighed objects. These values will then be
    taken into account in the normalization step, instead of taking the values
    from the calculated weights.
    """

    minval = None
    maxval = None

    def weight_multiplier(self, host_state):
        """How weighted this weigher should be.

        Override this method in a subclass, so that the returned value is
        read from a configuration option to permit operators specify a
        multiplier for the weigher. If the host is in an aggregate, this
        method of subclass can read the ``weight_multiplier`` from aggregate
        metadata of ``host_state``, and use it to overwrite multiplier
        configuration.

        :param host_state: The HostState object.
        """
        return 1.0

    @abc.abstractmethod
    def _weigh_object(self, obj, weight_properties):
        """Weigh an specific object."""

    def weigh_objects(self, weighed_obj_list, weight_properties):
        """Weigh multiple objects.

        Override in a subclass if you need access to all objects in order
        to calculate weights. Do not modify the weight of an object here,
        just return a list of weights.
        """
        # Calculate the weights
        weights = []
        for obj in weighed_obj_list:
            weight = self._weigh_object(obj.obj, weight_properties)

            # don't let the weight go beyond the defined max/min
            if self.minval is not None:
                weight = max(weight, self.minval)
            if self.maxval is not None:
                weight = min(weight, self.maxval)

            weights.append(weight)

        return weights


# Reference from openstack nova/scheduler/weights/__init__.py
class BaseHostWeigher(BaseWeigher):
    """Base class for host weights."""
