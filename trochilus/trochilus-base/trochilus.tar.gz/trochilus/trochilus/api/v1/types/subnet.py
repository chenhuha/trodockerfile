#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.db import constants as db_const


class BaseSubnetType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class AddressPoolResponse(types.BaseType):
    start_ip = wtypes.wsattr(types.IPAddressType())
    end_ip = wtypes.wsattr(types.IPAddressType())


class AddressDetailsResponse(types.BaseType):
    total_ip = wtypes.wsattr(wtypes.IntegerType())
    used_ip = wtypes.wsattr(wtypes.IntegerType())
    allocate_pool_ip = wtypes.wsattr(wtypes.IntegerType())
    allocable_ip = wtypes.wsattr(wtypes.IntegerType())


class SubnetResponse(BaseSubnetType):
    """Defines which attributes are to be shown on any response."""
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    vpc_id = wtypes.wsattr(wtypes.UuidType())
    cidr = wtypes.wsattr(wtypes.StringType())
    gateway = wtypes.wsattr(wtypes.IPv4AddressType())
    address_pools = wtypes.wsattr([AddressPoolResponse])
    address_details = wtypes.wsattr(
        wtypes.DictType(str, types.MultiType(int)))
    enable_dhcp = wtypes.wsattr(wtypes.IntegerType())
    dns_nameservers = wtypes.wsattr([wtypes.StringType()])
    project_id = wtypes.wsattr(wtypes.UuidType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)

    @classmethod
    def from_db_model(cls, data_model, children=False):
        subnet = super(SubnetResponse, cls).from_db_model(
            data_model, children=children)

        address_pool_type = AddressPoolResponse
        subnet.address_pools = [
            address_pool_type.from_db_model(address_pool)
            for address_pool in data_model.address_pools]

        if data_model.dns_nameservers:
            subnet.dns_nameservers = [dns_nameserver.ip_address
                                      for dns_nameserver
                                      in sorted(data_model.dns_nameservers,
                                                key=lambda x: x.order)]
        return subnet


class SubnetRootResponse(types.BaseType):
    subnet = wtypes.wsattr(SubnetResponse)


class SubnetsRootResponse(types.BaseType):
    subnets = wtypes.wsattr([SubnetResponse])
    subnet_links = wtypes.wsattr([types.PageType])


class AddressPoolRequest(types.BaseType):
    start_ip = wtypes.wsattr(types.IPAddressType(), mandatory=True)
    end_ip = wtypes.wsattr(types.IPAddressType(), mandatory=True)


class SubnetPUT(BaseSubnetType):
    """Defines the attributes of a PUT request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    address_pools = wtypes.wsattr([AddressPoolRequest])
    enable_dhcp = wtypes.wsattr(bool)
    dns_nameservers = wtypes.wsattr([wtypes.StringType()])
    project_id = wtypes.wsattr(wtypes.UuidType())
    user_id = wtypes.wsattr(wtypes.UuidType())


class SubnetRootPUT(types.BaseType):
    subnet = wtypes.wsattr(SubnetPUT)


class SubnetPOST(BaseSubnetType):
    """Defines the attributes of a POST request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    vpc_id = wtypes.wsattr(wtypes.UuidType(), mandatory=True)
    cidr = wtypes.wsattr(wtypes.StringType(), mandatory=True)
    gateway = wtypes.wsattr(wtypes.IPv4AddressType())
    address_pools = wtypes.wsattr([AddressPoolRequest])
    enable_dhcp = wtypes.wsattr(bool)
    dns_nameservers = wtypes.wsattr([wtypes.StringType()])
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())


class SubnetRootPOST(types.BaseType):
    subnet = wtypes.wsattr(SubnetPOST)
