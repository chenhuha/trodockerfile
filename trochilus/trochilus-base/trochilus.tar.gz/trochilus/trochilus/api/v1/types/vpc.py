#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.common import constants
from trochilus.db import constants as db_const


class BaseVpcType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class VpcResponse(BaseVpcType):
    """Defines which attributes are to be shown on any response."""
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    type = wtypes.wsattr(wtypes.StringType())
    vlan_id = wtypes.wsattr(wtypes.IntegerType())
    physical = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)


class VpcRootResponse(types.BaseType):
    vpc = wtypes.wsattr(VpcResponse)


class VpcsRootResponse(types.BaseType):
    vpcs = wtypes.wsattr([VpcResponse])
    vpc_links = wtypes.wsattr([types.PageType])


class VpcPUT(BaseVpcType):
    """Defines the attributes of a PUT request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())


class VpcRootPUT(types.BaseType):
    vpc = wtypes.wsattr(VpcPUT)


class VpcPOST(BaseVpcType):
    """Defines which attributes are to be shown on any response."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    type = wtypes.wsattr(wtypes.Enum(
        str, 'flat', 'vlan'), mandatory=True)
    physical = wtypes.wsattr(wtypes.StringType(max_length=255), mandatory=True)
    vlan_id = wtypes.wsattr(wtypes.IntegerType(minimum=constants.MIN_VLAN,
                                               maximum=constants.MAX_VLAN))
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())


class VpcRootPOST(types.BaseType):
    vpc = wtypes.wsattr(VpcPOST)


class VlanRange(types.BaseType):
    max = wtypes.wsattr(wtypes.IntegerType(minimum=constants.MIN_VLAN,
                                           maximum=constants.MAX_VLAN))
    min = wtypes.wsattr(wtypes.IntegerType(minimum=constants.MIN_VLAN,
                                           maximum=constants.MAX_VLAN))


class VpcNodeMappingResponse(BaseVpcType):
    agent_id = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())


class VpcNodeMappingRootResponse(types.BaseType):
    statuses = wtypes.wsattr([VpcNodeMappingResponse])
    status_links = wtypes.wsattr([types.PageType])
