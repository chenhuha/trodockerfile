#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg
from wsme import exc
from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.common import voi_utils
from trochilus.db import constants as db_const

CONF = cfg.CONF


class BaseVOIType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class VOIImageResponse(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    checksum = wtypes.wsattr(wtypes.StringType())
    location = wtypes.wsattr(wtypes.StringType())
    virtual_size = wtypes.wsattr(wtypes.IntegerType())
    size = wtypes.wsattr(wtypes.IntegerType())
    disk_format = wtypes.wsattr(wtypes.StringType())


class VOIImageRootResponse(types.BaseType):
    image = wtypes.wsattr(VOIImageResponse)


class VOIImagesRootResponse(types.BaseType):
    images = wtypes.wsattr([VOIImageResponse])
    image_links = wtypes.wsattr([types.PageType])


class VOIImagePOST(BaseVOIType):
    name = wtypes.wsattr(wtypes.StringType(), mandatory=True)
    disk_format = wtypes.wsattr(wtypes.Enum(
        str, 'qcow2', 'iso'), mandatory=True)
    description = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())


class VOIImageRootPOST(types.BaseType):
    image = wtypes.wsattr(VOIImagePOST)


class VOIImagePUT(BaseVOIType):
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())


class VOIImageRootPUT(types.BaseType):
    image = wtypes.wsattr(VOIImagePUT)


class IPaddress(BaseVOIType):
    ip_address = wtypes.wsattr(wtypes.StringType())
    subnet_id = wtypes.wsattr(wtypes.UuidType())


class VOIVMNic(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())
    vpc_id = wtypes.wsattr(wtypes.UuidType())
    ip_addresses = wtypes.wsattr(wtypes.ArrayType(IPaddress))
    mac_address = wtypes.wsattr(wtypes.StringType())

    @classmethod
    def from_db_model(cls, data_model, children=False):
        nic = super(VOIVMNic, cls).from_db_model(
            data_model, children=children)
        nic.ip_addresses = [
            IPaddress.from_db_model(address) for address in
            data_model.ip_addresses]
        return nic


class VOIVolume(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())
    size = wtypes.wsattr(wtypes.IntegerType())
    target = wtypes.wsattr(wtypes.StringType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    status = wtypes.wsattr(wtypes.StringType())
    index = wtypes.wsattr(wtypes.IntegerType())


class CDDriver(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())
    is_sys = wtypes.wsattr(bool)
    image_id = wtypes.wsattr(wtypes.UuidType())


class VOIVMResponse(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    image_id = wtypes.wsattr(wtypes.UuidType())
    agent_id = wtypes.wsattr(wtypes.UuidType())
    vcpu = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
    memory_mb = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
    root_disk_gb = wtypes.wsattr(wtypes.IntegerType())
    vnc_address = wtypes.wsattr(wtypes.StringType())
    spice_address = wtypes.wsattr(wtypes.StringType())
    nics = wtypes.wsattr(wtypes.ArrayType(VOIVMNic))
    disks = wtypes.wsattr(wtypes.ArrayType(VOIVolume))
    cd_drivers = wtypes.wsattr(wtypes.ArrayType(CDDriver))
    hostname = wtypes.wsattr(wtypes.StringType())
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")

    @classmethod
    def from_db_model(cls, data_model, children=False):
        vm = super(VOIVMResponse, cls).from_db_model(
            data_model, children=children)
        vm.nics = [
            VOIVMNic.from_db_model(nic) for nic in data_model.nics]
        vm.disks = [VOIVolume.from_db_model(volume) for
                    volume in data_model.disks]
        vm.cd_drivers = [CDDriver.from_db_model(cd_driver) for
                         cd_driver in data_model.cd_drivers]
        vm.hostname = data_model.agent.hostname
        return vm


class VOIVMRootResponse(types.BaseType):
    vm = wtypes.wsattr(VOIVMResponse)


class VOIVMsRootResponse(types.BaseType):
    vms = wtypes.wsattr([VOIVMResponse])
    vm_links = wtypes.wsattr([types.PageType])


class VOIVMPOST(BaseVOIType):
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    image_id = wtypes.wsattr(wtypes.UuidType())
    vcpu = wtypes.wsattr(wtypes.IntegerType())
    memory_mb = wtypes.wsattr(wtypes.IntegerType())
    root_disk_gb = wtypes.wsattr(wtypes.IntegerType())
    nics = wtypes.wsattr(wtypes.ArrayType(wtypes.DictType(str, str)))
    disks = wtypes.wsattr(wtypes.ArrayType(wtypes.DictType(str, int)))
    copy_from_vm_id = wtypes.wsattr(wtypes.UuidType())
    copy_data_disk = wtypes.wsattr(bool)
    data_disk_new_size = wtypes.wsattr(wtypes.IntegerType())
    create_from_vm_path = wtypes.wsattr(wtypes.StringType())
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")

    @staticmethod
    def validate(value):
        if value.create_from_vm_path and (not value.vcpu or
                                          not value.memory_mb):
            raise exc.InvalidInput("vcpu or memory_mb", None,
                                   "Mandatory field missing.")
        if (not value.copy_from_vm_id and not value.create_from_vm_path) and \
                (not value.image_id or not value.vcpu or not value.memory_mb):
            raise exc.InvalidInput("image_id or vcpu or memory_mb", None,
                                   "Mandatory field missing.")
        return value


class VOIVMRootPost(types.BaseType):
    vm = wtypes.wsattr(VOIVMPOST)


class VOIVMPUT(BaseVOIType):
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")


class VOIVMRootPUT(types.BaseType):
    vm = wtypes.wsattr(VOIVMPUT)


class VMActionPOST(types.BaseType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE),
        mandatory=True)
    extended_attr = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)))


class VMActionRootPOST(types.BaseType):
    action = wtypes.wsattr(VMActionPOST)


class VOIDataBackupPost(BaseVOIType):
    disk_base_filepath = wtypes.wsattr(wtypes.StringType())
    disk_dirpath = wtypes.wsattr(wtypes.StringType(), mandatory=True)
    disk_type = wtypes.wsattr(wtypes.Enum(str, 'sys', 'data'), mandatory=True)


class VOIDataBackupPostResponse(types.BaseType):
    status = wtypes.wsattr(wtypes.StringType())


class DiskDetailResponse(BaseVOIType):
    index = wtypes.wsattr(wtypes.IntegerType())
    path = wtypes.wsattr(wtypes.StringType())
    size = wtypes.wsattr(wtypes.IntegerType())
    name = wtypes.wsattr(wtypes.StringType())
    type = wtypes.wsattr(wtypes.StringType())


class DiskDetailsRootResponse(types.BaseType):
    disk_details = wtypes.wsattr([DiskDetailResponse])


class ShareDiskResponse(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())


class ShareDiskRootResponse(types.BaseType):
    share_disk = wtypes.wsattr(ShareDiskResponse)


class ShareDiskPOST(BaseVOIType):
    image_filepath = wtypes.wsattr(wtypes.StringType(), mandatory=True)
    base_dirpath = wtypes.wsattr(wtypes.StringType(), mandatory=True)
    id = wtypes.wsattr(wtypes.UuidType())


class ShareDiskDELETE(BaseVOIType):
    disk_dirpath = wtypes.wsattr(wtypes.StringType(), mandatory=True)


class ShareDiskPUT(BaseVOIType):
    disk_dirpath = wtypes.wsattr(wtypes.StringType(), mandatory=True)


class ShareTemplateDiskResponse(BaseVOIType):
    id = wtypes.wsattr(wtypes.UuidType())
    size = wtypes.wsattr(wtypes.IntegerType())
    vm_id = wtypes.wsattr(wtypes.UuidType())
    path = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())

    @classmethod
    def from_db_model(cls, data_model, children=False):
        disk = super(ShareTemplateDiskResponse, cls).from_db_model(
            data_model, children=children)
        _, disk.path = voi_utils.get_share_tmpl_disk_name_and_path(
            disk.id, CONF.voi_setting.share_template_disk_path)
        return disk


class ShareTemplateDiskRootResponse(types.BaseType):
    share_template_disk = wtypes.wsattr(ShareTemplateDiskResponse)


class ShareTemplateDiskPOST(BaseVOIType):
    size = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
