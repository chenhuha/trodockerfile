#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.db import constants as db_const


class BaseImageType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class ImageResponse(BaseImageType):
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    checksum = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    disk_format = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    location = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    size = wtypes.wsattr(wtypes.IntegerType())
    virtual_size = wtypes.wsattr(wtypes.IntegerType())
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")
    tags = wtypes.wsattr(wtypes.ArrayType(wtypes.StringType()))


class ImageRootResponse(types.BaseType):
    image = wtypes.wsattr(ImageResponse)


class ImagesRootResponse(types.BaseType):
    images = wtypes.wsattr([ImageResponse])
    image_links = wtypes.wsattr([types.PageType])


class ImagePOST(BaseImageType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    disk_format = wtypes.wsattr(wtypes.Enum(
        str, 'qcow2', 'raw', 'vhd', 'vhdx', 'vmdk', 'vdi'), mandatory=True)
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")
    tags = wtypes.wsattr(wtypes.ArrayType(str))


class ImageRootPOST(types.BaseType):
    image = wtypes.wsattr(ImagePOST)


class ImagePUT(BaseImageType):
    """Defines the attributes of a PUT request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")
    tags = wtypes.wsattr(wtypes.ArrayType(str))


class ImageRootPUT(types.BaseType):
    image = wtypes.wsattr(ImagePUT)
