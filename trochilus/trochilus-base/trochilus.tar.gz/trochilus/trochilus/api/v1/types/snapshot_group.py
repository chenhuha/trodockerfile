#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.api.v1.types import snapshot
from trochilus.db import constants as db_const


class BaseSnapshotGroupType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class SnapshotGroupResponse(BaseSnapshotGroupType):
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    size = wtypes.wsattr(wtypes.IntegerType())
    status = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    current = wtypes.wsattr(wtypes.IntegerType())
    previous = wtypes.wsattr(wtypes.UuidType())
    virtual_machine_id = wtypes.wsattr(wtypes.UuidType())
    snapshots = wtypes.wsattr(wtypes.ArrayType(snapshot.SnapshotResponse))

    @classmethod
    def from_db_model(cls, data_model, children=False):
        snapshot_group = super().from_db_model(
            data_model, children=children)

        snapshot_type = snapshot.SnapshotResponse
        snapshot_group.snapshots = [snapshot_type.from_db_model(snapshot)
                                    for snapshot in data_model.snapshot]
        return snapshot_group


class SnapshotGroupRootResponse(types.BaseType):
    snapshot_group = wtypes.wsattr(SnapshotGroupResponse)


class SnapshotsGroupRootResponse(types.BaseType):
    snapshot_groups = wtypes.wsattr([SnapshotGroupResponse])
    snapshot_group_links = wtypes.wsattr([types.PageType])


class SnapshotGroupPOST(BaseSnapshotGroupType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    virtual_machine_id = wtypes.wsattr(wtypes.UuidType(), mandatory=True)


class SnapshotGroupRootPOST(types.BaseType):
    snapshot_group = wtypes.wsattr(SnapshotGroupPOST)


class SnapshotGroupPut(BaseSnapshotGroupType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))


class SnapshotGroupRootPut(types.BaseType):
    snapshot_group = wtypes.wsattr(SnapshotGroupPut)


class SnapshotGroupActionPOST(types.BaseType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE), mandatory=True)
    extended_attr = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)))


class SnapshotGroupActionRootPOST(types.BaseType):
    action = wtypes.wsattr(SnapshotGroupActionPOST)
