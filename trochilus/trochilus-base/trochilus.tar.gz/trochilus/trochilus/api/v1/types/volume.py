#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import numpy as np
from wsme import exc
from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.db import constants as db_const


def validate_value_for_create_volume(value, checked_value, checked_keys):
    attr_count = np.count_nonzero(checked_value)
    if attr_count == 1:
        # It has only one attr.
        return value
    if attr_count == 0:
        if value.size:
            # It has no attr, but has size.
            return value
        # No attr, no size
        checked_keys.append("size")
        error = ("At least one attr from %s must exist for create volume."
                 "" % checked_keys)
        raise exc.ClientSideError(error)
    # It has more than one attr(image_id, volume_id, snapshot_id).
    error = ("The volume attrs %s must exist one at the same time"
             "" % checked_keys)
    raise exc.ClientSideError(error)


class BaseVolumeType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class VolumeResponse(BaseVolumeType):
    """Defines which attributes are to be shown on any response."""
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    size = wtypes.wsattr(wtypes.IntegerType())
    status = wtypes.wsattr(wtypes.StringType())
    backend = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    hostname = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    bootable = wtypes.wsattr(wtypes.IntegerType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    image_id = wtypes.wsattr(wtypes.UuidType())
    auto_delete = wtypes.wsattr(wtypes.IntegerType())
    attached_to = wtypes.wsattr(wtypes.UuidType())
    attached_index = wtypes.wsattr(wtypes.IntegerType())
    snapshot_id = wtypes.wsattr(wtypes.UuidType())
    volume_id = wtypes.wsattr(wtypes.UuidType())

    @classmethod
    def from_db_model(cls, data_model, children=False):
        volume = super().from_db_model(
            data_model, children=children)

        # Because a volume is directly mounted to a virtual machine
        # at the same time, there is at most one in the list
        list_vvm = data_model.vm_volume_mapping
        if list_vvm:
            volume.attached_to = list_vvm[0].virtual_machine_id
            volume.attached_index = list_vvm[0].attached_index
        else:
            volume.attached_to = None
            volume.attached_index = None

        return volume


class VolumeRootResponse(types.BaseType):
    volume = wtypes.wsattr(VolumeResponse)


class VolumesRootResponse(types.BaseType):
    volumes = wtypes.wsattr([VolumeResponse])
    volume_links = wtypes.wsattr([types.PageType])


class VolumePOST(BaseVolumeType):
    """Defines the attributes of a POST request."""
    name = wtypes.wsattr(wtypes.StringType())
    size = wtypes.wsattr(wtypes.IntegerType())
    backend = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    image_id = wtypes.wsattr(wtypes.UuidType())
    volume_id = wtypes.wsattr(wtypes.UuidType())
    snapshot_id = wtypes.wsattr(wtypes.UuidType())
    flatten = wtypes.wsattr(bool)

    @staticmethod
    def validate(value):
        return validate_value_for_create_volume(value, [
            value.volume_id, value.snapshot_id, value.image_id],
            ["volume_id", "snapshot_id", "image_id"])


class VolumeRootPOST(types.BaseType):
    volume = wtypes.wsattr(VolumePOST)


class VolumePut(BaseVolumeType):
    """Defines the attributes of a PUT request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))


class VolumeRootPut(types.BaseType):
    volume = wtypes.wsattr(VolumePut)


class VolumeForVMCreate(types.BaseType):
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    size = wtypes.wsattr(wtypes.IntegerType())
    backend = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    image_id = wtypes.wsattr(wtypes.UuidType())
    volume_id = wtypes.wsattr(wtypes.UuidType())
    snapshot_id = wtypes.wsattr(wtypes.UuidType())
    flatten = wtypes.wsattr(bool)

    @staticmethod
    def validate(value):
        return validate_value_for_create_volume(value, [
            value.id, value.volume_id, value.snapshot_id, value.image_id],
            ["id", "volume_id", "snapshot_id", "image_id"])


class VolumeActionPOST(types.BaseType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE), mandatory=True)
    extended_attr = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)))


class VolumeActionRootPOST(types.BaseType):
    action = wtypes.wsattr(VolumeActionPOST)
