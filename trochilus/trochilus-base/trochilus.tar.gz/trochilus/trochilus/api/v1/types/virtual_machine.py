#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.api.v1.types import nic
from trochilus.api.v1.types import volume
from trochilus.db import constants as db_const


class BaseVirtualMachineType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class VirtualMachineResponse(BaseVirtualMachineType):
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    agent_id = wtypes.wsattr(wtypes.UuidType())
    vcpu = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
    vnc_address = wtypes.wsattr(wtypes.StringType())
    spice_address = wtypes.wsattr(wtypes.StringType())
    memory_mb = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
    root_disk_gb = wtypes.wsattr(wtypes.IntegerType())
    image_id = wtypes.wsattr(wtypes.UuidType())
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")
    tags = wtypes.wsattr(wtypes.ArrayType(wtypes.StringType()))
    volumes = wtypes.wsattr(wtypes.ArrayType(volume.VolumeResponse))
    hostname = wtypes.wsattr(wtypes.StringType())
    nics = wtypes.wsattr(wtypes.ArrayType(nic.NicResponse))

    @classmethod
    def from_db_model(cls, data_model, children=False):
        vm = super(VirtualMachineResponse, cls).from_db_model(
            data_model, children=children)

        volumes = [vvm.volume for vvm in data_model.vm_volume_mapping]
        volume_type = volume.VolumeResponse
        vm.volumes = [
            volume_type.from_db_model(volume) for volume in volumes]

        vm.hostname = data_model.agent.hostname

        nic_type = nic.NicResponse
        vm.nics = [nic_type.from_db_model(nic)
                   for nic in data_model.nics]

        return vm


class VirtualMachineRootResponse(types.BaseType):
    vm = wtypes.wsattr(VirtualMachineResponse)


class VirtualMachinesRootResponse(types.BaseType):
    vms = wtypes.wsattr([VirtualMachineResponse])
    vm_links = wtypes.wsattr([types.PageType])


class VirtualMachinePOST(BaseVirtualMachineType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    vcpu = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
    memory_mb = wtypes.wsattr(wtypes.IntegerType(), mandatory=True)
    root_disk_gb = wtypes.wsattr(wtypes.IntegerType())
    image_id = wtypes.wsattr(wtypes.UuidType())
    volumes = wtypes.wsattr(wtypes.ArrayType(volume.VolumeForVMCreate))
    nics = wtypes.wsattr(wtypes.ArrayType(
        wtypes.DictType(str, types.MultiType(str, int, bool))))
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")
    tags = wtypes.wsattr(wtypes.ArrayType(str))
    del_root_disk_on_termination = wtypes.wsattr(bool)


class VirtualMachineRootPOST(types.BaseType):
    vm = wtypes.wsattr(VirtualMachinePOST)


class VirtualMachinePUT(BaseVirtualMachineType):
    """Defines the attributes of a PUT request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    metadata_ = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)), name="metadata")
    tags = wtypes.wsattr(wtypes.ArrayType(str))


class VirtualMachineRootPUT(types.BaseType):
    vm = wtypes.wsattr(VirtualMachinePUT)


class VMActionPOST(types.BaseType):
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE), mandatory=True)
    extended_attr = wtypes.wsattr(wtypes.DictType(
        str, types.MultiType(str, int, bool)))


class VMActionRootPOST(types.BaseType):
    action = wtypes.wsattr(VMActionPOST)
