#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.api.v1.types import network
from trochilus.db import constants as db_const


class BaseAgentType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class AgentResponse(BaseAgentType):
    """Defines which attributes are to be shown on any response."""
    id = wtypes.wsattr(wtypes.UuidType())
    hostname = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    status = wtypes.wsattr(wtypes.StringType())
    heartbeat_timestamp = wtypes.wsattr(wtypes.datetime.datetime)
    mgmt_ip = wtypes.wsattr(types.IPAddressType())
    api_version = wtypes.wsattr(wtypes.StringType())
    total_memory = wtypes.wsattr(wtypes.IntegerType())
    free_memory = wtypes.wsattr(wtypes.IntegerType())
    cpu_used_ratio = wtypes.wsattr(float)
    sys_disk_size = wtypes.wsattr(wtypes.IntegerType())
    sys_disk_used_size = wtypes.wsattr(wtypes.IntegerType())
    system = wtypes.wsattr(wtypes.StringType())
    version = wtypes.wsattr(float)
    cpu_thread = wtypes.wsattr(wtypes.IntegerType())
    cpu_socket = wtypes.wsattr(wtypes.IntegerType())
    cpu_MHZ = wtypes.wsattr(wtypes.StringType())
    cpu_core = wtypes.wsattr(wtypes.IntegerType())
    stepping = wtypes.wsattr(wtypes.IntegerType())
    model = wtypes.wsattr(wtypes.StringType())
    boot_time = wtypes.wsattr(wtypes.datetime.datetime)
    L2_cache = wtypes.wsattr(wtypes.StringType())
    L3_cache = wtypes.wsattr(wtypes.StringType())
    role = wtypes.wsattr(wtypes.ArrayType(wtypes.StringType()))
    networks = wtypes.wsattr(wtypes.ArrayType(network.NetworkResponse))
    disk_names = wtypes.wsattr(wtypes.StringType())
    net_pci_info = wtypes.wsattr(wtypes.ArrayType(wtypes.StringType()))
    host_username = wtypes.wsattr(wtypes.StringType())
    host_password = wtypes.wsattr(wtypes.StringType())
    ipmi_address = wtypes.wsattr(wtypes.StringType())
    ipmi_vendor = wtypes.wsattr(wtypes.StringType())
    ipmi_username = wtypes.wsattr(wtypes.StringType())
    ipmi_password = wtypes.wsattr(wtypes.StringType())

    @classmethod
    def from_db_model(cls, data_model, children=False):
        agent = super(AgentResponse, cls).from_db_model(
            data_model, children=children)

        network_type = network.NetworkResponse
        agent.networks = [network_type.from_db_model(network)
                          for network in data_model.network]

        return agent


class AgentRootResponse(types.BaseType):
    agent = wtypes.wsattr(AgentResponse)


class AgentsRootResponse(types.BaseType):
    agents = wtypes.wsattr([AgentResponse])
    agent_links = wtypes.wsattr([types.PageType])


class AgentPUT(BaseAgentType):
    """Defines the attributes of a PUT request."""
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))


class AgentRootPUT(types.BaseType):
    agent = wtypes.wsattr(AgentPUT)
