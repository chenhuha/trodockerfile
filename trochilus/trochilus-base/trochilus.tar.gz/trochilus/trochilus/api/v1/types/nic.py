#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types
from trochilus.common import constants
from trochilus.db import constants as db_const


class BaseNicType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class IpSubnetMappingResopnse(BaseNicType):
    subnet_id = wtypes.wsattr(wtypes.UuidType())
    ip_address = wtypes.wsattr(wtypes.StringType())


class NicResponse(BaseNicType):
    """Defines which attributes are to be shown on any response."""
    id = wtypes.wsattr(wtypes.UuidType())
    name = wtypes.wsattr(wtypes.StringType())
    description = wtypes.wsattr(wtypes.StringType())
    vpc_id = wtypes.wsattr(wtypes.UuidType())
    mac_address = wtypes.wsattr(wtypes.StringType())
    ip_addresses = wtypes.wsattr([IpSubnetMappingResopnse])
    hostname = wtypes.wsattr(wtypes.StringType())
    owner_id = wtypes.wsattr(wtypes.UuidType())
    owner_type = wtypes.wsattr(wtypes.StringType())
    auto_delete = wtypes.wsattr(wtypes.IntegerType())
    status = wtypes.wsattr(wtypes.StringType())
    project_id = wtypes.wsattr(wtypes.UuidType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    created_at = wtypes.wsattr(wtypes.datetime.datetime)
    updated_at = wtypes.wsattr(wtypes.datetime.datetime)

    @classmethod
    def from_db_model(cls, data_model, children=False):
        nic = super(NicResponse, cls).from_db_model(
            data_model, children=children)

        ip_subnet_type = IpSubnetMappingResopnse
        nic.ip_addresses = [
            ip_subnet_type.from_db_model(ip_address)
            for ip_address in data_model.ip_addresses]

        return nic


class NicRootResponse(types.BaseType):
    nic = wtypes.wsattr(NicResponse)


class NicsRootResponse(types.BaseType):
    nics = wtypes.wsattr([NicResponse])
    nic_links = wtypes.wsattr([types.PageType])


class IpSubnetMappingPUT(types.BaseType):
    ip_address = wtypes.wsattr(types.IPAddressType(), mandatory=True)
    subnet_id = wtypes.wsattr(wtypes.UuidType())


class NicPUT(BaseNicType):
    """Defines the attributes of a PUT request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    ip_addresses = wtypes.wsattr([IpSubnetMappingPUT])
    hostname = wtypes.wsattr(wtypes.StringType())
    owner_id = wtypes.wsattr(wtypes.UuidType())
    owner_type = wtypes.wsattr(wtypes.Enum(str, constants.NIC_OF_DHCP,
                                           constants.NIC_OF_VDI_VM,
                                           constants.NIC_OF_VOI_VM,
                                           constants.NIC_OF_RESERVE))


class NicRootPUT(types.BaseType):
    nic = wtypes.wsattr(NicPUT)


class IpSubnetMappingPOST(types.BaseType):
    ip_address = wtypes.wsattr(types.IPAddressType())
    subnet_id = wtypes.wsattr(wtypes.UuidType(), mandatory=True)


class NicPOST(BaseNicType):
    """Defines the attributes of a POST request."""
    name = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.NAME_FIELD_SIZE))
    description = wtypes.wsattr(
        wtypes.StringType(max_length=db_const.DESCRIPTION_FIELD_SIZE))
    ip_addresses = wtypes.wsattr([IpSubnetMappingPOST], mandatory=True)
    mac_address = wtypes.wsattr(wtypes.StringType())
    owner_type = wtypes.wsattr(wtypes.Enum(str, constants.NIC_OF_DHCP,
                                           constants.NIC_OF_VDI_VM,
                                           constants.NIC_OF_VOI_VM))
    hostname = wtypes.wsattr(wtypes.StringType())
    owner_id = wtypes.wsattr(wtypes.UuidType())
    user_id = wtypes.wsattr(wtypes.UuidType())
    project_id = wtypes.wsattr(wtypes.UuidType())


class NicRootPOST(types.BaseType):
    nic = wtypes.wsattr(NicPOST)
