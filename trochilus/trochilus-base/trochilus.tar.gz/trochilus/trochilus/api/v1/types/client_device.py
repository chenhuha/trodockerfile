#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from wsme import types as wtypes

from trochilus.api.common import types


class BaseClientDeviceType(types.BaseType):
    _type_to_model_map = {}
    _child_map = {}


class ClientDeviceResponse(BaseClientDeviceType):
    id = wtypes.wsattr(wtypes.UuidType())
    vpc_id = wtypes.wsattr(wtypes.StringType())
    mac = wtypes.wsattr(wtypes.StringType())
    ip = wtypes.wsattr(wtypes.StringType())
    last_update = wtypes.wsattr(wtypes.datetime.datetime)


class ClientDeviceRootResponse(types.BaseType):
    client_device = wtypes.wsattr(ClientDeviceResponse)


class ClientDevicesRootResponse(types.BaseType):
    client_device = wtypes.wsattr([ClientDeviceResponse])
