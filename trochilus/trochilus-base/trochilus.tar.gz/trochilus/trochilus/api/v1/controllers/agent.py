#   Copyright 2021 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from oslo_db import api as oslo_db_api
from oslo_db import exception as odb_exceptions
from oslo_log import log as logging
from oslo_utils import excutils
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import agent as agent_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import api as db_api

LOG = logging.getLogger(__name__)


class AgentController(base.BaseController):

    @wsme_pecan.wsexpose(agent_types.AgentRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Gets a agent's detail."""
        context = pecan_request.context.get('trochilus_context')
        db_agent = self.agent.get(context.session, id=id)
        if not db_agent:
            raise exceptions.NotFound(resource='agent', id=id)
        result = self._convert_db_to_type(db_agent,
                                          agent_types.AgentResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return agent_types.AgentRootResponse(agent=result)

    @wsme_pecan.wsexpose(agent_types.AgentsRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """Lists all agents."""
        context = pecan_request.context.get('trochilus_context')
        db_agents, links = self.agent.get_all(
            context.session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(
            db_agents, [agent_types.AgentResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)
        return agent_types.AgentsRootResponse(
            agents=result, agent_links=links)

    @wsme_pecan.wsexpose(agent_types.AgentRootResponse,
                         wtypes.text, status_code=200,
                         body=agent_types.AgentRootPUT)
    def put(self, id, agent_):
        agent = agent_.agent
        context = pecan_request.context.get('trochilus_context')
        with db_api.get_lock_session() as lock_session:
            agent_dict = agent.to_dict(render_unsets=False)
            if agent_dict:
                self.agent.update(lock_session, id, **agent_dict)

        db_agent = self.agent.get(context.session, id=id)
        if not db_agent:
            raise exceptions.NotFound(resource='agent', id=id)

        result = self._convert_db_to_type(db_agent,
                                          agent_types.AgentResponse)
        return agent_types.AgentRootResponse(agent=result)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, agent_id):
        """Deletes a Agent"""
        context = pecan_request.context.get('trochilus_context')

        db_agent = self.agent.get(context.session, id=agent_id)
        if not db_agent:
            raise exceptions.NotFound(resource='agent', id=agent_id)
        if db_agent.status == constants.AGENT_UP:
            raise exceptions.AgentStatusConflict(
                agent_id=agent_id, action='delete', status=constants.AGENT_UP)

        serial_session = db_api.get_session(autocommit=False)
        serial_session.connection(
            execution_options={'isolation_level': 'SERIALIZABLE'})
        try:
            self.agent.delete(serial_session, id=agent_id)
            serial_session.commit()
        # Handle when some resources still reference this agent
        except odb_exceptions.DBReferenceError as e:
            serial_session.rollback()
            raise exceptions.ObjectInUse(object='Agent', id=agent_id) from e
        except Exception as e:
            with excutils.save_and_reraise_exception():
                LOG.error('Unknown agent delete exception: %s', str(e))
                serial_session.rollback()
        finally:
            serial_session.close()

    @pecan_expose()
    def _lookup(self, agent_id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if agent_id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'shutdown':
                return AgentShutdownController(agent_id=agent_id), remainder
        return None


class AgentShutdownController(base.BaseController):
    def __init__(self, agent_id):
        super().__init__()
        self.agent_id = agent_id
        self.agent_client = agent_rest_driver.AgentRestClient()

    @wsme_pecan.wsexpose(None, wtypes.text, status_code=202)
    def put(self):
        """Shutdown trochilus agent"""
        pcontext = pecan_request.context
        context = pcontext.get('trochilus_context')
        db_agent = self.agent.get(context.session, id=self.agent_id)
        if not db_agent:
            raise exceptions.NotFound(resource='agent', id=self.agent_id)
        if db_agent.status == constants.AGENT_DOWN:
            raise exceptions.AgentStatusConflict(
                agent_id=db_agent.id, action='shutdown',
                status=constants.AGENT_DOWN)
        self.agent_client.shutdown_agent(db_agent)
