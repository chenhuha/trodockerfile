#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import math
import os

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import strutils
from oslo_utils import units
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.common import utils as api_utils
from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import voi as voi_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.common import voi_utils
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import nic_repo
from trochilus.db import voi_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class VMController(base.BaseController):
    def __init__(self):
        super().__init__()
        self.image_repo = voi_repo.ImageRepository()
        self.vm_repo = voi_repo.VMRepository()
        self.volume_repo = voi_repo.VolumeRepository()
        self.cd_driver_repo = voi_repo.CDDriverRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.nic_repo = nic_repo.NicRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()

    @wsme_pecan.wsexpose(voi_types.VOIVMsRootResponse, [wtypes.text],
                         ignore_extra_args=True)
    def get_all(self, fields=None):
        context = pecan_request.context.get('trochilus_context')
        db_vms, links = self.vm_repo.get_all(
            context.session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(list(db_vms),
                                          [voi_types.VOIVMResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)

        return voi_types.VOIVMsRootResponse(vms=result,
                                            vm_links=links)

    @wsme_pecan.wsexpose(voi_types.VOIVMRootResponse,
                         wtypes.text, [wtypes.text],
                         ignore_extra_args=True)
    def get_one(self, id, fields=None):
        context = pecan_request.context.get('trochilus_context')
        db_vm = self.vm_repo.get(context.session, id=id)
        if not db_vm:
            raise exceptions.NotFound(resource="voi_vm", id=id)
        result = self._convert_db_to_type(db_vm, voi_types.VOIVMResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return voi_types.VOIVMRootResponse(vm=result)

    @wsme_pecan.wsexpose(voi_types.VOIVMRootResponse,
                         wtypes.text, status_code=200,
                         body=voi_types.VOIVMRootPUT)
    def put(self, id, vm_):
        vm = vm_.vm
        context = pecan_request.context.get('trochilus_context')

        # Check VM exits
        db_vm = self.vm_repo.get(context.session, id=id)
        if not db_vm:
            raise exceptions.NotFound(resource='vm', id=id)

        # Update VM
        with db_api.get_lock_session() as lock_session:
            vm_dict = vm.to_dict(render_unsets=False)
            if vm_dict:
                self.vm_repo.update(lock_session, id, **vm_dict)

        # Show VM
        db_vm = self.vm_repo.get(lock_session, id=id)
        result = self._convert_db_to_type(
            db_vm, voi_types.VOIVMResponse)
        return voi_types.VOIVMRootResponse(vm=result)

    def _validate_create_nic(self, session, db_vm, nics):
        req_ip_addresses = []
        req_nic_ids = []
        for nic_dict in nics:
            subnet_id = nic_dict.get('subnet_id')
            ip = nic_dict.get('ip_address')
            nic_id = nic_dict.get('nic_id')
            if not (nic_id or subnet_id):
                raise exceptions.InvalidRequest(
                    msg='Either nic_id or subnet_id must be specified')
            if nic_id and ip:
                raise exceptions.InvalidRequest(
                    msg='subnet_id and ip_address can be '
                        'specified together')
            if nic_id:
                req_nic_ids.append(nic_id)
            else:
                req_ip_addresses.append(nic_dict)
            # Create nic
            created_nic_ids = self.nic_repo.validate_create_nic_for_vm(
                session, req_ip_addresses, db_vm.id,
                owner_type=constants.NIC_OF_VOI_VM)
            # Update attach info
            req_nic_ids += created_nic_ids
            self.nic_repo.validate_attach_nics(
                session, req_nic_ids, db_vm.id,
                owner_type=constants.NIC_OF_VOI_VM)

    def _validate_create_data_disk(self,
                                   session,
                                   db_vm,
                                   new_disks,
                                   src_vm_disks=None,
                                   path_convert_disks=None,
                                   data_disk_new_size=0):
        # 该虚拟机所有数据盘的列表
        all_disks = []
        src_vm_disks = src_vm_disks or []
        path_convert_disks = path_convert_disks or []
        # 默认被光驱占用的 index 我们定义为 2, 也就是系统中的第三个磁盘设备
        in_used_indexs = [constants.CDROM_DEFAULT_INDEX]
        # 转换被复制的 VM 的数据盘或通过路径创建模板机的 VM 的数据盘, 并记录 index.
        for vm_disk in src_vm_disks or path_convert_disks:
            disk = {}
            index = vm_disk.get('index') \
                if isinstance(vm_disk, dict) else vm_disk.index
            size = vm_disk.get('size') \
                if isinstance(vm_disk, dict) else vm_disk.size
            disk['size'] = max(size, data_disk_new_size)
            disk['vm_id'] = db_vm.id
            disk['status'] = constants.PREPARE_CREATE
            disk['index'] = index
            all_disks.append(disk)
            in_used_indexs.append(index)

        # 数据盘需要创建 volume 数据库记录。这里的 index 很重要，用于生
        # 成数据盘 qcow2 文件的名称和决定挂载的 target dev，
        # index 0 被系统盘占用（系统盘在数据库中没有记录）
        # index 2 被光驱占用, 数据盘 index 从 1 开始
        index = constants.DATA_DISK_START_INDEX
        # 为 new_disks 中的 disk 选择合适的 index
        for new_disk in new_disks:
            if not new_disk.get("size"):
                raise exceptions.VOIDiskRequireSize()
            new_disk['vm_id'] = db_vm.id
            new_disk['status'] = constants.PREPARE_CREATE
            while index in in_used_indexs:
                index += 1
            new_disk['index'] = index
            all_disks.append(new_disk)
            index += 1

        # 创建所有数据卷
        for disk in all_disks:
            self.volume_repo.create(session, **disk)

    def _validate_create_cdrom(
            self, session, db_vm, db_img=None, src_vm_cdrom=None):
        # 如果镜像是 iso 需要插入到光驱
        image_id = db_img.id if db_img and (
            db_img.disk_format == "iso") else None
        # 光驱内配置成被复制的 VM 的镜像
        if src_vm_cdrom:
            image_id = src_vm_cdrom.image_id
            is_sys = src_vm_cdrom.is_sys
        # VOI 模板机默认存在一个光驱, 用来插入 ISO 文件
        self.cd_driver_repo.create(
            session,
            **{"image_id": image_id,
                "vm_id": db_vm.id,
                "is_sys": is_sys if src_vm_cdrom else bool(image_id)})

    def _validate_src_vm_info(self, session, src_vm_id):
        # 检查被复制 VM 的相关信息
        src_db_vm = self.vm_repo.get(session, id=src_vm_id)
        if not src_db_vm:
            raise exceptions.NotFound(resource="voi_vm", id=src_vm_id)
        if src_db_vm.status != constants.STOPPED:
            msg = "The VM status must be stopped."
            raise exceptions.InvalidVMStatus(msg=msg)
        return src_db_vm

    def _validate_image_info(self, session, vm):
        # 校验镜像
        db_img = self.image_repo.get(session, id=vm.image_id)
        if not db_img:
            raise exceptions.NotFound(resource='voi_image', id=vm.image_id)
        if db_img.status != constants.ACTIVE:
            raise exceptions.ImageStatusConflict(img_status=db_img.status)
        # 如果是 qcow2 格式的镜像，默认系统盘大小就是 qcow2 的 virtual size
        if db_img.disk_format != "qcow2" and not vm.root_disk_gb:
            raise exceptions.RequireRootDiskSize(
                format=db_img.disk_format)
        return db_img

    def _validate_path_info(self, src_vm_path):
        root_disk_gb = 0
        path_convert_disks = []
        if not os.path.exists(src_vm_path):
            raise exceptions.InvalidRequest(msg="The directory "
                                            "does not exist")
        vm_base_dir = CONF.voi_setting.voi_vm_base_path
        if src_vm_path.startswith(vm_base_dir):
            raise exceptions.InvalidRequest(msg="Creating VOI VM from this "
                                            "directory is not supported.")

        dirpath, dirnames, filenames = next(os.walk(src_vm_path))
        for filename in filenames:
            disk_path = os.path.join(dirpath, filename)

            # 上传过来的磁盘列表中一定有 incr2 文件
            if constants.INCR2_DISK_NAME in filename and filename.endswith(
                    constants.VOI_DISK_SUFFIX_NAME):
                disk_info = voi_utils.get_qemu_img_info(disk_path)

                # 如果是数据盘 incr2 获取数据盘大小和索引
                if constants.DATA_DISK_PREFIX_NAME in filename:
                    # example:
                    # origin filename "$uuid-data1-base.qcow2"
                    # split filename ['$uuid-', '2-incr2.qcow2']
                    # [1][0] is 2
                    disk_index = filename.split(
                        constants.DATA_DISK_PREFIX_NAME)[1][0]
                    size = math.ceil(disk_info.virtual_size / units.Gi)
                    path_convert_disks.append({
                        "size": size,
                        "index": disk_index
                    })

                # 如果是系统盘 incr2 获取系统盘大小
                if constants.SYS_DISK_PREFIX_NAME in filename:
                    root_disk_gb = math.ceil(
                        disk_info.virtual_size / units.Gi)

        if not root_disk_gb:
            raise exceptions.InvalidRequest(msg='System disk not found.')

        return root_disk_gb, path_convert_disks

    def _validate_create_vm_from_path(self, vm_dict, root_disk_gb):
        vm_dict['root_disk_gb'] = root_disk_gb
        return vm_dict

    def _validate_create_vm_from_image(self, vm_dict, db_img):
        # vm_dict already has vcpu, memory_mb attributes
        root_disk_gb = vm_dict.get('root_disk_gb', 0)
        if not db_img.disk_format == 'iso':
            vm_dict['root_disk_gb'] = root_disk_gb if (
                root_disk_gb * units.Gi > db_img.virtual_size
            ) else math.ceil(db_img.virtual_size / units.Gi)

        return vm_dict

    def _validate_create_vm_from_copy(self, vm_dict, vm, src_db_vm):
        # vm_dict maybe has vcpu, memory_mb attributes
        root_disk_gb = vm_dict.get('root_disk_gb', 0)
        if not root_disk_gb:
            vm_dict['root_disk_gb'] = src_db_vm.root_disk_gb
        else:
            if root_disk_gb < src_db_vm.root_disk_gb:
                msg = ("Root disk size must be larger than the "
                       "source VOI VM.")
                raise exceptions.InvalidRequest(msg=msg)
        vm_dict['image_id'] = src_db_vm.image_id
        vm_dict['vcpu'] = vm.vcpu if vm.vcpu else src_db_vm.vcpu
        vm_dict['memory_mb'] = vm.memory_mb if vm.memory_mb else \
            src_db_vm.memory_mb

        return vm_dict

    @wsme_pecan.wsexpose(voi_types.VOIVMRootResponse,
                         body=voi_types.VOIVMRootPost,
                         status_code=201)
    def post(self, vm_):
        context = pecan_request.context.get('trochilus_context')
        vm = vm_.vm
        vm_dict = vm.to_dict()
        # 获取创建模板机的来源
        src_vm_id = vm_dict.pop("copy_from_vm_id", None)
        src_vm_path = vm_dict.pop("create_from_vm_path", None)
        # 判断是否是复制模板机, 判断是否复制数据盘, 复制的数据盘的新大小
        is_copy = bool(src_vm_id)
        is_copy_data_disk = vm_dict.pop("copy_data_disk", None)
        data_disk_new_size = vm_dict.pop("data_disk_new_size", 0)
        # 判断是否是基于路径创建模板机
        is_path = bool(src_vm_path)
        path_convert_disks = None
        # 默认是基于镜像创建模板机
        db_img = None

        if is_copy:
            src_db_vm = self._validate_src_vm_info(context.session,
                                                   src_vm_id)
            vm_dict = self._validate_create_vm_from_copy(vm_dict,
                                                         vm,
                                                         src_db_vm)
        elif is_path:
            root_disk_gb, path_convert_disks = \
                self._validate_path_info(src_vm_path)
            self._validate_create_vm_from_path(vm_dict,
                                               root_disk_gb)
        else:
            # Create from image
            db_img = self._validate_image_info(context.session, vm)
            vm_dict = self._validate_create_vm_from_image(vm_dict, db_img)

        # 这里先选择一个 agent 准备创建 vm 的数据库记录，后面网卡，卷和光
        # 驱的创建都要依赖 vm 的 id，所以 vm db 要先创建出来
        agent = self.agent_repo.get_agent_randomly(context.session)
        if not agent:
            raise exceptions.AgentUnavailable()

        # 配置 vm_dict 其他参数
        nics = vm_dict.pop("nics", [])
        disks = vm_dict.pop("disks", [])
        vm_dict['status'] = constants.PREPARE_CREATE
        vm_dict['agent_id'] = agent.id

        with db_api.get_lock_session() as lock_session:
            # 首先创建 VM 数据库记录
            db_vm = self.vm_repo.create(lock_session, **vm_dict)

            # 配置光驱
            if is_copy:
                self._validate_create_cdrom(
                    lock_session,
                    db_vm,
                    src_vm_cdrom=src_db_vm.cd_drivers[0])
            else:
                self._validate_create_cdrom(lock_session,
                                            db_vm,
                                            db_img=db_img)

            # 配置数据盘
            if is_copy and is_copy_data_disk:
                self._validate_create_data_disk(
                    lock_session,
                    db_vm,
                    disks,
                    src_vm_disks=src_db_vm.disks,
                    data_disk_new_size=data_disk_new_size)
            else:
                self._validate_create_data_disk(
                    lock_session,
                    db_vm,
                    disks,
                    path_convert_disks=path_convert_disks)

            # 配置网卡
            self._validate_create_nic(lock_session, db_vm, nics)

        # 通知 agent 创建 vm
        self.agent_client.create_voi_vm(
            agent, **{
                "id": db_vm.id,
                "src_vm_id": src_vm_id if is_copy else None,
                "is_copy_data_disk": is_copy_data_disk,
                "src_vm_path": src_vm_path})

        db_vm_ = self.vm_repo.get(context.session, id=db_vm.id)
        result = self._convert_db_to_type(db_vm_, voi_types.VOIVMResponse)
        return voi_types.VOIVMRootResponse(vm=result)

    @wsme_pecan.wsexpose(
        None, wtypes.text, status_code=204)
    def delete(self, id):
        context = pecan_request.context.get('trochilus_context')
        db_vm = self.vm_repo.get(context.session, id=id)
        if not db_vm:
            raise exceptions.NotFound(resource="voi_vm", id=id)
        self.vm_repo.update(
            context.session, id,
            **{"status": constants.PREPARE_DELETE})
        for nic in db_vm.nics:
            self.nic_repo.delete(context.session, id=nic.id)
        for disk in db_vm.disks:
            self.volume_repo.update(
                context.session, id=disk.id,
                **{"status": constants.DELETED})
        if db_vm.cd_drivers:
            self.cd_driver_repo.delete(
                context.session, id=db_vm.cd_drivers[0].id)
        agent = self.agent_repo.get(context.session, id=db_vm.agent_id)
        self.agent_client.delete_voi_vm(agent, **{"id": db_vm.id})

    @pecan_expose()
    def _lookup(self, id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'action':
                return VOIVMActionController(id=id), remainder
            if controller == 'disk_detail':
                return VOIDiskDetailController(id=id), remainder
        return None


class VOIVMActionController(base.BaseController):
    def __init__(self, id):
        super().__init__()
        self.id = id
        self.vm_repo = voi_repo.VMRepository()
        self.image_repo = voi_repo.ImageRepository()
        self.volume_repo = voi_repo.VolumeRepository()
        self.share_tmpl_vol_repo = voi_repo.ShareTemplateVolumeRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()

    @wsme_pecan.wsexpose(body=voi_types.VMActionRootPOST, status_code=201)
    def post(self, action_):
        action = action_.action

        session = pecan_request.context.get('trochilus_context').session
        db_vm = self.vm_repo.get(session, id=self.id)

        # Check if vm exists
        if not db_vm:
            LOG.debug("vm %(vm_id)s does not exist.", {'vm_id': self.id})
            raise exceptions.NotFound(resource='vm', id=self.id)

        try:
            action_func = getattr(self, action.name)
        except Exception as e:
            raise exceptions.UnsupportVMAction(action_name=action.name) from e

        action_dict = action.to_dict()
        action_func(session, db_vm, action_dict)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE])
    def stop(self, session, db_vm, action_dict):
        stop_extended_attr = action_dict.get('extended_attr', {})
        force_stop = strutils.bool_from_string(
            stop_extended_attr.get('force', False))
        self.vm_repo.update(
            session, db_vm.id,
            **{"status": constants.PREPARE_STOP})

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.stop_voi_vm(agent, id=self.id, force_stop=force_stop)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(
        vm_state=[constants.STOPPED, constants.PREPARE_START])
    def start(self, session, db_vm, action_dict):
        self.vm_repo.update(
            session, db_vm.id,
            **{"status": constants.PREPARE_START})
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.start_voi_vm(agent, id=self.id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE, constants.STOPPED])
    def reboot(self, session, db_vm, action_dict):
        reboot_extended_attr = action_dict.get("extended_attr", {})
        reboot_type = reboot_extended_attr.get('type', "SOFT").upper()

        if db_vm.status == constants.STOPPED and reboot_type == 'SOFT':
            raise exceptions.VMInvalidState(vm_id=db_vm.id,
                                            state=db_vm.status,
                                            method="reboot")

        LOG.info("Rebooting VOI VM %s with id: %s", reboot_type, self.id)

        self.vm_repo.update(session, self.id, status=constants.PREPARE_REBOOT)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.reboot_voi_vm(agent,
                                        id=self.id,
                                        reboot_type=reboot_type)

    def _validate_host_for_cold_migrate(self, session, db_vm, migrate_host):
        if migrate_host == db_vm.agent.hostname:
            raise exceptions.CannotMigrateToSameHost()
        if not self.agent_repo.get_all(session,
                                       hostname=migrate_host,
                                       status=constants.AGENT_UP)[0]:
            raise exceptions.AgentUnavailable

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def migrate(self, session, db_vm, action_dict):
        """Migrate VM to another host"""
        maigate_extended_attr = action_dict.get("extended_attr", {})
        migrate_host = maigate_extended_attr.get('host', None)
        migrate_agent_id = maigate_extended_attr.get('agent_id', None)

        if not migrate_host and not migrate_agent_id:
            # TODO(liupeng): Real scheduling mechanism in the future
            agent_all = self.agent_repo.get_all(
                session, exclude_agents=[db_vm.agent.hostname])
            agent = api_utils.scheduler_agent(agent_all)
            migrate_host = agent.hostname
        # migrate_agent_id is ignored if migrate_host is passed
        elif migrate_agent_id and not migrate_host:
            agent_obj = self.agent_repo.get(session, id=migrate_agent_id)
            if not agent_obj:
                raise exceptions.NotFound(
                    resource='agent', id=migrate_agent_id)
            migrate_host = agent_obj.hostname

        self._validate_host_for_cold_migrate(session, db_vm, migrate_host)

        LOG.info("Migrating VOI VM with id: %s, to %s", self.id, migrate_host)

        self.vm_repo.update(session, self.id, status=constants.PREPARE_MIGRATE)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.migrate_voi_vm(agent,
                                         id=self.id,
                                         migrate_host=migrate_host)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED, constants.ACTIVE])
    def reset(self, session, db_vm, action_dict):
        """Reset VOI VM"""
        LOG.info("Revertting VOI VM with id: %s.", self.id)
        self.vm_repo.update(session, self.id, status=constants.PREPARE_RESET)
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.reset_voi_vm(agent, id=self.id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED, constants.ACTIVE])
    def replace_iso(self, session, db_vm, action_dict):
        """Replace iso image"""
        replace_extended_attr = action_dict.get("extended_attr", {})
        image_id = replace_extended_attr.get('image_id', None)
        origin_vm_status = db_vm.status

        if image_id:
            # Check image info
            db_img = self.image_repo.get(session, id=image_id)
            if not db_img:
                raise exceptions.NotFound(resource="voi_image", id=image_id)
            if db_img.status != constants.IMAGE_ACTIVE:
                raise exceptions.InvalidImageStatus()
            if db_img.disk_format != 'iso':
                msg = 'Replace iso image format must be iso'
                raise exceptions.ImageFormatCheckFaild(msg=msg)
        else:
            # Exclude the case of empty strings
            image_id = None

        LOG.info("Replace iso image for VM with id: %s.", self.id)
        self.vm_repo.update(session,
                            self.id,
                            status=constants.PREPARE_REPLACE_ISO)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.replace_iso_voi_vm(agent,
                                             id=self.id,
                                             origin_vm_status=origin_vm_status,
                                             iso_image_id=image_id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def commit(self, session, db_vm, action_dict):
        LOG.info("Commit VOI VM %s.", self.id)
        self.vm_repo.update(session, self.id, status=constants.PREPARE_COMMIT)
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.commit_voi_vm(agent, id=self.id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def add_volume(self, session, db_vm, action_dict):
        LOG.info("VOI VM %s add volume.", self.id)
        add_volume_extended_attr = action_dict.get("extended_attr", {})
        origin_vm_status = db_vm.status

        # Check extended_attr
        if add_volume_extended_attr:
            size = add_volume_extended_attr.get('size', None)
            if not size:
                raise exceptions.VOIDiskRequireSize()
            if not isinstance(size, int) or (size < 0):
                msg = "The disk size must be an integer greater than zero"
                raise exceptions.InvalidRequest(msg=msg)
        else:
            raise exceptions.VOIDiskRequireSize()

        # Create data disk
        disk = {}
        disk['vm_id'] = db_vm.id
        disk['status'] = constants.PREPARE_CREATE
        disk['size'] = size
        # Compute disk index
        # Data disk index start from 1
        # 0 is system disk
        # 2 is cdrom
        index = constants.DATA_DISK_START_INDEX
        for db_disk in sorted(db_vm.disks, key=lambda i: i.index):
            # 跳过索引为 2 的(被 cdrom 占用)
            if index == constants.CDROM_DEFAULT_INDEX:
                index += 1
            if db_disk.index == index:
                index += 1
                continue
            break
        disk['index'] = index
        db_volume = self.volume_repo.create(session, **disk)

        self.vm_repo.update(
            session, self.id, status=constants.PREPARE_ADD_VOLUME)
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.add_volume_voi_vm(
            agent, id=self.id, origin_vm_status=origin_vm_status,
            volume_id=db_volume.id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def remove_volume(self, session, db_vm, action_dict):
        LOG.info("VOI VM %s remove volume.", self.id)
        origin_vm_status = db_vm.status
        remove_volume_extended_attr = action_dict.get("extended_attr", {})

        # Check extended_attr
        if not remove_volume_extended_attr:
            raise exceptions.VOIRemoveMustVolumeId()
        volume_id = remove_volume_extended_attr.get('volume_id', None)
        if not volume_id:
            raise exceptions.VOIRemoveMustVolumeId()
        db_volume = self.volume_repo.get(session, id=volume_id)
        if not db_volume:
            raise exceptions.NotFound(resource='volume', id=volume_id)
        if self.id != db_volume.vm_id:
            raise exceptions.InvalidRequest(
                msg="This volume does not belong to this VOI VM")

        # Update volume and VOI VM status
        self.volume_repo.update(
            session, volume_id, status=constants.PREPARE_DELETE)
        self.vm_repo.update(
            session, self.id, status=constants.PREPARE_REMOVE_VOLUME)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.remove_volume_voi_vm(
            agent, id=self.id, origin_vm_status=origin_vm_status,
            volume_id=volume_id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def attach_share_template_volume(self, session, db_vm, action_dict):
        extended_attr = action_dict.get("extended_attr", {})
        volume_id = extended_attr.get('volume_id')
        origin_vm_status = db_vm.status
        LOG.info("VOI VM %s attaching share template volume %s.", self.id,
                 volume_id)

        # Checkout if volume exits
        if not volume_id:
            raise exceptions.InvalidRequest(msg='share template volume'
                                                'volume_id must be present')
        db_volume = self.share_tmpl_vol_repo.get(session, id=volume_id)
        if not db_volume:
            LOG.debug("Fail to attach share template volume %(volume_id)s, "
                      "because share template volume does no exist.",
                      {'volume_id': volume_id})
            raise exceptions.NotFound(resource='voi share template volume',
                                      id=volume_id)

        with db_api.get_lock_session() as lock_session:
            # When preventing concurrent attach volume,chance to happen,
            # duplicate attached index are generated.
            db_share_disk_templates, _ = self.share_tmpl_vol_repo.get_all(
                lock_session, lock=True, vm_id=self.id)
            max_index = 10
            index_list = [tmpl.index for tmpl in db_share_disk_templates]
            for x in index_list:
                if max_index not in index_list:
                    break
                max_index += 1

            if self.share_tmpl_vol_repo.update(
                lock_session, volume_id, expected_status=constants.AVAILABLE,
                **{'status': constants.PREPARE_ATTACH,
                   'vm_id': self.id,
                   'index': max_index}) < 1:
                raise exceptions.StatusConflict(
                    id=volume_id,
                    resource='voi share template volume',
                    status=db_volume.status)

            self.vm_repo.update(lock_session, self.id,
                                status=constants.PREPARE_VOLUME_ATTACH)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.attach_share_template_volume(
            agent, id=db_vm.id, origin_vm_status=origin_vm_status,
            volume_id=volume_id)

    @api_utils.check_vm_agent()
    def detach_share_template_volume(self, session, db_vm, action_dict):
        """Detach volume"""
        extended_attr = action_dict.get("extended_attr", {})
        volume_id = extended_attr.get('volume_id')
        LOG.info("VOI VM %s detaching share template volume %s.", self.id,
                 volume_id)

        # Check vm status
        if db_vm.status not in [constants.PREPARE_VOLUME_DETACH,
                                constants.VOLUME_DETACHING,
                                constants.STOPPED]:
            raise exceptions.VMInvalidState(
                vm_id=db_vm.id,
                state=db_vm.status,
                method='detach_share_template_volume')

        # Check if volume exists
        if not volume_id:
            raise exceptions.InvalidRequest(msg='voi share template volume '
                                                'volume_id must be present')
        db_volume = self.share_tmpl_vol_repo.get(session, id=volume_id)
        if not db_volume:
            LOG.debug("Fail to attach share template volume %(volume_id)s, "
                      "because share volume template does no exist.",
                      {'volume_id': volume_id})
            raise exceptions.NotFound(resource='voi share template volume',
                                      id=volume_id)

        with db_api.get_lock_session() as lock_session:
            if self.share_tmpl_vol_repo.update(
                    lock_session, volume_id, expected_status=constants.IN_USE,
                    **{'status': constants.PREPARE_DETACH}) < 1:
                raise exceptions.StatusConflict(
                    id=volume_id,
                    resource='voi share template volume',
                    status=db_volume.status)

            self.vm_repo.update(session, self.id,
                                status=constants.PREPARE_VOLUME_DETACH,
                                expected_status=constants.STOPPED)
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.detach_share_template_volume(
            agent, id=db_vm.id, origin_vm_status=constants.STOPPED,
            volume_id=db_volume.id)


class VOIDiskDetailController(base.BaseController):

    def __init__(self, id):
        super().__init__()
        self.id = id
        self.vm_repo = voi_repo.VMRepository()

    @wsme_pecan.wsexpose(voi_types.DiskDetailsRootResponse, wtypes.text,
                         status_code=200)
    def get(self):
        session = pecan_request.context.get('trochilus_context').session
        db_vm = self.vm_repo.get(session, id=self.id)

        # Check if vm exists
        if not db_vm:
            LOG.debug("VOI VM %(vm_id)s does not exist.", {'vm_id': self.id})
            raise exceptions.NotFound(resource='vm', id=self.id)

        disk_details = []
        # Get VOI VM base dir
        vm_base_dir = CONF.voi_setting.voi_vm_base_path
        vm_dir = os.path.join(vm_base_dir, db_vm.id)
        # Add sys disk
        vm_disks = list(db_vm.disks)
        vm_disks.insert(0, constants.SYS_DISK_PREFIX_NAME)

        for disk in vm_disks:
            for middle_name in [constants.BASE_DISK_NAME,
                                constants.INCR1_DISK_NAME,
                                constants.INCR2_DISK_NAME]:
                # Generate disk path
                disk_prefix_name = constants.SYS_DISK_PREFIX_NAME \
                    if disk == constants.SYS_DISK_PREFIX_NAME \
                    else constants.DATA_DISK_PREFIX_NAME + str(disk.index)
                disk_name_unique_uuid = db_vm.id \
                    if disk == constants.SYS_DISK_PREFIX_NAME else disk.id
                disk_full_name = \
                    disk_name_unique_uuid + "-" + \
                    disk_prefix_name + "-" + \
                    middle_name + "." + \
                    constants.VOI_DISK_SUFFIX_NAME
                path = os.path.join(vm_dir, disk_full_name)
                # Get disk really size
                really_size = 0
                if os.path.exists(path):
                    data = voi_utils.get_qemu_img_info(path)
                    really_size = data.disk_size
                disk_details.append(voi_types.DiskDetailResponse(**{
                    "index": 0 if disk == constants.SYS_DISK_PREFIX_NAME
                    else disk.index,
                    "path": path,
                    'size': really_size,
                    'name': disk_full_name,
                    'type': middle_name
                }))

        return voi_types.DiskDetailsRootResponse(disk_details=disk_details)
