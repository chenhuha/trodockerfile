#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from oslo_config import cfg
from oslo_db import api as oslo_db_api
from oslo_log import log as logging
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import vpc as vpc_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import dhcp_repo
from trochilus.db import subnet_repo
from trochilus.db import vpc_repo
from trochilus.i18n import _


CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class VPCController(base.BaseController):

    def __init__(self):
        super().__init__()
        self.vpc_repo = vpc_repo.VpcRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.agentVpcController = AgentVpcController()
        self.dhcp_repo = dhcp_repo.DhcpNodeMappingRepository()
        self.subnet_repo = subnet_repo.SubnetRepository()

    @wsme_pecan.wsexpose(vpc_types.VpcRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Gets a vpc's details."""
        session = pecan_request.context.get('trochilus_context').session

        db_vpc = self.vpc_repo.get(session, id=id)

        if not db_vpc:
            raise exceptions.NotFound(resource='vpc', id=id)

        result = self._convert_db_to_type(db_vpc,
                                          vpc_types.VpcResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return vpc_types.VpcRootResponse(vpc=result)

    @wsme_pecan.wsexpose(vpc_types.VpcsRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """Lists all vpcs."""
        session = pecan_request.context.get('trochilus_context').session

        db_vpcs, links = self.vpc_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(list(db_vpcs),
                                          [vpc_types.VpcResponse])

        if fields is not None:
            result = self._filter_fields(result, fields)
        return vpc_types.VpcsRootResponse(vpcs=result, vpc_links=links)

    @wsme_pecan.wsexpose(vpc_types.VpcRootResponse,
                         wtypes.text, status_code=200,
                         body=vpc_types.VpcRootPUT)
    def put(self, id, vpc_):
        """Updates a vpc."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.debug("Updating vpc with id: %s", id)
        db_vpc = self.vpc_repo.get(session, id=id)

        if not db_vpc:
            raise exceptions.NotFound(resource='vpc', id=id)

        with db_api.get_lock_session() as lock_session:
            # Prepare the data for vpc operation.
            vpc_dict = vpc_.vpc.to_dict(render_unsets=False)
            if vpc_dict:
                self.vpc_repo.update(lock_session, id, **vpc_dict)

        # Force SQL alchemy to query the DB for ensure consistent results
        session.expire_all()
        db_vpc_ = self.vpc_repo.get(session, id=id)
        result = self._convert_db_to_type(db_vpc_,
                                          vpc_types.VpcResponse)
        return vpc_types.VpcRootResponse(vpc=result)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """Deletes a vpc record in database."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.debug("Deleting vpc with id: %s", id)

        db_vpc = self.vpc_repo.get(session, id=id)
        if not db_vpc:
            raise exceptions.NotFound(resource='vpc', id=id)
        if db_vpc.status in constants.DELETE_BAN:
            raise exceptions.DeleteConflict(
                resource='vpc', id=id, status=db_vpc.status)

        # Retrieve subnets information within a VPC
        db_subnets, _ = self.subnet_repo.get_all(session, vpc_id=id)

        with db_api.get_lock_session() as lock_session:
            if db_subnets:
                self._clear_subnets_within_vpc(session, id, db_subnets)
            self.vpc_repo.update(lock_session, id,
                                 **{'status': constants.PREPARE_DELETE})

        agents, links = self.agent_repo.get_all(session)
        if agents:
            self.agent_client.delete_vpc(agents, id=id)
        self.dhcp_repo.notify_dhcp_agent_if_need(constants.DELETE_VPC,
                                                 db_vpc.id,
                                                 delete_dhcp_nics=True)

    def _clear_subnets_within_vpc(self, lock_session, vpc_id, db_subnets):

        subnets_id = []
        for db_subnet in db_subnets:
            # If there is a nic in the subnet(except dhcp nic),
            # it is forbidden to delete it
            if db_subnet.alloc_ip_addresses:
                for alloc in db_subnet.alloc_ip_addresses:
                    if alloc.nic.owner_type != constants.NIC_OF_DHCP:
                        raise exceptions.ObjectInUse(object='subnet',
                                                     id=db_subnet.id)
            subnets_id.append(db_subnet.id)
        try:
            self.dhcp_repo.delete_dhcp_nics(lock_session, vpc_id)
            self.subnet_repo.delete_batch(lock_session, subnets_id)
        except Exception as e:
            raise exceptions.SubnetDeleteBatchFaild(
                subnets_id=subnets_id) from e

    @wsme_pecan.wsexpose(vpc_types.VpcRootResponse,
                         wtypes.text, status_code=200,
                         body=vpc_types.VpcRootPOST)
    def post(self, vpc_):
        """Creates a vpc."""
        session = pecan_request.context.get('trochilus_context').session
        vpc_dict = vpc_.vpc.to_dict()
        physical_obj = self.physical_repo.get_one(vpc_dict['physical'])
        if not physical_obj:
            raise exceptions.NotFound(
                resource='physical', id=vpc_dict['physical'])
        if vpc_dict['type'] == constants.VLAN:
            # If use specify a vlan id, we need to check whether it is valid
            if vpc_dict.get('vlan_id'):
                if not self.physical_repo.verify_vlan_id(
                        vpc_dict['physical'], vpc_dict.get('vlan_id')):
                    reason = _("the vlan id out of physical valn range")
                    raise exceptions.InvalidVlanId(
                        vlan_id=vpc_dict.get('vlan_id'), reason=reason)
                if self.vpc_repo.get(
                        session, physical=vpc_dict['physical'],
                        vlan_id=vpc_dict['vlan_id']):
                    reason = _("the vlan id already be used")
                    raise exceptions.InvalidVlanId(
                        vlan_id=vpc_dict.get('vlan_id'), reason=reason)
            else:
                exist_vlans = []
                vpc_objs, link = self.vpc_repo.get_all(
                    session, **{'physical': vpc_dict['physical'],
                                'type': constants.VLAN})
                for vpc_obj in vpc_objs:
                    exist_vlans.append(vpc_obj.vlan_id)
                # Try to allocate a vlan id automatically
                vlan_id = self.physical_repo.allocate_vlan_id(
                    vpc_dict['physical'], exist_vlans)
                if not vlan_id:
                    raise exceptions.VlanIdExhausted(
                        physical=vpc_dict['physical'])
                vpc_dict['vlan_id'] = vlan_id
        if vpc_dict['type'] == constants.FLAT:
            if not physical_obj['support_flat']:
                raise exceptions.InvalidPhysicalVpcType(
                    physical=vpc_dict['physical'], type=vpc_dict['type'])
            # One physical only one flat vpc
            vpc_objs, link = self.vpc_repo.get_all(
                session, **{'physical': vpc_dict['physical'],
                            'type': constants.FLAT})
            if vpc_objs:
                raise exceptions.PyhsicalFlatVpcAlreadyExist(
                    physical=vpc_dict['physical'])

        """create vpc"""
        vpc_dict['status'] = constants.PREPARE_CREATE
        db_vpc = self.vpc_repo.create(session, **vpc_dict)
        vpc_dict['id'] = db_vpc.id
        agents, links = self.agent_repo.get_all(session)
        if agents:
            self.agent_client.create_vpc(agents, **vpc_dict)

        db_vpc_ = self.vpc_repo.get(session, id=db_vpc.id)
        result = self._convert_db_to_type(db_vpc_, vpc_types.VpcResponse)
        return vpc_types.VpcRootResponse(vpc=result)

    @pecan_expose()
    def _lookup(self, vpc_id, *remainder):
        if vpc_id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'agents':
                pecan_request.context['vpc_id'] = vpc_id
                return self.agentVpcController, remainder
        return None


class AgentVpcController(base.BaseController):

    def __init__(self):
        super().__init__()
        self.vpc_node_repo = vpc_repo.VpcNodeMappingRepository()

    @wsme_pecan.wsexpose(vpc_types.VpcNodeMappingRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        session = pecan_request.context.get('trochilus_context').session
        mappings, links = self.vpc_node_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'),
            **{'vpc_id': pecan_request.context.get('vpc_id')})
        result = self._convert_db_to_type(list(mappings),
                                          [vpc_types.VpcNodeMappingResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)
        return vpc_types.VpcNodeMappingRootResponse(statuses=result,
                                                    status_links=links)
