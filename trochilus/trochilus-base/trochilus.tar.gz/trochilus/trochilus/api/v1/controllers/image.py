#   Copyright 2021 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

import os

from oslo_config import cfg
from oslo_db import api as oslo_db_api
from oslo_log import log as logging
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import image as image_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import api as db_api
from trochilus.db import image_repo
from trochilus.image import format_converter
from trochilus.image import format_inspector
from trochilus.image.image_store import filesystem_store
from trochilus.image.image_store.store import get_story

LOG = logging.getLogger(__name__)
CONF = cfg.CONF


class ImageController(base.BaseController):
    def __init__(self):
        super().__init__()
        self.image_repo = image_repo.ImageRepository()

    @wsme_pecan.wsexpose(image_types.ImageRootResponse,
                         wtypes.text, [wtypes.text],
                         ignore_extra_args=True)
    def get_one(self, id, fields=None):
        context = pecan_request.context.get('trochilus_context')

        db_img = self.image_repo.get(context.session, id)
        result = self._convert_db_to_type(db_img, image_types.ImageResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]

        return image_types.ImageRootResponse(image=result)

    @wsme_pecan.wsexpose(image_types.ImagesRootResponse, [wtypes.text],
                         ignore_extra_args=True)
    def get_all(self, fields=None):
        context = pecan_request.context.get('trochilus_context')

        db_imgs, links = self.image_repo.get_all(
            context.session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(list(db_imgs),
                                          [image_types.ImageResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)

        return image_types.ImagesRootResponse(images=result, image_links=links)

    @wsme_pecan.wsexpose(image_types.ImageRootResponse,
                         body=image_types.ImageRootPOST, status_code=201)
    def post(self, image_):
        """craete image record in database"""
        context = pecan_request.context.get('trochilus_context')

        image = image_.image
        image_dict = image.to_dict()
        image_dict['status'] = constants.IMAGE_QUEUED

        image_model = self.image_repo.create(context.session, **image_dict)
        result = self._convert_db_to_type(
            image_model, image_types.ImageResponse) if image_model.id else None

        return image_types.ImageRootResponse(image=result)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """delete image record in database and storage"""
        context = pecan_request.context.get('trochilus_context')
        store = get_story()

        db_img = self.image_repo.get(context.session, id)
        LOG.info("Deleting image %s with status %s.", id, db_img.status)

        try:
            store.delete(db_img.location, image_id=id)
        except exceptions.ImageFileNotFound:
            LOG.warning("The image file does not exist: %s. We continue"
                        " to delete records from the database", id)
        except exceptions.HasSnapshot as e:
            if db_img.status == constants.IMAGE_SAVING:
                LOG.warning("The image %s maybe upload completed, and the "
                            "image status is saving, but a "
                            "request to delete the image has been initiated,"
                            " and we will delete the image later.", id)
            else:
                LOG.warning(
                    "Remove image %s failed. It has snapshot(s) left.", id)
                raise e
        except exceptions.InUseByStore as e:
            if db_img.status == constants.IMAGE_SAVING:
                LOG.warning("The image %s maybe being uploaded, but a "
                            "request to delete the image has been initiated,"
                            " and we will delete the image later.", id)
            else:
                LOG.warning("Remove image %s failed. It is in use.", id)
                raise e
        except Exception as e:
            LOG.error("An unknown error when deleting a image %s: ", id)
            db_img.status = constants.IMAGE_ERROR
            db_img.save(context.session)
            raise e

        self.image_repo.update(context.session, id=id,
                               status=constants.DELETED)
        LOG.info("Image %s deleted successfully.", id)

    @wsme_pecan.wsexpose(image_types.ImageRootResponse,
                         wtypes.text, status_code=200,
                         body=image_types.ImageRootPUT)
    def put(self, id, _image):
        image = _image.image
        context = pecan_request.context.get('trochilus_context')
        with db_api.get_lock_session() as lock_session:
            image_dict = image.to_dict(render_unsets=False)
            if image_dict:
                self.image_repo.update(lock_session, id, **image_dict)

        db_img = self.image_repo.get(context.session, id)

        result = self._convert_db_to_type(db_img, image_types.ImageResponse)
        return image_types.ImageRootResponse(image=result)

    @pecan_expose()
    def _lookup(self, id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'file':
                return ImageDataController(id=id), remainder
        return None


class ImageDataController(base.BaseController):

    def __init__(self, id):
        super().__init__()
        self.id = id
        self.image_repo = image_repo.ImageRepository()

    def _restore(self, session, db_img):
        """Restore the image to queued status."""
        try:
            db_img.status = constants.IMAGE_QUEUED
            db_img.save(session)
        except Exception as e:
            msg = ("Unable to restore image %(image_id)s: %(e)s") % {
                'image_id': db_img.id, 'e': e}
            LOG.exception(msg)

    @pecan_expose()
    def get(self):
        context = pecan_request.context.get('trochilus_context')
        db_img = self.image_repo.get(context.session, self.id)
        store = get_story()

        if db_img.location:
            store.download(db_img.location, image_id=self.id)
        else:
            LOG.warning("The image file does not exist: %s", self.id)
            raise exceptions.ImageFileNotFound(image=self.id)

    # TODO(liupeng) Optimize response
    # Since wsme_pecan does not support application/octet-stream
    # we use pecan_expose, But rendering support for exceptions
    # is not very friendly
    @pecan_expose()
    def put(self):
        """Upload image file"""
        context = pecan_request.context.get('trochilus_context')

        db_img = self.image_repo.get(context.session, self.id)
        if db_img.status != constants.IMAGE_QUEUED:
            LOG.error("The status of the current iamge is %s. "
                      "Upload file is not allowed", db_img.status)
            raise exceptions.ImageStatusConflict(img_status=db_img.status)

        data = pecan_request.body_file
        disk_format = db_img.disk_format

        # Content Length is not always available
        image_length = pecan_request.content_length
        if image_length:
            LOG.debug("The image file content length is %s. "
                      "If the store is RBD, "
                      "the upload speed can be accelerated",
                      image_length)
            db_img.size = image_length

        # Check the information about uploaded files.
        # The value includes the format of the uploaded file and
        # the virtual size of the virtual disk and so on.
        inspector = format_inspector.get_inspector(disk_format)
        if inspector:
            fmt = inspector()
            data = format_inspector.InfoWrapper(
                data, fmt, image=db_img)
            LOG.debug('Format inspection for %s', fmt)
        else:
            raise exceptions.ImageFormatNotSupport()

        db_img.status = constants.IMAGE_SAVING
        db_img.save(context.session)
        LOG.info('The image %s status is changed to saving, '
                 'and the image uploading start', self.id)

        auto_convert = bool(pecan_request.headers.get('X-Image-Auto-Convert'))
        if auto_convert and disk_format == 'qcow2':
            LOG.info('The image format is qcow2 and request parameter '
                     'named auto_convert is true, so store in a local '
                     'temporary directory %s ',
                     CONF.image_settings.tmp_image_dir)
            if not os.path.exists(CONF.image_settings.tmp_image_dir):
                os.makedirs(CONF.image_settings.tmp_image_dir)

            local_store = filesystem_store.FilesystemStore(
                CONF.image_settings.tmp_image_dir)
            try:
                qcow2_img_location, _, _ = local_store.add(
                    db_img.id + '.qcow2', data,
                    image_size=db_img.size if db_img.size else 0)
            except Exception as e:
                LOG.error('Fail to store in a local temporary directory %s,'
                          'the exception is %s',
                          CONF.image_settings.tmp_image_dir, e)
                self._restore(context.session, db_img)
                raise e

            LOG.info('The image upload to local temporary directory is '
                     'completed, start to convert qcow2 to raw')
            try:
                raw_img_location = format_converter.convert_qcow2_to_raw(
                    qcow2_img_location)
            except Exception as e:
                LOG.error("Fail to onvert qcow2 to raw, the exception is %s",
                          e)
                self._restore(context.session, db_img)
                raise e

            LOG.info('The image convert qcow2 to raw is completed, delete '
                     'qcow2 image')
            try:
                local_store.delete(qcow2_img_location)
            except Exception as e:
                LOG.error("Fail to delete qcow2 image %s, the exception is %s",
                          qcow2_img_location, e)
                self._restore(context.session, db_img)
                raise e

            LOG.info('Start to store in backend store')
            # Build data to store raw image
            tmp_file = open(raw_img_location, 'rb')  # pylint: disable=R1732
            inspector = format_inspector.get_inspector('raw')
            db_img.disk_format = 'raw'
            db_img.size = os.stat(raw_img_location).st_size
            data = format_inspector.InfoWrapper(tmp_file, inspector(),
                                                image=db_img)

        store = get_story()
        try:
            db_img.location, db_img.size, db_img.checksum = store.add(
                db_img.id, data, image_size=db_img.size if db_img.size else 0)
            # If the disk format is RAW then the virtual size
            # is equal to the image size
            if disk_format == "raw":
                db_img.virtual_size = db_img.size
        except exceptions.ImageSizeLimitExceeded as e:
            LOG.error("The incoming image is too large")
            self._restore(context.session, db_img)
            raise e
        except Exception as e:
            LOG.error(
                "Image upload failed: %s.", db_img.id)
            self._restore(context.session, db_img)
            raise e
        finally:
            if auto_convert and disk_format == 'qcow2':
                tmp_file.close()
                local_store.delete(raw_img_location)

        # Query whether the image was deleted during upload
        current_db_img = self.image_repo.get(
            context.session, db_img.id, show_deleted=True)
        if current_db_img.status == constants.IMAGE_DELETED:
            LOG.warning("Image %s uploading completed, but the user performed "
                        "the delete image, try to delete the image", self.id)
            try:
                # If executed here, there is a high probability that
                # the image can be deleted.
                # If there is an exception, we set the status to error.
                # For error, we may need to manually clear the image in storage
                store.delete(db_img.location, db_img.id)
                return
            except Exception as e:
                LOG.error("In upload image method: "
                          "An unknown error when deleting a image %s: ", id)
                db_img.status = constants.IMAGE_ERROR
                db_img.save(context.session)
                raise e

        LOG.info('Image %s uploading completed', self.id)

        # Record on which host the image was uploaded
        db_img.metadata_.update(ip=CONF.api_settings.bind_host)
        update_meta_dict = dict(metadata_=db_img.metadata_)
        self.image_repo.update(context.session, db_img.id, **update_meta_dict)

        db_img.status = constants.IMAGE_ACTIVE
        db_img.save(context.session)
