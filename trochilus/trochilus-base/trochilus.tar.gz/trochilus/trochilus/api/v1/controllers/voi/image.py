#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os
import shutil

from oslo_config import cfg
from oslo_db import api as oslo_db_api
from oslo_log import log as logging
from oslo_utils import fileutils
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import voi as voi_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import api as db_api
from trochilus.db import voi_repo
from trochilus.image import format_inspector
from trochilus.image.image_store import filesystem_store

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class ImageController(base.BaseController):
    def __init__(self):
        super().__init__()
        self.base_dir = CONF.voi_setting.voi_image_base_path
        self.image_repo = voi_repo.ImageRepository()
        self.cd_driver_repo = voi_repo.CDDriverRepository()

    @wsme_pecan.wsexpose(voi_types.VOIImageRootResponse,
                         wtypes.text, [wtypes.text],
                         ignore_extra_args=True)
    def get_one(self, id, fields=None):
        context = pecan_request.context.get('trochilus_context')
        db_img = self.image_repo.get(context.session, id=id)
        if not db_img:
            raise exceptions.NotFound(resource="voi_image", id=id)
        result = self._convert_db_to_type(db_img, voi_types.VOIImageResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return voi_types.VOIImageRootResponse(image=result)

    @wsme_pecan.wsexpose(voi_types.VOIImagesRootResponse, [wtypes.text],
                         ignore_extra_args=True)
    def get_all(self, fields=None):
        context = pecan_request.context.get('trochilus_context')

        db_imgs, links = self.image_repo.get_all(
            context.session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(list(db_imgs),
                                          [voi_types.VOIImageResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)

        return voi_types.VOIImagesRootResponse(images=result,
                                               image_links=links)

    @wsme_pecan.wsexpose(voi_types.VOIImageRootResponse,
                         wtypes.text, status_code=200,
                         body=voi_types.VOIImageRootPUT)
    def put(self, id, _image):
        image = _image.image
        image_dict = image.to_dict(render_unsets=False)

        with db_api.get_lock_session() as lock_session:

            # Check image exist
            db_img = self.image_repo.get(lock_session, id=id)
            if not db_img:
                raise exceptions.NotFound(resource='voi_image', id=id)

            if image_dict:
                new_name = image_dict.get('name', None)
                if new_name and db_img.name != new_name:

                    # Check if is iso image
                    disk_format = db_img.disk_format
                    if disk_format == 'iso' and self.cd_driver_repo.get(
                            lock_session,
                            image_id=id):
                        raise exceptions.InvalidRequest(
                            msg='This ISO image %s is in use.' % db_img.name)

                    # Generate image path
                    image_dirpath = os.path.join(self.base_dir, id)
                    file_suffix = '.' + disk_format
                    src_image_filepath = os.path.join(image_dirpath,
                                                      db_img.name
                                                      ) + file_suffix
                    new_image_filepath = os.path.join(image_dirpath,
                                                      new_name
                                                      ) + file_suffix

                    # Rename image file
                    try:
                        shutil.move(src_image_filepath, new_image_filepath)
                    except Exception as e:
                        raise exceptions.InvalidRequest(
                            msg="The requested name %s "
                            "is invalid." % new_name) from e

                    # change location
                    image_dict['location'] = "file://" + new_image_filepath

                # update image
                self.image_repo.update(lock_session, id, **image_dict)

        db_img = self.image_repo.get(lock_session, id=id)
        result = self._convert_db_to_type(db_img, voi_types.VOIImageResponse)
        return voi_types.VOIImageRootResponse(image=result)

    @wsme_pecan.wsexpose(voi_types.VOIImageRootResponse,
                         body=voi_types.VOIImageRootPOST,
                         status_code=201)
    def post(self, image_):
        """craete image record in database"""
        context = pecan_request.context.get('trochilus_context')

        image = image_.image
        image_dict = image.to_dict()
        image_dict['status'] = constants.IMAGE_QUEUED

        image_model = self.image_repo.create(context.session, **image_dict)
        result = self._convert_db_to_type(
            image_model,
            voi_types.VOIImageResponse) if image_model.id else None

        return voi_types.VOIImageRootResponse(image=result)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """delete image record in database and storage"""
        context = pecan_request.context.get('trochilus_context')

        db_img = self.image_repo.get(context.session, id=id)
        if not db_img:
            raise exceptions.NotFound(resource="voi_image", id=id)
        # ISO image may be used in voi vm, so can not delete
        if db_img.disk_format == 'iso' and self.cd_driver_repo.get(
                context.session, image_id=id):
            raise exceptions.InvalidRequest(
                msg='This ISO image %s is in use.' % db_img.name)
        if db_img.location:
            file_path = db_img.location.replace("file://", "")
            try:
                shutil.rmtree(os.path.dirname(file_path))
            except FileNotFoundError:
                LOG.warning("Not fount image file when delete image %s", id)
        self.image_repo.update(context.session, id=id,
                               **{'status': constants.DELETED})

    @pecan_expose()
    def _lookup(self, id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'file':
                return ImageDataController(id=id), remainder
        return None


class ImageDataController(base.BaseController):

    def __init__(self, id):
        super().__init__()
        self.id = id
        self.image_repo = voi_repo.ImageRepository()
        self.base_dir = CONF.voi_setting.voi_image_base_path
        fileutils.ensure_tree(self.base_dir)

    def _restore(self, session, db_img):
        """Restore the image to queued status."""
        try:
            db_img.status = constants.IMAGE_QUEUED
            db_img.save(session)
        except Exception as e:
            msg = ("Unable to restore image %(image_id)s: %(e)s") % {
                'image_id': db_img.id, 'e': e}
            LOG.exception(msg)

    @pecan_expose()
    def get(self):
        context = pecan_request.context.get('trochilus_context')
        db_img = self.image_repo.get(context.session, id=self.id)
        image_dir = os.path.join(self.base_dir, db_img.id)
        store = filesystem_store.FilesystemStore(image_dir)

        if db_img.location:
            store.download(db_img.location, image_id=self.id)
        else:
            LOG.warning("The image file does not exist: %s", self.id)
            raise exceptions.ImageFileNotFound(image=self.id)

    @pecan_expose()
    def put(self):
        """upload image file"""
        context = pecan_request.context.get('trochilus_context')

        db_img = self.image_repo.get(context.session, id=self.id)
        image_format = db_img.disk_format
        if db_img.status != constants.IMAGE_QUEUED:
            LOG.error(
                "The status of the current iamge is %s. "
                "Upload file is not allowed", db_img.status)
            raise exceptions.ImageStatusConflict(img_status=db_img.status)

        data = pecan_request.body_file

        # Content Length is not always available
        image_length = pecan_request.content_length
        if image_length:
            LOG.debug("The image file content length is %s. "
                      "If the store is RBD, "
                      "the upload speed can be accelerated",
                      image_length)
            db_img.size = image_length

        # Check the information about uploaded files.
        # The value includes the format of the uploaded file and
        # the virtual size of the virtual disk and so on.
        inspector = format_inspector.get_inspector(image_format)
        if inspector:
            fmt = inspector()
            data = format_inspector.InfoWrapper(
                data, fmt, image=db_img)
            LOG.debug('Format inspection for %s', fmt)
        else:
            raise exceptions.ImageFormatNotSupport()

        db_img.status = constants.IMAGE_SAVING
        db_img.save(context.session)
        LOG.debug(
            'The image %s status is changed to saving, '
            'and the image uploading start', self.id)

        image_dir = os.path.join(self.base_dir, db_img.id)
        fileutils.ensure_tree(image_dir)
        store = filesystem_store.FilesystemStore(image_dir)
        try:
            db_img.location, db_img.size, db_img.checksum = store.add(
                db_img.name + '.' + image_format, data,
                image_size=db_img.size if db_img.size else 0)
        except exceptions.ImageSizeLimitExceeded as e:
            LOG.error("The incoming image is too large")
            self._restore(context.session, db_img)
            raise e
        except Exception as e:
            LOG.error(
                "Image upload failed: %s.", db_img.id)
            self._restore(context.session, db_img)
            raise e

        # Query whether the voi image was deleted during upload
        current_db_img = self.image_repo.get(context.session, id=db_img.id, )
        if not current_db_img:
            LOG.warning(
                "VOI image %s uploading completed, but the user performed "
                "the delete image, try to delete the image", self.id)
            try:
                # If executed here, there is a high probability that
                # the voi image can be deleted.
                # If there is an exception, we set the status to error.
                # For error, we may need to manually clear the image in storage
                file_path = db_img.location.replace("file://", "")
                shutil.rmtree(os.path.dirname(file_path))
                LOG.info("VOI image %s delete successfully", self.id)
                return
            except FileNotFoundError:
                LOG.warning("VOI image file has deleted when delete image %s",
                            self.id)
                return
            except Exception as e:
                LOG.error("In upload voi image method: "
                          "An unknown error when deleting a voi image %s: ",
                          id)
                db_img.status = constants.IMAGE_ERROR
                db_img.save(context.session)
                raise e

        LOG.debug('VOI image %s uploading completed', self.id)

        db_img.status = constants.IMAGE_ACTIVE
        db_img.save(context.session)
