#   Copyright 2021 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from oslo_config import cfg
from oslo_log import log as logging
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import snapshot as snapshot_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import base_repo
from trochilus.db import snapshot_repo
from trochilus.db import volume_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class SnapshotController(base.BaseController):

    def __init__(self):
        super(SnapshotController).__init__()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.volume_repo = volume_repo.VolumeRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()

    @wsme_pecan.wsexpose(snapshot_types.SnapshotRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Get a snapshot."""
        session = pecan_request.context.get('trochilus_context').session

        db_snapshot = self.snapshot_repo.get(session, id=id)
        if not db_snapshot:
            raise exceptions.NotFound(resource='snapshot', id=id)

        result = self._convert_db_to_type(db_snapshot,
                                          snapshot_types.SnapshotResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return snapshot_types.SnapshotRootResponse(snapshot=result)

    @wsme_pecan.wsexpose(snapshot_types.SnapshotsRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """List all snapshots."""
        session = pecan_request.context.get('trochilus_context').session
        db_snapshots, links = self.snapshot_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(
            list(db_snapshots), [snapshot_types.SnapshotResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)
        return snapshot_types.SnapshotsRootResponse(
            snapshots=result, snapshot_links=links)

    @wsme_pecan.wsexpose(snapshot_types.SnapshotRootResponse,
                         wtypes.text, status_code=200,
                         body=snapshot_types.SnapshotRootPut)
    def put(self, id, snapshot_):
        """Updates a snapshot."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.debug("Update snapshot with parameters: %s", id)
        db_snapshot = self.snapshot_repo.get(session, id=id)

        if not db_snapshot:
            raise exceptions.NotFound(resource='snapshot', id=id)

        with db_api.get_lock_session() as lock_session:
            snapshot_dict = snapshot_.snapshot.to_dict(render_unsets=False)
            if snapshot_dict:
                self.snapshot_repo.update(lock_session, id, **snapshot_dict)
        session.expire_all()

        db_snapshot = self.snapshot_repo.get(session, id=id)
        LOG.debug("Update snapshot successful.")
        result = self._convert_db_to_type(db_snapshot,
                                          snapshot_types.SnapshotResponse)
        return snapshot_types.SnapshotRootResponse(snapshot=result)

    def _validate_create_snapshot(self, session, snapshot_dict):
        """Prepare snapshot info, validate snapshot info and create snapshot"""
        db_volume = self.volume_repo.get(session,
                                         id=snapshot_dict['volume_id'])
        if not db_volume:
            raise exceptions.VolumeNotFound(id=snapshot_dict['volume_id'])

        if db_volume.status not in constants.USEFUL_VOL_STATUS:
            raise exceptions.InvalidVolume(
                id=db_volume.id, status=constants.USEFUL_VOL_STATUS,
                cur_status=db_volume.status)

        snapshot_dict['size'] = db_volume.get("size")
        snapshot_dict['status'] = constants.PREPARE_CREATE

        # Query information about the upper-level snapshot of a snapshot
        previous_snap = self.snapshot_repo.get(session,
                                               volume_id=db_volume.id,
                                               current=True)
        # If has snapshots and as current point in the volume,
        # Update the snapshot with current of false,
        # And use the snap id as the previous of the new snapshot.
        if previous_snap:
            with db_api.get_lock_session() as lock_session:
                self.snapshot_repo.update(lock_session,
                                          id=previous_snap.id,
                                          current=False)
            session.expire_all()
            snapshot_dict['previous'] = previous_snap.get('id')

        # The newly snapshot is the current point
        snapshot_dict['current'] = True

        db_snapshot = self.snapshot_repo.create(session, **snapshot_dict)
        return db_snapshot, db_volume

    @wsme_pecan.wsexpose(snapshot_types.SnapshotRootResponse,
                         status_code=200,
                         body=snapshot_types.SnapshotRootPOST)
    def post(self, snapshot_obj):
        """create a snapshot."""
        session = pecan_request.context.get('trochilus_context').session

        snapshot_dict = snapshot_obj.snapshot.to_dict()
        LOG.debug("Create snapshot with parameters: %s", snapshot_dict)

        db_snapshot, db_volume = self._validate_create_snapshot(
            session, snapshot_dict)

        agent = self.agent_repo.get_all(session, hostname=db_volume.get(
            "hostname"))[0][0]
        LOG.debug("Send to agent %(agent)s create snapshot %(id)s",
                  {"agent": agent.hostname, "id": db_snapshot.id})
        self.agent_client.create_snapshot(agent, id=db_snapshot.id)

        result = self._convert_db_to_type(db_snapshot,
                                          snapshot_types.SnapshotResponse)
        return snapshot_types.SnapshotRootResponse(snapshot=result)

    def _validate_and_delete_snapshot(self, session, db_snapshot):
        if db_snapshot.status in constants.DELETE_BAN:
            raise exceptions.DeleteConflict(resource='snapshot',
                                            id=db_snapshot.id,
                                            status=db_snapshot.status)
        # Check snapshot is in use
        if self.volume_repo.get_all(session, snapshot_id=db_snapshot.id)[0]:
            raise exceptions.SnapshotIsInUse(snap_id=db_snapshot.id)

        # Update status in the database
        with db_api.get_lock_session() as lock_session:

            # Update snapshot status
            self.snapshot_repo.update(
                lock_session, db_snapshot.id,
                **{"status": constants.PREPARE_DELETE})

            # update snapshot relation
            base_repo.update_relation_for_delete(
                lock_session, self.snapshot_repo, db_snapshot)

    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """Delete a snapshot by id"""
        session = pecan_request.context.get('trochilus_context').session
        LOG.info("Deleting snapshot with id: %s", id)

        db_snapshot = self.snapshot_repo.get(session, id=id)

        if not db_snapshot:
            raise exceptions.NotFound(resource='snapshot', id=id)
        if db_snapshot.snapshot_group_id:
            raise exceptions.SnapshotHasSnapshotGroup(
                id=id, sg_id=db_snapshot.snapshot_group_id)

        self._validate_and_delete_snapshot(session, db_snapshot)

        db_volume = self.volume_repo.get(session,
                                         id=db_snapshot['volume_id'])

        agent = self.agent_repo.get_all(session, hostname=db_volume.get(
            "hostname"))[0][0]
        self.agent_client.delete_snapshot(agent, id=id)
