#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


from oslo_config import cfg
from oslo_log import log as logging
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import client_device as client_device_types
from trochilus.common import exceptions
from trochilus.db import api as db_api
from trochilus.db import client_device_repo

LOG = logging.getLogger(__name__)
CONF = cfg.CONF


class ClientDeviceController(base.BaseController):
    def __init__(self):
        super().__init__()
        self.client_device = client_device_repo.ClientDeviceRepository()

    @wsme_pecan.wsexpose(
        client_device_types.ClientDeviceRootResponse,
        wtypes.text,
        [wtypes.text],
        ignore_extra_args=True,
    )
    def get_one(self, id, fields=None):
        """get client device info on id ."""
        session = pecan_request.context.get("trochilus_context").session

        devices = self.client_device.get(session=session, id=id)

        if not devices:
            raise exceptions.NotFound(resource='client_device', id=id)

        result = self._convert_db_to_type(
            devices, client_device_types.ClientDeviceResponse
        )

        if fields is not None:
            result = self._filter_fields([result], fields)[0]

        return client_device_types.ClientDeviceRootResponse(
            client_device=result)

    @wsme_pecan.wsexpose(
        client_device_types.ClientDevicesRootResponse,
        [wtypes.text],
        ignore_extra_args=True
    )
    def get_all(self):
        """get table client_device info"""
        session = pecan_request.context.get("trochilus_context").session

        devices, _ = self.client_device.get_all(session)
        result = self._convert_db_to_type(
            list(devices), [client_device_types.ClientDeviceResponse]
        )

        return client_device_types.ClientDevicesRootResponse(
            client_device=result)

    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """delete info with id"""
        session = pecan_request.context.get("trochilus_context").session
        LOG.debug("Deleting client device info with id: %s", id)

        devices = self.client_device.get(session=session, id=id)

        if not devices:
            raise exceptions.NotFound(resource='client_device', id=id)

        serial_session = db_api.get_session(autocommit=False)
        serial_session.connection(
            execution_options={'isolation_level': 'SERIALIZABLE'})
        try:
            self.client_device.delete(serial_session, id=id)
            serial_session.commit()
        finally:
            serial_session.close()
