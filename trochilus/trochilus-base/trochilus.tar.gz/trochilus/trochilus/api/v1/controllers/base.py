#    Copyright 2014 Rackspace
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg
from oslo_log import log as logging
from pecan import rest as pecan_rest
from wsme import types as wtypes

from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import physical_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class BaseController(pecan_rest.RestController):
    RBAC_TYPE = None

    def __init__(self):
        super().__init__()
        self.agent = agent_repo.AgentRepository()
        self.physical_repo = physical_repo.PhysicalRepository()

    @staticmethod
    def _convert_db_to_type(db_entity, to_type, children=False):
        """Converts a database model into an Trochilus WSME type

        :param db_entity: database model to convert
        :param to_type: converts db_entity to this type
        """
        if isinstance(to_type, list):
            to_type = to_type[0]

        def _convert(db_obj):
            return to_type.from_db_model(db_obj, children=children)
        if isinstance(db_entity, list):
            converted = [_convert(db_obj) for db_obj in db_entity]
        else:
            converted = _convert(db_entity)
        return converted

    @staticmethod
    def _get_db_obj(session, repo, id):
        """Gets an object from the database and returns it."""
        db_obj = repo.get(session, id=id)
        if not db_obj:
            LOG.debug('%(name)s %(id)s not found',
                      {'name': repo.model_class._name(), 'id': id})
            raise exceptions.NotFound(
                resource=repo.model_class._name(), id=id)
        return db_obj

    def _filter_fields(self, object_list, fields):
        if CONF.api_settings.allow_field_selection:
            for index, obj in enumerate(object_list):
                members = self._get_attrs(obj)
                for member in members:
                    if member not in fields:
                        setattr(obj, member, wtypes.Unset)
        return object_list

    @staticmethod
    def _get_attrs(obj):
        attrs = [attr for attr in dir(obj) if not callable(
            getattr(obj, attr)) and not attr.startswith("_")]
        return attrs
