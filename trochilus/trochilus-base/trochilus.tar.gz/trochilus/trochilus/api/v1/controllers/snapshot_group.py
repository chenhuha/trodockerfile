#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from oslo_config import cfg
from oslo_log import log as logging
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from oslo_utils import uuidutils
from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.controllers import snapshot
from trochilus.api.v1.controllers import \
    virtual_machine  # pylint: disable=R0401
from trochilus.api.v1.controllers import volume
from trochilus.api.v1.types import snapshot_group as sg_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import base_repo
from trochilus.db import snapshot_group_repo as sg_repo
from trochilus.db import snapshot_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import volume_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class SnapshotGroupController(base.BaseController):

    def __init__(self):
        super().__init__()
        # Note: sg = snapshot_group
        self.sg_repo = sg_repo.SnapshotGroupRepository()
        self.volume_repo = volume_repo.VolumeRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()

    @wsme_pecan.wsexpose(sg_types.SnapshotGroupRootResponse,
                         wtypes.text, [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Get a snapshot group."""
        session = pecan_request.context.get('trochilus_context').session

        db_sg = self.sg_repo.get(session, id=id)
        if not db_sg:
            raise exceptions.NotFound(resource='snapshot', id=id)

        result = self._convert_db_to_type(
            db_sg, sg_types.SnapshotGroupResponse)

        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return sg_types.SnapshotGroupRootResponse(snapshot_group=result)

    @wsme_pecan.wsexpose(sg_types.SnapshotsGroupRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """List all snapshots group."""
        session = pecan_request.context.get('trochilus_context').session
        db_sg, links = self.sg_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'))

        result = self._convert_db_to_type(
            list(db_sg), [sg_types.SnapshotGroupResponse])

        if fields is not None:
            result = self._filter_fields(result, fields)

        return sg_types.SnapshotsGroupRootResponse(
            snapshot_groups=result, snapshot_group_links=links)

    @wsme_pecan.wsexpose(sg_types.SnapshotGroupRootResponse,
                         wtypes.text, status_code=200,
                         body=sg_types.SnapshotGroupRootPut)
    def put(self, id, snapshot_group_):
        """Updates a snapshot group."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.debug("Update snapshot group with parameters: %s", id)
        db_sg = self.sg_repo.get(session, id=id)

        if not db_sg:
            raise exceptions.NotFound(resource='snapshot_group', id=id)

        with db_api.get_lock_session() as lock_session:
            sg_dict = snapshot_group_.snapshot_group.to_dict(
                render_unsets=False)
            if sg_dict:
                self.sg_repo.update(
                    lock_session, id, **sg_dict)
        session.expire_all()

        db_sg = self.sg_repo.get(session, id=id)
        LOG.debug("Update snapshot group successful.")

        result = self._convert_db_to_type(
            db_sg, sg_types.SnapshotGroupResponse)

        return sg_types.SnapshotGroupRootResponse(snapshot_group=result)

    def _validate_and_create_sg(self, session, db_vm, sg_name=None,
                                sg_description=None):
        # TODO(liupeng) Maybe we will limit the number of VM'snapshots

        # Check agent status
        if db_vm.agent.status == constants.AGENT_DOWN:
            raise exceptions.AgentUnavailable()

        # Check VM status
        if db_vm.status not in [constants.ACTIVE, constants.STOPPED]:
            raise exceptions.VMInvalidState(
                vm_id=db_vm.id,
                state=db_vm.status,
                method="snapshot")

        snapshot_dicts = []
        sg_size = 0
        sg_id = uuidutils.generate_uuid()

        # Generate information for creating snapshots
        volume_objs = [vvm.volume for vvm in db_vm.vm_volume_mapping]
        for volume_obj in volume_objs:
            snapshot_dicts.append(
                {
                    "name": "snapshot for {}-{}".format(
                        'volume', volume_obj.id),
                    "description": "Auto create by snapshot group",
                    "volume_id": volume_obj.id,
                    "status": constants.PREPARE_CREATE,
                    "snapshot_group_id": sg_id
                }
            )
            sg_size += volume_obj.size

        # Generate information for creating sg
        previous_sg_obj = self.sg_repo.get(session,
                                           virtual_machine_id=db_vm.id,
                                           current=True)

        sg_dict = {
            "id": sg_id,
            "name": sg_name or "snapshot group for vm-{}".format(
                db_vm.id),
            "description": sg_description or None,
            "size": sg_size,
            "status": constants.PREPARE_CREATE,
            "virtual_machine_id": db_vm.id,
            "current": True,
            "previous": previous_sg_obj.id if previous_sg_obj else None
        }

        # Create and update record in the database
        with db_api.get_lock_session() as lock_session:

            # Create snapshot group
            self.sg_repo.create(lock_session, **sg_dict)

            # Create snapshots
            for snapshot_dict in snapshot_dicts:
                snapshot.SnapshotController()._validate_create_snapshot(
                    lock_session, snapshot_dict)

            # Update previous_sg_obj current to False
            if previous_sg_obj:
                self.sg_repo.update(
                    lock_session, previous_sg_obj.id, **{"current": False})

        return self.sg_repo.get(session, id=sg_id)

    @wsme_pecan.wsexpose(sg_types.SnapshotGroupRootResponse,
                         status_code=200,
                         body=sg_types.SnapshotGroupRootPOST)
    def post(self, snapshot_group_):
        """create a snapshot group."""
        session = pecan_request.context.get('trochilus_context').session

        sg_dict = snapshot_group_.snapshot_group.to_dict()
        sg_name = sg_dict.get("name", None)
        sg_description = sg_dict.get("description", None)
        LOG.debug("Create snapshot group with parameters: %s", sg_dict)

        db_vm = self.vm_repo.get(session, id=sg_dict['virtual_machine_id'])
        db_sg = self._validate_and_create_sg(
            session, db_vm, sg_name, sg_description)

        agent = self.agent_repo.get_all(session, id=db_vm.agent_id)[0][0]
        LOG.debug("Send to agent %(agent)s create snapshot group %(id)s",
                  {"agent": agent.hostname, "id": db_sg.id})
        self.agent_client.create_snapshot_group(agent, id=db_sg.id)

        result = self._convert_db_to_type(
            db_sg, sg_types.SnapshotGroupResponse)
        return sg_types.SnapshotGroupRootResponse(
            snapshot_group=result)

    def _validate_and_delete_sg(self, session, db_sg):

        if db_sg.status in constants.DELETE_BAN:
            raise exceptions.DeleteConflict(resource='snapshot_group',
                                            id=db_sg.id,
                                            status=db_sg.status)

        # Update status in the database
        with db_api.get_lock_session() as lock_session:

            # Update snapshot group status
            self.sg_repo.update(
                lock_session, db_sg.id, **{"status": constants.PREPARE_DELETE})

            # Update snapshots status
            for snapshot_obj in db_sg.snapshot:
                snapshot.SnapshotController()._validate_and_delete_snapshot(
                    lock_session, snapshot_obj)

            # update sg relation
            base_repo.update_relation_for_delete(
                lock_session, self.sg_repo, db_sg)

    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """Delete a snapshot group by id"""
        session = pecan_request.context.get('trochilus_context').session
        LOG.info("Deleting snapshot group with id: %s", id)

        db_sg = self.sg_repo.get(session, id=id)
        if not db_sg:
            raise exceptions.NotFound(resource='snapshot_group', id=id)

        self._validate_and_delete_sg(session, db_sg)

        agent = self.agent_repo.get_all(session, id=db_sg.vm.agent_id)[0][0]
        LOG.debug("Send to agent %(agent)s delete snapshot group %(id)s",
                  {"agent": agent.hostname, "id": db_sg.id})
        self.agent_client.delete_snapshot_group(agent, id=db_sg.id)

    @pecan_expose()
    def _lookup(self, id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'action':
                return SnapshotGroupActionController(id=id), remainder
        return None


class SnapshotGroupActionController(base.BaseController):

    def __init__(self, id):
        super().__init__()
        self.id = id
        # Note: sg = snapshot_group
        self.sg_repo = sg_repo.SnapshotGroupRepository()
        self.volume_repo = volume_repo.VolumeRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()

    @wsme_pecan.wsexpose(
        body=sg_types.SnapshotGroupActionRootPOST, status_code=201)
    def post(self, action_):
        action = action_.action

        session = pecan_request.context.get('trochilus_context').session
        db_sg = self.sg_repo.get(session, id=self.id)
        if not db_sg:
            raise exceptions.NotFound(resource='snapshot_group', id=self.id)

        try:
            action_func = getattr(self, action.name)
        except Exception as e:
            raise exceptions.UnsupportVolumeAction(
                action_name=action.name) from e

        action_dict = action.to_dict()
        action_func(session, db_sg, action_dict)

    def _validate_vm_for_revert_sg(self, session, db_vm):

        # Check agent status
        if db_vm.agent.status == constants.AGENT_DOWN:
            raise exceptions.AgentUnavailable()

        # Check VM status
        if db_vm.status not in [constants.ACTIVE, constants.STOPPED]:
            raise exceptions.VMInvalidState(
                vm_id=db_vm.id,
                state=db_vm.status,
                method="revert")

    def _validate_revert_sg(self, session, db_sg):

        # Check sg status
        if db_sg.status != constants.AVAILABLE:
            raise exceptions.InvalidSnapshot(
                id=db_sg.id,
                status=constants.AVAILABLE,
                cur_status=db_sg.status)

        # Compute neet revert volumes and neet detach volumes
        db_vm = db_sg.vm
        origin_vm_status = db_vm.status
        self._validate_vm_for_revert_sg(session, db_vm)

        vm_attached_volume_id_set = {
            vvm.volume_id for vvm in db_vm.vm_volume_mapping
            if vvm.attach_status == constants.ATTACHED}

        volume_snapshot_map = {}

        def make_volume_snapshot_map(snapshot):
            volume_snapshot_map[snapshot.volume_id] = snapshot.id
            return snapshot.volume_id

        db_snapshots = db_sg.snapshot
        sg_associated_volume_id_set = {
            make_volume_snapshot_map(snapshot) for snapshot in db_snapshots}

        need_revert_volume_id_set = sg_associated_volume_id_set.intersection(
            vm_attached_volume_id_set)
        need_detach_volume_id_set = vm_attached_volume_id_set.difference(
            need_revert_volume_id_set)
        need_detach_volume_vvm_map = {}
        need_detach_volume_status_map = {}
        for vmm in db_vm.vm_volume_mapping:
            if vmm.volume_id in need_detach_volume_id_set:
                need_detach_volume_vvm_map[vmm.volume_id] = vmm.id
                need_detach_volume_status_map[
                    vmm.volume_id] = vmm.volume.status

        with db_api.get_lock_session() as lock_session:
            # Update vm status
            self.vm_repo.update(
                lock_session, db_vm.id, status=constants.PREPARE_REVERT)

            for volume_id, vvm_id in need_detach_volume_vvm_map.items():
                virtual_machine.VirtualMachineActionController(
                    db_vm.id)._do_detach_volume(
                    lock_session, volume_id, vvm_id,
                    need_detach_volume_status_map[volume_id], None)

            for volume_id in need_revert_volume_id_set:
                volume.VolumeActionController(
                    volume_id)._validate_volume_snapshot_for_revert(
                    lock_session, None, volume_snapshot_map.get(volume_id))

            # Update sg current
            current_sg = self.sg_repo.get(
                session, virtual_machine_id=db_vm.id, current=True)
            if current_sg and current_sg.id != db_sg.id:
                self.sg_repo.update(lock_session, current_sg.id, current=False)
            self.sg_repo.update(lock_session, db_sg.id, current=True)

        return (need_revert_volume_id_set, need_detach_volume_vvm_map,
                volume_snapshot_map, origin_vm_status)

    def revert(self, session, db_sg, action_dict):
        LOG.info("Prepare revert volumes %s to snapshot_group", self.id)

        (need_revert_volume_id_set, need_detach_volume_vvm_map,
         volume_snapshot_map, origin_vm_status) = self._validate_revert_sg(
             session, db_sg)

        agent = self.agent_repo.get(session, id=db_sg.vm.agent_id)
        self.agent_client.revert_snapshot_group(
            agent,
            id=self.id,
            origin_vm_status=origin_vm_status,
            need_revert_volume_ids=list(need_revert_volume_id_set),
            need_detach_volume_vvm_map=need_detach_volume_vvm_map,
            volume_snapshot_map=volume_snapshot_map)
