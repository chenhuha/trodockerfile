#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os
import shutil

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import fileutils
from oslo_utils import uuidutils
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import voi as voi_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.common import voi_utils
from trochilus.db import agent_repo
from trochilus.db import voi_repo

LOG = logging.getLogger(__name__)
CONF = cfg.CONF


class ShareDiskController(base.BaseController):

    def __init__(self):
        super().__init__()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.agent_repo = agent_repo.AgentRepository()

    @wsme_pecan.wsexpose(voi_types.DiskDetailsRootResponse,
                         wtypes.text,
                         status_code=200)
    def get(self, disk_dirpath=None):

        # Check disk_dirpath exits
        if not disk_dirpath or not os.path.exists(disk_dirpath):
            raise exceptions.InvalidRequest(msg="The directory "
                                            "does not exist.")

        # Generate disk details
        disk_details = []
        for middle_name in [constants.BASE_DISK_NAME,
                            constants.INCR1_DISK_NAME,
                            constants.INCR2_DISK_NAME]:
            disk_name, disk_filepath = \
                voi_utils.get_share_disk_name_and_path(middle_name,
                                                       disk_dirpath)

            # Get disk really size
            really_size = 0
            if os.path.exists(disk_filepath):
                data = voi_utils.get_qemu_img_info(disk_filepath)
                really_size = data.disk_size
            disk_details.append(voi_types.DiskDetailResponse(**{
                "path": disk_filepath,
                'size': really_size,
                'name': disk_name,
                'type': middle_name
            }))

        return voi_types.DiskDetailsRootResponse(disk_details=disk_details)

    @wsme_pecan.wsexpose(voi_types.ShareDiskRootResponse,
                         body=voi_types.ShareDiskPOST,
                         status_code=201)
    def post(self, data):
        disk_uuid = data.id if data.id else uuidutils.generate_uuid()
        image_filepath = data.image_filepath
        base_dirpath = data.base_dirpath

        # Check image_filepath and ensure share_disk_dirpath
        if not os.path.exists(image_filepath):
            raise exceptions.InvalidRequest(msg="The image file "
                                            "does not exist.")
        share_disk_dirpath = os.path.join(base_dirpath, disk_uuid)
        if os.path.exists(share_disk_dirpath):
            msg = "The path %s already exists." % share_disk_dirpath
            raise exceptions.InvalidRequest(msg=msg)
        fileutils.ensure_tree(share_disk_dirpath)

        # Copy image file
        share_base_disk_filename, share_base_disk_filepath = \
            voi_utils.get_share_disk_name_and_path(constants.BASE_DISK_NAME,
                                                   share_disk_dirpath)
        voi_utils.copy_image(image_filepath, share_base_disk_filepath)

        # Generate disk chain
        backing_file = share_base_disk_filename
        need_generate_disk_middle_names = [constants.INCR1_DISK_NAME,
                                           constants.INCR2_DISK_NAME,
                                           constants.CURRENT_DISK_NAME]
        for middle_name in need_generate_disk_middle_names:
            filename, filepath = \
                voi_utils.get_share_disk_name_and_path(middle_name,
                                                       share_disk_dirpath)
            voi_utils.create_cow_image(backing_file, filepath)
            backing_file = filename

        share_disk_result = voi_types.ShareDiskResponse(**{
            "id": disk_uuid
        })
        return voi_types.ShareDiskRootResponse(
            share_disk=share_disk_result
        )

    @wsme_pecan.wsexpose(None,
                         body=voi_types.ShareDiskDELETE,
                         status_code=204)
    def delete(self, data):
        disk_dirpath = data.disk_dirpath
        if not os.path.exists(disk_dirpath):
            raise exceptions.InvalidRequest(msg="The directory "
                                            "does not exist.")

        _, base_filepath = \
            voi_utils.get_share_disk_name_and_path(constants.BASE_DISK_NAME,
                                                   disk_dirpath)
        if not os.path.exists(base_filepath):
            raise exceptions.InvalidRequest(msg="The requested directory"
                                            " %s is invalid." % disk_dirpath)
        shutil.rmtree(disk_dirpath)

    @wsme_pecan.wsexpose(None,
                         body=voi_types.ShareDiskPUT,
                         status_code=200)
    def put(self, data):
        context = pecan_request.context.get('trochilus_context')
        disk_dirpath = data.disk_dirpath
        if not os.path.exists(disk_dirpath):
            raise exceptions.InvalidRequest(msg="The directory "
                                            "does not exist.")

        # 随机选择一个 agent 执行 commit 操作
        agent = self.agent_repo.get_agent_randomly(context.session)
        if not agent:
            raise exceptions.AgentUnavailable()
        # 通知 agent 执行 commit 操作
        self.agent_client.commit_share_disk(
            agent, **{
                "disk_dirpath": disk_dirpath
            })


class ShareTemplateDiskController(base.BaseController):

    def __init__(self):
        super().__init__()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.agent_repo = agent_repo.AgentRepository()
        self.share_tmpl_vol_repo = voi_repo.ShareTemplateVolumeRepository()

    @wsme_pecan.wsexpose(voi_types.ShareTemplateDiskRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True,
                         status_code=200)
    def get_one(self, id, fields=None):
        context = pecan_request.context.get('trochilus_context')
        db_volume = self.share_tmpl_vol_repo.get(context.session, id=id)
        if not db_volume:
            raise exceptions.NotFound(resource="voi share template volume",
                                      id=id)

        result = self._convert_db_to_type(db_volume,
                                          voi_types.ShareTemplateDiskResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return voi_types.ShareTemplateDiskRootResponse(
            share_template_disk=result)

    @wsme_pecan.wsexpose(voi_types.ShareTemplateDiskRootResponse,
                         body=voi_types.ShareTemplateDiskPOST,
                         status_code=201)
    def post(self, data):
        LOG.info("Creating voi share template volume")
        if not data.size:
            msg = "The share volume size is requested"
            raise exceptions.InvalidRequest(msg=msg)
        if data.size <= 0:
            msg = "The share volume size must be greater than 0"
            raise exceptions.InvalidRequest(msg=msg)

        session = pecan_request.context.get('trochilus_context').session
        db_volume = self.share_tmpl_vol_repo.create(
            session, **{'size': data.size, 'status': constants.AVAILABLE})

        template_base_path = CONF.voi_setting.share_template_disk_path
        fileutils.ensure_tree(template_base_path)
        _, template_path = voi_utils.get_share_tmpl_disk_name_and_path(
            db_volume.id, template_base_path)
        try:
            voi_utils.create_image(template_path, '%sG' % data.size)
        except Exception as e:
            LOG.error('Failed to create %s voi share template volume, because'
                      ' %s', db_volume.id, str(e))
            self.share_tmpl_vol_repo.update(
                session, db_volume.id, status=constants.ERROR)

        LOG.info("Share template disk %s create successful.", db_volume.id)

        result = self._convert_db_to_type(db_volume,
                                          voi_types.ShareTemplateDiskResponse)
        return voi_types.ShareTemplateDiskRootResponse(
            share_template_disk=result)

    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        LOG.info("Deleting voi share template volume %s", id)
        session = pecan_request.context.get('trochilus_context').session

        db_volume = self.share_tmpl_vol_repo.get(session, id=id)
        if not db_volume:
            raise exceptions.NotFound(resource='voi share template volume',
                                      id=id)
        if self.share_tmpl_vol_repo.update(
                session, id, expected_status=constants.AVAILABLE,
                **{'status': constants.DELETED}) < 1:
            raise exceptions.StatusConflict(
                id=id, resource='voi share template volume',
                status=db_volume.status)
        template_base_path = CONF.voi_setting.share_template_disk_path
        _, template_path = voi_utils.get_share_tmpl_disk_name_and_path(
            id, template_base_path)
        fileutils.delete_if_exists(template_path)
        LOG.info("Share template disk %s delete successful.", id)
