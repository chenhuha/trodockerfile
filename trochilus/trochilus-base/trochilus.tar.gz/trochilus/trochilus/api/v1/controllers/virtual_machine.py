#   Copyright 2021 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

import math

from oslo_concurrency import lockutils
from oslo_config import cfg
from oslo_db import api as oslo_db_api
from oslo_log import log as logging
from oslo_utils import strutils
from oslo_utils import units
from oslo_utils import uuidutils
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.common import utils as api_utils
from trochilus.api.v1.controllers import base
from trochilus.api.v1.controllers import snapshot
from trochilus.api.v1.controllers import snapshot_group as sg_ctrl
from trochilus.api.v1.controllers import volume
from trochilus.api.v1.types import virtual_machine as vm_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import dhcp_repo
from trochilus.db import image_repo
from trochilus.db import nic_repo
from trochilus.db import resource_provider_repo as rp_repo
from trochilus.db import snapshot_group_repo as sg_repo
from trochilus.db import snapshot_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import vm_volume_mapping_repo as vvm_repo
from trochilus.db import volume_repo
from trochilus.scheduler import manager as scheduler_manager

CONF = cfg.CONF
LOG = logging.getLogger(__name__)

sched_manager = scheduler_manager.SchedulerManager()


def schedule_agent(lock_session, schedule_spec):
    agent = sched_manager.select_destination(lock_session, schedule_spec)
    if not agent:
        raise exceptions.AgentUnavailable
    return agent


class VirtualMachineController(base.BaseController):
    def __init__(self):
        super().__init__()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.image_repo = image_repo.ImageRepository()
        self.volume_repo = volume_repo.VolumeRepository()
        self.nic_repo = nic_repo.NicRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.vvm_repo = vvm_repo.VMVolumeMappingRepository()
        self.dhcp_repo = dhcp_repo.DhcpNodeMappingRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()

    @wsme_pecan.wsexpose(vm_types.VirtualMachineRootResponse,
                         wtypes.text, [wtypes.text],
                         ignore_extra_args=True)
    def get_one(self, id, fields=None):
        context = pecan_request.context.get('trochilus_context')

        db_vm = self.vm_repo.get(context.session, id)
        result = self._convert_db_to_type(
            db_vm, vm_types.VirtualMachineResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]

        return vm_types.VirtualMachineRootResponse(vm=result)

    @wsme_pecan.wsexpose(vm_types.VirtualMachinesRootResponse, [wtypes.text],
                         ignore_extra_args=True)
    def get_all(self, fields=None):
        context = pecan_request.context.get('trochilus_context')

        db_vms, links = self.vm_repo.get_all(
            context.session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(list(db_vms),
                                          [vm_types.VirtualMachineResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)

        return vm_types.VirtualMachinesRootResponse(
            vms=result, vm_links=links)

    @wsme_pecan.wsexpose(vm_types.VirtualMachineRootResponse,
                         body=vm_types.VirtualMachineRootPOST,
                         status_code=201)
    def post(self, vm_):
        """Craete virtual machine record in database"""
        context = pecan_request.context.get('trochilus_context')

        vm = vm_.vm
        vm_dict = vm.to_dict()

        vm_id = uuidutils.generate_uuid()

        LOG.info("Starting prepare_create virtual machine")
        with db_api.get_lock_session() as lock_session:
            # Schedule vm
            schedule_spec = scheduler_manager.ScheduleSpec()
            schedule_spec.vm_id = vm_id
            schedule_spec.vcpu = vm_dict['vcpu']
            schedule_spec.memory_mb = vm_dict['memory_mb']
            agent = schedule_agent(lock_session, schedule_spec)

            vm_dict['id'] = vm_id
            vm_dict['agent_id'] = agent.id
            # Set the hostname to apply to volume
            vm_dict['hostname'] = agent.hostname
            vm_dict['del_root_disk_on_termination'] = vm_dict.get(
                'del_root_disk_on_termination', True)

            can_boot, db_vm = self._prepare_validate_create_vm(lock_session,
                                                               vm_dict)
            if can_boot is False:
                raise exceptions.VMCanNotBootable(vm_id=db_vm.id)

        db_vm = self.vm_repo.get(context.session, db_vm.id)

        LOG.debug("Send to agent %(agent)s create VM %(id)s",
                  {"agent": agent.hostname, "id": db_vm.id})
        self.agent_client.create_virtual_machine(agent, id=db_vm.id)
        self.dhcp_repo.notify_dhcp_agent_for_vm(db_vm.id, create_vm=True)

        result = self._convert_db_to_type(
            db_vm, vm_types.VirtualMachineResponse
        ) if db_vm.id else None

        return vm_types.VirtualMachineRootResponse(vm=result)

    def _validate_cascade_delete_vm(
            self, session, db_vm, cascade, del_datadisk):
        need_delete_sg_ids = []
        need_delete_snapshot_ids = []
        need_detach_volume_ids = []

        # Check VM status
        if db_vm.status in constants.DELETE_BAN:
            raise exceptions.DeleteConflict(
                resource='VM', id=db_vm.id, status=db_vm.status)

        # Get root disk snapshots
        vvms = [vvm for vvm in db_vm.vm_volume_mapping
                if vvm.attached_index == 0 and vvm.volume.snapshot]
        root_disk_snapshots = vvms[0].volume.snapshot if vvms else []

        data_disk_ids = [vvm.volume_id
                         for vvm in db_vm.vm_volume_mapping
                         if vvm.attached_index != 0]
        vm_sgs = db_vm.snapshot_group

        # Check snapshots and sgs if not cascade
        if not cascade:
            if root_disk_snapshots:
                raise exceptions.VMRootDiskHasSnapshot(id=db_vm.id)
            if vm_sgs:
                raise exceptions.VMHasSnapshotGroup(id=db_vm.id)
            if del_datadisk:
                # TODO(liupeng) Support delete data disk in not cascade
                # delete VM
                msg = ("If not cascade delete VM, don't support delete data"
                       " disk")
                raise exceptions.UnsupportDeleteVM(vm_id=db_vm.id, msg=msg)
        elif cascade:
            # Delete all sg
            if vm_sgs:
                for vm_sg in vm_sgs:
                    sg_ctrl.SnapshotGroupController()._validate_and_delete_sg(
                        session, vm_sg)
                    need_delete_sg_ids.append(vm_sg.id)

            if del_datadisk:
                # Get all snapshot does not belong to sg
                snapshot_objs = [
                    snapshot_obj for snapshot_objs in [
                        vvm.volume.snapshot for vvm in db_vm.vm_volume_mapping]
                    for snapshot_obj in snapshot_objs
                    if not snapshot_obj.snapshot_group_id]
            else:
                # Only delete root disk snapshot does not belong to sg
                snapshot_objs = [snapshot_obj for snapshot_obj
                                 in root_disk_snapshots
                                 if not snapshot_obj.snapshot_group_id]
            # Delete all snapshot does not belong to sg
            for snapshot_obj in snapshot_objs:
                snapshot.SnapshotController(
                )._validate_and_delete_snapshot(
                    session, snapshot_obj)

            # Because this is delete VM, so we don't set vm db status to
            # prepare_volume_detach in API.
            # In agent we directly set the detach status to detached,
            # if del_datadisk is true we delete the volume later.
            need_detach_volume_ids = data_disk_ids
            need_delete_snapshot_ids = [
                snapshot.id for snapshot in snapshot_objs]

        self.vm_repo.update(session, db_vm.id, status=constants.PREPARE_DELETE)

        return (need_delete_sg_ids,
                need_delete_snapshot_ids,
                need_detach_volume_ids,
                del_datadisk)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(
        None, wtypes.text, wtypes.text, wtypes.text, status_code=204)
    def delete(self, id, cascade=False, datadisk=False):
        """Delete a VM record in database."""
        LOG.info("Deleting VM with id: %s", id)
        session = pecan_request.context.get('trochilus_context').session
        cascade = strutils.bool_from_string(cascade)
        del_datadisk = strutils.bool_from_string(datadisk)

        db_vm = self.vm_repo.get(session, id)
        if not db_vm:
            raise exceptions.NotFound(resource='VM', id=id)

        (need_delete_sg_ids, need_delete_snapshot_ids, need_detach_volume_ids,
         del_datadisk) = self._validate_cascade_delete_vm(
            session, db_vm, cascade, del_datadisk)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        if cascade:
            self.agent_client.cascade_delete_vm(
                agent, id=id,
                need_delete_sg_ids=need_delete_sg_ids,
                need_delete_snapshot_ids=need_delete_snapshot_ids,
                need_detach_volume_ids=need_detach_volume_ids,
                del_datadisk=del_datadisk)
        else:
            self.agent_client.delete_virtual_machine(agent, id=db_vm.id)

        self.dhcp_repo.notify_dhcp_agent_for_vm(db_vm.id, delete_vm=True)

    @wsme_pecan.wsexpose(vm_types.VirtualMachineRootResponse,
                         wtypes.text,
                         status_code=200,
                         body=vm_types.VirtualMachineRootPUT)
    def put(self, id, vm_):
        vm = vm_.vm
        context = pecan_request.context.get('trochilus_context')
        with db_api.get_lock_session() as lock_session:
            vm_dict = vm.to_dict(render_unsets=False)
            if vm_dict:
                self.vm_repo.update(lock_session, id, **vm_dict)

        db_img = self.vm_repo.get(context.session, id)

        result = self._convert_db_to_type(
            db_img, vm_types.VirtualMachineResponse)
        return vm_types.VirtualMachineRootResponse(vm=result)

    def _prepare_validate_create_vm(self, lock_session, vm_dict):
        """Prepare vm info, validate vm info and create vm"""
        db_volumes = []
        db_vm_volume_mappings = []

        vm_id = vm_dict['id']
        image_id = vm_dict.get("image_id")
        root_disk_gb = vm_dict.get("root_disk_gb")
        volume_dicts = vm_dict.pop("volumes", None)
        volume_hostname = vm_dict.pop('hostname', None)
        del_root_disk_on_termination = vm_dict.pop(
            "del_root_disk_on_termination")
        nic_dicts = vm_dict.pop("nics", None)
        # If there is no 'image_id' and no volume list, throw an exception
        if image_id:
            root_disk_gb, volume_dicts = self._transform_image_to_volumes(
                lock_session, vm_id, image_id, volume_dicts, root_disk_gb or 0,
                del_root_disk_on_termination)
            # Take the largest of the root_disk_gb and image size
            vm_dict['root_disk_gb'] = root_disk_gb
        elif volume_dicts:
            dict_snapshot_id = volume_dicts[0].get("snapshot_id")
            dict_volume_id = volume_dicts[0].get("volume_id")
            if dict_snapshot_id:
                db_snapshot = self.snapshot_repo.get(lock_session,
                                                     id=dict_snapshot_id)
                volume_id = db_snapshot.volume_id
                db_volume = self.volume_repo.get(lock_session, id=volume_id)
                if db_volume.bootable:
                    volume_dicts[0]['auto_delete'] = 1
                elif not db_volume.bootable:
                    raise exceptions.VMSystemVolume()
            elif dict_volume_id:
                db_volume = self.volume_repo.get(lock_session,
                                                 id=dict_volume_id)
                if db_volume.bootable:
                    volume_dicts[0]['auto_delete'] = 1
                elif not db_volume.bootable:
                    raise exceptions.VMSystemVolume()
            else:
                raise exceptions.VMVolumeListError()

        elif volume_dicts is None:
            raise exceptions.VMVolumeListEmpty()

        vm_dict['status'] = constants.PREPARE_CREATE
        db_vm = self.vm_repo.create(lock_session, **vm_dict)

        LOG.info("Starting prepare_create volumes for virtual machine %s",
                 db_vm.id)
        for volume_dict in volume_dicts:
            volume_dict['hostname'] = volume_hostname

            db_volume = volume.VolumeController()._validate_create_volume(
                lock_session, volume_dict)
            db_volumes.append(db_volume)

        # Marks whether the virtual machine has a boot disk
        can_boot = any((v.id for v in db_volumes if v.bootable))

        LOG.info("Starting prepare create volumes attach "
                 "info for virtual machine %s",
                 db_vm.id)

        # Create attach record
        for inx, db_volume in enumerate(db_volumes):
            volume_attach_dict = dict(
                volume_id=db_volume.id,
                virtual_machine_id=db_vm.id,
                attached_index=inx)
            db_vvm = self.vvm_repo.validate_create_volume_attachment(
                lock_session, volume_attach_dict)

            db_vm_volume_mappings.append(db_vvm)

        # Create nic and update attach info
        if nic_dicts:
            LOG.info("Starting prepare_create nics for virtual machine %s",
                     db_vm.id)
            req_ip_addresses = []
            req_nic_ids = []
            for nic_dict in nic_dicts:
                subnet_id = nic_dict.get('subnet_id')
                ip = nic_dict.get('ip_address')
                nic_id = nic_dict.get('nic_id')
                if not (nic_id or subnet_id):
                    raise exceptions.InvalidRequest(
                        msg='Either nic_id or subnet_id must be specified')
                if nic_id and ip:
                    raise exceptions.InvalidRequest(
                        msg='subnet_id and ip_address can be '
                            'specified together')
                if nic_id:
                    req_nic_ids.append(nic_id)
                else:
                    req_ip_addresses.append(nic_dict)

            # Create nic
            created_nic_ids = self.nic_repo.validate_create_nic_for_vm(
                lock_session, req_ip_addresses, db_vm.id)
            # Update attach info
            req_nic_ids += created_nic_ids
            self.nic_repo.validate_attach_nics(lock_session, req_nic_ids,
                                               db_vm.id)
        return can_boot, db_vm

    def _transform_image_to_volumes(self, lock_session, vm_id,
                                    image_id, volumes, root_disk_gb,
                                    del_root_disk_on_termination):
        """Transform image to image volume information"""
        volumes = volumes or []

        LOG.debug("Create VM %s with image %s, transform the image to volume",
                  vm_id, image_id)

        db_image = self.image_repo.get(lock_session, image_id)

        if db_image.status != constants.IMAGE_ACTIVE:
            raise exceptions.InvalidImageStatus()

        image_virtual_size = db_image.virtual_size
        root_disk_gb = root_disk_gb if (
            root_disk_gb * units.Gi > image_virtual_size
        ) else math.ceil(image_virtual_size / units.Gi)

        # If create virtual machine with image_id
        # The default backend is obtained from the default_root_disk_backend
        volumes.insert(0, {
            "image_id": image_id,
            "size": root_disk_gb,
            "backend": CONF.vm_settings.default_root_disk_backend,
            "auto_delete": del_root_disk_on_termination
        })
        return root_disk_gb, volumes

    @pecan_expose()
    def _lookup(self, id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'action':
                return VirtualMachineActionController(id=id), remainder
        return None


class VirtualMachineActionController(base.BaseController):

    def __init__(self, id):
        super().__init__()
        self.id = id
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.image_repo = image_repo.ImageRepository()
        self.volume_repo = volume_repo.VolumeRepository()
        self.vvm_repo = vvm_repo.VMVolumeMappingRepository()
        self.nic_repo = nic_repo.NicRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.snapshot_group_repo = sg_repo.SnapshotGroupRepository()
        self.res_alloc_repo = rp_repo.ResourceAllocationRepository()

    @wsme_pecan.wsexpose(body=vm_types.VMActionRootPOST, status_code=201)
    def post(self, action_):
        action = action_.action

        session = pecan_request.context.get('trochilus_context').session
        db_vm = self.vm_repo.get(session, self.id)

        # Check if vm exists
        if not db_vm:
            LOG.debug("vm %(vm_id)s does not exist.", {'vm_id': self.id})
            raise exceptions.NotFound(resource='vm', id=self.id)

        try:
            action_func = getattr(self, action.name)
        except Exception as e:
            raise exceptions.UnsupportVMAction(action_name=action.name) from e

        action_dict = action.to_dict()
        action_func(session, db_vm, action_dict)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def start(self, session, db_vm, action_dict):
        LOG.info("Starting VM with id: %s", self.id)

        self.vm_repo.update(session, self.id, status=constants.PREPARE_START)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.start_virtual_machine(agent, id=self.id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE])
    def stop(self, session, db_vm, action_dict):
        LOG.info("Stopping VM with id: %s", self.id)

        self.vm_repo.update(session, self.id, status=constants.PREPARE_STOP)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.stop_virtual_machine(agent, id=self.id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE, constants.STOPPED])
    def reboot(self, session, db_vm, action_dict):
        reboot_extended_attr = action_dict.get("extended_attr", {})
        reboot_type = reboot_extended_attr.get('type', "SOFT").upper()

        if db_vm.status == constants.STOPPED and reboot_type == 'SOFT':
            raise exceptions.VMInvalidState(vm_id=db_vm.id, state=db_vm.status,
                                            method="reboot")

        LOG.info("Rebooting %s VM with id: %s", reboot_type, self.id)

        self.vm_repo.update(session, self.id, status=constants.PREPARE_REBOOT)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.reboot_virtual_machine(agent, id=self.id,
                                                 reboot_type=reboot_type)

    def _get_vm_root_disk_snapshots(self, db_vm):
        vvms = [vvm for vvm in db_vm.vm_volume_mapping
                if vvm.attached_index == 0 and vvm.volume.snapshot]
        return vvms[0].volume.snapshot if vvms else []

    def _validate_snapshot(self, session, db_vm, snapshot_id):
        snap_obj = self.snapshot_repo.get(session, id=snapshot_id)
        if not snap_obj:
            raise exceptions.NotFound(resource='snapshot', id=snapshot_id)

        if snap_obj.status != constants.AVAILABLE:
            raise exceptions.StatusConflict(
                resource="snapshot", id=snapshot_id, status=snap_obj.status)

        if db_vm.root_disk_gb < snap_obj.size:
            raise exceptions.SnapSizeExceedsRootDisk(
                root_disk_size=db_vm.root_disk_gb, snap_size=snap_obj.size)

    def _validate_image(self, session, db_vm, image_id):
        image_obj = self.image_repo.get(session, image_id)
        if image_obj.status != constants.IMAGE_ACTIVE:
            raise exceptions.InvalidImageStatus

        if image_obj.disk_format != 'raw':
            reason = ("rbd image rebuild requires image format to be 'raw'")
            raise exceptions.ImageDiskFormatError(
                image_id=image_id, reason=reason)

        if db_vm.root_disk_gb * units.Gi < image_obj.virtual_size:
            raise exceptions.ImageSizeExceedsRootDisk(
                img_size=image_obj.virtual_size / units.Gi,
                root_disk_size=db_vm.root_disk_gb)

    def _validate_attr_for_rebuild(self, session, db_vm,
                                   rebuild_extended_attr):
        need_delete_snapshot_ids = []
        need_delete_sgs_ids = []
        image_id = rebuild_extended_attr.get("image_id", None)
        snapshot_id = rebuild_extended_attr.get('snapshot_id', None)
        force = rebuild_extended_attr.get("force", False)

        # # Check root disk have snapshot
        # root_disk_snapshot_objs = self._get_vm_root_disk_snapshots(db_vm)
        # Get  snapshot of  non snapshot group
        need_delete_snapshot_objs = [
            snapshot_obj for snapshot_objs in [
                vvm.volume.snapshot for vvm in db_vm.vm_volume_mapping]
            for snapshot_obj in snapshot_objs
            if not snapshot_obj.snapshot_group_id]
        if need_delete_snapshot_objs:
            if not force:
                raise exceptions.VMRootDiskHasSnapshot(id=db_vm.id)
            # Check if the snapshot is the volume own snapshot
            need_delete_snapshot_ids = [
                snap_obj.id for snap_obj in need_delete_snapshot_objs]
            if snapshot_id in need_delete_snapshot_ids:
                raise exceptions.CannotRebuildWithOwnSnapshot(id=db_vm.id)
            # Delete all root disk snapshots
            for snapshot_obj in need_delete_snapshot_objs:
                snapshot.SnapshotController()._validate_and_delete_snapshot(
                    session, snapshot_obj)
        # Get snapshot group
        need_delete_sgs = db_vm.snapshot_group
        db_snapshot = self.snapshot_repo.get(session, id=snapshot_id)
        if need_delete_sgs:
            if not force:
                raise exceptions.VMRootDiskHasSnapshot(id=db_vm.id)
            for delete_sg in need_delete_sgs:
                if db_snapshot in delete_sg.snapshot:
                    raise exceptions.CannotRebuildWithOwnSnapshot(id=db_vm.id)
            need_delete_sgs_ids = [
                snap_sg_obj.id for snap_sg_obj in need_delete_sgs]
            for delete_sg in need_delete_sgs:
                sg_ctrl.SnapshotGroupController()._validate_and_delete_sg(
                    session, delete_sg)

        if not (image_id or snapshot_id):
            raise exceptions.CannotRebuildWithNonAttr()
        if image_id:
            self._validate_image(session, db_vm, image_id)
        elif snapshot_id:
            self._validate_snapshot(session, db_vm, snapshot_id)

        return need_delete_snapshot_ids, need_delete_sgs_ids

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE, constants.STOPPED])
    def rebuild(self, session, db_vm, action_dict):
        """Rebuild VM with another image or template snapshot of the VM"""
        rebuild_extended_attr = action_dict.get("extended_attr", {})
        force = rebuild_extended_attr.get("force")
        if force:
            pass
        elif db_vm.snapshot_group:
            raise exceptions.VMHasSnapshotGroup(id=db_vm.id)

        need_delete_snapshot_ids, need_delete_sgs_ids = \
            self._validate_attr_for_rebuild(
                session, db_vm, rebuild_extended_attr)
        rebuild_extended_attr['old_vm_status'] = db_vm.status
        rebuild_extended_attr[
            'need_delete_snapshot_ids'] = need_delete_snapshot_ids
        rebuild_extended_attr[
            'need_delete_sgs_ids'] = need_delete_sgs_ids

        LOG.info("Rebuiling VM with id: %s.", self.id)
        self.vm_repo.update(session, self.id, status=constants.PREPARE_REBUILD)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        if need_delete_snapshot_ids or need_delete_sgs_ids:
            self.agent_client.rebuild_vm(
                agent,
                id=self.id,
                **rebuild_extended_attr)
        else:
            self.agent_client.rebuild_virtual_machine(
                agent, id=self.id,
                **rebuild_extended_attr)

    def _validate_host_for_cold_migrate(self, session, db_vm, migrate_host):
        if migrate_host == db_vm.agent.hostname:
            raise exceptions.CannotMigrateToSameHost()
        if not self.agent_repo.get_all(session,
                                       hostname=migrate_host,
                                       status=constants.AGENT_UP)[0]:
            raise exceptions.AgentUnavailable

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def migrate(self, session, db_vm, action_dict):
        """Migrate VM to another host"""
        maigate_extended_attr = action_dict.get("extended_attr", {})
        migrate_host = maigate_extended_attr.get('host', None)
        migrate_agent_id = maigate_extended_attr.get('agent_id', None)

        if not migrate_host and not migrate_agent_id:
            # TODO(liupeng): Real scheduling mechanism in the future
            # Schedule vm to other host
            schedule_spec = scheduler_manager.ScheduleSpec()
            schedule_spec.vm_id = db_vm.id
            schedule_spec.vcpu = db_vm.vcpu
            schedule_spec.memory_mb = db_vm.memory_mb
            schedule_spec.ignored_hosts = [db_vm.agent.id]
            agent = schedule_agent(session, schedule_spec)
            migrate_host = agent.hostname
        # migrate_agent_id is ignored if migrate_host is passed
        elif migrate_agent_id and not migrate_host:
            agent_obj = self.agent_repo.get(session, id=migrate_agent_id)
            if not agent_obj:
                raise exceptions.NotFound(
                    resource='agent', id=migrate_agent_id)
            migrate_host = agent_obj.hostname

        self._validate_host_for_cold_migrate(session, db_vm, migrate_host)

        LOG.info("Migrating VM with id: %s, to %s", self.id, migrate_host)

        self.vm_repo.update(session, self.id, status=constants.PREPARE_MIGRATE)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.migrate_virtual_machine(agent, id=self.id,
                                                  migrate_host=migrate_host)

    def _validate_vm_configure_for_resize(self, db_vm, resize_extended_attr):
        db_dict = db_vm.to_dict()
        same_attr_count = 0

        if resize_extended_attr['root_disk_gb'] < db_vm.root_disk_gb:
            reason = 'Resize to root disk smaller then current is not allowed.'
            raise exceptions.CannotResizeDisk(reason=reason)

        for key in resize_extended_attr.keys():
            if resize_extended_attr[key] == db_dict.get(key, None):
                same_attr_count += 1
        if same_attr_count == 3:
            raise exceptions.CannotResizeToSameVMConfigure()

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.STOPPED])
    def resize(self, session, db_vm, action_dict):
        """Resize VM"""
        resize_extended_attr = action_dict.get("extended_attr", {})
        if not resize_extended_attr:
            raise exceptions.CannotResizeWithNonVMConfigure()

        resize_vcpu = resize_extended_attr.setdefault('vcpu', db_vm.vcpu)
        resize_memory_mb = resize_extended_attr.setdefault(
            'memory_mb', db_vm.memory_mb)
        resize_root_disk_gb = resize_extended_attr.setdefault(
            'root_disk_gb', db_vm.root_disk_gb)

        self._validate_vm_configure_for_resize(db_vm, resize_extended_attr)

        LOG.info("Resizing VM with id: %s, from "
                 "[vcpu: %s, memory_mb: %s, root_disk_gb: %s] to "
                 "[vcpu: %s, memory_mb: %s, root_disk_gb: %s]", self.id,
                 db_vm.vcpu, db_vm.memory_mb, db_vm.root_disk_gb,
                 resize_vcpu, resize_memory_mb, resize_root_disk_gb)

        # Because vcpu or memory size of vm changes, update resource allocation
        # about the host
        self.res_alloc_repo.update_allocations(
            db_vm.id, {constants.VCPU_CLASS_ID: resize_vcpu,
                       constants.MEMORY_CLASS_ID: resize_memory_mb})

        self.vm_repo.update(session, self.id, status=constants.PREPARE_RESIZE)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.resize_virtual_machine(
            agent, id=self.id,
            vcpu=resize_vcpu,
            memory_mb=resize_memory_mb,
            root_disk_gb=resize_root_disk_gb)

    @api_utils.check_vm_agent()
    def attach_nic(self, session, db_vm, action_dict):
        """attach nic"""
        extended_attr = action_dict.get("extended_attr", {})
        nic_id = extended_attr.get('nic_id')
        if not nic_id:
            raise exceptions.InvalidRequest(msg='nic_id must be present')
        db_nic = self.nic_repo.get(session, id=nic_id)

        # Check if nic exists
        if not db_nic:
            LOG.debug("Fail to attach nic %(nic_id)s, because "
                      "nic does not exist.", {'nic_id': nic_id})
            raise exceptions.NotFound(resource='nic', id=nic_id)

        with db_api.get_lock_session() as lock_session:
            # Update vm status
            self.vm_repo.update(lock_session, db_vm.id,
                                status=constants.PREPARE_NIC_ATTACH)
            # Update nic status
            update_nic_success = self.nic_repo.update(
                lock_session, nic_id, expected_status=constants.DOWN,
                **{'status': constants.PREPARE_ATTACH,
                   'owner_id': db_vm.id,
                   'owner_type': constants.NIC_OF_VDI_VM})
            if not update_nic_success:
                raise exceptions.NicStatusConflict(nic_id=nic_id,
                                                   status=db_nic.status,
                                                   action='attach')
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.attach_nic(agent, id=db_vm.id, nic_id=nic_id)

    @api_utils.check_vm_agent()
    def detach_nic(self, session, db_vm, action_dict):
        """detach nic"""
        extended_attr = action_dict.get("extended_attr", {})
        nic_id = extended_attr.get('nic_id')
        if not nic_id:
            raise exceptions.InvalidRequest(msg='nic_id must be present')
        db_nic = self.nic_repo.get(session, id=nic_id)

        # Check if nic exists
        if not db_nic:
            LOG.debug("Fail to attach nic %(nic_id)s, because "
                      "nic does not exist.", {'nic_id': nic_id})
            raise exceptions.NotFound(resource='nic', id=nic_id)
        # Check if the vm's owns nic
        if db_nic.owner_id:
            if db_nic.owner_id != db_vm.id:
                raise exceptions.InvalidRequest(msg='The vm has not the nic')
        else:
            raise exceptions.NicStatusConflict(nic_id=nic_id,
                                               status=db_nic.status,
                                               action='detach')
        # Check if the type of nic is vdi
        if db_nic.owner_type != constants.NIC_OF_VDI_VM:
            raise exceptions.InvalidRequest(msg='Only can detach the nic '
                                                'of vdi vm')
        # The nic created when creating vm cannot be detached.
        if db_nic.auto_delete:
            raise exceptions.InvalidRequest(
                msg='The nic created when creating vm cannot be detached')

        with db_api.get_lock_session() as lock_session:
            # Update vm status
            self.vm_repo.update(lock_session, db_vm.id,
                                status=constants.PREPARE_NIC_DETACH)
            # Update nic status
            update_nic_success = self.nic_repo.update(
                lock_session, nic_id, expected_status=constants.UP,
                **{'status': constants.PREPARE_DETACH})
            if not update_nic_success:
                raise exceptions.NicStatusConflict(nic_id=nic_id,
                                                   status=db_nic.status,
                                                   action='detach')
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.detach_nic(agent, id=db_vm.id, nic_id=nic_id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE, constants.STOPPED])
    def flatten(self, session, db_vm, action_dict):
        """flatten VM"""
        flatten_attr = action_dict.get("flatten_attr", {})
        flatten_attr['old_vm_status'] = db_vm.status

        volume_ids = [vvm.volume_id for vvm in db_vm.vm_volume_mapping]
        if volume_ids:
            for vvm_id in volume_ids:
                update_vvm_success = self.volume_repo.update_vm_volume(
                    session, vvm_id,
                    expected_status=constants.IN_USE,
                    **{'status': constants.PREPARE_FLATTEN})
                if not update_vvm_success:
                    raise exceptions.VolumeStatusError(volume_id=vvm_id,
                                                       action='flatten')

        self.vm_repo.update(session, self.id, status=constants.PREPARE_FLATTEN)
        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.flatten_virtual_machine(agent, id=self.id,
                                                  **flatten_attr)

    def attach_volume(self, session, db_vm, action_dict):
        """Attach volume"""
        extended_attr = action_dict.get("extended_attr", {})
        volume_id = extended_attr.get('volume_id')

        # Checkout if volume exits
        if not volume_id:
            raise exceptions.InvalidRequest(msg='volume_id must be present')
        db_volume = self.volume_repo.get(session, id=volume_id)
        if not db_volume:
            LOG.debug("Fail to attach volume %(volume_id)s, because"
                      "volume does no exist.", {'volume_id': volume_id})
            raise exceptions.NotFound(resource='volume', id=volume_id)

        # When preventing concurrent attach volume,chance to happen,
        # duplicate attached index are generated. Synchronize compute volume
        # attached index and update volume status, and create vvm record.
        with lockutils.lock('compute_volume_attached_index'
                            '_for_vm-{}'.format(db_vm.id)):
            vvm_objs = db_vm.vm_volume_mapping
            max_index = 0
            volume_list = [vvm.attached_index for vvm in vvm_objs]
            for x in volume_list:
                if max_index not in volume_list:
                    break
                max_index += 1

            # Create vvm record and update volume status
            with db_api.get_lock_session() as lock_session:
                db_vvm = self.vvm_repo.validate_create_volume_attachment(
                    lock_session, {"volume_id": volume_id,
                                   "virtual_machine_id": db_vm.id,
                                   "attached_index": max_index})

                update_volume_success = self.volume_repo.update_vm_volume(
                    lock_session,
                    volume_id,
                    expected_status=constants.AVAILABLE,
                    **{'status': constants.PREPARE_ATTACH})
                if not update_volume_success:
                    raise exceptions.VolumeStatusConflict(
                        volume_id=volume_id,
                        status=db_volume.status,
                        action='attach')

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.attach_volume(agent, id=db_vm.id,
                                        volume_id=volume_id,
                                        vvm_id=db_vvm.id)

    def _validate_detach_volume(self, session, db_vm, db_volume):
        # If db_vm is None, invoking from volume delete action
        if not db_vm:
            db_vm = self.vm_repo.get(session, id=self.id)

        # Check if the vm's owns volume
        db_vvm = self.vvm_repo.get(session, volume_id=db_volume.id,
                                   virtual_machine_id=db_vm.id,
                                   attach_status=constants.ATTACHED)
        if not db_vvm:
            raise exceptions.InvalidRequest(msg="The vm has not the volume")
        # The auto-deleted volume can not be detached
        if db_volume.auto_delete:
            raise exceptions.InvalidRequest(msg='The vm`s own volume cannot'
                                                'be detached')

        with db_api.get_lock_session() as lock_session:
            self._do_detach_volume(lock_session, db_volume.id, db_vvm.id,
                                   db_volume.status, db_vm.id)
        return db_vvm.id

    def _do_detach_volume(self, lock_session, volume_id, vvm_id,
                          volume_status, vm_id=None):
        # Update vvm attach_status to prepare_detach
        self.vvm_repo.update(lock_session, vvm_id,
                             attach_status=constants.PREPARE_DETACH)

        # Update volume status to prepare_detach
        update_volume_success = self.volume_repo.update_vm_volume(
            lock_session, volume_id, expected_status=constants.IN_USE,
            **{'status': constants.PREPARE_DETACH})
        if not update_volume_success:
            raise exceptions.VolumeStatusConflict(volume_id=volume_id,
                                                  status=volume_status,
                                                  action='detach')

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(
        vm_state=constants.CAN_ATTACH_DETACH_VOLUME_STATUS)
    def detach_volume(self, session, db_vm, action_dict):
        """Detach volume"""
        extended_attr = action_dict.get("extended_attr", {})
        volume_id = extended_attr.get('volume_id')

        # Check if volume exists
        if not volume_id:
            raise exceptions.InvalidRequest(msg='volume_id must be present')
        db_volume = self.volume_repo.get(session, id=volume_id)
        if not db_volume:
            LOG.debug("Fail to attach volume %(volume_id)s, because"
                      "volume does no exist.", {'volume_id': volume_id})
            raise exceptions.NotFound(resource='volume', id=volume_id)

        vvm_id = self._validate_detach_volume(session, db_vm, db_volume)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.detach_volume(agent, id=db_vm.id,
                                        volume_id=db_volume.id,
                                        vvm_id=vvm_id)

    @api_utils.check_vm_agent()
    @api_utils.check_vm_state(vm_state=[constants.ACTIVE, constants.STOPPED])
    def revert(self, session, db_vm, action_dict):
        """Revert VM"""
        extended_attr = action_dict.get("extended_attr", {})
        snapshot_id = extended_attr.get('snapshot_id')

        # Check if snapshot exists
        if not snapshot_id:
            raise exceptions.InvalidRequest(msg='snapshot_id must be present')
        db_snapshot = self.snapshot_repo.get(session, id=snapshot_id)
        if not db_snapshot:
            LOG.debug("Fail to revert VM %(vm_id)s, because"
                      "snapshot does no exist.", {'vm_id': db_vm.id})
            raise exceptions.NotFound(resource='snapshot', id=snapshot_id)

        # Check if snapshot is this VM's sys volume
        is_sys_volume_snapshot = False
        db_volume = db_snapshot.volume
        if db_volume.vm_volume_mapping:
            is_sys_volume_snapshot = \
                db_volume.vm_volume_mapping[0].attached_index == 0
        if not is_sys_volume_snapshot:
            raise exceptions.InvalidRequest(msg="This snapshot is not the VM's"
                                            " system volume snapshot")

        self.vm_repo.update(session, self.id, status=constants.PREPARE_REVERT)

        agent = self.agent_repo.get(session, id=db_vm.agent_id)
        self.agent_client.revert_virtual_machine(agent, id=db_vm.id,
                                                 sys_snapshot_id=snapshot_id)
