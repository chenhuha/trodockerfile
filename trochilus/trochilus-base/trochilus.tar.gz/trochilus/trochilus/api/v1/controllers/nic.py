#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

import netaddr

from oslo_config import cfg
from oslo_db import api as oslo_db_api
from oslo_log import log as logging
from pecan import request as pecan_request

from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import nic as nic_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import dhcp_repo
from trochilus.db import nic_repo
from trochilus.db import subnet_repo


CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class NicController(base.BaseController):

    def __init__(self):
        super().__init__()
        self.subnet_repo = subnet_repo.SubnetRepository()
        self.nic_repo = nic_repo.NicRepository()
        self.ip_alloc_repo = nic_repo.AddressAllocRepository()
        self.dhcp_repo = dhcp_repo.DhcpNodeMappingRepository()

    @wsme_pecan.wsexpose(nic_types.NicRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Gets a nic's details."""
        session = pecan_request.context.get('trochilus_context').session
        db_nic = self.nic_repo.get(session, id=id)
        if not db_nic:
            raise exceptions.NotFound(resource='nic', id=id)
        nic_result = self._convert_db_to_type(db_nic,
                                              nic_types.NicResponse)
        if fields is not None:
            nic_result = self._filter_fields([nic_result], fields)[0]
        return nic_types.NicRootResponse(nic=nic_result)

    @wsme_pecan.wsexpose(nic_types.NicsRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """Lists all nics."""
        session = pecan_request.context.get('trochilus_context').session
        db_nics, links = self.nic_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        nic_result = self._convert_db_to_type(list(db_nics),
                                              [nic_types.NicResponse])
        if fields is not None:
            nic_result = self._filter_fields(nic_result, fields)
        return nic_types.NicsRootResponse(nics=nic_result,
                                          nic_links=links)

    @wsme_pecan.wsexpose(nic_types.NicRootResponse,
                         wtypes.text, status_code=200,
                         body=nic_types.NicRootPUT)
    def put(self, id, nic_):
        """Updates a nic."""
        # Prepare the data for nic operation.
        nic_dict = nic_.nic.to_dict(render_unsets=False)
        LOG.debug("Updating nic %(id)s with parameters: %(param)s",
                  dict(id=id, param=nic_dict))

        session = pecan_request.context.get('trochilus_context').session
        db_nic = self.nic_repo.get(session, id=id)
        if not db_nic:
            raise exceptions.NotFound(resource='nic', id=id)

        ip_addresses = nic_dict.pop('ip_addresses', None)
        db_subnets = None
        if ip_addresses:
            # If no subnet_id, fill subnet_id in request parameter
            db_subnets = self._fill_subnet_id_and_get_subnets(session,
                                                              ip_addresses,
                                                              db_nic)
            # Validate that all subnets are from the same network
            self._validate_subnets_in_same_vpc(db_subnets)
            # Validate ip
            self.nic_repo.validate_ips(ip_addresses, db_subnets,
                                       db_nic.owner_type)

        # Validate owner_type
        if 'owner_type' in nic_dict and db_nic.owner_type not in \
                [constants.NIC_OF_RESERVE, nic_dict['owner_type']]:
            raise exceptions.InvalidRequest(
                msg='The owner_type column in the database already '
                    'has a value and cannot be modified')
        # Update nic
        self.nic_repo.update_nic(session, ip_addresses, db_nic, db_subnets,
                                 nic_dict)
        LOG.debug('Update nic %s successful', id)

        db_nic_ = self.nic_repo.get(session, id=id)
        # Notify dhcp agent if need
        if ip_addresses:
            self.dhcp_repo.notify_dhcp_agent_if_need(constants.UPDATE_NIC,
                                                     db_nic.vpc_id,
                                                     add_dhcp_ips=True,
                                                     delete_dhcp_ips=True,
                                                     nics=[db_nic])
        # Returns the created nic information
        nic_result = self._convert_db_to_type(db_nic_,
                                              nic_types.NicResponse)
        return nic_types.NicRootResponse(nic=nic_result)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """Deletes a nic record in database."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.debug("Deleting nic with id: %s", id)

        db_nic = self.nic_repo.get(session, id=id)
        if not db_nic:
            raise exceptions.NotFound(resource='nic', id=id)

        # If there is a nic in use, it is forbidden to delete it
        if db_nic.owner_type != constants.NIC_OF_RESERVE:
            raise exceptions.ObjectInUse(object='nic', id=id)

        self.nic_repo.delete(session, id=id)
        LOG.debug("Delete nic %s successful", id)

        # Notify dhcp agent if need
        self.dhcp_repo.notify_dhcp_agent_if_need(constants.DELETE_NIC,
                                                 db_nic.vpc_id,
                                                 delete_dhcp_ips=True,
                                                 nics=[db_nic])

    @wsme_pecan.wsexpose(nic_types.NicRootResponse,
                         wtypes.text, status_code=200,
                         body=nic_types.NicRootPOST)
    def post(self, nic_):
        # Prepare the data for nic operation.
        nic_dict = nic_.nic.to_dict()
        LOG.debug("Creating nics with parameters: %s", nic_dict)

        session = pecan_request.context.get('trochilus_context').session

        # Validate mac
        self._validate_mac(nic_dict)

        # Get subnets
        db_subnets = self.nic_repo.get_subnets(
            session, set(address['subnet_id']
                         for address in nic_dict['ip_addresses']))

        # Validate that all subnets are from the same network
        self._validate_subnets_in_same_vpc(db_subnets)

        # Validate ip
        self.nic_repo.validate_ips(nic_dict['ip_addresses'], db_subnets,
                                   nic_dict.get('owner_type'))

        # Create nic
        nic_id = self.nic_repo.create_nic(session, db_subnets, nic_dict)
        LOG.debug("Create nic %s successful", nic_id)

        db_nic_ = self.nic_repo.get(session, id=nic_id)
        # Notify dhcp agent if need
        self.dhcp_repo.notify_dhcp_agent_if_need(constants.CREATE_NIC,
                                                 db_nic_.vpc_id,
                                                 add_dhcp_ips=True,
                                                 nics=[db_nic_])
        # Returns the created nic information
        nic_result = self._convert_db_to_type(db_nic_,
                                              nic_types.NicResponse)
        return nic_types.NicRootResponse(nic=nic_result)

    @staticmethod
    def _validate_mac(nic_dict):
        mac = nic_dict.get('mac_address')
        if mac and not netaddr.valid_mac(mac):
            raise exceptions.InvalidAddressFormat(name='mac', addr=mac)

    @staticmethod
    def _validate_subnets_in_same_vpc(db_subnets):
        vpc_id = db_subnets[0].vpc_id
        for db_subnet in db_subnets:
            if vpc_id != db_subnet.vpc_id:
                raise exceptions.SubnetNotInSameVpc()

    def _fill_subnet_id_and_get_subnets(self, session, ip_addresses, db_nic):
        db_subnets, _ = self.subnet_repo.get_all(session,
                                                 vpc_id=db_nic.vpc_id)
        cidr_subnet_tuples = []
        id_subnet = {}
        for db_subnet in db_subnets:
            cidr_subnet_tuples.append((netaddr.IPNetwork(db_subnet.cidr),
                                       db_subnet))
            id_subnet[db_subnet.id] = db_subnet

        subnets = set()
        for address in ip_addresses:
            # The request parameter does not have subnet_id
            if not address.get('subnet_id'):
                # Find out which subnet contains this ip and fill subnet id
                for cidr, subnet in cidr_subnet_tuples:
                    if netaddr.IPAddress(address['ip_address']) in cidr:
                        address['subnet_id'] = subnet.id
                        subnets.add(subnet)
                        break
                else:
                    raise exceptions.IPaddressNotInCidr(
                        name='ip', addr=address['ip_address'], cidr='')
            else:
                if address['subnet_id'] in id_subnet:
                    subnets.add(id_subnet[address['subnet_id']])
                else:
                    raise exceptions.NotFound(resource='subnet',
                                              id=address['subnet_id'])
        return list(subnets)
