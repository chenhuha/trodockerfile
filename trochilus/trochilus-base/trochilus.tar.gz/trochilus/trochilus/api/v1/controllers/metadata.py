#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


from oslo_config import cfg
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.controllers import metadata_schema
from trochilus.api.v1.types import metadata as metadata_types

CONF = cfg.CONF


class MetadataController(base.BaseController):

    @wsme_pecan.wsexpose(metadata_types.MetadatasRootsResponse, wtypes.text)
    def get_all(self):
        support_inst_metadatas = CONF.api_settings.supported_instance_metadatas
        metadata_dict = metadata_schema.METADATA_SCHEMA.get("properties", {})
        metadata_list = []

        for k in support_inst_metadatas:
            if k in metadata_dict:
                metadata_dict[k]['key'] = k
                metadata_list.append(
                    metadata_types.MetadataResponse(**metadata_dict[k]))

        return metadata_types.MetadatasRootsResponse(
            metadatas=metadata_list
        )

    @wsme_pecan.wsexpose(metadata_types.MetadataRootsResponse, wtypes.text)
    def get_one(self, key):
        support_inst_metadatas = CONF.api_settings.supported_instance_metadatas
        metadata_dict = metadata_schema.METADATA_SCHEMA.get("properties", {})

        if key in support_inst_metadatas and metadata_dict:
            metadata_dict[key]['key'] = key
            metadata = metadata_types.MetadataResponse(**metadata_dict[key])

        return metadata_types.MetadataRootsResponse(
            metadata=metadata
        )
