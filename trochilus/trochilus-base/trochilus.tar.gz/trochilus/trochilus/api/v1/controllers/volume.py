#   Copyright 2021 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

import math

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import strutils
from oslo_utils import units
from pecan import expose as pecan_expose
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.controllers import snapshot
from trochilus.api.v1.controllers import \
    virtual_machine  # pylint: disable=R0401
from trochilus.api.v1.types import volume as volume_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import image_repo
from trochilus.db import snapshot_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import volume_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class VolumeController(base.BaseController):

    def __init__(self):
        super(VolumeController).__init__()
        self.volume_repo = volume_repo.VolumeRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.image_repo = image_repo.ImageRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()

    @wsme_pecan.wsexpose(volume_types.VolumeRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Get a volume."""
        session = pecan_request.context.get('trochilus_context').session

        db_volume = self.volume_repo.get(session, id=id)
        if not db_volume:
            msg = ("No volume found with id %s" % id)
            raise exceptions.VolumeNotFound(msg=msg)

        result = self._convert_db_to_type(db_volume,
                                          volume_types.VolumeResponse)
        if fields is not None:
            result = self._filter_fields([result], fields)[0]
        return volume_types.VolumeRootResponse(volume=result)

    @wsme_pecan.wsexpose(volume_types.VolumesRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """List all volumes."""
        session = pecan_request.context.get('trochilus_context').session
        db_volumes, links = self.volume_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'))
        result = self._convert_db_to_type(
            list(db_volumes), [volume_types.VolumeResponse])
        if fields is not None:
            result = self._filter_fields(result, fields)
        return volume_types.VolumesRootResponse(
            volumes=result, volume_links=links)

    @wsme_pecan.wsexpose(volume_types.VolumeRootResponse,
                         wtypes.text, status_code=200,
                         body=volume_types.VolumeRootPut)
    def put(self, id, _volume):
        """Updates a volume."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.info("Update volume with parameters: %s", id)
        db_volume = self.volume_repo.get(session, id=id)

        if not db_volume:
            raise exceptions.NotFound(resource='volume', id=id)

        with db_api.get_lock_session() as lock_session:
            volume_dict = _volume.volume.to_dict(render_unsets=False)
            if volume_dict:
                self.volume_repo.update(lock_session, id, **volume_dict)

        session.expire_all()
        db_volume = self.volume_repo.get(session, id=id)
        result = self._convert_db_to_type(db_volume,
                                          volume_types.VolumeResponse)
        return volume_types.VolumeRootResponse(volume=result)

    def _set_or_check_volume_backend(self, volume_dict):
        # Check API config
        conf_backends = CONF.api_settings.enabled_volume_backends
        if not conf_backends:
            msg = ('Configuration for trochilus-api does not specify '
                   '"enabled_volume_backends".')
            raise exceptions.APIException(msg=msg)

        # Set default backend and check backend.
        backend = volume_dict.get('backend', None)
        if not backend and len(conf_backends) > 1:
            msg = ("There are multiple backends configure, one must be "
                   "selected. %s" % CONF.api_settings.enabled_volume_backends)
            raise exceptions.InvalidRequest(msg=msg)
        if not backend:
            backend = volume_dict['backend'] = conf_backends[0]

        # Check backend is already configured
        if backend not in CONF.api_settings.enabled_volume_backends:
            msg = ("Backend %s is not configure in"
                   " enabled_volume_backends." % backend)
            raise exceptions.InvalidRequest(msg=msg)

    def _validate_update_volume_dict_from_volume(
            self, session, src_volume_id, volume_dict):
        db_src_volume = self.volume_repo.get(session, id=src_volume_id)
        size = volume_dict.get("size", None)

        if not db_src_volume:
            raise exceptions.VolumeNotFound(id=src_volume_id)
        if db_src_volume.status not in constants.USEFUL_VOL_STATUS:
            raise exceptions.InvalidVolume(
                id=db_src_volume.id,
                status=constants.USEFUL_VOL_STATUS,
                cur_status=db_src_volume.status)
        # Set volume size
        if not size and size != 0:
            volume_dict["size"] = db_src_volume.size
        elif size < db_src_volume.size:
            # The size of the volume must be larger than the size of the volume
            raise exceptions.SourceVolumeSizeExceedsVolume(
                size=db_src_volume.size, vol_size=size)

        volume_dict["backend"] = db_src_volume.backend
        volume_dict["bootable"] = db_src_volume.bootable

    def _validate_update_volume_dict_from_snapshot(
            self, session, src_snapshot_id, volume_dict):
        db_src_snapshot = self.snapshot_repo.get(session, id=src_snapshot_id)
        size = volume_dict.get("size", None)

        if not db_src_snapshot:
            raise exceptions.NotFound(resource='snapshot', id=src_snapshot_id)
        if db_src_snapshot.status not in constants.USEFUL_VOL_STATUS:
            raise exceptions.InvalidSnapshot(id=db_src_snapshot.id,
                                             status=constants.AVAILABLE,
                                             cur_status=db_src_snapshot.status)
        # Set volume size
        if not size and size != 0:
            volume_dict["size"] = db_src_snapshot.size
        elif size < db_src_snapshot.size:
            # The size of the volume must be larger than the size of the
            # snapshot
            raise exceptions.SourceSnapshotSizeExceedsVolume(
                size=db_src_snapshot.size, vol_size=size)

        volume_dict["backend"] = db_src_snapshot.volume.backend
        volume_dict["bootable"] = db_src_snapshot.volume.bootable

    def _validate_update_volume_dict_from_image(
            self, session, image_id, volume_dict):
        size = volume_dict.get("size", None)
        image_obj = self.image_repo.get(session, image_id)
        if image_obj.status != constants.IMAGE_ACTIVE:
            raise exceptions.InvalidImageStatus

        if not size and size != 0:
            volume_dict["size"] = math.ceil(image_obj.virtual_size / units.Gi)
        elif size * units.Gi < image_obj.virtual_size:
            # The size of the volume must be larger than the size of the image
            raise exceptions.ImageSizeExceedsVolume(
                img_size=image_obj.virtual_size / units.Gi, vol_size=size)

    def _validate_create_volume(self, session, volume_dict):
        """Prepare volume info, validate volume info and create volume"""
        id = volume_dict.get("id")
        image_id = volume_dict.get("image_id")
        src_volume_id = volume_dict.get("volume_id", None)
        src_snapshot_id = volume_dict.get("snapshot_id", None)

        if id:
            # When id is here, it means that this
            # is requested from the create VM API.
            # We only check db_volume status.
            db_volume = self.volume_repo.get(session, id=id)
            if not db_volume:
                msg = ("No volume found with id %s" % id)
                raise exceptions.NotFound(msg=msg)
            if db_volume.status != constants.AVAILABLE:
                raise exceptions.StatusConflict(
                    resource="volume", id=id, status=db_volume.status)
            return db_volume
        if image_id:
            # Create volume from image
            self._validate_update_volume_dict_from_image(
                session, image_id, volume_dict)
        elif src_volume_id:
            # Create volume form volume
            self._validate_update_volume_dict_from_volume(
                session, src_volume_id, volume_dict)
        elif src_snapshot_id:
            # Create volume form snapshot
            self._validate_update_volume_dict_from_snapshot(
                session, src_snapshot_id, volume_dict)
        else:
            # Create a blank volume
            pass

        self._set_or_check_volume_backend(volume_dict)
        # TODO(liupeng) Current status changes are prepare_clone to cloning.
        # In the future, set to prepare_create creating
        if src_volume_id or src_snapshot_id:
            volume_dict['status'] = constants.PREPARE_CLONE
        else:
            volume_dict['status'] = constants.PREPARE_CREATE
        db_volume = self.volume_repo.create(session, **volume_dict)

        return db_volume

    @wsme_pecan.wsexpose(volume_types.VolumeRootResponse,
                         status_code=200, body=volume_types.VolumeRootPOST)
    def post(self, volume_root_obj):
        """Create a volume."""
        session = pecan_request.context.get('trochilus_context').session

        kwargs = volume_root_obj.volume.to_dict()
        LOG.info("Create volume with parameters: %s", kwargs)

        # TODO(lxc): Add scheduler func for select a agent
        agent = self.agent_repo.get_agent_randomly(session)
        if not agent:
            raise exceptions.AgentUnavailable()

        kwargs['status'] = constants.PREPARE_CREATE
        kwargs['hostname'] = agent.hostname
        flatten = kwargs.pop("flatten", False)

        db_volume = self._validate_create_volume(session, kwargs)

        LOG.debug("Send to agent %(agent)s create volume %(id)s",
                  {"agent": agent.hostname, "id": db_volume.id})

        if db_volume.volume_id:
            self.agent_client.crete_volume_from_volume(
                agent, id=db_volume.id, src_vol_id=db_volume.volume_id)
        elif db_volume.snapshot_id:
            self.agent_client.create_volume_from_snapshot(
                agent,
                snap_id=db_volume.snapshot_id,
                vol_id=db_volume.id,
                flatten=flatten)
        else:
            self.agent_client.create_volume(agent, id=db_volume.id)

        result = self._convert_db_to_type(db_volume,
                                          volume_types.VolumeResponse)
        return volume_types.VolumeRootResponse(volume=result)

    def _validate_cascade_delete_volume(self, session, db_volume, cascade):

        is_attached = False
        need_delete_snapshot_ids = []

        if db_volume.status in constants.DELETE_BAN and not cascade:
            raise exceptions.VolumeDeleteConflict(id=db_volume.id,
                                                  status=db_volume.status)
        if db_volume.status == constants.IN_USE:
            # Detach volume, this will change volume status to prepare_detach
            vm_id = db_volume.vm_volume_mapping[0].virtual_machine_id
            virtual_machine.VirtualMachineActionController(
                vm_id)._validate_detach_volume(session, None, db_volume)
            is_attached = True

        vol_snapshots = db_volume.snapshot
        if vol_snapshots and not cascade:
            raise exceptions.VolumeHasSnapshot(id=db_volume.id)
        if vol_snapshots:
            # Delete the volume's snapshots, this will change snapshot status
            # to prepare_delete
            for vol_snapshot in vol_snapshots:
                snapshot.SnapshotController()._validate_and_delete_snapshot(
                    session, vol_snapshot)
                need_delete_snapshot_ids.append(vol_snapshot.id)

        if not is_attached:
            db_volume.status = constants.PREPARE_DELETE
        db_volume.save(session)

        return (is_attached, need_delete_snapshot_ids)

    @wsme_pecan.wsexpose(None, wtypes.text, wtypes.text, status_code=204)
    def delete(self, id, cascade=False):
        """Delete a volume by id"""
        session = pecan_request.context.get('trochilus_context').session
        cascade = strutils.bool_from_string(cascade)

        LOG.info("Deleting volume with id: %s", id)

        db_volume = self.volume_repo.get(session, id=id)
        if not db_volume:
            msg = ("No volume found with id %s" % id)
            raise exceptions.NotFound(msg=msg)

        (is_attached, need_delete_snapshot_ids
         ) = self._validate_cascade_delete_volume(session, db_volume, cascade)

        agent = self.agent_repo.get(session, hostname=db_volume.hostname)
        if cascade:
            self.agent_client.cascade_delete_volume(
                agent, id=id, is_attached=is_attached,
                need_delete_snapshot_ids=need_delete_snapshot_ids)
        else:
            self.agent_client.delete_volume(agent, id=id)

    @pecan_expose()
    def _lookup(self, id, *remainder):
        """Overridden pecan _lookup method for custom routing.

        Currently it checks if this was a failover request and routes
        the request to the FailoverController.
        """
        if id and remainder:
            controller = remainder[0]
            remainder = remainder[1:]
            if controller == 'action':
                return VolumeActionController(id=id), remainder
        return None


class VolumeActionController(base.BaseController):

    def __init__(self, id):
        super().__init__()
        self.id = id
        self.agent_repo = agent_repo.AgentRepository()
        self.agent_client = agent_rest_driver.AgentRestClient()
        self.volume_repo = volume_repo.VolumeRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()

    @wsme_pecan.wsexpose(body=volume_types.VolumeActionRootPOST,
                         status_code=201)
    def post(self, action_):
        action = action_.action

        session = pecan_request.context.get('trochilus_context').session
        db_volume = self.volume_repo.get(session, id=self.id)
        if not db_volume:
            raise exceptions.VolumeNotFound(id=self.id)

        try:
            action_func = getattr(self, action.name)
        except Exception as e:
            raise exceptions.UnsupportVolumeAction(
                action_name=action.name) from e

        action_dict = action.to_dict()
        action_func(session, db_volume, action_dict)

    def _validate_volume_snapshot_for_revert(
            self, session, db_volume, snapshot_id):

        # If db_volume is None, invoking from snapshot group revert action
        if not db_volume:
            db_volume = self.volume_repo.get(session, id=self.id)

        # Checkout volume status
        volume_state = db_volume.status
        if volume_state not in constants.USEFUL_VOL_STATUS:
            raise exceptions.InvalidVolume(
                id=db_volume.id,
                status=constants.USEFUL_VOL_STATUS,
                cur_status=db_volume.status)

        # Checkout snapshot status
        snapshot_obj = self.snapshot_repo.get(session,
                                              id=snapshot_id)
        if not snapshot_obj:
            raise exceptions.NotFound(resource='snapshot',
                                      id=snapshot_id)
        if snapshot_obj.status != constants.AVAILABLE:
            raise exceptions.InvalidSnapshot(
                id=snapshot_obj.id,
                status=constants.AVAILABLE,
                cur_status=snapshot_obj.status)

        # Update volume status
        self.volume_repo.update(session,
                                self.id,
                                status=constants.PREPARE_REVERT)

    def revert(self, session, db_volume, action_dict):
        LOG.info("Prepare revert volume %s to snapshot", self.id)

        origin_volume_status = db_volume.status
        revert_extended_attr = action_dict.get("extended_attr", {})
        snapshot_id = revert_extended_attr.get("snapshot_id", None)

        db_snapshot = self.snapshot_repo.get(session, id=snapshot_id)
        if db_volume.id != db_snapshot.volume_id:
            raise exceptions.SnapshotRollbackError(snap_id=snapshot_id)

        self._validate_volume_snapshot_for_revert(
            session, db_volume, snapshot_id)

        agent = self.agent_repo.get(session, hostname=db_volume.hostname)
        self.agent_client.revert_volume_to_snapshot(
            agent,
            id=self.id,
            snap_id=snapshot_id,
            volume_state=origin_volume_status)

    def resize(self, session, db_volume, action_dict):
        LOG.info("Preparing to change the size of volume %s", self.id)
        vol_state = db_volume.status

        # Check volume status
        if vol_state not in constants.USEFUL_VOL_STATUS:
            raise exceptions.InvalidVolumeState(
                id=db_volume.id,
                status=vol_state)

        # resize volume
        extended_attr = action_dict.get("extended_attr", {})
        volume_size = extended_attr.get('size')
        if not volume_size:
            raise exceptions.InvalidRequest(msg='size must be present')
        if volume_size <= db_volume.size:
            raise exceptions.InvalidRequest(msg='Must be greater than'
                                                ' the original value')
        with db_api.get_lock_session() as lock_session:
            # update volume status
            self.volume_repo.update(
                lock_session, db_volume.id,
                **{'status': constants.PREPARE_RESIZE})

        db_vvm = db_volume.vm_volume_mapping
        if db_vvm:
            db_vm = self.vm_repo.get(session, id=db_vvm[0].virtual_machine_id)
            agent = self.agent_repo.get(session, id=db_vm.agent_id)
        else:
            agent = self.agent_repo.get(session, hostname=db_volume.hostname)
        self.agent_client.resize_volume(agent,
                                        id=db_volume.id,
                                        volume_size=volume_size,
                                        volume_state=vol_state)
