#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os

from oslo_log import log as logging
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.agent.agent_client import agent_rest_driver
from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import voi as voi_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.common import voi_utils

LOG = logging.getLogger(__name__)


class BackupDiskController(base.BaseController):
    def __init__(self):
        super().__init__()
        self.agent_client = agent_rest_driver.AgentRestClient()

    BACKUP_DISK_INDEX_MAP = {
        constants.BACKUP_DATA_DISK_PREFIX_NAME: 1,
        constants.SYS_DISK_PREFIX_NAME: 0
    }

    SUPPORT_PREFIX_NAMES = [constants.BACKUP_DATA_DISK_PREFIX_NAME,
                            constants.SYS_DISK_PREFIX_NAME]

    SUPPORT_MIDDLE_NAMES = [constants.INCR1_DISK_NAME,
                            constants.INCR2_DISK_NAME]

    @wsme_pecan.wsexpose(voi_types.DiskDetailsRootResponse,
                         wtypes.text,
                         status_code=200)
    def get(self, disk_dirpath=None):

        # Check disk_dirpath exits
        if not disk_dirpath or not os.path.exists(disk_dirpath):
            raise exceptions.InvalidRequest(msg="The directory "
                                            "does not exist.")

        disk_details = []
        # Get filename and filepath
        dirpath, dirnames, filenames = next(os.walk(disk_dirpath))
        for filename in filenames:
            disk_filepath = os.path.join(dirpath, filename)
            prefix_name = [
                name for name in self.SUPPORT_PREFIX_NAMES
                if name in filename]
            if prefix_name and filename.endswith(
                    constants.VOI_DISK_SUFFIX_NAME):
                middle_name = [
                    name for name in self.SUPPORT_MIDDLE_NAMES
                    if name in filename]
                if middle_name:
                    really_size = 0
                    if os.path.exists(disk_filepath):
                        data = voi_utils.get_qemu_img_info(disk_filepath)
                        really_size = data.disk_size
                    disk_details.append(voi_types.DiskDetailResponse(**{
                        "index": self.BACKUP_DISK_INDEX_MAP.get(
                            prefix_name[0]),
                        "path": disk_filepath,
                        'size': really_size,
                        'name': filename,
                        'type': middle_name[0]
                    }))
            else:
                continue

        return voi_types.DiskDetailsRootResponse(disk_details=disk_details)

    @wsme_pecan.wsexpose(voi_types.VOIDataBackupPostResponse,
                         body=voi_types.VOIDataBackupPost,
                         status_code=201)
    def post(self, data):
        context = pecan_request.context.get('trochilus_context')
        disk_base_filepath = data.disk_base_filepath or None
        disk_dirpath = data.disk_dirpath
        disk_type = data.disk_type

        if not os.path.exists(disk_dirpath):
            raise exceptions.NotFound(
                resource="disk_dirpath", id=disk_dirpath)
        if disk_base_filepath and not os.path.exists(disk_base_filepath):
            raise exceptions.NotFound(
                resource="disk_base_filepath", id=disk_base_filepath)

        # 随机选择一个 agent 执行 commit 操作
        agent = self.agent.get_agent_randomly(context.session)
        if not agent:
            raise exceptions.AgentUnavailable()
        # 通知 agent 执行合并操作
        self.agent_client.commit_backup_disk(
            agent, **{
                "disk_base_filepath": disk_base_filepath,
                "disk_dirpath": disk_dirpath,
                "disk_type": disk_type
            })

        return voi_types.VOIDataBackupPostResponse(status="ok")
