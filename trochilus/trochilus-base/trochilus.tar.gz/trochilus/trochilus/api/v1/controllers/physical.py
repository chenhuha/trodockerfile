#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import physical as physical_types
from trochilus.common import exceptions


class PhysicalController(base.BaseController):

    def __init__(self):
        super().__init__()

    def _convert_object_to_type(self, physical_obj):
        type_vlan_ranges = []
        for vlan_range in physical_obj['vlan_ranges']:
            type_vlan_ranges.append(physical_types.VlanRange(**vlan_range))
        return physical_types.PhysicalResponse(
            **{'name': physical_obj['name'],
               'support_flat': physical_obj['support_flat'],
               'vlan_ranges': type_vlan_ranges})

    @wsme_pecan.wsexpose(physical_types.PhysicalRootResponse,
                         wtypes.text, ignore_extra_args=True)
    def get_one(self, name):
        phy_obj = self.physical_repo.get_one(name)
        if not phy_obj:
            raise exceptions.NotFound(resource='physical', id=name)
        phy_type = self._convert_object_to_type(phy_obj)
        return physical_types.PhysicalRootResponse(pyhsical=phy_type)

    @wsme_pecan.wsexpose(physical_types.PhysicalsRootResponse,
                         ignore_extra_args=True)
    def get_all(self):
        all_physical = []
        for physical_obj in self.physical_repo.get_all():
            all_physical.append(self._convert_object_to_type(physical_obj))
        return physical_types.PhysicalsRootResponse(physicals=all_physical)
