#   Copyright 2022 Troila
#
#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.

import ipaddress as ipaddr
import netaddr

from oslo_config import cfg
from oslo_db import api as oslo_db_api
from oslo_log import log as logging
from pecan import request as pecan_request
from wsme import types as wtypes
from wsmeext import pecan as wsme_pecan

from trochilus.api.v1.controllers import base
from trochilus.api.v1.types import subnet as subnet_types
from trochilus.common import constants
from trochilus.common import exceptions
from trochilus.db import api as db_api
from trochilus.db import dhcp_repo
from trochilus.db import nic_repo
from trochilus.db import subnet_repo
from trochilus.db import vpc_repo


CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class SubnetController(base.BaseController):

    def __init__(self):
        super().__init__()
        self.subnet_repo = subnet_repo.SubnetRepository()
        self.addr_pool_repo = subnet_repo.AddressPoolRepository()
        self.dns_repo = subnet_repo.DnsNameServerRepository()
        self.vpc_repo = vpc_repo.VpcRepository()
        self.dhcp_repo = dhcp_repo.DhcpNodeMappingRepository()
        self.ip_alloc_repo = nic_repo.AddressAllocRepository()

    @wsme_pecan.wsexpose(subnet_types.SubnetRootResponse, wtypes.text,
                         [wtypes.text], ignore_extra_args=True)
    def get_one(self, id, fields=None):
        """Gets a subnet's details."""
        session = pecan_request.context.get('trochilus_context').session
        db_subnet = self.subnet_repo.get(session, id=id)

        if not db_subnet:
            raise exceptions.NotFound(resource='subnet', id=id)

        db_subnet.address_details = self._calculate_address_details(
            session, db_subnet)
        subnet_result = self._convert_db_to_type(db_subnet,
                                                 subnet_types.SubnetResponse)
        if fields is not None:
            subnet_result = self._filter_fields([subnet_result], fields)[0]
        return subnet_types.SubnetRootResponse(subnet=subnet_result)

    @wsme_pecan.wsexpose(subnet_types.SubnetsRootResponse,
                         [wtypes.text], ignore_extra_args=True)
    def get_all(self, fields=None):
        """Lists all subnets."""
        session = pecan_request.context.get('trochilus_context').session
        db_subnets, links = self.subnet_repo.get_all(
            session,
            pagination_helper=pecan_request.context.get('pagination_helper'))

        for db_subnet in db_subnets:
            db_subnet.address_details = self._calculate_address_details(
                session, db_subnet)

        subnet_result = self._convert_db_to_type(list(db_subnets),
                                                 [subnet_types.SubnetResponse])
        if fields is not None:
            subnet_result = self._filter_fields(subnet_result, fields)
        return subnet_types.SubnetsRootResponse(subnets=subnet_result,
                                                subnet_links=links)

    @wsme_pecan.wsexpose(subnet_types.SubnetRootResponse,
                         wtypes.text, status_code=200,
                         body=subnet_types.SubnetRootPUT)
    def put(self, id, subnet_):
        """Updates a subnet."""
        session = pecan_request.context.get('trochilus_context').session
        db_subnet = self.subnet_repo.get(session, id=id)

        # Prepare the data for subnet operation.
        subnet_dict = subnet_.subnet.to_dict(render_unsets=False)
        LOG.debug("Updating subnet %(id)s with parameters: %(param)s",
                  dict(id=id, param=subnet_dict))

        if not db_subnet:
            raise exceptions.NotFound(resource='subnet', id=id)

        # Validate the start_ip and end_ip in cidr if address_pools exist
        address_pools = subnet_dict.pop('address_pools', None)
        if address_pools:
            # Referenced from openstack neutron/db/ipam_backend_mixin.py
            self.subnet_repo.validate_address_pools(
                address_pools, db_subnet.cidr)
            # Validate the gateway out of address pools
            # Refers from openstack neutron/db/ipam_backend_mixin.py
            self.subnet_repo.validate_gw_out_of_pools(
                db_subnet.gateway, address_pools)

        # Validate dns
        dns_nameservers = subnet_dict.pop('dns_nameservers', None)
        if dns_nameservers:
            self.subnet_repo.validate_dns(dns_nameservers)

        # Determine whether the first subnet if the subnet enable dhcp
        # Determine whether the last subnet if the subnet disable dhcp
        # Determine whether to add dhcp ip if the subnet is not first
        # to enable dhcp
        # Determine whether to delete dhcp ip if the subnet is not last
        # to disable dhcp
        create_dhcp_nics, delete_dhcp_nics, add_dhcp_ips, delete_dhcp_ips = \
            self.dhcp_repo.need_to_handle_dhcp(session,
                                               subnet_dict.get('enable_dhcp'),
                                               db_subnet)

        with db_api.get_lock_session() as lock_session:
            # Update in subnet table
            if any(['name' in subnet_dict, 'description' in subnet_dict,
                    'enable_dhcp' in subnet_dict]):
                self.subnet_repo.update(lock_session, id, **subnet_dict)
            # Insert or delete in address_pool table
            if address_pools:
                # Add new adress pools
                db_addr_pools = set((pool.start_ip, pool.end_ip)
                                    for pool in db_subnet.address_pools)
                request_addr_pools = set((pool['start_ip'], pool['end_ip'])
                                         for pool in address_pools)
                create_addr_pools = request_addr_pools.\
                    difference(db_addr_pools)
                if create_addr_pools:
                    create_list = [{'subnet_id': db_subnet.id,
                                    'start_ip': pool[0],
                                    'end_ip': pool[1]} for pool
                                   in create_addr_pools]
                    self.addr_pool_repo.create_batch(lock_session, create_list)
                # Delete old address pools
                delete_ids = [db_pool.id for db_pool in
                              db_subnet.address_pools
                              if (db_pool.start_ip, db_pool.end_ip)
                              not in request_addr_pools]
                if delete_ids:
                    self.addr_pool_repo.delete_batch(lock_session, delete_ids)
            # Update dns_nameserver table
            if dns_nameservers is not None:
                self.dns_repo.delete_batch(lock_session, db_subnet.id)
                if dns_nameservers:
                    param_for_create = [{'subnet_id': db_subnet.id,
                                        'ip_address': ip_address,
                                         'order': index}
                                        for index, ip_address
                                        in enumerate(dns_nameservers)]
                    self.dns_repo.create_batch(lock_session, param_for_create)
            # Handle dhcp
            if create_dhcp_nics:
                self.dhcp_repo.create_dhcp_nics(lock_session, db_subnet)
            if delete_dhcp_nics:
                self.dhcp_repo.delete_dhcp_nics(lock_session, db_subnet.vpc_id)
            if add_dhcp_ips:
                self.dhcp_repo.add_dhcp_ips(lock_session, db_subnet)
            if delete_dhcp_ips:
                self.dhcp_repo.delete_dhcp_ips(lock_session,
                                               db_subnet.vpc_id,
                                               db_subnet.id)

        # Force SQL alchemy to query the DB for ensure consistent results
        session.expire_all()

        LOG.debug("Update subnet %s successful", id)
        db_subnet_ = self.subnet_repo.get(session, id=id)

        update_dhcp_dns = (db_subnet_.enable_dhcp and
                           dns_nameservers is not None)
        if subnet_dict.get('enable_dhcp') is not None or update_dhcp_dns:
            self.dhcp_repo.notify_dhcp_agent_if_need(
                constants.UPDATE_SUBNET, db_subnet.vpc_id,
                create_dhcp_nics=create_dhcp_nics,
                delete_dhcp_nics=delete_dhcp_nics,
                add_dhcp_ips=add_dhcp_ips,
                delete_dhcp_ips=delete_dhcp_ips,
                update_dhcp_dns=update_dhcp_dns)

        db_subnet_.address_details = self._calculate_address_details(
            session, db_subnet_)

        subnet_result = self._convert_db_to_type(db_subnet_,
                                                 subnet_types.SubnetResponse)
        return subnet_types.SubnetRootResponse(subnet=subnet_result)

    @oslo_db_api.wrap_db_retry(max_retries=5, retry_on_deadlock=True)
    @wsme_pecan.wsexpose(None, wtypes.text, status_code=204)
    def delete(self, id):
        """Deletes a subnet record in database."""
        session = pecan_request.context.get('trochilus_context').session
        LOG.debug("Deleting subnet with id: %s", id)

        db_subnet = self.subnet_repo.get(session, id=id)
        if not db_subnet:
            raise exceptions.NotFound(resource='subnet', id=id)

        # If there is a nic in the subnet(except dhcp nic),
        # it is forbidden to delete it
        if db_subnet.alloc_ip_addresses:
            for alloc in db_subnet.alloc_ip_addresses:
                if alloc.nic.owner_type != constants.NIC_OF_DHCP:
                    raise exceptions.ObjectInUse(object='subnet', id=id)

        # Determine whether the last subnet if the subnet disable dhcp
        # Determine whether to delete dhcp ip if the subnet is not last to
        # disable dhcp
        _, delete_dhcp_nics, _, delete_dhcp_ips = \
            self.dhcp_repo.need_to_handle_dhcp(session, False, db_subnet)
        with db_api.get_lock_session() as lock_session:
            # handle dhcp
            if delete_dhcp_nics:
                self.dhcp_repo.delete_dhcp_nics(lock_session, db_subnet.vpc_id)
            if delete_dhcp_ips:
                self.dhcp_repo.delete_dhcp_ips(lock_session,
                                               db_subnet.vpc_id,
                                               db_subnet.id)

            self.subnet_repo.delete(lock_session, id=id)
            LOG.debug("Delete subnet %s successful", id)

        self.dhcp_repo.notify_dhcp_agent_if_need(
            constants.DELETE_SUBNET, db_subnet.vpc_id,
            delete_dhcp_nics=delete_dhcp_nics, delete_dhcp_ips=delete_dhcp_ips)

    @wsme_pecan.wsexpose(subnet_types.SubnetRootResponse,
                         wtypes.text, status_code=200,
                         body=subnet_types.SubnetRootPOST)
    def post(self, subnet_):
        """Creates a subnet."""
        session = pecan_request.context.get('trochilus_context').session

        # Prepare the data for subnet operation.
        subnet_dict = subnet_.subnet.to_dict()
        LOG.debug("Creating subnet with parameters: %s", subnet_dict)

        db_vpc = self.vpc_repo.get(session, id=subnet_dict['vpc_id'])
        if not db_vpc:
            raise exceptions.NotFound(resource='vpc',
                                      id=subnet_dict['vpc_id'])

        # Collect the information of all subnets in the same vpc
        existing_subnets, _ = self.subnet_repo.get_all(session,
                                                       vpc_id=db_vpc.id)
        # Rectify the CIDR format and verify the format of the cidr
        subnet_dict['cidr'] = self.subnet_repo.validate_cidr(
            subnet_dict, existing_subnets)

        if subnet_dict.get('gateway'):
            # Validate the gataway ip is valid in the cidr
            self.subnet_repo.validate_ip_invalid_in_subnet(
                subnet_dict['gateway'], subnet_dict['cidr'], 'gateway ip')
        else:
            # If no input gateway ip, the address is assigned from
            # the cidr ranges as the default gateway ip
            subnet_dict['gateway'] = self.subnet_repo.allocate_gateway(
                subnet_dict['cidr'])

        # Verify adress pool
        address_pools = subnet_dict.pop('address_pools', None)
        if address_pools:
            # Refers from openstack neutron/db/ipam_backend_mixin.py
            self.subnet_repo.validate_address_pools(address_pools,
                                                    subnet_dict['cidr'])
        else:
            # Refers from openstack neutron/ipam/utils.py
            address_pools = self.subnet_repo.generate_pools(
                subnet_dict['cidr'], subnet_dict['gateway'])

        # Validate the gateway out of address pools
        # Refers from openstack neutron/db/ipam_backend_mixin.py
        self.subnet_repo.validate_gw_out_of_pools(subnet_dict['gateway'],
                                                  address_pools)

        # Validate dns
        dns_nameservers = subnet_dict.pop('dns_nameservers', None)
        if dns_nameservers:
            self.subnet_repo.validate_dns(dns_nameservers)

        # If request does not set enable_dhcp, set true
        if subnet_dict.get('enable_dhcp') is None:
            subnet_dict['enable_dhcp'] = True

        with db_api.get_lock_session() as lock_session:
            db_subnet = self.subnet_repo.create(lock_session, **subnet_dict)
            if address_pools:
                address_pools = [{'start_ip': pool['start_ip'],
                                  'end_ip': pool['end_ip'],
                                  'subnet_id': db_subnet.id}
                                 for pool in address_pools]
                self.addr_pool_repo.create_batch(lock_session, address_pools)
            if dns_nameservers:
                dns_nameservers = [{'subnet_id': db_subnet.id,
                                    'ip_address': ip_address,
                                    'order': index}
                                   for index, ip_address
                                   in enumerate(dns_nameservers)]
                self.dns_repo.create_batch(lock_session, dns_nameservers)

            # Determine whether the first subnet if the subnet enable dhcp
            # Determine whether to add dhcp ip if the subnet is not first to
            # to enable dhcp
            create_dhcp_nics, _, add_dhcp_ips, _ = \
                self.dhcp_repo.need_to_handle_dhcp(lock_session,
                                                   db_subnet.enable_dhcp,
                                                   db_subnet)
            # handle dhcp
            if create_dhcp_nics:
                self.dhcp_repo.create_dhcp_nics(lock_session, db_subnet)
            if add_dhcp_ips:
                self.dhcp_repo.add_dhcp_ips(lock_session, db_subnet)
            LOG.debug("Create subnet %s successful", db_subnet.id)
        db_subnet_ = self.subnet_repo.get(session, id=db_subnet.id)

        self.dhcp_repo.notify_dhcp_agent_if_need(
            constants.CREATE_SUBNET, db_subnet_.vpc_id,
            create_dhcp_nics=create_dhcp_nics, add_dhcp_ips=add_dhcp_ips)

        # Calculate the total IP number within CIDR
        total_ip_within_cidr = self._calculate_total_ip_within_cidr(
            db_subnet_.get('cidr'))
        # The number of allocate_pool_ip within the newly address pool
        # is equal to the number of allocable_ip.
        # used_ip = 1, Cuz gateway address occupy an ip within the cidr
        allocate_pool_ip = \
            self._calculate_allocate_ip_within_address_pools(
                session, db_subnet_.get('id'))
        db_subnet_.address_detail = {'total_ip': total_ip_within_cidr,
                                     'used_ip': 1,
                                     'allocate_pool_ip': allocate_pool_ip,
                                     'allocable_ip': allocate_pool_ip}

        subnet_result = self._convert_db_to_type(db_subnet_,
                                                 subnet_types.SubnetResponse)
        return subnet_types.SubnetRootResponse(subnet=subnet_result)

    def _calculate_total_ip_within_cidr(self, cidr):
        """Calculate total ip within the cidr"""
        total_ip_within_cidr = ipaddr.IPv4Network(cidr).num_addresses
        return total_ip_within_cidr

    def _calculate_used_ip_within_cidr(self, session, subnet_id):
        """Calculate the number of IP addresses occupy with nics"""
        # Query the IP addresses assigned in the subnet
        # to the address allocation table
        ip_alloc, _ = self.ip_alloc_repo.get_all(
            session, subnet_id=subnet_id)
        # ip_count = 1, Cuz gateway address occupy an ip within the cidr
        ip_count = 1
        if ip_alloc:
            ip_count += len(ip_alloc)
        return ip_count

    def _calculate_allocate_ip_within_address_pools(self, session,
                                                    subnet_id):
        """Calculate allocate pool ip within the address pools"""
        address_pools, _ = self.addr_pool_repo.get_all(
            session, subnet_id=subnet_id)
        allocate_pool_ip = 0
        if address_pools:
            for address_pool in address_pools:
                allocate_pool_ip += len(list(netaddr.IPRange(
                    address_pool['start_ip'], address_pool['end_ip'])))
        return allocate_pool_ip

    def _calculate_used_ip_within_address_pools(self, session, subnet_id):
        # Query the IP addresses assigned in the subnet
        # to the address allocation table
        ip_alloc, _ = self.ip_alloc_repo.get_all(
            session, subnet_id=subnet_id)
        address_pools, _ = self.addr_pool_repo.get_all(
            session, subnet_id=subnet_id)
        used_ip = 0
        ips_addr = []
        if ip_alloc:
            for address in ip_alloc:
                ips_addr.append(address.get('ip_address'))
        if address_pools:
            for pool in address_pools:
                ip_range = netaddr.IPRange(pool.get('start_ip'),
                                           pool.get('end_ip'))
                for index in range(len(ips_addr)):
                    if ips_addr[index] and ips_addr[index] in ip_range:
                        used_ip += 1
                        ips_addr[index] = None
        return used_ip

    def _calculate_address_details(self, session, db_subnet):
        # Calculate the total IP number in CIDR
        total_ip_within_cidr = self._calculate_total_ip_within_cidr(
            db_subnet.get('cidr'))
        # Calculate used ip from address allocation table
        used_ip_within_cidr = self._calculate_used_ip_within_cidr(
            session, db_subnet.get('id'))

        # Calculate the usable ip num in the address pools
        allocate_pool_ip = \
            self._calculate_allocate_ip_within_address_pools(
                session, db_subnet.get('id'))

        # Calculate the number of IP addresses
        # has been allocated in the lastest address pool
        used_ip_within_pools = \
            self._calculate_used_ip_within_address_pools(
                session, db_subnet.get('id'))
        allocable_ip_within_pools = allocate_pool_ip \
            - used_ip_within_pools

        # Update the latest addreesses information
        # to the address detail table
        address_detail = {'total_ip': total_ip_within_cidr,
                          'used_ip': used_ip_within_cidr,
                          'allocate_pool_ip': allocate_pool_ip,
                          'allocable_ip': allocable_ip_within_pools}
        return address_detail
