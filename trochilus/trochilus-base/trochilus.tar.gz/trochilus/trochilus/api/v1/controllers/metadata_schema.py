# Copyright 2018 Rackspace US Inc.  All rights reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

# This is a JSON schema validation dictionary
# https://json-schema.org/latest/json-schema-validation.html
#
# Note: This is used to generate the amphora driver "supported flavor
#       metadata" dictionary. Each property should include a description
#       for the user to understand what this flavor setting does.
#
# Where possible, the property name should match the configuration file name
# for the setting. The configuration file setting is the default when a
# setting is not defined in a flavor profile.


METADATA_SCHEMA = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Metadata Schema",
    "description": "This schema is used to verify metadata",
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "k1": {
            "type": "string",
            "description": "Check field K1",
            "enum": ["k1_v1", "k1_v2", "k1_v3"]
        },
        "k2": {
            "type": "string",
            "description": "Check field K2",
        },
        "k3": {
            "type": "string",
            "description": "Check field K2",
            "enum": ["k1_v1", "k1_v2", "k1_v3"]
        }
    }
}
