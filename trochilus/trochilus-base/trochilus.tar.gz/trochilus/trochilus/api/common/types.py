#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import copy

import netaddr
from wsme import types as wtypes


class IPAddressType(wtypes.UserType):
    basetype = str
    name = 'ipaddress'

    @staticmethod
    def validate(value):
        """Validates whether value is an IPv4 or IPv6 address."""
        try:
            wtypes.IPv4AddressType.validate(value)
            return value
        except ValueError:
            try:
                wtypes.IPv6AddressType.validate(value)
                return value
            except ValueError as e:
                error = 'Value should be IPv4 or IPv6 format'
                raise ValueError(error) from e


class CidrType(wtypes.UserType):
    basetype = str
    name = 'cidr'

    @staticmethod
    def validate(value):
        """Validates whether value is an IPv4 or IPv6 CIDR."""
        try:
            return str(netaddr.IPNetwork(value).cidr)
        except (ValueError, netaddr.core.AddrFormatError) as e:
            error = 'Value should be IPv4 or IPv6 CIDR format'
            raise ValueError(error) from e


class BaseType(wtypes.Base):
    @classmethod
    def _full_response(cls):
        return False

    @classmethod
    def from_db_model(cls, db_model, children=False):
        """Converts db_model to Trochilus WSME type.

        :param db_model: database model to convert from
        :param children: convert child database models
        """
        type_dict = db_model.to_dict()

        if not hasattr(cls, '_type_to_model_map'):
            return cls(**type_dict)

        dm_to_type_map = {value: key
                          for key, value in cls._type_to_model_map.items()}

        new_dict = copy.deepcopy(type_dict)
        for key, value in type_dict.items():
            if isinstance(value, dict):
                for child_key, child_value in value.items():
                    if '.'.join([key, child_key]) in dm_to_type_map:
                        new_dict['_'.join([key, child_key])] = child_value
            elif key in ['name', 'description'] and value is None:
                new_dict[key] = ''
            else:
                if key in dm_to_type_map:
                    new_dict[dm_to_type_map[key]] = value
                    del new_dict[key]
        return cls(**new_dict)

    @classmethod
    def translate_dict_keys_to_db_model(cls, wsme_dict):
        """Translate the keys from wsme class type, to db_model."""
        if not hasattr(cls, '_type_to_model_map'):
            return wsme_dict
        res = {}
        for (k, v) in wsme_dict.items():
            if k in cls._type_to_model_map:
                k = cls._type_to_model_map[k]
                if '.' in k:
                    parent, child = k.split('.')
                    if parent not in res:
                        res[parent] = {}
                    res[parent][child] = v
                    continue
            res[k] = v
        return res

    @classmethod
    def translate_key_to_db_model(cls, key):
        """Translate the keys from wsme class type, to db_model."""
        if not hasattr(cls, '_type_to_model_map') or (
                key not in cls._type_to_model_map):
            return key
        return cls._type_to_model_map[key]

    def to_dict(self, render_unsets=False):
        """Converts Trochilus WSME type to dictionary.

        :param render_unsets: If True, will convert items that are WSME Unset
                              types to None. If False, does not add the item
        """
        if hasattr(self, 'admin_state_up') and getattr(
                self, 'admin_state_up') is None:
            # This situation will be hit during request with
            # admin_state_up is null. If users specify this field to null,
            # then we treat it as False
            self.admin_state_up = bool(self.admin_state_up)
        wsme_dict = {}
        for attr in dir(self):
            if attr.startswith('_'):
                continue
            value = getattr(self, attr, None)
            if value and callable(value):
                continue
            if value and isinstance(value, BaseType):
                value = value.to_dict(render_unsets=render_unsets)
            if value and isinstance(value, list):
                value = [val.to_dict(render_unsets=render_unsets)
                         if isinstance(val, BaseType) else val
                         for val in value]
            if isinstance(value, wtypes.UnsetType):
                if render_unsets:
                    value = None
                else:
                    continue
            wsme_dict[attr] = value
        return self.translate_dict_keys_to_db_model(wsme_dict)


class PageType(BaseType):
    href = wtypes.StringType()
    rel = wtypes.StringType()


class MultiType(wtypes.UserType):
    """A complex type that represents one or more types.

    Used for validating that a value is an instance of one of the types.
    :param *types: Variable-length list of types.
    """

    def __init__(self, *types):
        self.types = types

    def __str__(self):
        return ' | '.join(map(str, self.types))

    def validate(self, value):
        for t in self.types:
            try:
                return wtypes.validate_value(t, value)
            except (ValueError, TypeError):
                # An error is raised at the end of the function
                # when the types don't match.
                pass
        else:  # pylint: disable=W0120
            raise ValueError(
                ("Wrong type. Expected '%(type)s', got '%(value)s'")
                % {'type': self.types, 'value': type(value)})


class IdOnlyType(BaseType):
    id = wtypes.wsattr(wtypes.UuidType(), mandatory=True)
