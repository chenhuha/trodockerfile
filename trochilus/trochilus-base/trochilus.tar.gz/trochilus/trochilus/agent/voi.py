#  Copyright 2022 Troila
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.

import os
import shutil
import typing as ty

from oslo_concurrency import processutils
from oslo_config import cfg
from oslo_log import log as logging
from oslo_service import loopingcall
from oslo_utils import excutils
from oslo_utils import fileutils
from oslo_utils import timeutils

from trochilus.agent.common import exceptions
from trochilus.agent.compute import event as virtevent
from trochilus.agent.compute.libvirt import config as vconfig
from trochilus.agent.compute.libvirt import driver
from trochilus.agent.compute.libvirt import power_state
from trochilus.agent.compute import utils
from trochilus.common import constants
from trochilus.common import exceptions as api_exceptions
from trochilus.common import voi_utils
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import voi_repo

if ty.TYPE_CHECKING:
    import libvirt
else:
    libvirt = None

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class VOI(driver.LibvirtDriver):

    def __init__(self, queue, network_manager):
        super().__init__()
        self.status_queue = queue
        self.image_repo = voi_repo.ImageRepository()
        self.vm_repo = voi_repo.VMRepository()
        self.volume_repo = voi_repo.VolumeRepository()
        self.share_tmpl_vol_repo = voi_repo.ShareTemplateVolumeRepository()
        self.vm_base_dir = CONF.voi_setting.voi_vm_base_path
        self.network_manager = network_manager
        self.agent_repo = agent_repo.AgentRepository()
        self.initialize()
        self.register_event_listener(self.handle_events)
        fileutils.ensure_tree(self.vm_base_dir)

    def _set_console_address(self, session, vm_power_state, db_vm):
        spice_add = CONF.vm_settings.spice_server_listen
        vnc_add = CONF.vm_settings.vnc_server_listen
        if vm_power_state == power_state.SHUTDOWN:
            db_vm.vnc_address = None
            db_vm.spice_address = None
        else:
            port_dict = self.get_console_port(db_vm)
            if port_dict.get('vnc', None):
                db_vm.vnc_address = vnc_add + ":" + port_dict.get('vnc')
            if port_dict.get('spice', None):
                db_vm.spice_address = spice_add + ":" + port_dict.get('spice')
        db_vm.save(session)

    def _sync_vm_power_state(self, session, db_vm, vm_power_state):
        if CONF.agent_settings.hostname != db_vm.agent.hostname:
            LOG.info("During the sync_power process the "
                     "VOI VM has moved from "
                     "host %(src)s to host %(dst)s",
                     {'src': CONF.agent_settings.hostname,
                      'dst': db_vm.agent.hostname})
            return
        if (db_vm.status == constants.ACTIVE and
                vm_power_state == power_state.SHUTDOWN):
            db_vm.status = constants.STOPPED
            db_vm.save(session)
            LOG.warning("The VOI VM shuts down abnormally.")
            self.status_queue.put(
                {"resource_type": "voi_vm",
                 "resource_id": db_vm.id,
                 "previous_status": constants.ACTIVE,
                 "current_status": constants.STOPPED,
                 "action": "stop",
                 "timestamp": timeutils.utcnow()})
        elif db_vm.status == constants.STOPPED:
            if vm_power_state != power_state.SHUTDOWN:
                LOG.warning("[VOI VM %s] VM status is %s, But VOI VM's power"
                            " status is running.", db_vm.id, db_vm.status)
        self._set_console_address(session, vm_power_state, db_vm)

    def handle_lifecycle_event(self, event):
        session = db_api.get_session()
        vm_id = event.get_vm_uuid()
        db_vm = self.vm_repo.get(session, id=vm_id)
        if not db_vm:
            raise exceptions.VMNotFound(vm_id=vm_id)
        LOG.info("[VOI VM %(vm_uuid)s] VM %(state)s (Lifecycle Event)",
                 {'vm_uuid': vm_id, 'state': event.get_name()})

        vm_power_state = None
        event_transition = event.get_transition()
        # TODO(liupeng) Handle SUSPENDED, MIGRATE, POSTCOPY event
        if event.get_transition() == virtevent.EVENT_LIFECYCLE_STOPPED:
            vm_power_state = power_state.SHUTDOWN
        elif event.get_transition() == virtevent.EVENT_LIFECYCLE_STARTED:
            vm_power_state = power_state.RUNNING
        elif event.get_transition() == virtevent.EVENT_LIFECYCLE_PAUSED:
            vm_power_state = power_state.PAUSED
        elif event.get_transition() == virtevent.EVENT_LIFECYCLE_RESUMED:
            vm_power_state = power_state.RUNNING
        else:
            LOG.warning("Unexpected lifecycle event: %d", event_transition)

        current_power_state = self.get_info(db_vm).state
        # The event may be delayed, thus not reflecting
        # the current VOI VM power state. In that case, ignore the event.
        if current_power_state == vm_power_state:
            LOG.debug('[VOI VM %(vm_id)s] Synchronizing VM power state after '
                      'lifecycle event "%(event)s"; current vm_state:'
                      ' %(vm_state)s,  VM power_state: %(vm_power_state)s',
                      {'event': event.get_name(),
                       'vm_state': db_vm.status,
                       'vm_power_state': vm_power_state,
                       'vm_id': db_vm.id})
            self._sync_vm_power_state(session, db_vm, vm_power_state)

    def handle_events(self, event):
        if isinstance(event, virtevent.LifecycleEvent):
            try:
                self.handle_lifecycle_event(event)
            except (api_exceptions.NotFound, exceptions.VMNotFound):
                LOG.debug("Event %s arrived for non-existent VOI VM. The "
                          "VOI VM was probably deleted.", event)
        else:
            LOG.debug("Ignoring event %s", event)

    def execute(self, *args, **kwargs):
        return processutils.execute(*args, **kwargs)

    def _get_nic_config(self, nic_obj):
        return self.network_manager.get_nic_config(
            nic_obj, CONF.vm_settings.virt_type)

    def _get_disk_name_and_path(self, vm_obj, vm_disk_obj,
                                disk_prefix_name, disk_middle_name):
        vm_dir = os.path.join(self.vm_base_dir, vm_obj.id)
        # Check is data disk
        if disk_prefix_name == constants.DATA_DISK_PREFIX_NAME:
            if not vm_disk_obj:
                msg = "Get data disk full path must need disk object"
                raise exceptions.InternalServerError(msg=msg)
            disk_prefix_name = constants.DATA_DISK_PREFIX_NAME + str(
                vm_disk_obj.index)
        prefix_uuid = vm_disk_obj.id if vm_disk_obj else vm_obj.id
        disk_name = (prefix_uuid +
                     "-" +
                     disk_prefix_name +
                     "-" +
                     disk_middle_name +
                     "." +
                     constants.VOI_DISK_SUFFIX_NAME)
        disk_path = os.path.join(vm_dir, disk_name)

        return disk_name, disk_path

    def _resize_image(self, base_disk_path, size):
        cmd = ['qemu-img', 'resize', base_disk_path, str(size) + 'G']
        self.execute(*cmd)

    def _create_base_disk(self, base_disk_path, size):
        cmd = [
            'qemu-img', 'create', '-f', 'qcow2', base_disk_path,
            str(size) + 'G'
        ]
        self.execute(*cmd)

    def _generate_disk_chain(self, vm_obj, vm_disk_obj, disk_prefix,
                             source_disk_path=None):
        # VOI 虚机用到的 qcow2 文件都要有一个 base 文件，三个增
        # 量文件（两个 incre 一个 current）
        size = vm_disk_obj.size if vm_disk_obj else vm_obj.root_disk_gb
        base_image_name, base_disk_path = self._get_disk_name_and_path(
            vm_obj,
            vm_disk_obj,
            disk_prefix,
            constants.BASE_DISK_NAME)

        if source_disk_path:
            # 从别的地方把母盘 copy 过来，然后调整大小（通常是从镜像目录 copy 过来）
            voi_utils.copy_image(source_disk_path, base_disk_path)
            self._resize_image(base_disk_path, size)
        else:
            # 创建一个母盘，用于数据盘或ISO启动的虚拟机
            self._create_base_disk(base_disk_path, size)

        # generate other incremental disk
        generate_disk_list = [constants.INCR1_DISK_NAME,
                              constants.INCR2_DISK_NAME,
                              constants.CURRENT_DISK_NAME]
        previous_incr_disk_name = base_image_name
        current_disk_name = ''
        current_disk_path = ''
        for generate_disk in generate_disk_list:
            incr_disk_name, incr_disk_path = self._get_disk_name_and_path(
                vm_obj,
                vm_disk_obj,
                disk_prefix,
                generate_disk)
            voi_utils.create_cow_image(previous_incr_disk_name,
                                       incr_disk_path)
            previous_incr_disk_name = incr_disk_name
            current_disk_name = incr_disk_name
            current_disk_path = incr_disk_path

        return current_disk_name, current_disk_path

    def _get_iso_config(self, iso_image_path, attached_index, boot_order=None):
        disk_config = vconfig.LibvirtConfigGuestDisk()
        if boot_order:
            disk_config.boot_order = str(boot_order)
        disk_config.readonly = True
        disk_config.source_device = 'cdrom'
        disk_config.driver_format = 'raw'
        disk_config.target_bus = 'sata'
        disk_config.source_type = 'file'
        disk_config.source_path = iso_image_path
        disk_config.target_dev = utils.generate_device_name(
            'sd', attached_index)
        return disk_config

    def _get_disk_config(self, file_path, attached_index, boot_order=None):
        disk_config = vconfig.LibvirtConfigGuestDisk()
        if boot_order:
            disk_config.boot_order = str(boot_order)
        disk_config.driver_format = 'qcow2'
        disk_config.target_bus = 'sata'
        disk_config.source_type = 'file'
        disk_config.source_path = file_path
        disk_config.target_dev = utils.generate_device_name(
            'sd', attached_index)
        return disk_config

    def _prepare_resources(self, vm_obj):
        session = db_api.get_session()
        img_obj = self.image_repo.get(session, id=vm_obj.image_id)
        # 准备系统盘 qcow2 文件
        image_path = img_obj.location.replace("file://", "")
        if img_obj.disk_format == "qcow2":
            self._generate_disk_chain(
                vm_obj, None, constants.SYS_DISK_PREFIX_NAME, image_path)
        elif img_obj.disk_format == "iso":
            self._generate_disk_chain(
                vm_obj, None, constants.SYS_DISK_PREFIX_NAME)
        else:
            raise exceptions.InvalidImageFormat(format=img_obj.disk_format)
        # 准备数据盘 qcow2 文件
        for disk in vm_obj.disks:
            self._generate_disk_chain(
                vm_obj, disk, constants.DATA_DISK_PREFIX_NAME)

    def _prepare_xml(self, vm_obj):
        session = db_api.get_session()
        guest_conf_obj = self._get_guest_config(vm_obj, [], None)
        guest_conf_obj.os_bootmenu = True
        # 为了兼容 VOI VM ISO 安装操作系统, 我们在开机时添加延迟默认为 15 秒,
        # 这样 15 秒后才会出现按任意键的字样 (不加延迟的话很快就会出现
        # Press any key to boot form CD or DVD... ,
        # 这个时候如果不按任意键就会进入  SHELL 界面, 需要通过硬重启或者通过
        # vnc 界面按 ctrl+alt+delete 进行重启, 才能再次进入按任意键界面)
        guest_conf_obj.os_bootmenu_timeout = True

        # Support UEFI boot
        boot_type = vm_obj.metadata_.get('boot_type',
                                         constants.VOI_DEFAULT_BOOT_TYPE)
        self._config_guest_by_boot_type(guest_conf_obj, boot_type)

        # 添加系统盘 xml
        _, sys_disk_path = self._get_disk_name_and_path(
            vm_obj, None, constants.SYS_DISK_PREFIX_NAME,
            constants.CURRENT_DISK_NAME)
        guest_conf_obj.add_device(
            self._get_disk_config(sys_disk_path, 0, boot_order=1))

        # 添加数据盘 xml
        # 目前 voi 模板机硬盘和光驱都使用 sata 设备
        # 数据盘索引从 1 开始
        max_index = 0
        for disk in vm_obj.disks:
            if disk.index > max_index:
                max_index = disk.index
            _, data_disk_path = self._get_disk_name_and_path(
                vm_obj, disk, constants.DATA_DISK_PREFIX_NAME,
                constants.CURRENT_DISK_NAME)
            guest_conf_obj.add_device(
                self._get_disk_config(data_disk_path, disk.index))

        # 添加光驱 xml
        # 光驱有且只有一个, 光驱的 index 默认为 2
        cd_driver = vm_obj.cd_drivers[0]
        cd_img_path = None
        if cd_driver.image_id:
            cd_img_obj = self.image_repo.get(session, id=cd_driver.image_id)
            cd_img_path = cd_img_obj.location.replace("file://", "")
        if cd_driver.is_sys:
            iso_conf = self._get_iso_config(
                cd_img_path, constants.CDROM_DEFAULT_INDEX, boot_order=2)
        else:
            iso_conf = self._get_iso_config(cd_img_path,
                                            constants.CDROM_DEFAULT_INDEX)
        guest_conf_obj.add_device(iso_conf)

        # 添加网卡 xml
        for nic in vm_obj.nics:
            guest_conf_obj.add_device(self._get_nic_config(nic))

        # 添加共享模板盘 xml
        max_index = 10
        for disk in vm_obj.share_template_disks:
            if disk.index > max_index:
                max_index = disk.index
            _, disk_path = voi_utils.get_share_tmpl_disk_name_and_path(
                disk.id, CONF.voi_setting.share_template_disk_path)
            guest_conf_obj.add_device(
                self._get_disk_config(disk_path, disk.index))

        return guest_conf_obj.to_xml()

    def _copy_src_voi_disks(self, vm_obj, src_vm_obj, is_copy_data_disk):
        vm_dir = os.path.join(self.vm_base_dir, vm_obj.id)
        src_vm_dir = os.path.join(self.vm_base_dir, src_vm_obj.id)
        if is_copy_data_disk:
            # vm_dir should not exist, In this way,
            # we can directly use the `cp -r` command to generate the directory
            voi_utils.copy_image(src_vm_dir, vm_dir)
        else:
            # Create vm_dir first
            fileutils.ensure_tree(vm_dir)
            for middle_name in constants.DISK_MIDDLE_NAME_LIST:
                _, src_disk_path = self._get_disk_name_and_path(
                    src_vm_obj,
                    None,
                    constants.SYS_DISK_PREFIX_NAME,
                    middle_name)
                _, dest_disk_path = self._get_disk_name_and_path(
                    vm_obj,
                    None,
                    constants.SYS_DISK_PREFIX_NAME,
                    middle_name)
                if os.path.exists(src_disk_path):
                    voi_utils.copy_image(src_disk_path, dest_disk_path)

    def _rebase_vm_disk(self, vm_obj, vm_disk, disk_prefix_name):
        # Rebase all backing file
        for idx, middle_name in enumerate(constants.DISK_MIDDLE_NAME_LIST):
            # Only non-base disks need rebase
            if middle_name != constants.BASE_DISK_NAME:
                previous_middle_name = \
                    constants.DISK_MIDDLE_NAME_LIST[idx - 1]
                previous_disk_name, _ = \
                    self._get_disk_name_and_path(vm_obj,
                                                 vm_disk,
                                                 disk_prefix_name,
                                                 previous_middle_name)
                _, disk_path = self._get_disk_name_and_path(
                    vm_obj,
                    vm_disk,
                    disk_prefix_name,
                    middle_name)
                if os.path.exists(disk_path):
                    voi_utils.rebase_backing_file(previous_disk_name,
                                                  disk_path)

    def _rename_rebase_and_resize_copied_disks(
            self, vm_obj, src_vm_obj, is_copy_data_disk):
        # Get need rename and rebase resize disks
        src_disks = list(src_vm_obj.disks) if is_copy_data_disk else []
        src_disks.insert(0, constants.SYS_DISK_PREFIX_NAME)
        for src_disk in src_disks:
            # Check is sys disk
            if src_disk == constants.SYS_DISK_PREFIX_NAME:
                disk_prefix_name = constants.SYS_DISK_PREFIX_NAME
                src_disk = None
                vm_disk = None
            else:
                disk_prefix_name = constants.DATA_DISK_PREFIX_NAME
                # Used to get the destination disk path
                vm_disk = [disk for disk in vm_obj.disks
                           if disk.index == src_disk.index][0]

            # Rename all disk file
            for middle_name in constants.DISK_MIDDLE_NAME_LIST:
                _, src_disk_path = self._get_disk_name_and_path(
                    src_vm_obj,
                    src_disk,
                    disk_prefix_name,
                    middle_name)
                _, dest_disk_path = self._get_disk_name_and_path(
                    vm_obj,
                    vm_disk,
                    disk_prefix_name,
                    middle_name)
                # Modify the parent directory name of the copied disk file
                src_disk_path = src_disk_path.replace(src_vm_obj.id,
                                                      vm_obj.id,
                                                      1)
                if os.path.exists(src_disk_path):
                    os.rename(src_disk_path, dest_disk_path)

            self._rebase_vm_disk(vm_obj, vm_disk, disk_prefix_name)

            # Resize copied sys file and all data files
            for middle_name in constants.DISK_MIDDLE_NAME_LIST:
                _, disk_path = self._get_disk_name_and_path(
                    vm_obj,
                    vm_disk,
                    disk_prefix_name,
                    middle_name)
                disk_size = vm_obj.root_disk_gb if (
                    disk_prefix_name == constants.SYS_DISK_PREFIX_NAME) else \
                    vm_disk.size
                if os.path.exists(disk_path):
                    self._resize_image(disk_path, disk_size)

    def _prepare_resources_with_copy(
            self, vm_obj, src_vm_obj, is_copy_data_disk):
        LOG.info("VOI VM %s starting copy disk file from source VOI VM %s",
                 vm_obj.id, src_vm_obj.id)

        # Copy src disk file, auto create destination directory.
        self._copy_src_voi_disks(vm_obj, src_vm_obj, is_copy_data_disk)

        # Rename rebase and resize copied file
        self._rename_rebase_and_resize_copied_disks(
            vm_obj, src_vm_obj, is_copy_data_disk)

        # Create new disk file
        copied_disk_index = [] if not is_copy_data_disk else [
            disk.index for disk in src_vm_obj.disks]
        for disk in vm_obj.disks:
            if disk.index not in copied_disk_index:
                self._generate_disk_chain(vm_obj,
                                          disk,
                                          constants.DATA_DISK_PREFIX_NAME)

    def _rename_and_rebase_moved_disks(self, vm_dirpath, vm_obj):
        dirpath, dirnames, filenames = next(os.walk(vm_dirpath))

        for filename in filenames:
            src_disk_path = os.path.join(dirpath, filename)
            src_middle_name = [name
                               for name in constants.DISK_MIDDLE_NAME_LIST
                               if name in filename]
            if filename.endswith(constants.VOI_DISK_SUFFIX_NAME):
                if constants.SYS_DISK_PREFIX_NAME in filename:
                    disk_prefix_name = constants.SYS_DISK_PREFIX_NAME
                    vm_disk = None
                elif constants.DATA_DISK_PREFIX_NAME in filename:
                    disk_prefix_name = constants.DATA_DISK_PREFIX_NAME
                    # Used to get the destination disk path
                    disk_index = filename.split(
                        constants.DATA_DISK_PREFIX_NAME)[1][0]
                    vm_disk = [disk for disk in vm_obj.disks
                               if str(disk.index) == disk_index][0]
                else:
                    continue

                _, dest_disk_path = self._get_disk_name_and_path(
                    vm_obj,
                    vm_disk,
                    disk_prefix_name,
                    src_middle_name[0])
                os.rename(src_disk_path, dest_disk_path)

                self._rebase_vm_disk(vm_obj, vm_disk, disk_prefix_name)

    def _prepare_resources_with_path(self, vm_dir, vm_obj, src_vm_path):
        # Move src path to vm path
        shutil.move(src_vm_path, vm_dir)
        self._rename_and_rebase_moved_disks(vm_dir, vm_obj)

    def create(self, **data):
        LOG.info("[VOI VM %s] Creating", data['id'])

        def _wait_for_boot():
            """Called at an interval until the VM is running."""
            state = self.get_info(vm_obj).state

            if state == power_state.RUNNING:
                LOG.info("[VOI VM %s] VM create successfully.", vm_obj.id)
                raise loopingcall.LoopingCallDone()

        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=data['id'])
        vm_dir = os.path.join(self.vm_base_dir, vm_obj.id)
        src_vm_id = data['src_vm_id']
        is_copy_data_disk = data['is_copy_data_disk']
        src_vm_path = data['src_vm_path']

        try:
            # Because, the following two operations will automatically
            # generate the directory
            # 1. if src_vm_path exist, shutil.move() needs to be called
            # 2. if src_vm_id exist, 'cp -r' needs to be called
            # So no need to create directory.
            if not any([src_vm_path, src_vm_id]):
                fileutils.ensure_tree(vm_dir)
            if src_vm_id:
                src_vm_obj = self.vm_repo.get(session, id=src_vm_id)
                self._prepare_resources_with_copy(
                    vm_obj, src_vm_obj, is_copy_data_disk)
            elif src_vm_path:
                self._prepare_resources_with_path(vm_dir, vm_obj, src_vm_path)
            else:
                self._prepare_resources(vm_obj)
            self._ensure_vm_current_disks(vm_obj)

            vm_xml = self._prepare_xml(vm_obj)
            self._create_guest(vm_xml)
            LOG.debug("[VOI VM %s] Guest created on hypervisor", vm_obj.id)

            timer = loopingcall.FixedIntervalLoopingCall(_wait_for_boot)
            timer.start(interval=0.5).wait()
        except Exception as e:
            LOG.error('Create VOI VM %s failed.', vm_obj.id)
            self.vm_repo.update(session, id=data['id'],
                                **{'status': constants.ERROR})
            self.status_queue.put(
                {"resource_type": "voi_vm",
                 "resource_id": vm_obj.id,
                 "current_status": constants.ERROR,
                 "error_msg": str(e),
                 "timestamp": timeutils.utcnow(),
                 "action": "create"})
            raise e
        else:
            LOG.info("[VOI VM %s] Create VM successful.", data['id'])
            self.vm_repo.update(session, id=data['id'],
                                **{'status': constants.ACTIVE})
            # VOI volumes do not need to send webhooks
            for vm_disk in vm_obj.disks:
                self.volume_repo.update(
                    session, id=vm_disk.id, status=constants.IN_USE)
            self.status_queue.put(
                {"resource_type": "voi_vm",
                 "resource_id": vm_obj.id,
                 "current_status": constants.ACTIVE,
                 "timestamp": timeutils.utcnow(),
                 "action": "create"})

    def delete(self, **data):
        LOG.info("[VOI VM %s] Deleting", data['id'])
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=data['id'])
        self.destroy_vm(vm_obj)
        vm_dir = os.path.join(self.vm_base_dir, vm_obj.id)
        try:
            shutil.rmtree(vm_dir)
        except FileNotFoundError:
            LOG.warning("The resources related vm %s "
                        "already ba deleted.", vm_obj.id)
        except Exception:
            # 不因为删除目录失败而造成虚拟机删除失败
            # 在这里我们捕获一些未知异常, 并输出到日志中
            # 但是 VOI 虚拟机状态还是更新成 deleted
            LOG.warning('Delete VOI VM %s files failed', vm_obj.id)

        LOG.info("[VOI VM %s] Delete VOI VM successful.", data['id'])
        self.vm_repo.update(session, id=data['id'],
                            **{"status": constants.DELETED})
        self.status_queue.put(
            {"resource_type": "voi_vm",
             "resource_id": vm_obj.id,
             "current_status": constants.DELETED,
             "timestamp": timeutils.utcnow(),
             "action": "delete"})

    def _power_off(self, vm_obj):
        timeout = CONF.vm_settings.clean_shutdown_timeout
        retry_interval = CONF.vm_settings.clean_shutdown_retry_interval
        self.power_off(vm_obj, timeout, retry_interval)

    def stop(self, **data):
        LOG.info("[VOI VM %s] Stopping", data['id'])

        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=data['id'])
        force_stop = data['force_stop']
        try:
            if force_stop:
                self.power_off(vm_obj)
            else:
                self._power_off(vm_obj)
        except Exception as e:
            LOG.error('Stop VOI VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "voi_vm",
                                       "resource_id": data['id'],
                                       "previous_status": constants.STOPPING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "stop",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.STOPPED
        vm_obj.save(session)
        LOG.info("[VOI VM %s] Stop successful", data['id'])
        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": data['id'],
            "previous_status": constants.STOPPING,
            "current_status": constants.STOPPED,
            "action": "stop",
            "timestamp": timeutils.utcnow()})

    def _ensure_vm_current_disks(self, vm_obj):
        # ensure sys disk
        _, sys_disk_path = self._get_disk_name_and_path(
            vm_obj, None, constants.SYS_DISK_PREFIX_NAME,
            constants.CURRENT_DISK_NAME)
        if not os.path.exists(sys_disk_path):
            sys_incre2_disk_name, _ = self._get_disk_name_and_path(
                vm_obj, None, constants.SYS_DISK_PREFIX_NAME,
                constants.INCR2_DISK_NAME)
            voi_utils.create_cow_image(sys_incre2_disk_name,
                                       sys_disk_path)
        # ensure data disk
        for vm_disk in vm_obj.disks:
            _, data_disk_path = self._get_disk_name_and_path(
                vm_obj, vm_disk, constants.DATA_DISK_PREFIX_NAME,
                constants.CURRENT_DISK_NAME)
            if not os.path.exists(data_disk_path):
                data_incre2_disk_name, _ = self._get_disk_name_and_path(
                    vm_obj, vm_disk, constants.DATA_DISK_PREFIX_NAME,
                    constants.INCR2_DISK_NAME)
                voi_utils.create_cow_image(data_incre2_disk_name,
                                           data_disk_path)

    def _hard_reboot(self, vm_obj):
        self.destroy_vm(vm_obj)
        self._ensure_vm_current_disks(vm_obj)
        xml = self._prepare_xml(vm_obj)
        self._create_guest(xml)

        def _wait_for_reboot():
            """Called at an interval until the VM is running again."""
            state = self.get_info(vm_obj).state

            if state == power_state.RUNNING:
                LOG.info("[VOI VM %s] VM rebooted successfully.", vm_obj.id)
                raise loopingcall.LoopingCallDone()

        timer = loopingcall.FixedIntervalLoopingCall(_wait_for_reboot)
        timer.start(interval=0.5).wait()

    def start(self, **data):
        LOG.info("[VOI VM %s] Starting", data['id'])
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=data['id'])
        try:
            self._hard_reboot(vm_obj)
        except Exception as e:
            LOG.error('Start VOI VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "voi_vm",
                                       "resource_id": vm_obj.id,
                                       "previous_status": constants.STARTING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "start",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.ACTIVE
        vm_obj.save(session)

        LOG.info("[VOI VM %s] Start VM successful", data['id'])
        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": vm_obj.id,
            "previous_status": constants.STARTING,
            "current_status": constants.ACTIVE,
            "action": "start",
            "timestamp": timeutils.utcnow()})

    def _reboot(self, vm_obj, reboot_type='SOFT'):
        if reboot_type == 'SOFT':
            try:
                soft_reboot_success = self._soft_reboot(vm_obj)
            except libvirt.libvirtError as e:
                LOG.debug("[VOI VM %s] VM soft reboot failed: %s",
                          vm_obj.id, e)
                soft_reboot_success = False
            if soft_reboot_success:
                LOG.info("[VOI VM %s] VM soft rebooted successfully.",
                         vm_obj.id)
                return
            LOG.warning("[VOI VM %s] Failed to soft reboot VM. "
                        "Trying hard reboot.", vm_obj.id)
        self._hard_reboot(vm_obj)

    def reboot(self, id, reboot_type='SOFT'):
        """Reboot the given VM."""
        LOG.info("[VOI VM %s] Rebooting", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)

        try:
            self._reboot(vm_obj, reboot_type)
        except Exception as e:
            LOG.error('Reboot VOI VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "voi_vm",
                                       "resource_id": id,
                                       "previous_status": constants.REBOOTING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "reboot",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.ACTIVE
        vm_obj.save(session)

        LOG.info("[VOI VM %s] Reboot successful", id)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.REBOOTING,
            "current_status": constants.ACTIVE,
            "action": "reboot",
            "timestamp": timeutils.utcnow()})

    def _migrate(self, vm_obj, migrate_host):
        # Because it is a cold migration,we only need to
        # clear the residual resources on the source node
        self._undefine_domain(vm_obj)
        # TODO(liupeng) Cleanup nic resource

    def migrate(self, id, migrate_host=None):
        """Migrate the given VM."""
        LOG.info("[VOI VM %s] Migrating", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)

        try:
            self._migrate(vm_obj, migrate_host)
        except Exception as e:
            LOG.error('Migrate VOI VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "voi_vm",
                                       "resource_id": id,
                                       "previous_status": constants.MIGRATING,
                                       "current_status": constants.ERROR,
                                       "action": "migrate",
                                       "error_msg": str(e),
                                       "timestamp": timeutils.utcnow()})

        # Modify the agent id after the migration is successful
        agent_obj = self.agent_repo.get(session, hostname=migrate_host)
        vm_obj.agent_id = agent_obj.id
        # Because only cold migration is currently supported,
        # the migration and VM state is stopped
        vm_obj.status = constants.STOPPED
        vm_obj.save(session)

        LOG.info("[VOI VM %s] Migrate successful", id)

        self.status_queue.put({"resource_type": "voi_vm",
                               "resource_id": id,
                               "previous_status": constants.MIGRATING,
                               "current_status": constants.STOPPED,
                               "action": "migrate",
                               "timestamp": timeutils.utcnow()})

    def _delete_all_vm_current_disk(self, vm_obj):
        # Delete vm's sys current disk
        _, sys_disk_path = self._get_disk_name_and_path(
            vm_obj, None, constants.SYS_DISK_PREFIX_NAME,
            constants.CURRENT_DISK_NAME)
        fileutils.delete_if_exists(sys_disk_path)
        # Delete all vm's data current disk
        for vm_disk in vm_obj.disks:
            _, data_disk_path = self._get_disk_name_and_path(
                vm_obj, vm_disk, constants.DATA_DISK_PREFIX_NAME,
                constants.CURRENT_DISK_NAME)
            fileutils.delete_if_exists(data_disk_path)

    def reset(self, id):
        LOG.info("[VOI VM %s] Resetting", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        state = self.get_info(vm_obj).state
        if state == power_state.RUNNING:
            self.power_off(vm_obj)

        # Delete all current disk
        self._delete_all_vm_current_disk(vm_obj)

        # Reset VOI VM and the vm status to stopped
        vm_obj.status = constants.STOPPED
        vm_obj.save(session)

        LOG.info("[VOI VM %s] Reset VM successful", id)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.RESETTING,
            "current_status": constants.STOPPED,
            "action": "reset",
            "timestamp": timeutils.utcnow()
        })

    def replace_iso(self, id, origin_vm_status, iso_image_id):
        """Action replace_iso"""
        session = db_api.get_session()
        iso_image_path = None
        vm_obj = self.vm_repo.get(session, id=id)
        img_obj = self.image_repo.get(session, id=iso_image_id)
        if img_obj:
            iso_image_path = img_obj.location.replace("file://", "")

        LOG.info("[VOI VM %s] replacing", id)
        try:
            self._replace_cdrom_iso_image(vm_obj, iso_image_path)
        except Exception as e:
            # Don't set VOI VM status to error
            LOG.warning('Replace iso with VOI VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session,
                                    vm_obj.id,
                                    status=origin_vm_status)
                self.status_queue.put({
                    "resource_type": "voi_vm",
                    "resource_id": id,
                    "previous_status": constants.REPLACING_ISO,
                    "current_status": origin_vm_status,
                    "error_msg": str(e),
                    "action": "replace_iso",
                    "timestamp": timeutils.utcnow()
                })

        vm_obj.cd_drivers[0].image_id = iso_image_id
        vm_obj.status = origin_vm_status
        vm_obj.save(session)

        LOG.info("[VOI VM %s] replace iso successful", id)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.REPLACING_ISO,
            "current_status": origin_vm_status,
            "action": "replace_iso",
            "timestamp": timeutils.utcnow()
        })

    def commit(self, id):
        """Action commit VOI VM"""
        LOG.info("[VOI VM %s] committing", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        vm_disks = list(vm_obj.disks)
        vm_disks.insert(0, constants.SYS_DISK_PREFIX_NAME)
        self._ensure_vm_current_disks(vm_obj)

        try:
            for vm_disk in vm_disks:
                disk_prefix_name = constants.DATA_DISK_PREFIX_NAME
                # Check is sys disk
                if vm_disk == constants.SYS_DISK_PREFIX_NAME:
                    vm_disk = None
                    disk_prefix_name = constants.SYS_DISK_PREFIX_NAME

                # Generate filename and filepath
                base_filename, _ = self._get_disk_name_and_path(
                    vm_obj,
                    vm_disk,
                    disk_prefix_name,
                    constants.BASE_DISK_NAME)
                incr1_filename, incr1_filepath = \
                    self._get_disk_name_and_path(vm_obj,
                                                 vm_disk,
                                                 disk_prefix_name,
                                                 constants.INCR1_DISK_NAME)
                incr2_filename, incr2_filepath = \
                    self._get_disk_name_and_path(vm_obj,
                                                 vm_disk,
                                                 disk_prefix_name,
                                                 constants.INCR2_DISK_NAME)
                _, curr_filepath = self._get_disk_name_and_path(
                    vm_obj,
                    vm_disk,
                    disk_prefix_name,
                    constants.CURRENT_DISK_NAME)

                voi_utils.commit_disk_file(base_filename,
                                           incr1_filename, incr1_filepath,
                                           incr2_filename, incr2_filepath,
                                           curr_filepath)

        except Exception as e:
            self.vm_repo.update(session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "voi_vm",
                "resource_id": id,
                "previous_status": constants.COMMITTING,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "commit",
                "timestamp": timeutils.utcnow()
            })
            raise exceptions.CommitVOIVMFailed(vm_id=id, reason=str(e))

        vm_obj.status = constants.STOPPED
        vm_obj.save(session)
        LOG.info("[VOI VM %s] commit successful", id)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.COMMITTING,
            "current_status": constants.STOPPED,
            "action": "commit",
            "timestamp": timeutils.utcnow()
        })

    def _remove_data_disk_chain(self, vm_obj, volume_obj):
        remove_disk_name_list = [
            constants.CURRENT_DISK_NAME,
            constants.INCR2_DISK_NAME,
            constants.INCR1_DISK_NAME,
            constants.BASE_DISK_NAME
        ]
        for disk_name in remove_disk_name_list:
            _, remove_disk_path = self._get_disk_name_and_path(
                vm_obj,
                volume_obj,
                constants.DATA_DISK_PREFIX_NAME,
                disk_name)
            fileutils.delete_if_exists(remove_disk_path)

    def add_volume(self, id, origin_vm_status, volume_id):
        LOG.info("[VOI VM %s] adding volume", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        volume_obj = self.volume_repo.get(session, id=volume_id)

        try:
            # Generate disk file chain
            _, current_disk_path = self._generate_disk_chain(
                vm_obj, volume_obj, constants.DATA_DISK_PREFIX_NAME, None)
            # Attach volume
            self.attach_volume(vm_obj, self._get_disk_config(
                current_disk_path, volume_obj.index))
        except Exception as e:
            self.vm_repo.update(session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "voi_vm",
                "resource_id": id,
                "previous_status": constants.ADDING_VOLUME,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "add_volume",
                "timestamp": timeutils.utcnow()
            })
            raise exceptions.VOIVMAddVolumeFailed(vm_id=id, reason=str(e))

        vm_obj.status = origin_vm_status
        vm_obj.save(session)
        # VOI volume do not need to send webhook
        self.volume_repo.update(
            session, id=volume_id, status=constants.IN_USE)
        LOG.info("[VOI VM %s] add volume successful", id)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.ADDING_VOLUME,
            "current_status": origin_vm_status,
            "action": "add_volume",
            "timestamp": timeutils.utcnow()
        })

    def remove_volume(self, id, origin_vm_status, volume_id):
        LOG.info("[VOI VM %s] removing volume", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        volume_obj = self.volume_repo.get(session, id=volume_id)

        try:
            # Get current disk full path
            _, cur_disk_path = self._get_disk_name_and_path(
                vm_obj,
                volume_obj,
                constants.DATA_DISK_PREFIX_NAME,
                constants.CURRENT_DISK_NAME)
            # Detach volume
            self.detach_volume(vm_obj,
                               self._get_disk_config(
                                   cur_disk_path,
                                   volume_obj.index))
            # Remove disk file
            self._remove_data_disk_chain(vm_obj, volume_obj)
        except Exception as e:
            self.vm_repo.update(session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "voi_vm",
                "resource_id": id,
                "previous_status": constants.REMOVING_VOLUME,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "remove_volume",
                "timestamp": timeutils.utcnow()
            })
            raise exceptions.VOIVMRemoveVolumeFailed(vm_id=id, reason=str(e))

        vm_obj.status = origin_vm_status
        vm_obj.save(session)
        # VOI volume do not need to send webhook
        self.volume_repo.update(
            session, id=volume_id, status=constants.DELETED)
        LOG.info("[VOI VM %s] remove volume successful", id)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.REMOVING_VOLUME,
            "current_status": origin_vm_status,
            "action": "remove_volume",
            "timestamp": timeutils.utcnow()
        })

    def attach_share_template_volume(self, id, origin_vm_status, volume_id):
        LOG.info("[VOI VM %s] adding share template volume ", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        volume_obj = self.share_tmpl_vol_repo.get(session, id=volume_id)
        _, volume_path = voi_utils.get_share_tmpl_disk_name_and_path(
            volume_id, CONF.voi_setting.share_template_disk_path)
        try:
            # Attach volume
            self.attach_volume(vm_obj, self._get_disk_config(
                volume_path, volume_obj.index))
        except Exception as e:
            self.vm_repo.update(session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "voi_vm",
                "resource_id": id,
                "previous_status": constants.VOLUME_ATTACHING,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "attach_share_template_volume",
                "timestamp": timeutils.utcnow()
            })
            self.update_share_template_disk_status(
                session, volume_id, 'attach_share_template_volume',
                constants.AVAILABLE, expected_status=constants.ATTACHING)
            raise exceptions.VOIVMAddVolumeFailed(vm_id=id, reason=str(e))

        vm_obj.status = origin_vm_status
        vm_obj.save(session)

        self.status_queue.put({
            "resource_type": "voi_vm",
            "resource_id": id,
            "previous_status": constants.VOLUME_ATTACHING,
            "current_status": origin_vm_status,
            "action": "attach_share_template_volume",
            "timestamp": timeutils.utcnow()
        })

        self.update_share_template_disk_status(
            session, volume_id, 'attach_share_template_volume',
            constants.IN_USE, expected_status=constants.ATTACHING)

        LOG.info("[VOI VM %s] attach share template volume successful", id)

    def detach_share_template_volume(self, id, origin_vm_status, volume_id):
        LOG.info("[VOI VM %s] removing share template volume", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        volume_obj = self.share_tmpl_vol_repo.get(session, id=volume_id)
        _, volume_path = voi_utils.get_share_tmpl_disk_name_and_path(
            volume_id, CONF.voi_setting.share_template_disk_path)
        try:
            # Detach volume
            self.detach_volume(vm_obj,
                               self._get_disk_config(volume_path,
                                                     volume_obj.index))
        except Exception as e:
            self.vm_repo.update(session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "voi_vm",
                "resource_id": id,
                "previous_status": constants.VOLUME_DETACHING,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "detach_share_template_volume",
                "timestamp": timeutils.utcnow()
            })
            self.update_share_template_disk_status(
                session, volume_id, 'detach_share_template_volume',
                constants.IN_USE, expected_status=constants.DETACHING)
            raise exceptions.VOIVMRemoveVolumeFailed(vm_id=id, reason=str(e))

        with db_api.get_lock_session() as lock_session:
            share_templates, _ = self.share_tmpl_vol_repo.get_all(
                lock_session, lock=True, vm_id=id)

            self.update_share_template_disk_status(
                lock_session, volume_id, 'detach_share_template_volume',
                constants.AVAILABLE, expected_status=constants.DETACHING,
                **{'vm_id': None, 'index': None})

            detaching_templates = [share_template for share_template
                                   in share_templates
                                   if share_template.id != volume_id and
                                   share_template.status != constants.IN_USE]
            if not detaching_templates:
                vm_obj.status = origin_vm_status
                vm_obj.save(session)
                self.status_queue.put({
                    "resource_type": "voi_vm",
                    "resource_id": id,
                    "previous_status": constants.VOLUME_DETACHING,
                    "current_status": origin_vm_status,
                    "action": "detach_share_template_volume",
                    "timestamp": timeutils.utcnow()
                })

        LOG.info("[VOI VM %s] detach share template volume successful", id)

    def update_share_template_disk_status(
            self, session, volume_id, action, update_status,
            expected_status=None, **kwargs):
        update_data = kwargs or {}
        update_data['status'] = update_status
        if self.share_tmpl_vol_repo.update(
                session, volume_id, expected_status=expected_status,
                **update_data) == 1:
            self.status_queue.put(
                {"resource_type": "voi_share_template_volume",
                 "resource_id": volume_id,
                 "previous_status": expected_status,
                 "current_status": update_status,
                 "timestamp": timeutils.utcnow(),
                 "action": action})
        else:
            LOG.warn('The expected status of nic %(volume_id)s is not '
                     '%(expected_status)s, so update voi share '
                     'template disk status failed',
                     {'volume_id': volume_id,
                      'expected_status': expected_status})

    def update_voi_vm_status(self, session, vm_id, action, update_status,
                             expected_status=None, success=True, **kwargs):
        if success:
            update_data = kwargs or {}
            update_data['status'] = update_status
            if self.vm_repo.update(session, vm_id,
                                   expected_status=expected_status,
                                   **update_data) == 1:
                self.status_queue.put(
                    {"resource_type": "voi_vm",
                     "resource_id": vm_id,
                     "previous_status": expected_status,
                     "current_status": update_status,
                     "timestamp": timeutils.utcnow(),
                     "action": action})
            else:
                LOG.warn('The expected status of VOI vm %(vm_id)s is not '
                         '%(expected_status)s, so update vm status failed',
                         {'vm_id': vm_id,
                          'expected_status': expected_status})
        else:
            LOG.warn("Fail to %(action)s VOI vm %(vm_id)s, so not update "
                     "VOI vm status", {'action': action, 'vm_id': vm_id})


class ShareDisk():
    def __init__(self, queue):
        self.status_queue = queue

    def commit(self, disk_dirpath):
        """Share disk commit"""
        LOG.info("Committing share disk from %s", disk_dirpath)

        disk_uuid = os.path.basename(os.path.normpath(disk_dirpath))
        # Generate filename and filepath
        base_filename, _ = voi_utils.get_share_disk_name_and_path(
            constants.BASE_DISK_NAME,
            disk_dirpath)
        incr1_filename, incr1_filepath = \
            voi_utils.get_share_disk_name_and_path(constants.INCR1_DISK_NAME,
                                                   disk_dirpath)
        incr2_filename, incr2_filepath = \
            voi_utils.get_share_disk_name_and_path(constants.INCR2_DISK_NAME,
                                                   disk_dirpath)
        _, curr_filepath = voi_utils.get_share_disk_name_and_path(
            constants.CURRENT_DISK_NAME,
            disk_dirpath)

        try:
            voi_utils.commit_disk_file(base_filename,
                                       incr1_filename, incr1_filepath,
                                       incr2_filename, incr2_filepath,
                                       curr_filepath)
        except Exception as e:
            self.status_queue.put({
                "resource_type": "share_disk",
                "resource_id": disk_uuid,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "commit",
                "timestamp": timeutils.utcnow()
            })
            raise exceptions.CommitShareDiskFailed(path=disk_dirpath,
                                                   reason=str(e))

        LOG.info("Share disk path %s commit successful.", disk_dirpath)

        self.status_queue.put({
            "resource_type": "share_disk",
            "resource_id": disk_uuid,
            "current_status": constants.ACTIVE,
            "action": "commit",
            "timestamp": timeutils.utcnow()
        })


class BackupDisk():
    def __init__(self, queue):
        self.status_queue = queue

    DISK_TYPE_DISK_PREFIX_NAME_MAP = {
        'sys': constants.SYS_DISK_PREFIX_NAME,
        # Current only support buckup disk commit "data" is "data1"
        'data': constants.BACKUP_DATA_DISK_PREFIX_NAME
    }

    def commit(self, disk_dirpath, disk_type, disk_base_filepath=None):
        """Disk commit"""
        LOG.info("Committing disk from %s", disk_dirpath)

        # Get filename and filepath
        resource_id = os.path.basename(os.path.normpath(disk_dirpath))
        incr1_filename = incr1_filepath = \
            incr2_filename = incr2_filepath \
            = curr_filepath = 'Empty filepath or filename'
        dirpath, dirnames, filenames = next(os.walk(disk_dirpath))
        for filename in filenames:
            disk_filepath = os.path.join(dirpath, filename)
            disk_prefix_name = self.DISK_TYPE_DISK_PREFIX_NAME_MAP.get(
                disk_type)
            if disk_prefix_name in filename and filename.endswith(
                    constants.VOI_DISK_SUFFIX_NAME):
                if not disk_base_filepath:
                    if constants.BASE_DISK_NAME in filename:
                        disk_base_filepath = disk_filepath
                if constants.INCR1_DISK_NAME in filename:
                    incr1_filename = filename
                    incr1_filepath = disk_filepath
                if constants.INCR2_DISK_NAME in filename:
                    incr2_filename = filename
                    incr2_filepath = disk_filepath
                if constants.CURRENT_DISK_NAME in filename:
                    curr_filepath = disk_filepath
            else:
                continue

        try:
            if not disk_base_filepath:
                raise exceptions.CommitBackupDiskFailed(
                    path=disk_dirpath,
                    reason="Backup disk has no base file.")
            voi_utils.commit_disk_file(disk_base_filepath,
                                       incr1_filename, incr1_filepath,
                                       incr2_filename, incr2_filepath,
                                       curr_filepath)
        except Exception as e:
            LOG.error('Committing buckup disk %s failed. Reason is %s',
                      resource_id, e)
            self.status_queue.put({
                "resource_type": "backup_" + disk_type + "_disk",
                "resource_id": resource_id,
                "error_msg": str(e),
                "current_status": constants.ERROR,
                "action": "commit",
                "timestamp": timeutils.utcnow()
            })
            raise exceptions.CommitBackupDiskFailed(path=disk_dirpath,
                                                    reason=str(e))

        LOG.info("Disk path %s commit successful.", disk_dirpath)

        self.status_queue.put({
            "resource_type": "backup_" + disk_type + "_disk",
            "resource_id": resource_id,
            "current_status": constants.ACTIVE,
            "action": "commit",
            "timestamp": timeutils.utcnow()
        })
