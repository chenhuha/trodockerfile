# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import collections
import functools
import threading

from oslo_concurrency import lockutils
from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import timeutils
from trochilus.agent.common import exceptions
from trochilus.agent.common import external_process
from trochilus.agent.compute.libvirt import config as vconfig
from trochilus.agent.net.dhcp.drivers.client_device import DiscoveryClient
from trochilus.agent.net.dhcp.drivers import dnsmasq
from trochilus.agent.net.vpc.drivers import linux_bridge
from trochilus.common import constants
from trochilus.common import exceptions as api_exceptions
from trochilus.common import utils as common_utils
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import client_device_repo
from trochilus.db import dhcp_repo
from trochilus.db import nic_repo
from trochilus.db import subnet_repo
from trochilus.db import vpc_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)

VPCInfo = collections.namedtuple(
    'VPCInfo', ['id', 'namespace', 'subnets', 'nics', 'mtu'])
SubnetInfo = collections.namedtuple(
    'SubnetInfo', ['id', 'cidr', 'enable_dhcp', 'dns_nameservers', 'gateway'])
DnsNameServerInfo = collections.namedtuple(
    'DnsNameServerInfo', ['subnet_id', 'ip_address', 'order'])
NicInfo = collections.namedtuple(
    'NicInfo', ['id', 'vpc_id', 'owner_type',
                'ip_addresses', 'hostname', 'mac_address'])
IpAddressInfo = collections.namedtuple(
    'IpAddressInfo', ['subnet', 'ip_address'])

_SYNC_STATE_LOCK = lockutils.ReaderWriterLock()


def _sync_lock(f):
    """Decorator to block all operations for a global sync call."""

    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        with _SYNC_STATE_LOCK.write_lock():
            return f(*args, **kwargs)

    return wrapped


def _wait_if_syncing(f):
    """Decorator to wait if any sync operations are in progress."""

    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        with _SYNC_STATE_LOCK.read_lock():
            return f(*args, **kwargs)

    return wrapped


class Vpc(object):

    def __init__(self, queue):
        self.vpc_dirver = None
        try:
            self.vpc_dirver = linux_bridge.LinuxBridgeVpcDriver()
        except Exception as e:
            LOG.error('Failed to initialize vpc driver , the exception is '
                      '%s', e)
        if not self.vpc_dirver:
            LOG.error("There is not a valid VpcDriver."
                      "Agent terminated!")
            raise exceptions.VpcDriverInvalid()

        self.agent_repo = agent_repo.AgentRepository()
        self.vpc_repo = vpc_repo.VpcRepository()
        self.vpc_node_repo = vpc_repo.VpcNodeMappingRepository()
        self.hostname = CONF.agent_settings.hostname
        self.agent_id = None
        self.status_queue = queue

    def sync_vpc(self, ensure_vpc_ready=False, delete_invalid_vpc=False):
        try:
            LOG.debug("Sync vpc")
            self._sync_vpc_node_mappings()
            self._assert_vpc_status()
            # In the timed task， do not check if exist invalid vpc. Because
            # there is rarely a case that there is bridge but not data in the
            # database.
            if delete_invalid_vpc:
                self._delete_invalid_vpc()
            # In the timed task， do not check if vpc ready. Because there is
            # rarely a case that there is data in the database but no bridge in
            # os.
            if ensure_vpc_ready:
                self._ensure_vpc_ready()
        except Exception as e:
            LOG.error('Fail to sync vpc, exception is %s', e)

    def _sync_vpc_node_mappings(self):
        """Synchronize information from vpc table to vpv_node_mapping table"""
        with db_api.get_lock_session() as lock_session:
            vpcs, _ = self.vpc_repo.get_all(lock_session)
            if not vpcs:
                return
            for vpc in vpcs:
                # create vpc on current node
                if (vpc.status in [constants.ACTIVE,
                                   constants.DOWN,
                                   constants.DOWNGRADE,
                                   constants.ERROR]) \
                    or (vpc.status in [constants.PREPARE_CREATE,
                                       constants.CREATING] and
                        timeutils.delta_seconds(vpc.created_at,
                                                timeutils.utcnow()) > 10):
                    if vpc.vpc_node_mappings:
                        mappings = [vpc_node_mapping
                                    for vpc_node_mapping
                                    in vpc.vpc_node_mappings if
                                    vpc_node_mapping.agent_id ==
                                    self.get_current_agent_id()]
                        if not mappings:
                            self.create(**vpc.to_dict())
                    else:
                        self.create(**vpc.to_dict())
                # delete vpc on current node
                elif vpc.status in [constants.PREPARE_DELETE,
                                    constants.DELETING]\
                        and timeutils.delta_seconds(vpc.updated_at,
                                                    timeutils.utcnow()) > 10:
                    if vpc.vpc_node_mappings:
                        mappings = [vpc_node_mapping
                                    for vpc_node_mapping
                                    in vpc.vpc_node_mappings if
                                    vpc_node_mapping.agent_id ==
                                    self.get_current_agent_id()]
                        if not mappings:
                            self.delete(vpc.id)

    def _assert_vpc_status(self):
        """assert vpc status """
        session = db_api.get_session()
        vpcs, _ = self.vpc_repo.get_all(session)
        if not vpcs:
            return
        agents, _ = self.agent_repo.get_all(session)
        agent_status_dict = self._get_agent_status_dict(agents)
        for vpc in vpcs:
            self._assert_one_vpc_status(vpc, agent_status_dict, session)

    @staticmethod
    def _get_agent_status_dict(agents):
        agent_dict = {}
        for agent in agents:
            agent_dict[agent.id] = agent.status
        return agent_dict

    def _assert_one_vpc_status(self, vpc, agent_dict, session, action='sync'):
        if vpc.vpc_node_mappings:
            if vpc.status in [constants.PREPARE_CREATE,
                              constants.PREPARE_DELETE]:
                return vpc

            # Synchronize the vpc status on each node according to
            # the agent status
            self._assert_vpc_status_on_node(vpc.vpc_node_mappings, agent_dict)

            # Synchronize the overall vpc state based on the
            # vpc state on each node"""
            old_status = vpc.status
            has_active = has_error = has_down = False
            for mapping in vpc.vpc_node_mappings:
                if mapping.status == constants.ACTIVE:
                    has_active = True
                elif mapping.status == constants.ERROR:
                    has_error = True
                elif mapping.status == constants.DOWN:
                    has_down = True
            if has_active:
                if not has_error and not has_down:
                    new_status = constants.ACTIVE
                else:
                    new_status = constants.DOWNGRADE
            else:
                if has_error and not has_down:
                    new_status = constants.ERROR
                else:
                    new_status = constants.DOWN
            if old_status != new_status:
                if self.vpc_repo.update(
                        session, id=vpc.id, expected_status=old_status,
                        **{'status': new_status}):
                    self.status_queue.put({"resource_type": "vpc",
                                           "resource_id": vpc.id,
                                           "previous_status": old_status,
                                           "current_status": vpc.status,
                                           "timestamp": timeutils.utcnow(),
                                           "action": action})
        return vpc

    @staticmethod
    def _assert_vpc_status_on_node(vpc_node_mappings, agent_dict):
        if vpc_node_mappings:
            for mapping in vpc_node_mappings:
                if mapping.agent_id in agent_dict:
                    if mapping.status == constants.ACTIVE \
                            and agent_dict[mapping.agent_id] \
                            == constants.AGENT_DOWN:
                        mapping.status = constants.DOWN
                    if mapping.status == constants.DOWN \
                            and agent_dict[mapping.agent_id] \
                            == constants.AGENT_UP:
                        mapping.status = constants.ACTIVE
                else:
                    """agent does not exist"""
                    if mapping.status == constants.ACTIVE:
                        mapping.status = constants.DOWN
        return vpc_node_mappings

    def _delete_invalid_vpc(self):
        session = db_api.get_session()
        db_vpcs, _ = self.vpc_repo.get_all(session)
        shoule_exist_vpcs = [common_utils.get_bridge_name(db_vpc.id)
                             for db_vpc in db_vpcs]
        real_exist_vpc_names = set(self.vpc_dirver.get_all_vpc_names())
        delete_vpc_names = real_exist_vpc_names.difference(shoule_exist_vpcs)
        for delete_vpc_name in delete_vpc_names:
            LOG.info('delete invalid vpc, name is %s', delete_vpc_name)
            self.vpc_dirver.delete_vpc_by_name(delete_vpc_name)

    def _ensure_vpc_ready(self):
        session = db_api.get_session()
        db_vpcs, _ = self.vpc_repo.get_all(session)
        if not db_vpcs:
            return
        for db_vpc in db_vpcs:
            bridge_name = common_utils.get_bridge_name(db_vpc.id)
            if not self.vpc_dirver.is_vpc_ready(bridge_name):
                vpc_dict = db_vpc.to_dict()
                self.vpc_dirver.create_vpc(vpc_dict)

    def create(self, **vpc):
        id = vpc['id']
        session = db_api.get_session(autocommit=True)
        try:
            self.vpc_dirver.create_vpc(vpc)
        except Exception as e:
            LOG.error("Fail to create Vpc equal to id %s in node,"
                      "exception is %s", id, e)
            self.vpc_node_repo.create(session,
                                      **{'agent_id':
                                          self.get_current_agent_id(),
                                         'vpc_id': id,
                                         'status': constants.ERROR})
        else:
            self.vpc_node_repo.create(session,
                                      **{'agent_id':
                                          self.get_current_agent_id(),
                                         'vpc_id': id,
                                         'status': constants.ACTIVE})
        # Synchronize vpc  status whether the creation succeeds or fails
        agents, _ = self.agent_repo.get_all(session)
        agent_status_dict = self._get_agent_status_dict(agents)
        vpc = self.vpc_repo.get(session, id=id)
        self._assert_one_vpc_status(vpc, agent_status_dict, session,
                                    action='create')

    def delete(self, id):
        session = db_api.get_session(autocommit=True)
        try:
            self.vpc_dirver.delete_vpc(id)
        except Exception as e:
            LOG.error("Fail to delete Vpc equal to id %s in node ,"
                      "exception is %s", id, e)
            self.vpc_node_repo.update(session,
                                      id,
                                      self.get_current_agent_id(),
                                      **{'status': constants.ERROR})
        else:
            self.vpc_node_repo.delete(session,
                                      vpc_id=id,
                                      agent_id=self.get_current_agent_id())
            # If it is the last agent to delete, set
            # the status of the vpc deleted
            vpc_node_mappings, _ = self.vpc_node_repo.\
                get_all(session,
                        **{'agent_id': self.get_current_agent_id(),
                           'vpc_id': id})
            if not vpc_node_mappings:
                try:
                    self.vpc_repo.update(session, id=id,
                                         **{'status': constants.DELETED})
                    self.status_queue.put({"resource_type": "vpc",
                                           "resource_id": id,
                                           "current_status": constants.DELETED,
                                           "timestamp": timeutils.utcnow(),
                                           "action": "delete"})
                    LOG.info("Delete Vpc equal to id %s successfully", id)
                except Exception as e:
                    LOG.error("Fail to delete Vpc equal to id %s in db ,"
                              "exception is %s", id, e)

    def get_current_agent_id(self):
        if not self.agent_id:
            session = db_api.get_session(autocommit=False)
            agent_obj = self.agent_repo.get(session,
                                            hostname=CONF.
                                            agent_settings.hostname)
            self.agent_id = agent_obj.id
        return self.agent_id

    def add_interface(self, vpc_id, interface_name):
        bridge_name = common_utils.get_bridge_name(vpc_id)
        self.vpc_dirver.add_interface(bridge_name, interface_name)


# This class for packet capture
class DhcpDriverWrapper(dnsmasq.Dnsmasq):

    def __init__(self, conf, vpc, process_monitor, vpc_pool, thread_pool):
        super().__init__(conf, vpc, process_monitor)
        self.cd_repo = client_device_repo.ClientDeviceRepository()
        self.DiscoveryClient = DiscoveryClient()
        self.vpc_pool = vpc_pool
        self.thread_pool = thread_pool

    def reload_allocations(self):
        # reload config file
        super().reload_allocations()

        if super().interface_name:
            self.start_cli_discover()

    def enable(self):
        # Enable dhcp
        super().enable()

        self.start_cli_discover()

    def disable(self, retain_port=False, block=False):
        # Disable dhcp
        super().disable(retain_port, block)

        self.stop_cli_discover()

    def start_cli_discover(self):
        if self.vpc.id not in self.vpc_pool:
            interface_name = None
            for nic in self.vpc.nics:
                if nic.owner_type == constants.NIC_OF_DHCP and \
                        nic.hostname == CONF.agent_settings.hostname:
                    interface_name = self.get_interface_in_root_namespace(nic)
            try:
                if interface_name:
                    sniff = self.DiscoveryClient.start(iface=interface_name)
                    self.thread_pool[self.vpc.id] = [sniff]
            except Exception as e:
                LOG.debug(
                    'client device discover service stop, exception is %s', e)
            self.vpc_pool.add(self.vpc.id)
            self.refresh()

        else:
            LOG.debug('%s client device already running', self.vpc.id,)

    def update_db(self, device_info):
        session = db_api.get_session(autocommit=True)
        if device_info:
            for mac in device_info:
                device = self.cd_repo.get_by_mac(session, mac)
                if device:
                    self.cd_repo.update(session,
                                        device.id,
                                        **{'ip': device_info[mac]['ip'],
                                           'last_update': device_info
                                           [mac]['last_update']})

                else:
                    self.cd_repo.create(session=session,
                                        **{'vpc_id': self.vpc.id,
                                           'mac': mac,
                                           'ip': device_info[mac]['ip'],
                                           'last_update': device_info
                                           [mac]['last_update']})

    # Write to database every five minutes
    def refresh(self):
        # refresh in 10 minutes
        timer = threading.Timer(600.0, self.refresh)
        timer.start()
        if len(self.thread_pool[self.vpc.id]) > 1:
            self.thread_pool[self.vpc.id].pop()
        self.thread_pool[self.vpc.id].append(timer)
        self.update_db(self.DiscoveryClient.device_info)

    def stop_cli_discover(self):
        if not self.vpc.nics:
            try:
                self.thread_pool[self.vpc.id][0].stop()
                self.thread_pool[self.vpc.id][1].cancel()
                self.thread_pool.pop(self.vpc.id)
                self.vpc_pool.remove(self.vpc.id)
            except KeyError:
                LOG.debug('Not %s in thread_pool', self.vpc.id)


class Dhcp(object):

    def __init__(self):
        dnsmasq.Dnsmasq.validate_os_support_dnsmasq()
        self.vpc_repo = vpc_repo.VpcRepository()
        self.subnet_repo = subnet_repo.SubnetRepository()
        self.nic_repo = nic_repo.NicRepository()
        self.dhcp_repo = dhcp_repo.DhcpNodeMappingRepository()
        self.process_monitor = external_process.\
            ProcessMonitor(CONF.agent_settings, 'dhcp')
        self.cache = DhcpCache()
        self._populate_vpcs_cache()
        self.vpc_pool = set()
        self.thread_pool = {}

    def _populate_vpcs_cache(self):
        """Populate the networks cache when the DHCP-agent starts."""
        existing_vpc_ids = dnsmasq.Dnsmasq.existing_dhcp_vpcs(CONF)
        session = db_api.get_session()
        existing_vpcs, _ = self.vpc_repo.get_all(session, ids=existing_vpc_ids)
        for vpc in existing_vpcs:
            self.cache.put_vpc(self._convert_to_vpc_info(vpc))

    def _get_dhcp_driver(self, vpc_id):
        db_vpc = self.vpc_repo.get(db_api.get_session(), id=vpc_id)
        if not db_vpc:
            raise api_exceptions.NotFound(resource='nic', id=vpc_id)
        return DhcpDriverWrapper(CONF,
                                 self._convert_to_vpc_info(db_vpc),
                                 self.process_monitor,
                                 self.vpc_pool,
                                 self.thread_pool)

    def active(self, vpc_id):
        return self._get_dhcp_driver(vpc_id).active

    def get_interface_in_root_namespace(self, nic):
        return self._get_dhcp_driver(nic.vpc_id).\
            get_interface_in_root_namespace(nic)

    @_wait_if_syncing
    def _handle_vpc_delete(self, vpc_id):
        vpc = VPCInfo(vpc_id, self._get_dhcp_namespace(vpc_id),
                      None, None, None)
        self.cache.remove_vpc(vpc_id)
        DhcpDriverWrapper(CONF, vpc, self.process_monitor,
                          self.vpc_pool, self.thread_pool).disable()

    @_wait_if_syncing
    def _handle_subnet_create_or_update(self, vpc_id):
        db_vpc = self._get_vpc_by_id(db_api.get_session(), vpc_id)
        vpc = self._convert_to_vpc_info(db_vpc)
        if self._is_dhcp_nic_existing(vpc):
            self._refresh_dhcp_helper(vpc)
        else:
            self.cache.remove_vpc(vpc_id)
            self._get_dhcp_driver(vpc_id).disable()

    @_wait_if_syncing
    def _handle_subnet_delete(self, vpc_id):
        db_vpc = self._get_vpc_by_id(db_api.get_session(), vpc_id)
        self._refresh_dhcp_helper(self._convert_to_vpc_info(db_vpc))

    def _get_vpc_by_id(self, session, id):
        vpc = self.vpc_repo.get(session, id=id)
        if not vpc:
            raise api_exceptions.NotFound(resource='vpc', id=id)
        return vpc

    @_wait_if_syncing
    def _handle_nic_create_or_update(self, nic_id):
        session = db_api.get_session()
        db_nic = self._get_nic_by_id(session, nic_id)
        vpc = self.cache.get_vpc_by_id(db_nic.vpc_id)
        if vpc and self._is_dhcp_nic_existing(vpc):
            self._reload_allocations(self._convert_to_nic_info(db_nic), vpc)

    def _get_nic_by_id(self, session, id):
        nic = self.nic_repo.get(session, id=id)
        if not nic:
            raise api_exceptions.NotFound(resource='nic', id=id)
        return nic

    @_wait_if_syncing
    def _handle_nic_delete(self, nic_id):
        nic = self.cache.get_nic_by_id(nic_id)
        if nic:
            vpc = self.cache.get_vpc_by_id(nic.vpc_id)
            if vpc and self._is_dhcp_nic_existing(vpc):
                self.cache.remove_nic(nic_id)
                self._reload_allocations(nic, vpc)

    @staticmethod
    def _is_dhcp_nic_existing(vpc):
        for nic in vpc.nics:
            if nic.hostname == CONF.agent_settings.hostname and \
                    nic.owner_type == constants.NIC_OF_DHCP:
                return True
        return False

    def _refresh_dhcp_helper(self, vpc):
        # Refresh or disable DHCP for a vpc depending
        # on the current state of the vpc.
        if not vpc:
            return None
        old_vpc = self.cache.get_vpc_by_id(vpc.id)
        if not old_vpc:
            # DHCP current not running for network.
            return self._enable_dhcp_helper(vpc)

        if not any(s for s in vpc.subnets if s.enable_dhcp):
            self._disable_dhcp_helper(vpc.id)
            return None
        old_cidrs = [s.cidr for s in old_vpc.subnets if s.enable_dhcp]
        new_cidrs = [s.cidr for s in vpc.subnets if s.enable_dhcp]
        if old_cidrs == new_cidrs:
            self._get_dhcp_driver(vpc.id).reload_allocations()
            self.cache.put_vpc(vpc)
        elif self._get_dhcp_driver(vpc.id).restart():
            self.cache.put_vpc(vpc)
        return None

    def _enable_dhcp_helper(self, vpc):
        """Enable DHCP for a vpc that meets enabling criteria."""
        self._configure_dhcp_for_network(vpc)

    def _configure_dhcp_for_network(self, vpc):
        if vpc.subnets and any(s for s in vpc.subnets if s.enable_dhcp)\
                and self._get_dhcp_driver(vpc.id).enable():
            self.cache.put_vpc(vpc)

    def _disable_dhcp_helper(self, vpc_id):
        """Disable DHCP for a vpc known to the agent."""
        vpc = self.cache.get_vpc_by_id(vpc_id)
        if vpc and self._get_dhcp_driver(vpc.id).disable():
            self.cache.remove_vpc(vpc_id)

    def _reload_allocations(self, nic, vpc):
        LOG.info("Trigger reload_allocations for nic %s on vpc %s",
                 nic, vpc)
        self.cache.put_nic(nic)
        self._get_dhcp_driver(vpc.id).reload_allocations()

    def sync_dhcp(self, session, hostname, delete_invalid_dhcp=False):
        if delete_invalid_dhcp:
            self._delete_invalid_dhcp(session)

        try:
            dhcp_node_mappings, _ = self.dhcp_repo.get_all(session)
            # Delete invalid dhcp agent info
            invalid_dhcp_agents = set(
                mapping.hostname for mapping in dhcp_node_mappings
                if mapping.agent.status != constants.AGENT_UP)
            if invalid_dhcp_agents:
                self.dhcp_repo.delete_dhcp_agent_infos(invalid_dhcp_agents)
                dhcp_node_mappings, _ = self.dhcp_repo.get_all(session)

            for mapping in dhcp_node_mappings:
                # This agent has dhcp
                if mapping.hostname == hostname:
                    # Sync info about dhcp from db
                    self._sync_local_dhcp(session, hostname)
                    # If dhcp nic status is down, it means dhcp interface does
                    # not add to bridge.return nic ids to add dhcp interface to
                    # bridge
                    dhcp_nics, _ = self.nic_repo.get_all(
                        session, hostname=hostname,
                        owner_type=constants.NIC_OF_DHCP)
                    if dhcp_nics:
                        return [dhcp_nic.id for dhcp_nic
                                in dhcp_nics
                                if dhcp_nic.status == constants.DOWN]
                    break
            else:
                if len(dhcp_node_mappings) < \
                        self.dhcp_repo.get_expected_dhcp_agents_num(session):
                    # Attempt to start dhcp in this agent
                    create_dhcp_nic_ids = self.dhcp_repo.\
                        add_dhcp_agent_info(hostname)
                    LOG.info('Create dhcp nic id %s when sync dhcp',
                             create_dhcp_nic_ids)
                    if create_dhcp_nic_ids:
                        self._start_local_dhcp(session, hostname)
                        return create_dhcp_nic_ids
                else:
                    # Attempt to stop dhcp in this agent
                    self._close_local_dhcp_if_active(session)
        except Exception as e:
            LOG.error('Fail to sync dhcp, exception is %s', e)
        return None

    @_sync_lock
    def _sync_local_dhcp(self, session, hostname):
        vpcs, _ = self.vpc_repo.get_all(session)
        if vpcs:
            for vpc in vpcs:
                for subnet in vpc.subnets:
                    if subnet.enable_dhcp:
                        LOG.info('Sync local dhcp on %s node', hostname)
                        dhcp_driver = self._get_dhcp_driver(vpc.id)
                        if dhcp_driver.active:
                            dhcp_driver.reload_allocations()
                        else:
                            # It is a case that the agent has dhcp, but nic of
                            # the vpc does not exist. For example,there is one
                            # available ip in the ip pool of the subnet of this
                            # vpc, but for 3 dhcp agents, only 1 dhcp agent has
                            # a dhcp nic, and the other two dhcp agents do not
                            # have the dhcp nic.
                            if self._is_dhcp_nic_existing(vpc):
                                dhcp_driver.enable()
                        self.cache.put_vpc(self._convert_to_vpc_info(vpc))
                        break

    @_sync_lock
    def _start_local_dhcp(self, session, hostname):
        vpcs, _ = self.vpc_repo.get_all(session)
        if vpcs:
            for vpc in vpcs:
                for subnet in vpc.subnets:
                    if subnet.enable_dhcp:
                        LOG.info('Start local dhcp on %s node', hostname)
                        self._get_dhcp_driver(vpc.id).restart()
                        self.cache.put_vpc(self._convert_to_vpc_info(vpc))
                        break

    @_sync_lock
    def _close_local_dhcp_if_active(self, session):
        vpcs, _ = self.vpc_repo.get_all(session)
        if vpcs:
            for vpc in vpcs:
                for subnet in vpc.subnets:
                    if subnet.enable_dhcp:
                        dhcp_driver = self._get_dhcp_driver(vpc.id)
                        if dhcp_driver.active:
                            LOG.info('Close invalid dhcp process on %s node',
                                     CONF.agent_settings.hostname)
                            dhcp_driver.disable()
                            self.cache.remove_vpc(vpc.id)
                        break

    def _delete_invalid_dhcp(self, session):
        db_subnets, _ = self.subnet_repo.get_all(session)
        should_exist_namespaces = set(
            self._get_dhcp_namespace(db_subnet.vpc_id)
            for db_subnet in db_subnets if db_subnet.enable_dhcp)
        real_exist_namespaces = set(
            dnsmasq.Dnsmasq.get_all_dhcp_network_namespaces())
        delete_namespaces = real_exist_namespaces.difference(
            should_exist_namespaces)
        for delete_namespace in delete_namespaces:
            delete_vpc_id = delete_namespace[len(
                constants.DHCP_NAMESPACE_PREFIX) + 1:]
            self._handle_vpc_delete(delete_vpc_id)

    def _convert_to_vpc_info(self, vpc):
        # Only add subnets with dhcp enabled
        subnet_infos = []
        id_subnet = {}
        for subnet in vpc.subnets:
            if not subnet.enable_dhcp:
                continue
            dns_infos = []
            if subnet.dns_nameservers:
                for dns_nameserver in sorted(subnet.dns_nameservers,
                                             key=lambda x: x.order):
                    dns_infos.append(
                        DnsNameServerInfo(dns_nameserver.subnet_id,
                                          dns_nameserver.ip_address,
                                          dns_nameserver.order))
            subnet_info = SubnetInfo(subnet.id, subnet.cidr,
                                     subnet.enable_dhcp, dns_infos,
                                     subnet.gateway)
            subnet_infos.append(subnet_info)
            id_subnet[subnet.id] = subnet_info
        # Only add nic in subnet that enables dhcp
        nic_infos = []
        for nic in vpc.nics:
            nic_info = self._convert_to_nic_info(nic, id_subnet)
            if nic_info:
                nic_infos.append(nic_info)
        return VPCInfo(vpc.id, self._get_dhcp_namespace(vpc.id),
                       subnet_infos, nic_infos, 1450)

    @staticmethod
    def _convert_to_nic_info(nic, id_subnet=None):
        ip_address_infos = []
        for address in nic.ip_addresses:
            if id_subnet is not None:
                if address.subnet_id in id_subnet and \
                        id_subnet[address.subnet_id].enable_dhcp:
                    ip_address_infos.append(IpAddressInfo(
                        id_subnet[address.subnet_id], address.ip_address))
            elif address.subnet.enable_dhcp:
                ip_address_infos.append(IpAddressInfo(address.subnet,
                                                      address.ip_address))
        if ip_address_infos:
            return NicInfo(nic.id, nic.vpc_id,
                           nic.owner_type,
                           ip_address_infos,
                           nic.hostname,
                           nic.mac_address)
        return None

    @staticmethod
    def _get_dhcp_namespace(vpc_id):
        return constants.DHCP_NAMESPACE_PREFIX + '-' + vpc_id

    def handle_dhcp(self, action, vpc_id, nic_id=None):
        session = db_api.get_session()
        if not self._validate_dhcp_agent(session):
            return
        if action in [constants.CREATE_SUBNET, constants.UPDATE_SUBNET]:
            self._handle_subnet_create_or_update(vpc_id)
        elif action == constants.DELETE_SUBNET:
            self._handle_subnet_delete(vpc_id)
        elif action in [constants.CREATE_NIC, constants.UPDATE_NIC]:
            self._handle_nic_create_or_update(nic_id)
        elif action == constants.DELETE_NIC:
            self._handle_nic_delete(nic_id)
        elif action in constants.DHCP_FOR_VPC:
            self._handle_vpc_delete(vpc_id)
        else:
            LOG.error('The dhcp operation related to the action %(action)s '
                      'is not supported', action)
            raise exceptions.ActionNotSupport(resource='dhcp',
                                              action=action)

    def _validate_dhcp_agent(self, session):
        dhcp_node_mappings, _ = self.dhcp_repo.get_all(session)
        continue_handle = True
        hostname = CONF.agent_settings.hostname

        for mapping in dhcp_node_mappings:
            if mapping.hostname == hostname:
                break
        else:
            if len(dhcp_node_mappings) < \
                    self.dhcp_repo.get_expected_dhcp_agents_num(session):
                if self.dhcp_repo.add_dhcp_agent_info(hostname):
                    self._start_local_dhcp(session, hostname)
                else:
                    continue_handle = False
                    LOG.info('The %s node does not has dhcp, so ignore '
                             'request about dhcp from API side', hostname)
            else:
                continue_handle = False
        return continue_handle

    def get_dhcp_nic(self, session, vpc_id):
        dhcp_nic = self.nic_repo.get(session,
                                     vpc_id=vpc_id,
                                     hostname=CONF.agent_settings.hostname,
                                     owner_type=constants.NIC_OF_DHCP)
        if not dhcp_nic:
            raise api_exceptions.NotFound(resource='the nic of vpc',
                                          id=vpc_id)
        return dhcp_nic


class DhcpCache(object):
    """Agent cache of the current vpc info."""

    def __init__(self):
        self.id_vpc = {}
        self.nic_lookup = {}

    def get_vpc_by_id(self, vpc_id):
        return self.id_vpc.get(vpc_id)

    def get_vpc_by_nic_id(self, nic_id):
        return self.id_vpc.get(self.nic_lookup.get(nic_id))

    def get_nic_by_id(self, nic_id):
        vpc = self.get_vpc_by_nic_id(nic_id)
        if vpc:
            for nic in vpc.nics:
                if nic.id == nic_id:
                    return nic
        return None

    def put_vpc(self, vpc):
        if vpc.id in self.id_vpc:
            self.remove_vpc(vpc.id)
        self.id_vpc[vpc.id] = vpc
        for nic in vpc.nics:
            self.nic_lookup[nic.id] = vpc.id

    def remove_vpc(self, vpc_id):
        vpc = self.id_vpc.pop(vpc_id, None)
        if vpc:
            for nic in vpc.nics:
                del self.nic_lookup[nic.id]

    def put_nic(self, nic):
        vpc = self.get_vpc_by_id(nic.vpc_id)
        for index in range(len(vpc.nics)):
            if vpc.nics[index].id == nic.id:
                vpc.nics[index] = nic
                break
        else:
            vpc.nics.append(nic)

        self.nic_lookup[nic.id] = vpc.id

    def remove_nic(self, nic_id):
        vpc = self.get_vpc_by_nic_id(nic_id)

        for index in range(len(vpc.nics)):
            if vpc.nics[index].id == nic_id:
                del vpc.nics[index]
                del self.nic_lookup[nic_id]
                break


class Network(object):

    def __init__(self, queue):
        self.status_queue = queue
        self.vpc = Vpc(queue)
        self.nic_repo = nic_repo.NicRepository()
        self.subnet_repo = subnet_repo.SubnetRepository()
        self.dhcp = Dhcp()

    def create_vpc(self, **vpc):
        self.vpc.create(**vpc)

    def delete_vpc(self, id):
        self.vpc.delete(id)

    def sync_vpc(self, ensure_vpc_ready=False, delete_invalid_vpc=False):
        self.vpc.sync_vpc(ensure_vpc_ready, delete_invalid_vpc)

    def create_dhcp(self, action, vpc_id):
        # Enable dhcp, need to add dhcp nic to vpc's
        # bridge after enable dhcp.
        self.dhcp.handle_dhcp(action, vpc_id)
        if self.dhcp.active(vpc_id):
            LOG.info('Add dhcp interface to vpc %s', vpc_id)
            session = db_api.get_session()
            # Get the interface name of dhcp nic in root namespace
            dhcp_nic = self.dhcp.get_dhcp_nic(session, vpc_id)
            dhcp_interface_name = self.dhcp. \
                get_interface_in_root_namespace(dhcp_nic)
            # Add dhcp interface to vpc
            self.vpc.add_interface(vpc_id, dhcp_interface_name)
            # Update nic ’s status and notify webhook
            self.update_nic_status(session, dhcp_nic.id,
                                   action, constants.UP)

    def update_dhcp(self, action, vpc_id, nic_id=None):
        self.dhcp.handle_dhcp(action, vpc_id, nic_id)

    def delete_dhcp(self, action, vpc_id):
        self.dhcp.handle_dhcp(action, vpc_id)

    def sync_dhcp(self, delete_invalid_dhcp=False):
        session = db_api.get_session()
        hostname = CONF.agent_settings.hostname
        dhcp_nic_ids = self.dhcp.sync_dhcp(session, hostname,
                                           delete_invalid_dhcp)
        # add dhcp interface to bridge
        if dhcp_nic_ids:
            LOG.info('Add nic %s to bridge when sync dhcp', dhcp_nic_ids)
            dhcp_nic_ids, _ = self.nic_repo.get_all(session, ids=dhcp_nic_ids)
            for dhcp_nic in dhcp_nic_ids:
                dhcp_interface_name = self.dhcp. \
                    get_interface_in_root_namespace(dhcp_nic)
                # Add dhcp interface to vpc
                self.vpc.add_interface(dhcp_nic.vpc_id, dhcp_interface_name)
                # Update nic ’s status
                self.nic_repo.update(session,
                                     dhcp_nic.id,
                                     **{'status': constants.UP})

    def get_nic_config(self, db_nic, virt_type):
        if virt_type is None:
            raise exceptions.InternalServerError(
                msg="vif_type parameter must be present")
        if virt_type in ('kvm', 'qemu'):
            conf = vconfig.LibvirtConfigGuestInterface()
            conf.mac_addr = db_nic.mac_address
            conf.model = 'virtio'
            conf.net_type = "bridge"
            conf.source_dev = common_utils.get_bridge_name(db_nic.vpc_id)
            devname = self._get_vm_nic_name(db_nic.id)
            conf.target_dev = devname
            # In openstack neutron, thr default value of mtu in vpc is 1450
            conf.mtu = 1450
            if db_nic.owner_type == constants.NIC_OF_VOI_VM:
                # VOI VM boot from iso(windows) not support virtio device
                conf.model = 'e1000'
        else:
            raise exceptions.InternalServerError(msg='Unexpected virt_type')

        return conf

    def delete_nic(self, session, nic_id):
        if self.nic_repo.delete(session, id=nic_id):
            self.status_queue.put(
                {"resource_type": "nic",
                 "resource_id": nic_id,
                 "previous_status": None,
                 "current_status": constants.DOWN,
                 "timestamp": timeutils.utcnow(),
                 "action": 'detach'})

    def update_nic_status(self, session, nic_id, action, update_status,
                          expected_status=None, success=True, **kwargs):
        if success:
            update_data = kwargs or {}
            update_data['status'] = update_status
            if self.nic_repo.update(session, nic_id,
                                    expected_status=expected_status,
                                    **update_data) == 1:
                self.status_queue.put(
                    {"resource_type": "nic",
                     "resource_id": nic_id,
                     "previous_status": expected_status,
                     "current_status": update_status,
                     "timestamp": timeutils.utcnow(),
                     "action": action})
            else:
                LOG.warn('The expected status of nic %(nic_id)s is not '
                         '%(expected_status)s, so update nic status failed',
                         {'nic_id': nic_id,
                          'expected_status': expected_status})
        else:
            LOG.warn("Fail to %(action)s nic %(nic_id)s, so not update "
                     "nic status", {'action': action, 'nic_id': nic_id})

    def init_host(self):
        self.sync_vpc(ensure_vpc_ready=True, delete_invalid_vpc=True)
        self.sync_dhcp(delete_invalid_dhcp=True)
        self._add_vm_interface_to_vpc()

    def _add_vm_interface_to_vpc(self):
        # add vdi vm's interface to bridge if need
        nics, _ = self.nic_repo.get_all(db_api.get_session(),
                                        owner_type=constants.NIC_OF_VDI_VM)
        for nic in nics:
            if nic.status == constants.UP and \
                    nic.hostname == CONF.agent_settings.hostname:
                self.vpc.add_interface(nic.vpc_id,
                                       self._get_vm_nic_name(nic.id))

    @staticmethod
    def _get_vm_nic_name(nic_id):
        # get vdi vm's interface
        return (constants.TAP_DEVICE_PREFIX + nic_id)[:constants.LINUX_DEV_LEN]
