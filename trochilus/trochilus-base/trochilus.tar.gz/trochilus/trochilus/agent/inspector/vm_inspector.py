#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import timeutils

from trochilus.agent.common import exceptions
from trochilus.agent.common import resource_processing_queue as queue
from trochilus.agent.compute.libvirt import power_state
from trochilus.agent.inspector import base_inspector
from trochilus.common import constants
from trochilus.db import api as db_api
from trochilus.db import virtual_machine_repo as vm_repo


LOG = logging.getLogger(__name__)
CONF = cfg.CONF


class VMInspector(base_inspector.Inspector):
    def __init__(self, agent_queue, vm_manager):
        super().__init__(agent_queue)

        # Init repo
        self.vm_repo = vm_repo.VirtualMachineRepository()

        # Init manager
        self.vm_manager = vm_manager

    def _stop_unexpected_shutdown_vm(self, session, agent_id):
        # Get all active vms
        filters = {'status': constants.ACTIVE,
                   'agent_id': agent_id}
        active_vms = self.vm_repo.get_all(session, **filters)[0]
        for vm_obj in active_vms:
            # Get VM info in hypervisor
            try:
                vm_info = self.vm_manager.driver.get_info(vm_obj)
            except exceptions.VMNotFound:
                LOG.warning("[VM %s]The VM status is %s, but not exits"
                            " in hypervisor. Someone may have "
                            "manually undefined the VM. And set VM status",
                            " to stopped", vm_obj.id, vm_obj.status)
                vm_obj.status = constants.STOPPED
                vm_obj.save(session)
                continue

            vm_power_state = vm_info.state
            if vm_power_state in (power_state.SHUTDOWN,
                                  power_state.CRASHED):
                LOG.warning("[VM %(vm_id)s] VM shutdown by itself. "
                            "Calling the vm stop API. Current vm_state: "
                            "%(vm_state)s, current VM power_state:"
                            " %(vm_power_state)s",
                            {'vm_state': vm_obj.status,
                             'vm_power_state': vm_power_state,
                             'vm_id': vm_obj.id})
                try:
                    self.vm_manager.stop(vm_obj.id)
                except Exception as e:
                    LOG.warning("[VM %s]error during stop() in "
                                "inspect vm power status. Exception is %s",
                                vm_obj.id, e)

    def power_status_inspector(self):
        LOG.info("Starting inspect VM power status...")

        session = db_api.get_session()
        db_agent = self.agent_repo.get_agent_by_hostname(
            session, CONF.agent_settings.hostname)
        if db_agent and self.agent_repo.is_agent_up(db_agent):
            # Sync VDI VM shutdown power status
            self._stop_unexpected_shutdown_vm(session, db_agent.id)
        else:
            LOG.error("Jump over inspect VM power status, Because agent "
                      "is not available")

    def _check_vm_create_time(self, session, agent_id):
        timeout = CONF.agent_settings.vm_create_timeout
        if timeout == 0:
            return

        # Get all creating vms
        filters = {'status': constants.CREATING,
                   'agent_id': agent_id}
        creating_vms = self.vm_repo.get_all(session, **filters)[0]

        for vm_obj in creating_vms:
            if timeutils.is_older_than(vm_obj.created_at, timeout):
                self.vm_manager.update_vm_status(
                    session, vm_obj.id, 'create',
                    constants.ERROR,
                    expected_status=constants.CREATING)
                LOG.warning("[VM %s] VM create timed out. Set to error "
                            "state.", vm_obj.id)

    def create_timeout_inspector(self):
        LOG.info("Starting inspect VM create timeout...")

        session = db_api.get_session()
        db_agent = self.agent_repo.get_agent_by_hostname(
            session, CONF.agent_settings.hostname)
        if db_agent and self.agent_repo.is_agent_up(db_agent):
            self._check_vm_create_time(session, db_agent.id)
        else:
            LOG.error("Jump over inspect VM create timeout, "
                      "Because agent is not available")

    def process_status_of_creating(self, session, vm_obj):
        LOG.warning("[VM %s] VM create stuck. Set to error "
                    "state.", vm_obj.id)
        self.vm_manager.update_vm_status(
            session, vm_obj.id, 'create',
            constants.ERROR,
            expected_status=constants.CREATING)

    def process_status_of_deleting(self, session, vm_obj):
        LOG.warning("[VM %s] VM delete stuck. Set to error "
                    "state.", vm_obj.id)
        self.vm_manager.update_vm_status(
            session, vm_obj.id, 'delete',
            constants.ERROR,
            expected_status=constants.DELETING)

    def process_status_of_starting(self, session, vm_obj):
        LOG.warning("[VM %s] VM start stuck. "
                    "Try start the VM again.", vm_obj.id)
        self.agent_queue.add(
            queue.ResourceUpdate(vm_obj.id,
                                 0,
                                 resource='vm',
                                 action='start',
                                 payload={'id': vm_obj.id})
        )

    def process_status_of_stopping(self, session, vm_obj):
        LOG.warning("[VM %s] VM stop stuck. "
                    "Try stop the VM again.", vm_obj.id)
        self.agent_queue.add(
            queue.ResourceUpdate(vm_obj.id,
                                 0,
                                 resource='vm',
                                 action='stop',
                                 payload={'id': vm_obj.id})
        )

    def process_status_of_rebooting(self, session, vm_obj):
        LOG.warning("[VM %s] VM reboot stuck. "
                    "Try soft reboot the VM again.", vm_obj.id)
        self.agent_queue.add(
            queue.ResourceUpdate(vm_obj.id,
                                 0,
                                 resource='vm',
                                 action='reboot',
                                 payload={'id': vm_obj.id})
        )

    def get_process(self, status):
        process = {
            constants.CREATING: self.process_status_of_creating,
            constants.DELETING: self.process_status_of_deleting,
            constants.STARTING: self.process_status_of_starting,
            constants.STOPPING: self.process_status_of_stopping,
            constants.REBOOTING: self.process_status_of_rebooting
        }
        return process[status]

    def stuck_ing_status_inspector(self):
        LOG.info("Starting inspect VM stuck 'ing' status...")

        session = db_api.get_session()
        db_agent = self.agent_repo.get_agent_by_hostname(
            session, CONF.agent_settings.hostname)
        if db_agent and self.agent_repo.is_agent_up(db_agent):
            filters = {'agent_id': db_agent.id}
            ing_vms = self.vm_repo.get_all_ing_status_vms(session, **filters)

            for vm in ing_vms:
                if vm.status in constants.NEED_PROCESS_ING_STATUS_LIST:
                    self.get_process(vm.status)(session, vm)

        else:
            LOG.error("Jump over inspect VM stuck 'ing' status,"
                      " Because agent is not available")

    def get_inspector(self, inspector_name):
        inspectors = {
            constants.POWER_STATUS_INSPECTOR: self.power_status_inspector,
            constants.CREATE_TIMEOUT_INSPECTOR: self.create_timeout_inspector,
            constants.STUCK_ING_STATUS_INSPECTOR:
                self.stuck_ing_status_inspector,
        }
        return inspectors[inspector_name]
