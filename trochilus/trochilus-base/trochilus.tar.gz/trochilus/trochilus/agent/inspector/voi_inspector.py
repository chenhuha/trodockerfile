#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import timeutils

from trochilus.agent.common import exceptions
from trochilus.agent.common import resource_processing_queue as queue
from trochilus.agent.compute.libvirt import power_state
from trochilus.agent.inspector import base_inspector
from trochilus.common import constants
from trochilus.db import api as db_api
from trochilus.db import voi_repo


LOG = logging.getLogger(__name__)
CONF = cfg.CONF


class VOIInspector(base_inspector.Inspector):
    def __init__(self, agent_queue, voi_vm_manager):
        super().__init__(agent_queue)

        # Init repo
        self.voi_vm_repo = voi_repo.VMRepository()

        # Init manager
        self.voi_vm_manager = voi_vm_manager

    def _stop_unexpected_shutdown_voi_vm(self, session, agent_id):
        # Get all active voi vms
        filters = {'status': constants.ACTIVE,
                   'agent_id': agent_id}
        active_voi_vms = self.voi_vm_repo.get_all(session, **filters)[0]
        for voi_vm_obj in active_voi_vms:
            # Get VOI VM info in hypervisor
            try:
                voi_vm_info = self.voi_vm_manager.get_info(voi_vm_obj)
            except exceptions.VMNotFound:
                LOG.warning("[VOI VM %s]The VOI VM status is %s, but not exits"
                            " in hypervisor. Someone may have manually "
                            "undefined the VOI VM. And set VOI VM status",
                            " to stopped", voi_vm_obj.id, voi_vm_obj.status)
                voi_vm_obj.status = constants.STOPPED
                voi_vm_obj.save(session)
                continue

            voi_vm_power_state = voi_vm_info.state
            if voi_vm_power_state in (power_state.SHUTDOWN,
                                      power_state.CRASHED):
                LOG.warning("[VOI VM %(vm_id)s] VM shutdown by itself. "
                            "Calling the vm stop API. Current vm_state: "
                            "%(vm_state)s, current VM power_state:"
                            " %(vm_power_state)s",
                            {'vm_state': voi_vm_obj.status,
                             'vm_power_state': voi_vm_power_state,
                             'vm_id': voi_vm_obj.id})
                try:
                    self.voi_vm_manager.stop(id=voi_vm_obj.id, force_stop=True)
                except Exception as e:
                    LOG.warning("[VOI VM %s]error during stop() in "
                                "inspect voi power status. Exception is %s",
                                voi_vm_obj.id, e)

    def power_status_inspector(self):
        LOG.info("Starting inspect VOI VM power status...")

        session = db_api.get_session()
        db_agent = self.agent_repo.get_agent_by_hostname(
            session, CONF.agent_settings.hostname)
        if db_agent and self.agent_repo.is_agent_up(db_agent):
            # Sync VOI VM shutdown power status
            self._stop_unexpected_shutdown_voi_vm(session, db_agent.id)
        else:
            LOG.error("Jump over inspect VOI VM power status, Because agent "
                      "is not available")

    def _check_voi_vm_create_time(self, session, agent_id):
        timeout = CONF.agent_settings.voi_vm_create_timeout
        if timeout == 0:
            return

        # Get all creating vms
        filters = {'status': constants.CREATING,
                   'agent_id': agent_id}
        creating_voi_vms = self.voi_vm_repo.get_all(session, **filters)[0]

        for voi_vm_obj in creating_voi_vms:
            if timeutils.is_older_than(voi_vm_obj.created_at, timeout):
                self.voi_vm_manager.update_voi_vm_status(
                    session, voi_vm_obj.id, 'create',
                    constants.ERROR,
                    expected_status=constants.CREATING)
                LOG.warning("[VOI VM %s] VOI VM craete timed out. Set to "
                            "error state.", voi_vm_obj.id)

    def create_timeout_inspector(self):
        LOG.info("Starting inspect VOI VM create timeout...")

        session = db_api.get_session()
        db_agent = self.agent_repo.get_agent_by_hostname(
            session, CONF.agent_settings.hostname)
        if db_agent and self.agent_repo.is_agent_up(db_agent):
            self._check_voi_vm_create_time(session, db_agent.id)
        else:
            LOG.error("Jump over inspect VOI VM create timeout, "
                      "Because agent is not available")

    def process_status_of_creating(self, session, voi_vm_obj):
        LOG.warning("[VOI VM %s] VM create stuck. Set VM to error "
                    "state.", voi_vm_obj.id)
        self.voi_vm_manager.update_voi_vm_status(
            session, voi_vm_obj.id, 'create',
            constants.ERROR,
            expected_status=constants.CREATING)

    def process_status_of_deleting(self, session, voi_vm_obj):
        LOG.warning("[VOI VM %s] VM delete stuck. Set VM to error "
                    "state.", voi_vm_obj.id)
        self.voi_vm_manager.update_voi_vm_status(
            session, voi_vm_obj.id, 'delete',
            constants.ERROR,
            expected_status=constants.DELETING)

    def process_status_of_starting(self, session, voi_vm_obj):
        LOG.warning("[VOI VM %s] VM start stuck. "
                    "Try start the VM again.", voi_vm_obj.id)
        self.agent_queue.add(
            queue.ResourceUpdate(voi_vm_obj.id,
                                 0,
                                 resource='voi',
                                 action='start',
                                 payload={'id': voi_vm_obj.id})
        )

    def process_status_of_stopping(self, session, voi_vm_obj):
        LOG.warning("[VOI VM %s] VM stop stuck. "
                    "Try stop the VM again.", voi_vm_obj.id)
        self.agent_queue.add(
            queue.ResourceUpdate(voi_vm_obj.id,
                                 0,
                                 resource='voi',
                                 action='stop',
                                 payload={'id': voi_vm_obj.id,
                                          'force_stop': False})
        )

    def process_status_of_rebooting(self, session, voi_vm_obj):
        LOG.warning("[VOI VM %s] VM reboot stuck. "
                    "Try soft reboot the VM again.", voi_vm_obj.id)
        self.agent_queue.add(
            queue.ResourceUpdate(voi_vm_obj.id,
                                 0,
                                 resource='voi',
                                 action='reboot',
                                 payload={'id': voi_vm_obj.id,
                                          'reboot_type': 'SOFT'})
        )

    def get_process(self, status):
        process = {
            constants.CREATING: self.process_status_of_creating,
            constants.DELETING: self.process_status_of_deleting,
            constants.STARTING: self.process_status_of_starting,
            constants.STOPPING: self.process_status_of_stopping,
            constants.REBOOTING: self.process_status_of_rebooting
        }
        return process[status]

    def stuck_ing_status_inspector(self):
        LOG.info("Starting inspect VOI VM stuck 'ing' status...")

        session = db_api.get_session()
        db_agent = self.agent_repo.get_agent_by_hostname(
            session, CONF.agent_settings.hostname)
        if db_agent and self.agent_repo.is_agent_up(db_agent):
            agent_id = db_agent.id
            filters = {'agent_id': agent_id}
            ing_voi_vms = self.voi_vm_repo.get_all_ing_status_vms(
                session, **filters)

            for voi_vm in ing_voi_vms:
                if voi_vm.status in constants.NEED_PROCESS_ING_STATUS_LIST:
                    self.get_process(voi_vm.status)(session, voi_vm)

        else:
            LOG.error("Jump over inspect VOI VM stuck 'ing' status,"
                      " Because agent is not available")

    def get_inspector(self, inspector_name):
        inspectors = {
            constants.POWER_STATUS_INSPECTOR: self.power_status_inspector,
            constants.CREATE_TIMEOUT_INSPECTOR: self.create_timeout_inspector,
            constants.STUCK_ING_STATUS_INSPECTOR:
                self.stuck_ing_status_inspector,
        }
        return inspectors[inspector_name]
