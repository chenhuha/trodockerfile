# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_config import cfg


CONF = cfg.CONF


class VolumeDriver(object):

    def __init__(self, backend):
        self.backend = backend
        self._init_driver()

    def _init_driver(self):
        pass

    @property
    def config(self):
        """Get backend config group"""
        return getattr(CONF, self.backend)

    def create_volume(self, volume, image=None):
        raise NotImplementedError()

    def delete_volume(self, volume):
        raise NotImplementedError()

    def crete_volume_from_volume(self, clone_vol, src_vol):
        """Create a cloned volume base another volume."""
        raise NotImplementedError()

    def create_volume_from_snapshot(self, snapshot, volume):
        """Creates a volume from snapshot."""
        raise NotImplementedError()

    def get_mon_info(self):
        raise NotImplementedError()

    def get_disk_config(self, volume):
        raise NotImplementedError()

    def create_snapshot(self, snapshot):
        """Creates a snapshot."""
        raise NotImplementedError()

    def delete_snapshot(self, snapshot):
        """Deletes a snapshot."""
        raise NotImplementedError()

    def revert_snapshot(self, volume, snapshot):
        """Revert volume/image to snapshot."""
        raise NotImplementedError()

    def rebuild_volume(self, volume, image=None, snapshot=None):
        """Support for volume rebuild from image or snapshot"""
        raise NotImplementedError()

    def extend_volume(self, volume, volume_size, volume_state):
        """Increase the size of the volume"""
        raise NotImplementedError()
