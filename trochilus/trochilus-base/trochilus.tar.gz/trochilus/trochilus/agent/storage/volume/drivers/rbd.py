# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import math
import urllib

from eventlet import tpool
from oslo_concurrency import processutils
from oslo_config import cfg
from oslo_log import log as logging
from oslo_serialization import jsonutils
from oslo_utils import units
from oslo_utils import uuidutils
from trochilus.agent.common import exceptions
from trochilus.agent.compute.libvirt import config as vconfig
from trochilus.agent.compute import utils
from trochilus.agent.storage.volume.driver import VolumeDriver
from trochilus.i18n import _

try:
    import rados
    import rbd
except ImportError:
    rados = None
    rbd = None


CONF = cfg.CONF
LOG = logging.getLogger(__name__)


RBD_OPTS = [
    cfg.StrOpt('rbd_cluster_name',
               default='ceph',
               help='The name of ceph cluster'),
    cfg.StrOpt('rbd_pool',
               default='volumes',
               help='The RADOS pool where rbd volumes are stored'),
    cfg.StrOpt('rbd_user',
               default='trochilus',
               help='The RADOS client name for accessing rbd volumes '
                    '- only set when using cephx authentication'),
    cfg.StrOpt('rbd_ceph_conf',
               default='',  # default determined by librados
               help='Path to the ceph configuration file'),
    cfg.StrOpt('rbd_keyring_conf',
               default='',
               help='Path to the ceph keyring file')
]


class RADOSClient(object):
    """Context manager to simplify error handling for connecting to ceph."""

    def __init__(self, rbd_driver, pool=None):
        self.rbd_driver = rbd_driver
        self.client, self.ioctx = self._connect_to_rados(pool)

    def __enter__(self):
        return self

    def __exit__(self, type_, value, traceback):
        self._disconnect_from_rados()

    def _connect_to_rados(self, pool):
        config = self.rbd_driver.config

        rbd_cluster_name = config.rbd_cluster_name
        pool = pool if pool else config.rbd_pool
        rbd_user = config.rbd_user
        rbd_ceph_conf = config.rbd_ceph_conf
        rbd_keyring_conf = config.rbd_keyring_conf

        client = rados.Rados(
            clustername=rbd_cluster_name,
            conffile=rbd_ceph_conf,
            rados_id=rbd_user)

        client.connect()
        ioctx = client.open_ioctx(pool)
        LOG.debug("Connected to ceph cluster with params: %s",
                  {'conf': rbd_ceph_conf, 'rbd_user': rbd_user,
                   'pool': pool, 'keyring_conf': rbd_keyring_conf})
        return client, ioctx

    def _disconnect_from_rados(self):
        self.ioctx.close()
        self.client.shutdown()


class RBDVolumeProxy(object):
    def __init__(self, rbd_volume):
        self.rbd_volume = tpool.Proxy(rbd_volume)

    def __enter__(self):
        return self

    def __exit__(self, type_, value, traceback):
        self.rbd_volume.close()

    def __getattr__(self, attrib):
        return getattr(self.rbd_volume, attrib)


class RBDVolumeDriver(VolumeDriver):

    def __init__(self, backend):
        super().__init__(backend)

    def _init_driver(self):
        driver_info = {
            "driver": self.__class__.__name__,
            "backend": self.backend
        }
        LOG.info("Starting volume driver %(driver)s for backend %(backend)s",
                 driver_info)
        CONF.register_opts(RBD_OPTS, group=self.backend)

        if not rbd or not rados:
            LOG.error("Please confirm python3-rbd and"
                      " python3-rados installed.")
            raise ImportError

        LOG.info("Driver %(driver)s for backend %(backend)s initialization"
                 " completed successfully", driver_info)

    def RBDProxy(self):
        return tpool.Proxy(rbd.RBD())

    def _get_children_info(self, volume, snap):
        """List children for the given snapshot of a volume."""

        # Returns a list of (pool, volume).
        children_list = []
        if snap:
            volume.set_snap(snap)
            children_list = volume.list_children()
            volume.set_snap(None)

        return children_list

    def rbd_name(self, volume_id):
        volume_name_template = self.config.volume_name_template
        return volume_name_template % volume_id

    def create_volume(self, volume_obj, image_obj=None, snapshot_obj=None):
        rbd_name = self.rbd_name(volume_obj.id)
        volume_size = volume_obj.size * units.Gi

        if image_obj:
            location = image_obj.location
            image_format = image_obj.disk_format
            self.clone_image(rbd_name, location, volume_size, image_format)
        elif snapshot_obj:
            self._clone(rbd_name, self.config.rbd_pool,
                        self.rbd_name(snapshot_obj.volume_id), snapshot_obj.id)
            self._resize(rbd_name, volume_size)
        else:
            with RADOSClient(self) as client:
                self.RBDProxy().create(client.ioctx, rbd_name, volume_size)

    def delete_volume(self, volume_obj):
        rbd_name = self.rbd_name(volume_obj.id)
        with RADOSClient(self) as client:
            try:
                self.RBDProxy().remove(client.ioctx, rbd_name)
            except rbd.ImageNotFound:
                LOG.info("volume %s no longer exists in backend",
                         rbd_name)
                return

    def revert_snapshot(self, volume_obj, snapshot_obj):
        rbd_name = self.rbd_name(volume_obj.id)
        with RADOSClient(self) as client:
            with rbd.Image(client.ioctx, rbd_name) as volume:
                try:
                    volume.rollback_to_snap(snapshot_obj.id)
                except Exception as e:
                    raise exceptions.SnapRevertFailed(
                        snapshot_id=snapshot_obj.id) from e

    def crete_volume_from_volume(self, volume_obj, src_volume_obj):
        """Create a cloned volume from the volume."""
        clone_name = self.rbd_name(volume_obj.id)
        src_name = self.rbd_name(src_volume_obj.id)
        src_snap = "{}.clone_snap".format(uuidutils.generate_uuid())

        # Otherwise do COW clone.
        with RADOSClient(self) as client:
            # TODO(liupeng) Support temporary snapshot reuse within a certain
            # period of time instead of creating a new one every time
            #
            # Create new snapshot of source volume
            LOG.debug("creating snapshot='%s'", src_snap)
            with RBDVolumeProxy(rbd.Image(client.ioctx, src_name)) as volume:
                volume.create_snap(src_snap)
                volume.protect_snap(src_snap)

            try:
                # Clone a volume using the snapshot
                LOG.debug("cloning '%(src_name)s@%(src_snap)s' to "
                          "'%(clone_name)s'",
                          {'src_name': src_name, 'src_snap': src_snap,
                           'clone_name': clone_name})
                self.RBDProxy().clone(client.ioctx, src_name, src_snap,
                                      client.ioctx, clone_name)
            except Exception as e:
                with RBDVolumeProxy(rbd.Image(client.ioctx,
                                              src_name)) as volume:
                    volume.unprotect_snap(src_snap)
                    volume.remove_snap(src_snap)
                msg = (_("Failed to clone '%(src_name)s@%(src_snap)s' to "
                         "'%(clone_name)s', error: %(error)s") %
                       {'src_name': src_name,
                        'src_snap': src_snap,
                        'clone_name': clone_name,
                        'error': e})
                raise exceptions.VolumeBackendAPIException(data=msg) from e

            try:
                LOG.debug("flattening volume %s", clone_name)
                self._flatten(clone_name)
            except Exception as e:
                msg = (_("Failed to flatten volume %(volume)s with "
                         "error: %(error)s.") %
                       {'volume': clone_name,
                        'error': e})
                raise exceptions.VolumeBackendAPIException(data=msg) from e

            try:
                # remove temporary snap
                LOG.debug("remove temporary snap %s", src_snap)
                with RBDVolumeProxy(rbd.Image(client.ioctx,
                                              src_name)) as volume:
                    volume.unprotect_snap(src_snap)
                    volume.remove_snap(src_snap)
            except Exception as e:
                msg = (_("Failed to remove temporary snap "
                         "%(snap_name)s, error: %(error)s") %
                       {'snap_name': src_snap,
                        'error': e})
                raise exceptions.VolumeBackendAPIException(data=msg) from e

            if int(volume_obj.size) > int(src_volume_obj.size):
                volume_size = volume_obj.size * units.Gi
                self._resize(clone_name, volume_size)

        LOG.debug("clone created successfully")

    def create_volume_from_snapshot(self, snapshot_obj,
                                    volume_obj, flatten):
        """Creates a volume from a snapshot."""
        src_volume = self.rbd_name(snapshot_obj.volume_id)
        clone_volume = self.rbd_name(volume_obj.id)
        with RADOSClient(self) as client:
            self.RBDProxy().clone(client.ioctx, src_volume, snapshot_obj.id,
                                  client.ioctx, clone_volume)
        if flatten:
            self._flatten(clone_volume)

        if int(volume_obj.size) > int(snapshot_obj.size):
            volume_size = volume_obj.size * units.Gi
            self._resize(clone_volume, volume_size)

    def _flatten(self, volume_name):
        """Flatten the volume aim to detach volume dependencies."""
        LOG.debug('flattening volume %s', volume_name)
        with RADOSClient(self) as client:
            with RBDVolumeProxy(rbd.Image(client.ioctx,
                                          volume_name)) as volume:
                try:
                    volume.flatten()
                    LOG.debug("flatten %s successful.", volume_name)
                except Exception as e:
                    if e.errno == 22:
                        LOG.debug(
                            "Rbd image %s does not have parent, it is still "
                            "successful", volume_name)
                    else:
                        LOG.error(
                            "Process flatten volume %s faield, the exception "
                            "is %s", volume_name, e)

    def create_snapshot(self, snapshot_obj):
        """Creates an rbd snapshot."""
        rbd_name = self.rbd_name(snapshot_obj.volume_id)

        with RADOSClient(self) as client:
            with RBDVolumeProxy(rbd.Image(client.ioctx, rbd_name)) as volume:
                volume.create_snap(snapshot_obj.id)
                volume.protect_snap(snapshot_obj.id)

    def delete_snapshot(self, snapshot_obj):
        """Deletes an rbd snapshot."""
        rbd_name = self.rbd_name(snapshot_obj.volume_id)

        with RADOSClient(self) as client:
            # Unprotect snapshot before deleting a snapshot
            try:
                volume = RBDVolumeProxy(rbd.Image(client.ioctx, rbd_name))
                volume.unprotect_snap(snapshot_obj.id)
            except rbd.InvalidArgument:
                LOG.info(
                    "InvalidArgument: Unable to unprotect snapshot %s.",
                    snapshot_obj.id)
            except rbd.ImageNotFound:
                LOG.info(
                    "ImageNotFound: Unable to unprotect snapshot %s.",
                    snapshot_obj.id)
            except rbd.ImageBusy as e:
                children_list = self._get_children_info(volume,
                                                        snapshot_obj.id)
                if children_list:
                    for (pool, vol) in children_list:
                        LOG.info('Volume %(pool)s/%(volume)s is dependent '
                                 'on the snapshot %(snap)s.',
                                 {'pool': pool,
                                  'volume': vol,
                                  'snap': snapshot_obj.id})
                raise exceptions.SnapshotIsBusy(
                    snapshot_name=snapshot_obj.id) from e
            finally:
                volume.close()

            # Deleting the snapshot
            try:
                volume = RBDVolumeProxy(rbd.Image(client.ioctx, rbd_name))
                volume.remove_snap(snapshot_obj.id)
            except rbd.ImageNotFound:
                LOG.error("Snapshot %s does not exist in backend.",
                          snapshot_obj.id)
            finally:
                volume.close()

    def _parse_location(self, location):
        prefix = 'rbd://'
        if not location.startswith(prefix):
            reason = 'Not stored in rbd'
            raise exceptions.ImageUnacceptable(
                image_id=location, reason=reason)
        pieces = [urllib.parse.unquote(loc)
                  for loc in location[len(prefix):].split('/')]
        if len(pieces) != 4:
            reason = 'Not an rbd snapshot'
            raise exceptions.ImageUnacceptable(
                image_id=location, reason=reason)
        return pieces

    def _get_fsid(self):
        with RADOSClient(self) as client:
            return client.client.get_fsid()

    def _check_cloneable(self, image_location, image_format):
        try:
            fsid, pool, image, snapshot = self._parse_location(image_location)
        except exceptions.ImageUnacceptable as e:
            LOG.debug('not cloneable: %s.', e)
            raise e

        if self._get_fsid() != fsid:
            reason = '%s is in a different ceph cluster.' % image_location
            LOG.debug(reason)
            raise exceptions.ImageUnacceptable(image_id=image, reason=reason)

        if image_format != 'raw':
            reason = ("rbd image clone requires image format to be "
                      "'raw' but image %(image)s is '%(format)s'"
                      ) % dict(image=image_location, format=image_format)
            LOG.debug(reason)
            raise exceptions.ImageUnacceptable(image_id=image, reason=reason)

        # check that we can read the image
        try:
            with RADOSClient(self, pool=pool) as client:
                with rbd.Image(
                        client.ioctx, image, snapshot, read_only=True
                ) as image:
                    return True
        except rbd.Error as e:
            reason = ('Unable to open image %(loc)s: %(err)s.') % dict(
                loc=image_location, err=e)
            LOG.debug(reason)
            raise exceptions.ImageUnacceptable(image_id=image, reason=reason)

    def _resize(self, rbd_name, virtual_size):
        with RADOSClient(self) as client:
            with RBDVolumeProxy(rbd.Image(client.ioctx, rbd_name)) as image:
                image.resize(virtual_size)

    def clone_image(self,
                    rbd_name,
                    image_location,
                    volume_size,
                    image_format):
        self._check_cloneable(image_location, image_format)

        _prefix, pool, image, snapshot = \
            self._parse_location(image_location)
        self._clone(rbd_name, pool, image, snapshot)
        self._resize(rbd_name, volume_size)

    def _clone(self, rbd_name, src_pool, src_image, src_snap):
        LOG.debug('cloning %(pool)s/%(img)s@%(snap)s to %(dst)s',
                  dict(pool=src_pool, img=src_image, snap=src_snap,
                       dst=rbd_name))

        chunk_size = 8 * units.Mi
        order = int(math.log(chunk_size, 2))

        with RADOSClient(self, src_pool) as src_client:
            with RADOSClient(self) as dest_client:
                self.RBDProxy().clone(src_client.ioctx,
                                      src_image,
                                      src_snap,
                                      dest_client.ioctx,
                                      rbd_name,
                                      order=order)

    def ceph_args(self):
        """Command line parameters

        List of command line parameters to be passed to ceph commands to
        reflect RBDDriver configuration such as RBD user name and location
        of ceph.conf.
        """
        args = []
        if self.config.rbd_user:
            args.extend(['--id', self.config.rbd_user])
        if self.config.rbd_ceph_conf:
            args.extend(['--conf', self.config.rbd_ceph_conf])
        return args

    def _get_mon_addrs(self, strip_brackets=True):
        args = ['ceph', 'mon', 'dump', '--format=json'] + self.ceph_args()
        out, _ = processutils.execute(*args)
        lines = out.split('\n')
        if lines[0].startswith('dumped monmap epoch'):
            lines = lines[1:]
        monmap = jsonutils.loads('\n'.join(lines))
        addrs = [mon['addr'] for mon in monmap['mons']]
        hosts = []
        ports = []
        for addr in addrs:
            host_port = addr[:addr.rindex('/')]
            host, port = host_port.rsplit(':', 1)
            if strip_brackets:
                host = host.strip('[]')
            hosts.append(host)
            ports.append(port)
        return hosts, ports

    def get_disk_config(self, volume_obj):
        rbd_name = self.rbd_name(volume_obj.id)
        # A volume can only be mounted to one VM at a time
        target_dev = utils.generate_device_name(
            'vd', volume_obj.vm_volume_mapping[0].attached_index)

        hosts, ports = self._get_mon_addrs()
        disk_config = vconfig.LibvirtConfigGuestDisk()
        disk_config.driver_format = 'raw'
        disk_config.target_bus = 'virtio'
        disk_config.target_dev = target_dev
        disk_config.source_type = 'network'
        disk_config.source_protocol = 'rbd'
        disk_config.source_name = '%s/%s' % (
            self.config.rbd_pool, rbd_name)
        disk_config.source_hosts = hosts
        disk_config.source_ports = ports
        disk_config.auth_secret_uuid = CONF.vm_settings.rbd_secret_uuid
        disk_config.auth_username = self.config.rbd_user
        disk_config.auth_secret_type = 'ceph'

        return disk_config

    def rebuild_volume(self, volume_obj, image_obj=None, snapshot_obj=None):
        self.delete_volume(volume_obj)
        self.create_volume(volume_obj, image_obj, snapshot_obj)

    def flatten_volume(self, volume_obj):
        clone_volume = self.rbd_name(volume_obj.id)
        try:
            self._flatten(clone_volume)
        except rbd.InvalidArgument:
            LOG.debug("Volume need to be flattened")

    def extend_volume(self, volume, volume_size):
        """Increase the size of the volume"""
        src_volume = self.rbd_name(volume.id)
        if volume_size > int(volume.size):
            volume_size = volume_size * units.Gi
            self._resize(src_volume, volume_size)

    class ConnRadosConfig(object):

        def __init__(self, rbd_cluster_name, rbd_pool, rbd_user,
                     rbd_ceph_conf, rbd_keyring_conf):
            self.rbd_cluster_name = rbd_cluster_name
            self.rbd_pool = rbd_pool
            self.rbd_user = rbd_user
            self.rbd_ceph_conf = rbd_ceph_conf
            self.rbd_keyring_conf = rbd_keyring_conf
