# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import os
import urllib

from oslo_concurrency import processutils as putils
from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import units
from requests import get
from trochilus.agent.compute.libvirt import config as vconfig
from trochilus.agent.compute import utils
from trochilus.agent.storage.volume.driver import VolumeDriver
from trochilus.i18n import _


CONF = cfg.CONF
LOG = logging.getLogger(__name__)


LVM_OPTS = [
    cfg.StrOpt('volume_group',
               default='trochilus-volumes',
               help='Name for the VG that will contain exported volumes'),
    cfg.StrOpt('thin_pool_lv',
               default='data_pool',
               help='Name for the thin pool logical volume in the VG'),
    cfg.StrOpt('lv_type',
               default='thin',
               help='Type of LVM logical volume.')]


class LVMVolumeDriver(VolumeDriver):

    def __init__(self, backend):
        super().__init__(backend)

    def _init_driver(self):
        driver_info = {
            "driver": self.__class__.__name__,
            "backend": self.backend
        }
        LOG.info("Starting volume driver %(driver)s for backend %(backend)s",
                 driver_info)
        CONF.register_opts(LVM_OPTS, group=self.backend)
        LOG.info("Driver %(driver)s for backend %(backend)s initialization"
                 " completed successfully", driver_info)

    def execute(self, *args, **kwargs):
        return putils.execute(*args, **kwargs)

    def lvm_name(self, volume_id):
        volume_name_template = self.config.volume_name_template
        return volume_name_template % volume_id

    def _create_volume(self, volume_obj):
        lv_name = self.lvm_name(volume_obj.get('id'))
        lv_size = "%sG" % volume_obj.get('size')
        vg_pool_name = self.config.volume_group

        if self.config.lv_type == 'thin':
            thin_pool_path = "%s/%s" % (vg_pool_name, self.config.thin_pool_lv)
            cmd = ['lvcreate', '-n', lv_name,
                   '-V', lv_size, '-T', thin_pool_path]
        else:
            cmd = ['lvcreate', '-n', lv_name, '-L', lv_size, vg_pool_name]

        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.exception('Error creating Volume')
            LOG.error('Cmd: %s', err.cmd)
            LOG.error('StdOut: %s', err.stdout)
            LOG.error('StdErr: %s', err.stderr)
            raise

    def create_volume(self, volume_obj, image_obj=None, snapshot_obj=None):
        """Creates a logical volume."""
        if snapshot_obj:
            self.create_volume_from_snapshot(snapshot_obj, volume_obj)
        elif image_obj:
            self._create_volume(volume_obj)
            image_format = self._local_path(self.lvm_name(volume_obj.id))
            self.convert_image(image_format, "raw", image_obj)
        else:
            self._create_volume(volume_obj)

    def _delete_volume(self, lv_name):
        """Delete a logical volume."""
        lv_path = "%s/%s" % (self.config.volume_group, lv_name)
        cmd = ['lvremove', lv_path, '-y']

        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.debug('Error reported running lvremove: CMD: %(command)s, '
                      'RESPONSE: %(response)s',
                      {'command': err.cmd, 'response': err.stderr})
            if "Failed to find logical volume" in err.stderr:
                return
            raise

    def delete_volume(self, volume_obj):
        """Delete a logical volume."""
        lv_name = self.lvm_name(volume_obj.get('id'))
        self._delete_volume(lv_name)

    def convert_image(self, dest: str, out_format: str, image_obj):
        location = image_obj.location
        source = urllib.parse.urlparse(location).path

        if not os.path.exists(source):
            chunk_size = CONF.image.filesystem_store_chunk_size
            self.download_image(source, image_obj, chunk_size=chunk_size)
        self._convert_image(source, dest, out_format)

    def download_image(self, source, image_obj, chunk_size=1024 * 16) -> None:
        image_ip = image_obj.metadata_["ip"]
        #  Todo(hanxuecheng): 9906 need to read from the configuration
        #  in the future
        port = CONF.api_settings.bind_port
        url = "http://{}:{}/v1/image/{}/file".format(image_ip,
                                                     port,
                                                     image_obj.id)
        with get(url, stream=True) as req:
            with open(source, 'wb') as f:
                for chunk in req.iter_content(chunk_size=chunk_size):
                    f.write(chunk)

    def _convert_image(self, source: str, dest: str, out_format: str) -> None:
        cmd = self._get_qemu_convert_cmd(source,
                                         dest,
                                         out_format=out_format)
        self.execute(*cmd)

    def _get_qemu_convert_cmd(self, src: str, dest: str,
                              out_format: str) -> list:

        cmd = ['qemu-img', 'convert', '-O', out_format]
        cmd += [src, dest]
        return cmd

    def get_disk_config(self, volume_obj):
        lv_name = self.lvm_name(volume_obj.id)
        # A volume can only be mounted to one VM at a time
        target_dev = utils.generate_device_name(
            'vd', volume_obj.vm_volume_mapping[0].attached_index)

        disk_config = vconfig.LibvirtConfigGuestDisk()
        disk_config.driver_format = 'raw'
        disk_config.driver_name = 'qemu'
        disk_config.target_bus = 'virtio'
        disk_config.target_dev = target_dev
        disk_config.source_type = 'block'
        disk_config.source_path = '/dev/%s/%s' % (
            self.config.volume_group, lv_name)

        return disk_config

    def _create_snapshot(self, snapshot_dict):
        lv_name = snapshot_dict.get('name')
        lv_path = "%s/%s" % (self.config.volume_group,
                             snapshot_dict.get('volume_name'))
        cmd = ['lvcreate', '-s', '-n', lv_name, lv_path]
        if self.config.lv_type != 'thin':
            lv_size = "%sG" % snapshot_dict.get('size')
            cmd.extend(['-L', lv_size])

        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.exception('Error creating snapshot')
            LOG.error('Cmd: %s', err.cmd)
            LOG.error('StdOut: %s', err.stdout)
            LOG.error('StdErr: %s', err.stderr)
            raise

    def create_snapshot(self, snapshot_obj):
        """Creates a snapshot of the logical volume."""
        snapshot_dict = {'name': "snap-%s" % snapshot_obj.id,
                         'volume_name': self.lvm_name(snapshot_obj.volume_id)}
        if self.config.lv_type != 'thin':
            snapshot_dict['size'] = snapshot_obj.size
        self._create_snapshot(snapshot_dict)

    def delete_snapshot(self, snapshot_obj):
        """Delete a snapshot of the logical volume."""
        # LVM snapshots are a read / write copy of the original LV
        # In essence, it is also a logical volume
        # Invoke the delete volume of method
        lv_name = "snap-%s" % snapshot_obj.id
        self._delete_volume(lv_name)

    def _lv_has_snapshot(self, lv_name):
        cmd = ['lvdisplay', '--noheading', '-C', '-o',
               'Attr', '%s/%s' % (self.config.volume_group, lv_name)]
        attr, _err = self.execute(*cmd)
        if attr:
            attr = attr.strip()
            if (attr[0] == 'o') or (attr[0] == 'O'):
                return True
        return False

    def extend_volume(self, volume_obj, volume_size):
        """Extend the size of a logical volume."""
        if volume_size > int(volume_obj.size):
            lv_name = self.lvm_name(volume_obj.id)
            has_snapshot = None
            if self.config.lv_type != 'thin':
                has_snapshot = self._lv_has_snapshot(lv_name)
                if has_snapshot:
                    self._deactivate_lv(lv_name)
            lv_path = "%s/%s" % (self.config.volume_group, lv_name)
            cmd = ['lvextend', '-L', '%sG' % volume_size, lv_path]

            try:
                self.execute(*cmd)
            except putils.ProcessExecutionError as err:
                LOG.exception('Error extending Volume')
                LOG.error('Cmd     :%s', err.cmd)
                LOG.error('StdOut  :%s', err.stdout)
                LOG.error('StdErr  :%s', err.stderr)
                raise
            if has_snapshot:
                self._activate_lv(lv_name)

    def create_volume_from_volume(self, volume_obj, src_volume_obj):
        """Creates a clone of the specified volume."""
        # If it is a thin volume type,
        # then directly convert the snapshot to a logical volume
        if self.config.lv_type == 'thin':
            # Create a snapshot of the src volume
            snapshot_dict = {'name': self.lvm_name(volume_obj.id),
                             'volume_name': self.lvm_name(src_volume_obj.id)}
            self._create_snapshot(snapshot_dict)
            # Activate thin logical volume snapshot
            self._activate_lv(snapshot_dict.get('name'))
            return

        clone_snapshot = {'name': 'clone-snap-%s' % src_volume_obj.id,
                          'volume_name': self.lvm_name(src_volume_obj.id),
                          'size': src_volume_obj.size}
        self._create_snapshot(clone_snapshot)
        try:
            # Create a new blank logical volume
            self._create_volume(volume_obj)
            # Copy data from the source lv to the destination lv
            self._copy_lv_data(clone_snapshot.get('name'),
                               self.lvm_name(volume_obj.id))
        finally:
            self._delete_volume(clone_snapshot.get('name'))

    def create_volume_from_snapshot(self, snapshot_obj, volume_obj, *args):
        """Creates a volume from a snapshot."""
        lv_name = self.lvm_name(volume_obj.get('id'))
        snapshot_name = "snap-%s" % snapshot_obj.id
        if self.config.lv_type == 'thin':
            snapshot_dict = {'name': lv_name, 'volume_name': snapshot_name}
            # Create a logical volume snapshot of the source snapshot
            self._create_snapshot(snapshot_dict)
            # Activate thin logical volume snapshot
            self._activate_lv(lv_name)
            return
        # Create a new blank logical volume
        self._create_volume(volume_obj)
        # Copy data from the source lv to the destination lv
        self._copy_lv_data(snapshot_name, lv_name)

    def _local_path(self, lv_name):
        vg_local_path = self.config.volume_group.replace('-', '--')
        lv_local_path = lv_name.replace('-', '--')
        return "/dev/mapper/%s-%s" % (vg_local_path, lv_local_path)

    def _copy_lv_data(self, src_lv, dest_lv):
        src_lv_path = self._local_path(src_lv)
        dest_lv_path = self._local_path(dest_lv)
        # read and write up to BYTES bytes at a time
        blocksize = 1 * units.Mi
        size_in_bytes = 1 * units.Gi
        cmd = ['dd', 'if=%s' % src_lv_path, 'of=%s' % dest_lv_path,
               'bs=%s' % blocksize, 'count=%d' % size_in_bytes]

        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.exception('Error Copy Volume data')
            LOG.error('Cmd     :%s', err.cmd)
            LOG.error('StdOut  :%s', err.stdout)
            LOG.error('StdErr  :%s', err.stderr)
            raise

    def revert_snapshot(self, volume_obj, snapshot_obj):
        """Revert a volume to a snapshot"""
        if self.config.lv_type == 'thin':
            msg = _("Revert volume to snapshot not implemented for thin LVM.")
            raise NotImplementedError(msg)

        snapshot_name = "snap-%s" % snapshot_obj.id
        vg_pool_name = self.config.volume_group
        # Restoring the volume to the state
        # at the time the snapshot was created
        cmd = ['lvconvert', '--merge',
               '%s/%s' % (vg_pool_name, snapshot_name)]

        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.exception('Error Revert Volume')
            LOG.error('Cmd     :%s', err.cmd)
            LOG.error('StdOut  :%s', err.stdout)
            LOG.error('StdErr  :%s', err.stderr)
            raise
        lv_name = self.lvm_name(volume_obj.id)
        # Change the active state of lv to invalid
        self._deactivate_lv(lv_name)
        # Change the state of the lv to a valid state
        self._activate_lv(lv_name)
        # Merge the snapshot into the original volume,
        # at which point the snapshot will be destroyed
        # Recreate the snapshot that was destroyed by the revert
        self.create_snapshot(snapshot_obj)

    def _activate_lv(self, lv_name):
        """Ensure that logical volume/snapshot logical volume is activated"""
        lv_path = "%s/%s" % (self.config.volume_group, lv_name)

        cmd = ['lvchange', '-ay', '-K', lv_path]
        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.exception('Error activating LV')
            LOG.error('Cmd     :%s', err.cmd)
            LOG.error('StdOut  :%s', err.stdout)
            LOG.error('StdErr  :%s', err.stderr)
            raise

    def _deactivate_lv(self, lv_name):
        """Ensure that logical volume/snapshot logical volume is deactivated"""
        lv_path = "%s/%s" % (self.config.volume_group, lv_name)
        cmd = ['lvchange', '-an', lv_path]
        try:
            self.execute(*cmd)
        except putils.ProcessExecutionError as err:
            LOG.exception('Error deactivating LV')
            LOG.error('Cmd     :%s', err.cmd)
            LOG.error('StdOut  :%s', err.stdout)
            LOG.error('StdErr  :%s', err.stderr)
            raise

    def rebuild_volume(self, volume_obj, image_obj=None, snapshot_obj=None):
        self.delete_volume(volume_obj)
        self.create_volume(volume_obj, image_obj, snapshot_obj)

    def flatten_volume(self, volume_obj):
        pass
