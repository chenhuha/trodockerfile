# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_log import log as logging
from oslo_utils import excutils
from oslo_utils import timeutils

from trochilus.common import constants
from trochilus.db import api as db_api
from trochilus.db import snapshot_group_repo as sg


LOG = logging.getLogger(__name__)


class SnapshotGroup():

    def __init__(self, queue, snapshot_manager, vm_manager, volume_manager):
        self.snapshot_manager = snapshot_manager
        self.vm_manager = vm_manager
        self.volume_manager = volume_manager
        self.snapshot_group_repo = sg.SnapshotGroupRepository()
        self.status_queue = queue

    def _create(self, snapshot_group_obj):
        # If VM is active, we need to freeze the filesystem before taking
        # snapshots. But we don't change the state of the VM.
        # Freezing the filesystem is invisible to the user
        if snapshot_group_obj.vm.status == constants.ACTIVE:
            # TODO(liupeng) Determine whether the vm or image has
            # qemu_guest_image metadata, and then decide whether to freeze the
            # file system
            self.vm_manager.quiesce(snapshot_group_obj.virtual_machine_id)

        try:
            for snapshot in snapshot_group_obj.snapshot:
                self.snapshot_manager.create(snapshot.id)
        except Exception:
            LOG.error("Failed to create snapshot while creating snapshot "
                      "group %s.",
                      snapshot_group_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_manager.unquiesce(
                    snapshot_group_obj.virtual_machine_id)

        self.vm_manager.unquiesce(snapshot_group_obj.virtual_machine_id)

    def create(self, id):
        """Create snapshot with the given snapshot group."""
        LOG.info("Create snapshot with snapshot group %s", id)
        session = db_api.get_session()
        snapshot_group_obj = self.snapshot_group_repo.get(session, id=id)

        try:
            self._create(snapshot_group_obj)
        except Exception as e:
            LOG.error('Create snapshot group %s failed.',
                      snapshot_group_obj.id)
            with excutils.save_and_reraise_exception():
                self.snapshot_group_repo.update(
                    session, snapshot_group_obj.id, status=constants.ERROR)
                self.status_queue.put(
                    {"resource_type": "snapshot_group",
                     "resource_id": id,
                     "previous_status": constants.CREATING,
                     "current_status": constants.ERROR,
                     "error_msg": str(e),
                     "action": "create",
                     "timestamp": timeutils.utcnow()})

        snapshot_group_obj.status = constants.AVAILABLE
        snapshot_group_obj.save(session)

        LOG.info("Create snapshot group %s successful.", id)

        self.status_queue.put(
            {"resource_type": "snapshot_group",
             "resource_id": id,
             "previous_status": constants.CREATING,
             "current_status": constants.AVAILABLE,
             "action": "create",
             "timestamp": timeutils.utcnow()})

    def _delete(self, snapshot_group_obj):
        for snapshot in snapshot_group_obj.snapshot:
            self.snapshot_manager.delete(snapshot.id)

    def delete(self, id):
        """Delete snapshots with the given snapshot group."""
        LOG.info("Delete snapshots with snapshot group %s", id)
        session = db_api.get_session()
        snapshot_group_obj = self.snapshot_group_repo.get(session, id=id)

        try:
            self._delete(snapshot_group_obj)
        except Exception as e:
            LOG.error('Delete snapshot group %s failed.',
                      snapshot_group_obj.id)
            with excutils.save_and_reraise_exception():
                self.snapshot_group_repo.update(
                    session, snapshot_group_obj.id, status=constants.ERROR)
                self.status_queue.put(
                    {"resource_type": "snapshot_group",
                     "resource_id": id,
                     "previous_status": constants.DELETING,
                     "current_status": constants.ERROR,
                     "error_msg": str(e),
                     "action": "delete",
                     "timestamp": timeutils.utcnow()})

        snapshot_group_obj.status = constants.DELETED
        snapshot_group_obj.save(session)

        LOG.info("Delete snapshot group %s successful.", id)

        self.status_queue.put(
            {"resource_type": "snapshot_group",
             "resource_id": id,
             "previous_status": constants.DELETING,
             "current_status": constants.DELETED,
             "action": "delete",
             "timestamp": timeutils.utcnow()})

    def _revert(self, snapshot_group_obj, origin_vm_status,
                need_revert_volume_ids, need_detach_volume_vvm_map,
                volume_snapshot_map):
        '''Revert sg

        1. Force stop VM if vm status is active
        2. Revert volume and detach volume
        3. Start VM If vm status is active
        '''
        vm_obj = snapshot_group_obj.vm
        is_vm_active = origin_vm_status == constants.ACTIVE
        if is_vm_active:
            # Forced shutdown VM does not require data security
            self.vm_manager._power_off(vm_obj, force_stop=True)
        # Detach volumes
        for detach_volume_id, vmm_id in need_detach_volume_vvm_map.items():
            self.vm_manager.detach_volume(vm_obj.id, detach_volume_id, vmm_id)
        # Revert volumes
        for revert_volume_id in need_revert_volume_ids:
            # For sg revert,
            # the volumes that can be reversed are in the in-use state
            self.volume_manager.revert(
                revert_volume_id,
                volume_snapshot_map.get(revert_volume_id),
                constants.IN_USE)
        if is_vm_active:
            self.vm_manager._power_on(vm_obj,
                                      self.vm_manager._get_vm_volumes(vm_obj),
                                      self.vm_manager.get_vm_nics(vm_obj))

    def revert(self, id, origin_vm_status, need_revert_volume_ids,
               need_detach_volume_vvm_map, volume_snapshot_map):
        """Revert the given snapshot group."""
        LOG.info("Revert snapshot group %s", id)
        session = db_api.get_session()
        snapshot_group_obj = self.snapshot_group_repo.get(session, id=id)

        try:
            self._revert(snapshot_group_obj, origin_vm_status,
                         need_revert_volume_ids, need_detach_volume_vvm_map,
                         volume_snapshot_map)
        except Exception:
            LOG.error('Revert snapshot group %s failed.',
                      snapshot_group_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_manager.update_vm_status(
                    session, snapshot_group_obj.vm.id, 'revert',
                    constants.ERROR,
                    expected_status=constants.REVERTING)

        self.vm_manager.update_vm_status(
            session, snapshot_group_obj.vm.id, 'revert',
            origin_vm_status,
            expected_status=constants.REVERTING)
        LOG.info("Revert snapshot group %s successful.", id)
