# Copyright (c) 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import functools
import time

from oslo_config import cfg
from oslo_log import log as logging
import requests
import simplejson

from trochilus.agent.common import exceptions as agent_exc
from trochilus.common import constants as consts
from trochilus.common import exceptions
from trochilus.common import utils

CONF = cfg.CONF
LOG = logging.getLogger(__name__)
API_VERSION = 'v1.0'
AGENT_API_CLIENT = (
    "Trochilus agent Rest Client/{version} ").format(version=API_VERSION)


class AgentRestClient(object):
    def __init__(self):
        super().__init__()
        self.get = functools.partial(self.request, 'get')
        self.post = functools.partial(self.request, 'post')
        self.put = functools.partial(self.request, 'put')
        self.delete = functools.partial(self.request, 'delete')
        self.session = requests.Session()

    def _base_url(self, ip, api_version=None):
        if utils.is_ipv6(ip):
            ip = '[{ip}]'.format(ip=ip)
        if api_version:
            return "http://{ip}:{port}/{version}/".format(
                ip=ip,
                port=CONF.agent_settings.bind_port,
                version=api_version)
        return "http://{ip}:{port}/".format(
            ip=ip,
            port=CONF.agent_settings.bind_port)

    def request(self, method, agent, path='/', timeout_dict=None,
                retry_404=True, **kwargs):
        cfg_agent_client = CONF.agent_rest_client
        if timeout_dict is None:
            timeout_dict = {}
        req_conn_timeout = timeout_dict.get(
            consts.REQ_CONN_TIMEOUT,
            cfg_agent_client.rest_request_conn_timeout)
        req_read_timeout = timeout_dict.get(
            consts.REQ_READ_TIMEOUT,
            cfg_agent_client.rest_request_read_timeout)
        conn_max_retries = timeout_dict.get(
            consts.CONN_MAX_RETRIES, cfg_agent_client.connection_max_retries)
        conn_retry_interval = timeout_dict.get(
            consts.CONN_RETRY_INTERVAL,
            cfg_agent_client.connection_retry_interval)

        LOG.debug("request url %s", path)
        _request = getattr(self.session, method.lower())
        _url = self._base_url(agent.mgmt_ip, agent.api_version) + path
        LOG.debug("request url %s", _url)
        reqargs = {
            'url': _url,
            'timeout': (req_conn_timeout, req_read_timeout), }
        reqargs.update({'json': kwargs})
        headers = reqargs.setdefault('headers', {})

        headers['User-Agent'] = AGENT_API_CLIENT
        exception = None
        # Keep retrying
        for dummy in range(conn_max_retries):
            try:
                r = _request(**reqargs)
                LOG.debug('Connected to agent. Response: %(resp)s',
                          {'resp': r})

                content_type = r.headers.get('content-type', '')
                # Check the 404 to see if it is just that the network in the
                # trochilus is not yet up, in which case retry.
                # Otherwise return the response quickly.
                if r.status_code == 404:
                    if not retry_404:
                        return r
                    LOG.debug('Got a 404 (content-type: %(content_type)s) -- '
                              'connection data: %(content)s',
                              {'content_type': content_type,
                               'content': r.content})
                    if content_type.find("application/json") == -1:
                        LOG.debug("Amphora agent not ready.")
                        raise requests.ConnectionError
                    try:
                        json_data = r.json().get('details', '')
                        if 'No suitable network interface found' in json_data:
                            LOG.debug("Amphora network interface not found.")
                            raise requests.ConnectionError
                    except simplejson.JSONDecodeError:  # if r.json() fails
                        pass  # TODO(rm_work) Should we do something?
                return r
            except (requests.ConnectionError, requests.Timeout) as e:
                exception = e
                LOG.warning("Could not connect to agent. Retrying.")
                time.sleep(conn_retry_interval)
        LOG.error("Connection retries (currently set to %(max_retries)s) "
                  "exhausted.  The trochilus is unavailable. Reason: "
                  "%(exception)s",
                  {'max_retries': conn_max_retries,
                   'exception': exception})
        raise exceptions.AgentRESTClientRetryError(retyr_num=conn_max_retries,
                                                   agent_id=agent.id,
                                                   exception=str(exception))

    def get_api_version(self, agent, timeout_dict=None):
        agent.api_version = None
        r = self.get(agent, retry_404=False, timeout_dict=timeout_dict)
        # Handle 404 special as we don't want to log an ERROR on 404
        agent_exc.check_exception(r, (404,))
        if r.status_code == 404:
            raise agent_exc.NotFound()
        return r.json()

    def shutdown_agent(self, agent):
        r = self.put(agent, 'node/shutdown', retry_404=False)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json()

    def create_volume(self, agent, **kwargs):
        r = self.post(agent, path='volume/create', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def delete_volume(self, agent, **kwargs):
        r = self.delete(agent, path='volume/delete', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def crete_volume_from_volume(self, agent, **kwargs):
        r = self.post(agent, path='volume/clone', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def revert_volume_to_snapshot(self, agent, **kwargs):
        r = self.post(agent, path='volume/revert', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def resize_volume(self, agent, **kwargs):
        r = self.post(agent, path='volume/resize', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def create_volume_from_snapshot(self, agent, **kwargs):
        r = self.post(agent, path='snapshot/clone', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def create_snapshot(self, agent, **kwargs):
        r = self.post(agent, path='snapshot/create', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def delete_snapshot(self, agent, **kwargs):
        r = self.delete(agent, path='snapshot/delete', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def create_vpc(self, agents, **kwargs):
        return self.notify_multiple_agents(agents, self.post,
                                           path='vpc/create', **kwargs)

    def delete_vpc(self, agents, **kwargs):
        return self.notify_multiple_agents(agents, self.delete,
                                           path='vpc/delete', **kwargs)

    @staticmethod
    def notify_multiple_agents(agents, process, path, **kwargs):
        results = []
        for agent in agents:
            if agent.status == consts.AGENT_UP:
                try:
                    # Send a request to the agent.  The parameter named
                    # 'process' is a function pointer whose value is get,
                    # post,update,delete
                    r = process(agent, path, **kwargs)
                    agent_exc.check_exception(r, agent_id=agent.id)
                    results.append(r)
                except Exception as err:
                    LOG.error("Failed to send request whose path is %s"
                              "to agent with hostname %s, the reason is %s",
                              path, agent.hostname, err)
            else:
                LOG.info("The status of agent with id %s is down, so not to "
                         "notify this agent with path %s", agent.id, path)
        return results

    def create_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/create', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def delete_virtual_machine(self, agent, **kwargs):
        r = self.delete(agent, path='vm/delete', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def start_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/start', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def stop_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/stop', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def reboot_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/reboot', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def migrate_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/migrate', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def resize_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/resize', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def rebuild_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/rebuild', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def attach_nic(self, agent, **kwargs):
        r = self.post(agent, path='vm/attach_nic', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def detach_nic(self, agent, **kwargs):
        r = self.post(agent, path='vm/detach_nic', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def create_snapshot_group(self, agent, **kwargs):
        r = self.post(agent, path='snapshot_group/create', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def delete_snapshot_group(self, agent, **kwargs):
        r = self.delete(agent, path='snapshot_group/delete', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def flatten_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/flatten', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def revert_virtual_machine(self, agent, **kwargs):
        r = self.post(agent, path='vm/revert', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def revert_snapshot_group(self, agent, **kwargs):
        r = self.post(agent, path='snapshot_group/revert', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def attach_volume(self, agent, **kwargs):
        r = self.post(agent, path='vm/attach_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def detach_volume(self, agent, **kwargs):
        r = self.post(agent, path='vm/detach_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def create_dhcp(self, agent, **kwargs):
        r = self.post(agent, path='dhcp/create', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def update_dhcp(self, agent, **kwargs):
        r = self.put(agent, path='dhcp/update', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def delete_dhcp(self, agent, **kwargs):
        r = self.delete(agent, path='dhcp/delete', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def cascade_delete_volume(self, agent, **kwargs):
        r = self.delete(agent, path='cascade/delete_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def cascade_delete_vm(self, agent, **kwargs):
        r = self.delete(agent, path='cascade/delete_vm', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def rebuild_vm(self, agent, **kwargs):
        r = self.post(agent, path='cascade/rebuild_vm', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def create_voi_vm(self, agent, **kwargs):
        r = self.post(agent, path='voi/create', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def delete_voi_vm(self, agent, **kwargs):
        r = self.delete(agent, path='voi/delete', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def stop_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/stop', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def start_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/start', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def reboot_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/reboot', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def migrate_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/migrate', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def reset_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/reset', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def replace_iso_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/replace_iso', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def commit_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/commit', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def add_volume_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/add_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def remove_volume_voi_vm(self, agent, **kwargs):
        r = self.put(agent, path='voi/remove_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def commit_share_disk(self, agent, **kwargs):
        r = self.put(agent, path='share_disk/commit', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def attach_share_template_volume(self, agent, **kwargs):
        r = self.put(agent, path='voi/attach_share_template_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def detach_share_template_volume(self, agent, **kwargs):
        r = self.put(agent, path='voi/detach_share_template_volume', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json

    def commit_backup_disk(self, agent, **kwargs):
        r = self.post(agent, path='backup_disk/commit', **kwargs)
        agent_exc.check_exception(r, agent_id=agent.id)
        return r.json
