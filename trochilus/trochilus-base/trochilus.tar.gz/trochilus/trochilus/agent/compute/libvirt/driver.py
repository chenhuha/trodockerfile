# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import functools
import inspect
import os
import queue
import socket
import threading
import time
import typing as ty

import eventlet
from eventlet import greenio
from eventlet import greenthread
from eventlet import patcher
from eventlet import tpool
from oslo_config import cfg
from oslo_log import log as logging
from oslo_service import loopingcall
from oslo_utils import excutils
from oslo_utils import importutils
from oslo_utils import units
from trochilus.agent.common import exceptions
from trochilus.agent.compute.driver import VMDriver
from trochilus.agent.compute import event as virtevent
from trochilus.agent.compute.libvirt import config as vconfig
from trochilus.agent.compute.libvirt import event as libvirtevent
from trochilus.agent.compute.libvirt import guest as libvirt_guest
from trochilus.agent.compute.libvirt import power_state
from trochilus.common import constants

if ty.TYPE_CHECKING:
    import libvirt
else:
    libvirt = None

CONF = cfg.CONF
CONNECTION_URI = "qemu:///system"
native_socket = patcher.original('socket')
native_threading = patcher.original("threading")
native_Queue = patcher.original("queue")
LOG = logging.getLogger(__name__)
# Max usb3.0 ports is 15
REDIRDEV_DEVICE_AND_USB3_PORTS_COUNT = 8
# UEFI support
DEFAULT_UEFI_LOADER_PATH = {
    "x86_64": ['/usr/share/OVMF/OVMF_CODE.fd',
               '/usr/share/OVMF/OVMF_CODE.secboot.fd',
               '/usr/share/qemu/ovmf-x86_64-code.bin'],
    "x86_64_csm": ['/usr/share/edk2.git/ovmf-x64/OVMF_CODE-with-csm.fd'],
    "x86_64_pure": ['/usr/share/edk2.git/ovmf-x64/OVMF_CODE-pure-efi.fd']
}


class LibvirtDriver(VMDriver):
    # TODO(yangjianfeng) Remove volume_manager, we should process
    # volume entry in vm_manager
    def __init__(self, volume_manager=None):
        super().__init__()

        global libvirt
        if libvirt is None:
            libvirt = importutils.import_module('libvirt')

        self._uri = CONNECTION_URI
        self._read_only = False
        self._initial_connection = True
        self._wrapped_conn = None
        self._wrapped_conn_lock = threading.Lock()

        # TODO(liupeng) Implement a handler to
        # update the agent's hypervisor state
        # If hypervisor connect faild set the agent down
        self._conn_event_handler = None
        self._conn_event_handler_queue = queue.Queue()

        self._events_delayed = {}
        # Note(toabctl): During a reboot of a domain, STOPPED and
        #                STARTED events are sent. To prevent shutting
        #                down the domain during a reboot, delay the
        #                STOPPED lifecycle event some seconds.
        self._lifecycle_delay = 15

        self._lifecycle_event_handler = self.emit_event
        self._event_queue = None
        self._libvirt_proxy_classes = self._get_libvirt_proxy_classes(libvirt)
        self._libvirt_proxy = self._wrap_libvirt_proxy(libvirt)

        self._initialized = False

        # Handles ongoing device manipultion in libvirt where we wait for the
        # events about success or failure.
        self._device_event_handler = AsyncDeviceEventsHandler()

        self.volume_manager = volume_manager

    def _create_vm(self, vm_obj, volume_objs, nic_cfgs):
        xml = self._get_guest_config(vm_obj, volume_objs, nic_cfgs).to_xml()
        self._create_guest(xml)
        LOG.debug("[VM %s] Guest created on hypervisor", vm_obj.id)

        def _wait_for_boot():
            """Called at an interval until the VM is running."""
            state = self.get_info(vm_obj).state

            if state == power_state.RUNNING:
                LOG.info("[VM %s] VM create successfully.", vm_obj.id)
                raise loopingcall.LoopingCallDone()

        timer = loopingcall.FixedIntervalLoopingCall(_wait_for_boot)
        timer.start(interval=0.5).wait()

    def create_vm(self, vm_obj, volume_objs, nic_cfgs):
        self._create_vm(vm_obj, volume_objs, nic_cfgs)

    def _hard_reboot(self, vm_obj, volume_objs, nic_cfgs):

        self.destroy_vm(vm_obj)

        xml = self._get_guest_config(vm_obj, volume_objs, nic_cfgs).to_xml()
        self._create_guest(xml)

        def _wait_for_reboot():
            """Called at an interval until the VM is running again."""
            state = self.get_info(vm_obj).state

            if state == power_state.RUNNING:
                LOG.info("[VM %s] VM rebooted successfully.", vm_obj.id)
                raise loopingcall.LoopingCallDone()

        timer = loopingcall.FixedIntervalLoopingCall(_wait_for_reboot)
        timer.start(interval=0.5).wait()

    def _wait_for_running(self, vm_obj):
        state = self.get_info(vm_obj).state

        if state == power_state.RUNNING:
            LOG.info("[VM %s] VM running successfully.", vm_obj.id)
            raise loopingcall.LoopingCallDone()

    def _soft_reboot(self, vm_obj):
        guest = self.get_guest(vm_obj)
        state = guest.get_power_state(self)

        old_domid = guest.id
        if state == power_state.RUNNING:
            guest.shutdown()

        # TODO(liupeng) if windows update?
        # If there is a windows update,
        # then the soft restart time will be extended indefinitely
        # At this time, if you force a shutdown, Windows may be damaged.

        for x in range(CONF.vm_settings.wait_soft_reboot_seconds):
            guest = self.get_guest(vm_obj)

            state = guest.get_power_state(self)
            new_domid = guest.id

            # NOTE(ivoks): By checking domain IDs, we make sure we are
            #              not recreating domain that's already running.
            if old_domid != new_domid:
                # pylint: disable=R1705
                if state in (power_state.SHUTDOWN, power_state.CRASHED):
                    LOG.info("[VM %s] VM shutdown successfully.", vm_obj.id)
                    guest.launch()
                    timer = loopingcall.FixedIntervalLoopingCall(
                        self._wait_for_running, vm_obj)
                    timer.start(interval=0.5).wait()
                    return True
                else:
                    LOG.info("[VM %s] VM may have been rebooted during"
                             " soft reboot, so return now.", vm_obj.id)
                    return True
            greenthread.sleep(1)
        return False

    def power_on(self, vm_obj, volume_objs, nic_cfgs):
        self._hard_reboot(vm_obj, volume_objs, nic_cfgs)

    def get_console_port(self, vm_obj):
        config = self.get_guest(vm_obj).get_config()
        port_dic = {}
        for guest_driver in config.devices:
            if isinstance(guest_driver, vconfig.LibvirtConfigGuestGraphics):
                if guest_driver.type == 'vnc':
                    port_dic['vnc'] = guest_driver.port
                elif guest_driver.type == 'spice':
                    port_dic['spice'] = guest_driver.port
        return port_dic

    def reboot(self, vm_obj, volume_objs, nic_cfgs, reboot_type):
        if reboot_type == 'SOFT':
            try:
                soft_reboot_success = self._soft_reboot(vm_obj)
            except libvirt.libvirtError as e:
                LOG.debug("[VM %s] VM soft reboot failed: %s",
                          vm_obj.id, e)
                soft_reboot_success = False
            # pylint: disable=R1705
            if soft_reboot_success:
                LOG.info("[VM %s] VM soft rebooted successfully.",
                         vm_obj.id)
                return
            else:
                LOG.warning("[VM %s] Failed to soft reboot VM. "
                            "Trying hard reboot.", vm_obj.id)
        self._hard_reboot(vm_obj, volume_objs, nic_cfgs)

    def _clean_shutdown(self, vm_obj, timeout, retry_interval):
        """Attempt to shutdown the VMs gracefully."""
        # List of states that represent a shutdown VM
        SHUTDOWN_STATES = [power_state.SHUTDOWN,
                           power_state.CRASHED]

        try:
            guest = self.get_guest(vm_obj)
        except exceptions.VMNotFound:
            # If the VM has gone then we don't need to
            # wait for it to shutdown
            return True

        state = guest.get_power_state(self)
        if state in SHUTDOWN_STATES:
            LOG.info("[VM %s]VM already shutdown.", vm_obj.id)
            return True

        guest.shutdown()
        retry_countdown = retry_interval

        for sec in range(timeout):

            guest = self.get_guest(vm_obj)
            state = guest.get_power_state(self)

            if state in SHUTDOWN_STATES:
                LOG.info("[VM %s] VM shutdown successfully "
                         "after %d seconds.", vm_obj.id, sec)
                return True

            if retry_countdown == 0:
                retry_countdown = retry_interval
                # VM could shutdown at any time, in which case we
                # will get an exception when we call shutdown
                try:
                    LOG.debug("[VM %s] VM in state %s after %d seconds - "
                              "resending shutdown", vm_obj.id, state, sec)
                    guest.shutdown()
                except libvirt.libvirtError:
                    # Assume this is because its now shutdown, so loop
                    # one more time to clean up.
                    LOG.debug("[VM %s] Ignoring libvirt exception from "
                              "shutdown request.", vm_obj.id)
                    continue
            else:
                retry_countdown -= 1

            time.sleep(1)

        LOG.info("[VM %s] VM failed to shutdown in %d seconds.",
                 vm_obj.id, timeout)
        return False

    def power_off(self, vm_obj, timeout=0, retry_interval=0):
        # TODO(liupeng) if windows update?
        # If there is a windows update,
        # then the soft restart time will be extended indefinitely
        # At this time, if you force a shutdown, Windows may be damaged.
        if timeout:
            self._clean_shutdown(vm_obj, timeout, retry_interval)
        self._destroy_vm(vm_obj)

    def destroy_vm(self, vm_obj):
        self._destroy_vm(vm_obj)
        self._undefine_domain(vm_obj)

    def _undefine_domain(self, vm_obj):
        try:
            guest = self.get_guest(vm_obj)
            try:
                # support_uefi=True
                # support all bios and uefi undefine xml
                guest.delete_configuration(support_uefi=True)
            except libvirt.libvirtError as e:
                with excutils.save_and_reraise_exception() as ctxt:
                    errcode = e.get_error_code()
                    if errcode == libvirt.VIR_ERR_NO_DOMAIN:
                        LOG.debug("[VM %s] Called undefine, "
                                  "but domain already gone.",
                                  vm_obj.id)
                        ctxt.reraise = False
                    else:
                        LOG.error('[VM %(id)s] Error from libvirt during '
                                  'undefine. Code=%(errcode)s Error=%(e)s',
                                  {'errcode': errcode,
                                   'e': e, 'id': vm_obj.id})
        except exceptions.VMNotFound:
            pass

    def _destroy_vm(self, vm_obj):
        try:
            guest = self.get_guest(vm_obj)
        except exceptions.VMNotFound:
            guest = None

        if guest is not None:
            try:
                old_domid = guest.id
                guest.poweroff()
            except libvirt.libvirtError as e:
                is_okay = False
                errcode = e.get_error_code()
                if errcode == libvirt.VIR_ERR_NO_DOMAIN:
                    # Domain already gone. This can safely be ignored.
                    is_okay = True
                elif errcode == libvirt.VIR_ERR_OPERATION_INVALID:
                    # If the VM is already shut off, we get this:
                    # Code=55 Error=Requested operation is not valid:
                    # domain is not running

                    state = guest.get_power_state(self)
                    if state == power_state.SHUTDOWN:
                        is_okay = True
                elif errcode == libvirt.VIR_ERR_OPERATION_TIMEOUT:
                    LOG.warning("[VM %s]Cannot destroy VM, operation time out",
                                vm_obj.id)
                    reason = "operation time out"
                    raise exceptions.VMPowerOffFailure(reason=reason)
                elif errcode == libvirt.VIR_ERR_SYSTEM_ERROR:
                    with excutils.save_and_reraise_exception():
                        LOG.warning("[VM %s] Cannot destroy VM, general system"
                                    " call failure", vm_obj.id)
                if not is_okay:
                    with excutils.save_and_reraise_exception():
                        LOG.error('[VM %(id)s] Error from libvirt during '
                                  'destroy. Code=%(errcode)s Error=%(e)s',
                                  {'errcode': errcode, 'e': e, 'id': vm_obj.id}
                                  )

        old_domid = -1

        def _wait_for_destroy(expected_domid):
            """Called at an interval until the VM is gone."""
            try:
                dom_info = self.get_info(vm_obj)
                state = dom_info.state
                new_domid = dom_info.internal_id
            except exceptions.VMNotFound:
                LOG.debug("[VM %s] During wait destroy, VM disappeared.",
                          vm_obj.id)
                state = power_state.SHUTDOWN

            if state == power_state.SHUTDOWN:
                LOG.info("[VM %s] VM destroyed successfully.", vm_obj.id)
                raise loopingcall.LoopingCallDone()
            if new_domid != expected_domid:
                LOG.info("[VM %s] VM may be started again.", vm_obj.id)
                kwargs['is_running'] = True
                raise loopingcall.LoopingCallDone()

        kwargs = {'is_running': False}
        timer = loopingcall.FixedIntervalLoopingCall(_wait_for_destroy,
                                                     old_domid)
        timer.start(interval=0.5).wait()
        if kwargs['is_running']:
            LOG.info("Going to destroy VM again.", vm_obj.id)
            self._destroy_vm(vm_obj)

    def attach_nic(self, vm_obj, nic_cfg):
        guest = self.get_guest(vm_obj)
        try:
            state = guest.get_power_state(None)
            live = state in (power_state.RUNNING, power_state.PAUSED)
            guest.attach_device(nic_cfg, persistent=True, live=live)
        except libvirt.libvirtError as e:
            LOG.error('Attaching nic %(nic_config)s failed.',
                      {'nic_config': repr(nic_cfg)}, vm=vm_obj)
            raise exceptions.NicAttachFailed(vm_id=vm_obj.id) from e

    def detach_nic(self, vm_obj, nic_cfg):
        guest = self.get_guest(vm_obj)
        try:
            get_dev = functools.partial(guest.get_interface_by_cfg, nic_cfg)
            self._detach_with_retry(
                guest,
                vm_obj.id,
                get_dev,
                device_name=nic_cfg.target_dev,
            )
        except exceptions.DeviceNotFound:
            # The nic is gone so just log it as a warning.
            LOG.warning('Detaching nic %(nic_config)s failed because '
                        'the device is no longer found on the guest.',
                        {'nic_config': repr(nic_cfg)}, vm=vm_obj)

    def attach_volume(self, vm_obj, volume_cfg):
        guest = self.get_guest(vm_obj)
        try:
            state = guest.get_power_state(None)
            live = state in (power_state.RUNNING, power_state.PAUSED)
            guest.attach_device(volume_cfg, persistent=True, live=live)
        except libvirt.libvirtError as e:
            LOG.error('Attaching volume %(volume_config)s failed.',
                      {'volume_config': repr(volume_cfg)}, vm=vm_obj)
            # Return the original exception
            raise e

    def detach_volume(self, vm_obj, volume_cfg):
        guest = self.get_guest(vm_obj)
        try:
            get_dev = functools.partial(guest.get_disk, volume_cfg.target_dev)
            self._detach_with_retry(
                guest,
                vm_obj.id,
                get_dev,
                device_name=volume_cfg.target_dev,
            )
        except exceptions.DeviceNotFound:
            # The volume is gone so just log it as a warning.
            LOG.warning('Detaching volume %(volume_config)s failed because '
                        'the device is no longer found on the guest.',
                        {'volume_config': repr(volume_cfg)}, vm=vm_obj)

    def reload_volume_size(self, vm_obj, volume_id, volume_size):
        guest = self.get_guest(vm_obj)
        state = guest.get_power_state(None)
        if state != power_state.RUNNING:
            LOG.info("[VM %s] VM not required reload volume size.", vm_obj.id)
            return
        disk = None
        for d in guest.get_all_disks():
            source_name = d.source_name if d.source_name else d.source_path
            x = source_name.split("volume-")[1]
            if volume_id == x:
                disk = d
        if not disk:
            raise exceptions.VolumeNotFound(volume_id=volume_id)
        disk_path = disk.target_dev
        dev = guest.get_block_device(disk_path)
        dev.resize(volume_size * units.Gi)

    @staticmethod
    def _get_libvirt_proxy_classes(libvirt_module):
        """get_libvirt_proxy_classes

        Return a tuple for tpool.Proxy's autowrap argument containing all
        public vir* classes defined by the libvirt module.
        """

        # Get a list of (name, class) tuples of libvirt classes
        classes = inspect.getmembers(libvirt_module, inspect.isclass)

        # Return a list of just the vir* classes, filtering out libvirtError
        # and any private globals pointing at private internal classes.
        return tuple(
            cls[1] for cls in classes if cls[0].startswith("vir"))

    def _wrap_libvirt_proxy(self, obj):
        """Return an object wrapped in a tpool.

        Proxy using autowrap appropriate for the libvirt module.
        """

        # libvirt is not pure python, so eventlet monkey patching doesn't work
        # on it. Consequently long-running libvirt calls will not yield to
        # eventlet's event loop, starving all other greenthreads until
        # completion. eventlet's tpool.Proxy handles this situation for us by
        # executing proxied calls in a native thread.
        return tpool.Proxy(obj, autowrap=self._libvirt_proxy_classes)

    def _native_thread(self):
        """Receives async events coming in from libvirtd.

        This is a native thread which runs the default
        libvirt event loop implementation. This processes
        any incoming async events from libvirtd and queues
        them for later dispatch. This thread is only
        permitted to use libvirt python APIs, and the
        driver.queue_event method. In particular any use
        of logging is forbidden, since it will confuse
        eventlet's greenthread integration
        """

        while True:
            libvirt.virEventRunDefaultImpl()

    def _dispatch_thread(self):
        """Dispatches async events coming in from libvirtd.

        This is a green thread which waits for events to
        arrive from the libvirt event loop thread. This
        then dispatches the events to the compute manager.
        """

        while True:
            self._dispatch_events()

    def _conn_event_thread(self):
        """Dispatches async connection events"""
        # NOTE(mdbooth): This thread doesn't need to jump through the same
        # hoops as _dispatch_thread because it doesn't interact directly
        # with the libvirt native thread.
        while True:
            self._dispatch_conn_event()

    def _dispatch_conn_event(self):
        # NOTE(mdbooth): Splitting out this loop looks redundant, but it
        # means we can easily dispatch events synchronously from tests and
        # it isn't completely awful.
        handler = self._conn_event_handler_queue.get()
        try:
            handler()
        except Exception:
            LOG.exception('Exception handling connection event')
        finally:
            self._conn_event_handler_queue.task_done()

    @staticmethod
    def _event_device_removed_callback(conn, dom, dev, opaque):
        """Receives device removed events from libvirt.

        NB: this method is executing in a native thread, not
        an eventlet coroutine. It can only invoke other libvirt
        APIs, or use self._queue_event(). Any use of logging APIs
        in particular is forbidden.
        """
        self = opaque
        uuid = dom.UUIDString()
        self._queue_event(libvirtevent.DeviceRemovedEvent(uuid, dev))

    @staticmethod
    def _event_device_removal_failed_callback(conn, dom, dev, opaque):
        """Receives device removed events from libvirt.

        NB: this method is executing in a native thread, not
        an eventlet coroutine. It can only invoke other libvirt
        APIs, or use self._queue_event(). Any use of logging APIs
        in particular is forbidden.
        """
        self = opaque
        uuid = dom.UUIDString()
        self._queue_event(libvirtevent.DeviceRemovalFailedEvent(uuid, dev))

    @staticmethod
    def _event_lifecycle_callback(conn, dom, event, detail, opaque):
        """Receives lifecycle events from libvirt.

        NB: this method is executing in a native thread, not
        an eventlet coroutine. It can only invoke other libvirt
        APIs, or use self._queue_event(). Any use of logging APIs
        in particular is forbidden.
        """

        self = opaque

        uuid = dom.UUIDString()
        transition = None
        if event == libvirt.VIR_DOMAIN_EVENT_STOPPED:
            transition = virtevent.EVENT_LIFECYCLE_STOPPED
        elif event == libvirt.VIR_DOMAIN_EVENT_STARTED:
            transition = virtevent.EVENT_LIFECYCLE_STARTED
        # TODO(liupeng) Get SUSPENDED event information,
        # and then get MIGRATE or POSTCOPY events
        elif event == libvirt.VIR_DOMAIN_EVENT_RESUMED:
            transition = virtevent.EVENT_LIFECYCLE_RESUMED

        if transition is not None:
            self._queue_event(virtevent.LifecycleEvent(uuid, transition))

    def _close_callback(self, conn, reason, opaque):
        close_info = {'conn': conn, 'reason': reason}
        self._queue_event(close_info)

    @staticmethod
    def _test_connection(conn):
        try:
            conn.getLibVersion()
            return True
        except libvirt.libvirtError as e:
            if (e.get_error_code() in (libvirt.VIR_ERR_SYSTEM_ERROR,
                                       libvirt.VIR_ERR_INTERNAL_ERROR) and
                e.get_error_domain() in (libvirt.VIR_FROM_REMOTE,
                                         libvirt.VIR_FROM_RPC)):
                LOG.debug('Connection to libvirt broke')
                return False
            raise

    @staticmethod
    def _connect_auth_cb(creds, opaque):
        if len(creds) == 0:
            return 0
        msg = "Can not handle authentication request for %d credentials" % len(
            creds)
        raise exceptions.InternalServerError(msg=msg)

    def _connect(self, uri, read_only):
        auth = [[libvirt.VIR_CRED_AUTHNAME,
                 libvirt.VIR_CRED_ECHOPROMPT,
                 libvirt.VIR_CRED_REALM,
                 libvirt.VIR_CRED_PASSPHRASE,
                 libvirt.VIR_CRED_NOECHOPROMPT,
                 libvirt.VIR_CRED_EXTERNAL],
                self._connect_auth_cb,
                None]

        flags = 0
        if read_only:
            flags = libvirt.VIR_CONNECT_RO
        return self._libvirt_proxy.openAuth(uri, auth, flags)

    def _queue_event(self, event):
        """Puts an event on the queue for dispatch.

        This method is called by the native event thread to
        put events on the queue for later dispatch by the
        green thread. Any use of logging APIs is forbidden.
        """

        if self._event_queue is None:
            return

        # Queue the event...
        self._event_queue.put(event)

        # ...then wakeup the green thread to dispatch it
        c = ' '.encode()
        self._event_notify_send.write(c)
        self._event_notify_send.flush()

    def _dispatch_events(self):
        """Wait for & dispatch events from native thread

        Blocks until native thread indicates some events
        are ready. Then dispatches all queued events.
        """

        # Wait to be notified that there are some
        # events pending
        try:
            _c = self._event_notify_recv.read(1)
            assert _c
        except ValueError:
            return  # will be raised when pipe is closed

        # Process as many events as possible without
        # blocking
        last_close_event = None
        # required for mypy
        if self._event_queue is None:
            return
        while not self._event_queue.empty():
            try:
                event_type = ty.Union[
                    virtevent.VMEvent, ty.Mapping[str, ty.Any]]
                event: event_type = self._event_queue.get(block=False)
                if issubclass(type(event), virtevent.VMEvent):
                    # call possibly with delay
                    self._event_emit_delayed(event)

                elif 'conn' in event and 'reason' in event:
                    last_close_event = event
            except native_Queue.Empty:
                pass
        if last_close_event is None:
            return
        conn = last_close_event['conn']
        # get_new_connection may already have disabled the host,
        # in which case _wrapped_conn is None.
        with self._wrapped_conn_lock:
            if conn == self._wrapped_conn:
                reason = str(last_close_event['reason'])
                msg = "Connection to libvirt lost: %s" % reason
                self._wrapped_conn = None
                self._queue_conn_event_handler(False, msg)

    def _event_emit_delayed(self, event):
        """Emit events - possibly delayed."""
        def event_cleanup(gt, *args, **kwargs):
            """Callback function for greenthread.

            Called to cleanup the _events_delayed dictionary when an event
            was called.
            """
            event = args[0]
            self._events_delayed.pop(event.uuid, None)

        # Cleanup possible delayed stop events.
        if event.uuid in self._events_delayed.keys():  # pylint: disable=C0201
            self._events_delayed[event.uuid].cancel()
            self._events_delayed.pop(event.uuid, None)
            LOG.debug("Removed pending event for %s due to event", event.uuid)

        if (isinstance(event, virtevent.LifecycleEvent) and
                event.transition == virtevent.EVENT_LIFECYCLE_STOPPED):
            # Delay STOPPED event, as they may be followed by a STARTED
            # event in case the VM is rebooting
            id_ = greenthread.spawn_after(self._lifecycle_delay,
                                          self._event_emit, event)
            self._events_delayed[event.uuid] = id_
            # add callback to cleanup self._events_delayed dict after
            # event was called
            id_.link(event_cleanup, event)
        else:
            self._event_emit(event)

    def _event_emit(self, event):
        if self._lifecycle_event_handler is not None:
            self._lifecycle_event_handler(event)

    def _init_events_pipe(self):
        """Create a self-pipe for the native thread to synchronize on.

        This code is taken from the eventlet tpool module, under terms
        of the Apache License v2.0.
        """

        self._event_queue = native_Queue.Queue()
        try:
            rpipe, wpipe = os.pipe()
            self._event_notify_send = greenio.GreenPipe(wpipe, 'wb', 0)
            self._event_notify_recv = greenio.GreenPipe(rpipe, 'rb', 0)
        except (ImportError, NotImplementedError):
            # This is Windows compatibility -- use a socket instead
            #  of a pipe because pipes don't really exist on Windows.
            sock = native_socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.bind(('localhost', 0))
            sock.listen(50)
            csock = native_socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            csock.connect(('localhost', sock.getsockname()[1]))
            nsock, addr = sock.accept()
            self._event_notify_send = nsock.makefile('wb', 0)
            gsock = greenio.GreenSocket(csock)
            self._event_notify_recv = gsock.makefile('rb', 0)

    def _init_events(self):
        """Initializes the libvirt events subsystem.

        This requires running a native thread to provide the
        libvirt event loop integration. This forwards events
        to a green thread which does the actual dispatching.
        """

        self._init_events_pipe()

        LOG.debug("Starting native event thread")
        self._event_thread = native_threading.Thread(
            target=self._native_thread)
        self._event_thread.setDaemon(True)
        self._event_thread.start()

        LOG.debug("Starting green dispatch thread")
        eventlet.spawn(self._dispatch_thread)

    def _get_new_connection(self):
        # call with _wrapped_conn_lock held
        LOG.debug('Connecting to libvirt: %s', self._uri)

        # This will raise an exception on failure
        wrapped_conn = self._connect(self._uri, self._read_only)

        try:
            LOG.debug("Registering for lifecycle events %s", self)
            wrapped_conn.domainEventRegisterAny(
                None,
                libvirt.VIR_DOMAIN_EVENT_ID_LIFECYCLE,
                self._event_lifecycle_callback,
                self)
            wrapped_conn.domainEventRegisterAny(
                None,
                libvirt.VIR_DOMAIN_EVENT_ID_DEVICE_REMOVED,
                self._event_device_removed_callback,
                self)
            wrapped_conn.domainEventRegisterAny(
                None,
                libvirt.VIR_DOMAIN_EVENT_ID_DEVICE_REMOVAL_FAILED,
                self._event_device_removal_failed_callback,
                self)
        except Exception as e:
            LOG.warning("URI %(uri)s does not support events: %(error)s",
                        {'uri': self._uri, 'error': e})

        try:
            LOG.debug("Registering for connection events: %s", str(self))
            wrapped_conn.registerCloseCallback(self._close_callback, None)
        except libvirt.libvirtError as e:
            LOG.warning("URI %(uri)s does not support connection"
                        " events: %(error)s",
                        {'uri': self._uri, 'error': e})

        return wrapped_conn

    def _queue_conn_event_handler(self, *args, **kwargs):
        if self._conn_event_handler is None:
            return

        def handler():
            return self._conn_event_handler(*args, **kwargs)

        self._conn_event_handler_queue.put(handler)

    def _get_connection(self):
        # multiple concurrent connections are protected by _wrapped_conn_lock
        with self._wrapped_conn_lock:
            # Drop the existing connection if it is not usable
            if (self._wrapped_conn is not None and
                    not self._test_connection(self._wrapped_conn)):
                self._wrapped_conn = None
                # Connection was previously up, and went down
                self._queue_conn_event_handler(
                    False, 'Connection to libvirt lost')

            if self._wrapped_conn is None:
                try:
                    # This will raise if it fails to get a connection
                    self._wrapped_conn = self._get_new_connection()
                except Exception as ex:
                    with excutils.save_and_reraise_exception():
                        # If we previously had a connection and it went down,
                        # we generated a down event for that above.
                        # We also want to generate a down event for an initial
                        # failure, which won't be handled above.
                        if self._initial_connection:
                            self._queue_conn_event_handler(
                                False,
                                'Failed to connect to libvirt: %(msg)s' %
                                {'msg': ex})
                finally:
                    self._initial_connection = False

                self._queue_conn_event_handler(True, None)

        return self._wrapped_conn

    def get_connection(self):
        """Returns a connection to the hypervisor

        :returns: a libvirt.virConnect object
        """
        try:
            conn = self._get_connection()
        except libvirt.libvirtError as ex:
            LOG.exception("Connection to libvirt failed: %s", ex)
            raise exceptions.HypervisorUnavailable()

        return conn

    @staticmethod
    def _libvirt_error_handler(context, err):
        # Just ignore instead of default outputting to stderr.
        pass

    def initialize(self):
        if self._initialized:
            return

        # NOTE(dkliban): Error handler needs to be registered before libvirt
        #                connection is used for the first time.  Otherwise, the
        #                handler does not get registered.
        libvirt.registerErrorHandler(self._libvirt_error_handler, None)
        libvirt.virEventRegisterDefaultImpl()
        self._init_events()

        LOG.debug("Starting connection event dispatch thread")
        eventlet.spawn(self._conn_event_thread)

        self._initialized = True

    def emit_event(self, event: virtevent.VMEvent) -> None:
        """EMIT_EVENT

        Handles libvirt specific events locally and dispatches the rest to
        the compute manager.
        """
        if isinstance(event, libvirtevent.LibvirtEvent):
            # These are libvirt specific events handled here on the driver
            # level instead of propagating them to the compute manager level
            if isinstance(event, libvirtevent.DeviceEvent):
                had_clients = self._device_event_handler.notify_waiters(event)

                if had_clients:
                    LOG.debug(
                        "Received event %s from libvirt while the driver is "
                        "waiting for it; dispatched.",
                        event,
                    )
                else:
                    LOG.warning(
                        "Received event %s from libvirt but the driver is not "
                        "waiting for it; ignored.",
                        event,
                    )
            else:
                LOG.debug(
                    "Received event %s from libvirt but no handler is "
                    "implemented for it in the libvirt driver so it is "
                    "ignored", event)
        else:
            # Let the generic driver code dispatch the event to the compute
            # manager
            super().emit_event(event)

    def write_vm_config(self, xml):
        """Defines a domain, but does not start it."""

        domain = self.get_connection().defineXML(xml)
        return libvirt_guest.Guest(domain)

    def _guest_add_qga_device(self, guest, vm_obj):
        qga = vconfig.LibvirtConfigGuestChannel()
        qga.type = "unix"
        qga.target_name = "org.qemu.guest_agent.0"
        qga.source_path = ("/var/lib/libvirt/qemu/%s.%s.sock" %
                           ("org.qemu.guest_agent.0", vm_obj.guest_name))
        guest.add_device(qga)

    @staticmethod
    def _guest_add_video_device(guest):
        add_video_driver = False
        if CONF.vm_settings.vnc_enabled:
            graphics = vconfig.LibvirtConfigGuestGraphics()
            graphics.type = "vnc"
            graphics.listen = CONF.vm_settings.vnc_server_listen
            guest.add_device(graphics)
            add_video_driver = True

        if CONF.vm_settings.spice_enabled:
            graphics = vconfig.LibvirtConfigGuestSpiceGraphics()
            graphics.listen = CONF.vm_settings.spice_server_listen
            guest.add_device(graphics)
            add_video_driver = True

        return add_video_driver

    def _get_disk_config(self, volume_obj):

        # TODO(liupeng) IMPL LVM volume config info
        # if getattr(CONF, volume_obj.backend).volume_driver
        disk_config = self.volume_manager.drivers[
            volume_obj.backend].get_disk_config(
            volume_obj)
        return disk_config

    def _get_guest_disks_config(self, volume_objs):
        disks_config = []
        for volume_obj in volume_objs:
            disk_config = self._get_disk_config(volume_obj)
            disks_config.append(disk_config)
        return disks_config

    def _guest_add_disks_config(self, guest_conf_obj, volume_objs):

        disks_config = self._get_guest_disks_config(volume_objs)

        for disk_config in disks_config:
            guest_conf_obj.add_device(disk_config)

    @staticmethod
    def _guest_add_memory_balloon(guest):
        # Memory balloon device only support 'qemu/kvm' hypervisor
        if (
            CONF.vm_settings.virt_type in ('qemu', 'kvm') and
            CONF.vm_settings.mem_stats_period_seconds > 0
        ):
            balloon = vconfig.LibvirtConfigMemoryBalloon()
            balloon.model = 'virtio'
            # See https://libvirt.org/formatdomain.html#memory-balloon-device
            balloon.period = CONF.vm_settings.mem_stats_period_seconds
            guest.add_device(balloon)

    def _guest_add_usb3_root_controller(self, guest):
        """Add USB root controller"""
        usbhost = vconfig.LibvirtConfigGuestUSB3HostController()
        usbhost.index = 0
        usbhost.model = "nec-xhci"
        usbhost.ports = REDIRDEV_DEVICE_AND_USB3_PORTS_COUNT
        guest.add_device(usbhost)

    def _guest_add_usb1_root_controller(self, guest):
        """Add USB root controller"""
        usbhost = vconfig.LibvirtConfigGuestUSBHostController()
        usbhost.index = 1
        usbhost.model = "piix3-uhci"
        guest.add_device(usbhost)

    def _guest_add_video_driver(self, guest):
        video = vconfig.LibvirtConfigGuestVideo()
        video.type = 'qxl' if CONF.vm_settings.spice_enabled else 'virtio'
        guest.add_device(video)

    def _guest_add_pointer_device(self, guest):
        pointer = vconfig.LibvirtConfigGuestInput()
        guest.add_device(pointer)

    def _guest_add_sound_device(self, guest):
        sound = vconfig.LibvirtConfigGuestSound()
        guest.add_device(sound)

    def _guest_add_spice_channel(self, guest):
        channel = vconfig.LibvirtConfigGuestChannel()
        channel.type = 'spicevmc'
        channel.target_name = "com.redhat.spice.0"
        guest.add_device(channel)

    def _guest_add_redirdev_device(self, guest, port):
        redirdev = vconfig.LibvirtConfigGuestRedirdev()
        redirdev.port = port
        guest.add_device(redirdev)

    def _guest_add_unix_channel(self, guest):
        channel = vconfig.LibvirtConfigGuestChannel()
        channel.type = 'unix'
        channel.target_name = "com.troila.kly.0"
        guest.add_device(channel)

    def _guest_add_spice_port_channel(self, guest):
        channel = vconfig.LibvirtConfigGuestChannel()
        channel.type = 'spiceport'
        channel.target_name = "com.troila.newbee.ca.0"
        channel.source_channel = "com.troila.newbee.ca.0"
        guest.add_device(channel)

    def _get_cpu_topology(self, vm_obj):
        # TODO(liupeng) Our default VM is windows. In future, we support to
        # distinguish between windows and linux through image metadata,
        # but some time VM create from snapshot_id and volume_id, it's
        # image_id is None. Remember to add image_id for VM.
        vm_vcpus = vm_obj.vcpu
        sockets, cores, threads = vm_vcpus, 1, 1
        # If vcpu is odd, we don't care
        if vm_obj.vcpu % 2 == 0:
            # We set default max socket is 2, max thread is 1
            sockets, threads = 2, 1
            cores = int(vm_vcpus / 2)
        return sockets, cores, threads

    def _guset_add_cpu_config(self, guest, vm_obj):
        cpu = vconfig.LibvirtConfigGuestCPU()
        cpu.mode = "host-model"
        sockets, cores, threads = self._get_cpu_topology(vm_obj)
        cpu.sockets = sockets
        cpu.cores = cores
        cpu.threads = threads
        guest.cpu = cpu

    def _guset_add_clock_config(self, guest):
        # TODO(liupeng) Our default VM is windows. In future, we support to
        # distinguish between windows and linux through image metadata.
        clk = vconfig.LibvirtConfigGuestClock()
        clk.offset = 'localtime'

        if CONF.vm_settings.virt_type == "kvm":
            tmpit = vconfig.LibvirtConfigGuestTimer()
            tmpit.name = "pit"
            tmpit.tickpolicy = "delay"

            tmrtc = vconfig.LibvirtConfigGuestTimer()
            tmrtc.name = "rtc"
            tmrtc.tickpolicy = "catchup"

            clk.add_timer(tmpit)
            clk.add_timer(tmrtc)

            # Support for windows guest
            tmhyperv = vconfig.LibvirtConfigGuestTimer()
            tmhyperv.name = "hypervclock"
            tmhyperv.present = True
            clk.add_timer(tmhyperv)

        guest.set_clock(clk)

    def _guest_add_pcie_root_ports(self, guest_conf_obj):
        pcieroot = vconfig.LibvirtConfigGuestPCIeRootController()
        guest_conf_obj.add_device(pcieroot)

        for x in range(0, CONF.vm_settings.num_pcie_ports):
            pcierootport = vconfig.LibvirtConfigGuestPCIeRootPortController()
            guest_conf_obj.add_device(pcierootport)

    def _config_guest_by_boot_type(self, guest_conf_obj, boot_type):
        if boot_type == constants.UEFI:
            caps = self.get_capabilities()
            guest_conf_obj.os_loader = DEFAULT_UEFI_LOADER_PATH[
                caps.host.cpu.arch][0]
            guest_conf_obj.os_loader_type = "pflash"
            guest_conf_obj.os_mach_type = 'q35'
            self._guest_add_pcie_root_ports(guest_conf_obj)

    def _guset_add_seclabel_config(self, guest_conf_obj):
        seclabel = vconfig.LibvirtConfigSeclabel()
        seclabel.type = 'none'
        guest_conf_obj.set_seclabel(seclabel)

    def _get_guest_config(self, vm_obj, volume_objs, nic_cfgs=None):
        """Get config data for parameters."""
        guest_conf_obj = vconfig.LibvirtConfigGuest()
        guest_conf_obj.virt_type = CONF.vm_settings.virt_type
        guest_conf_obj.name = vm_obj.guest_name
        guest_conf_obj.uuid = vm_obj.id
        # We are using default unit for memory: KiB
        guest_conf_obj.memory = vm_obj.memory_mb * units.Ki
        guest_conf_obj.vcpus = vm_obj.vcpu
        guest_conf_obj.os_type = 'hvm'

        # Support UEFI boot
        boot_type = vm_obj.metadata_.get('boot_type',
                                         constants.VDI_DEFAULT_BOOT_TYPE)
        self._config_guest_by_boot_type(guest_conf_obj, boot_type)

        guest_conf_obj.features.append(vconfig.LibvirtConfigGuestFeatureACPI())
        guest_conf_obj.features.append(vconfig.LibvirtConfigGuestFeatureAPIC())

        self._guset_add_cpu_config(guest_conf_obj, vm_obj)
        self._guset_add_clock_config(guest_conf_obj)
        self._guset_add_seclabel_config(guest_conf_obj)

        if nic_cfgs:
            for nic_cfg in nic_cfgs:
                guest_conf_obj.add_device(nic_cfg)

        # TODO(liupeng)
        # 1. Generate guest numa topology config
        # 2. Generate guest metadata config
        # 3. Generate consoles config
        # etc...

        self._guest_add_memory_balloon(guest_conf_obj)
        self._guest_add_disks_config(guest_conf_obj, volume_objs)

        # Generate spice vnc qxl sound_card etc..
        if self._guest_add_video_device(guest_conf_obj):
            self._guest_add_sound_device(guest_conf_obj)
            self._guest_add_video_driver(guest_conf_obj)

            # Add usb1.0 controller and bind pointer device to this
            self._guest_add_usb1_root_controller(guest_conf_obj)
            self._guest_add_pointer_device(guest_conf_obj)

            if CONF.vm_settings.spice_enabled:
                # Add usb3.0 controller and bind redirdev device to this
                self._guest_add_usb3_root_controller(guest_conf_obj)
                for port in range(1, REDIRDEV_DEVICE_AND_USB3_PORTS_COUNT + 1):
                    self._guest_add_redirdev_device(guest_conf_obj, port)
                self._guest_add_spice_channel(guest_conf_obj)
                # Generate troila spiceport channel
                self._guest_add_spice_port_channel(guest_conf_obj)

        # Generate troila agent channel
        self._guest_add_unix_channel(guest_conf_obj)

        # TODO(liupeng) At present, our VM image has qga installed by default,
        # In the future, we will decide whether to load the configuration
        # according to whether the VM has qemu_guest_agent metadata or
        # image has qemu_guest_agent metadata
        self._guest_add_qga_device(guest_conf_obj, vm_obj)

        return guest_conf_obj

    def _create_guest(self, xml):
        """Create a Guest from XML."""
        guest = libvirt_guest.Guest.create(xml, self)
        guest.launch()
        return guest

    def _resize(self, vm_obj, volume_objs, nic_cfgs):
        xml = self._get_guest_config(vm_obj, volume_objs, nic_cfgs).to_xml()
        # We just redefine the VM but don't start the VM
        libvirt_guest.Guest.create(xml, self)

    def resize(self, vm_obj, volume_objs, nic_cfgs):
        self._resize(vm_obj, volume_objs, nic_cfgs)

    def _get_domain(self, vm_obj):
        """Retrieve libvirt domain object for an VM."""
        try:
            conn = self.get_connection()
            return conn.lookupByUUIDString(vm_obj.id)
        except libvirt.libvirtError as ex:
            error_code = ex.get_error_code()
            if error_code == libvirt.VIR_ERR_NO_DOMAIN:
                raise exceptions.VMNotFound(vm_id=vm_obj.id)

            msg = ('Error from libvirt while looking up %(vm_name)s: '
                   '[Error Code %(error_code)s] %(ex)s' %
                   {'vm_name': vm_obj.name,
                    'error_code': error_code,
                    'ex': ex})
            raise exceptions.InternalServerError(msg=msg)

    def get_guest(self, vm_obj):
        """Retrieve libvirt guest object for an VM."""
        return libvirt_guest.Guest(self._get_domain(vm_obj))

    def get_info(self, vm_obj):
        """Retrieve information from libvirt for a specific VM"""
        guest = self.get_guest(vm_obj)
        return guest.get_info(self)

    def unquiesce(self, vm_obj):
        """Thaw the guest filesystems after snapshot."""
        self._set_quiesced(vm_obj, False)

    def quiesce(self, vm_obj):
        """Freeze the guest filesystems to prepare for snapshot.

        The qemu-guest-agent must be setup to execute fsfreeze.
        """
        self._set_quiesced(vm_obj, True)

    def _set_quiesced(self, vm_obj, quiesced):
        try:
            guest = self.get_guest(vm_obj)
            if quiesced:
                guest.freeze_filesystems()
            else:
                guest.thaw_filesystems()
        except libvirt.libvirtError as ex:
            error_code = ex.get_error_code()
            msg = ('Error from libvirt while quiescing %(vm_id)s: '
                   '[Error Code %(error_code)s] %(ex)s'
                   % {'vm_id': vm_obj.id,
                      'error_code': error_code, 'ex': ex})
            raise exceptions.InternalServerError(msg=msg)

    def _replace_cdrom_iso_image(self, vm_obj, iso_image_path):
        guest = self.get_guest(vm_obj)
        state = guest.get_power_state(self)
        if state == power_state.RUNNING:
            flags = libvirt.VIR_DOMAIN_DEVICE_MODIFY_CURRENT
            flags |= libvirt.VIR_DOMAIN_DEVICE_MODIFY_LIVE
            flags |= libvirt.VIR_DOMAIN_DEVICE_MODIFY_CONFIG
            cdrom_disk_config = guest.get_disk(
                constants.CDROM_DEFAULT_DRIVER_TARGET)
            if cdrom_disk_config:
                cdrom_disk_config.source_path = iso_image_path
                guest._domain.updateDeviceFlags(
                    cdrom_disk_config.to_xml(), flags)

    # _detach_with_retry、
    # _detach_from_persistent()、
    # _detach_from_live_with_retry()、
    # _detach_from_live_and_wait_for_event()、
    # _detach_sync()
    # Above functions are completely copied from nova/virt/libvirt/driver.py.
    # The _detach_with_retry function calls other functions.
    # The _detach_with_retry function is used to detach device, eg: nic、volume.
    # The purpose of a full copy is to prevent bugs.
    def _detach_with_retry(
        self,
        guest: libvirt_guest.Guest,
        instance_uuid: str,
        # to properly typehint this param we would need typing.Protocol but
        # that is only available since python 3.8
        get_device_conf_func: ty.Callable,
        device_name: str,
    ) -> None:
        """Detaches a device from the guest

        If the guest is a running state then the detach is performed on both
        the persistent and live domains.

        In case of live detach this call will wait for the libvirt event
        signalling the end of the detach process.

        If the live detach times out then it will retry the detach. Detach from
        the persistent config is not retried as it is:

        * synchronous and no event is sent from libvirt
        * it is always expected to succeed if the device is in the domain
          config

        :param guest: the guest we are detach the device from
        :param instance_uuid: the UUID of the instance we are detaching the
            device from
        :param get_device_conf_func: function which returns the configuration
            for device from the domain, having one optional boolean parameter
            `from_persistent_config` to select which domain config to query
        :param device_name: This is the name of the device used solely for
            error messages. Note that it is not the same as the device alias
            used by libvirt to identify the device.
        :raises exception.DeviceNotFound: if the device does not exist in the
            domain even before we try to detach or if libvirt reported that the
            device is missing from the domain synchronously.
        :raises exception.DeviceDetachFailed: if libvirt reported error during
            detaching from the live domain or we timed out waiting for libvirt
            events and run out of retries
        :raises libvirt.libvirtError: for any other errors reported by libvirt
            synchronously.
        """
        state = guest.get_power_state(None)
        live = state in (power_state.RUNNING, power_state.PAUSED)

        persistent = guest.has_persistent_configuration()

        if not persistent and not live:
            # nothing to do
            return

        persistent_dev = None
        if persistent:
            persistent_dev = get_device_conf_func(from_persistent_config=True)

        live_dev = None
        if live:
            live_dev = get_device_conf_func()

        # didn't find the device in either domain
        if persistent_dev is None and live_dev is None:
            raise exceptions.DeviceNotFound(device=device_name, id='')

        if persistent_dev:
            try:
                self._detach_from_persistent(
                    guest, instance_uuid, persistent_dev, get_device_conf_func,
                    device_name)
            except exceptions.DeviceNotFound:
                if live_dev:
                    # ignore the error so that we can do the live detach
                    LOG.warning(
                        'Libvirt reported sync error while detaching '
                        'device %s from instance %s from the persistent '
                        'domain config. Ignoring the error to proceed with '
                        'live detach as the device exists in the live domain.',
                        device_name, instance_uuid)
                else:
                    # if only persistent detach was requested then give up
                    raise

        if live_dev:
            self._detach_from_live_with_retry(
                guest, instance_uuid, live_dev, get_device_conf_func,
                device_name)

    def _detach_from_persistent(
        self,
        guest: libvirt_guest.Guest,
        instance_uuid: str,
        persistent_dev: ty.Union[
            vconfig.LibvirtConfigGuestDisk,
            vconfig.LibvirtConfigGuestInterface],
        get_device_conf_func,
        device_name: str,
    ):
        LOG.debug(
            'Attempting to detach device %s from instance %s from '
            'the persistent domain config.', device_name, instance_uuid)

        self._detach_sync(
            persistent_dev, guest, instance_uuid, device_name,
            persistent=True, live=False)

        # make sure the dev is really gone
        persistent_dev = get_device_conf_func(
            from_persistent_config=True)
        if not persistent_dev:
            LOG.info(
                'Successfully detached device %s from instance %s '
                'from the persistent domain config.',
                device_name, instance_uuid)
        else:
            # Based on the libvirt devs this should never happen
            LOG.warning(
                'Failed to detach device %s from instance %s '
                'from the persistent domain config. Libvirt did not '
                'report any error but the device is still in the '
                'config.', device_name, instance_uuid)

    def _detach_from_live_with_retry(
        self,
        guest: libvirt_guest.Guest,
        instance_uuid: str,
        live_dev: ty.Union[
            vconfig.LibvirtConfigGuestDisk,
            vconfig.LibvirtConfigGuestInterface],
        get_device_conf_func,
        device_name: str,
    ):
        max_attempts = CONF.vm_settings.device_detach_attempts
        for attempt in range(max_attempts):
            LOG.debug(
                '(%s/%s): Attempting to detach device %s with device '
                'alias %s from instance %s from the live domain config.',
                attempt + 1, max_attempts, device_name, live_dev.alias,
                instance_uuid)

            self._detach_from_live_and_wait_for_event(
                live_dev, guest, instance_uuid, device_name)

            # make sure the dev is really gone
            live_dev = get_device_conf_func()
            if not live_dev:
                LOG.info(
                    'Successfully detached device %s from instance %s '
                    'from the live domain config.', device_name, instance_uuid)
                # we are done
                return

            LOG.debug(
                'Failed to detach device %s with device alias %s from '
                'instance %s from the live domain config. Libvirt did not '
                'report any error but the device is still in the config.',
                device_name, live_dev.alias, instance_uuid)

        msg = (
            'Run out of retry while detaching device %s with device '
            'alias %s from instance %s from the live domain config. '
            'Device is still attached to the guest.')
        LOG.error(msg, device_name, live_dev.alias, instance_uuid)
        raise exceptions.DeviceDetachFailed(
            device=device_name,
            reason=msg % (device_name, live_dev.alias, instance_uuid))

    def _detach_from_live_and_wait_for_event(
        self,
        dev: ty.Union[
            vconfig.LibvirtConfigGuestDisk,
            vconfig.LibvirtConfigGuestInterface],
        guest: libvirt_guest.Guest,
        instance_uuid: str,
        device_name: str,
    ) -> None:
        """Detaches a device from the liv config and wait

        Detaches a device from the live config of the guest and waits for
        the libvirt event singling the finish of the detach.

        :param dev: the device configuration to be detached
        :param guest: the guest we are detach the device from
        :param instance_uuid: the UUID of the instance we are detaching the
            device from
        :param device_name: This is the name of the device used solely for
            error messages.
        :raises exception.DeviceNotFound: if libvirt reported that the device
            is missing from the domain synchronously.
        :raises libvirt.libvirtError: for any other errors reported by libvirt
            synchronously.
        :raises DeviceDetachFailed: if libvirt sent DeviceRemovalFailedEvent
        """
        # So we will issue an detach to libvirt and we will wait for an
        # event from libvirt about the result. We need to set up the event
        # handling before the detach to avoid missing the event if libvirt
        # is really fast
        # NOTE(gibi): we need to use the alias name of the device as that
        # is what libvirt will send back to us in the event
        waiter = self._device_event_handler.create_waiter(
            instance_uuid, dev.alias,
            {libvirtevent.DeviceRemovedEvent,
             libvirtevent.DeviceRemovalFailedEvent})
        try:
            self._detach_sync(
                dev, guest, instance_uuid, device_name, persistent=False,
                live=True)
        except Exception:
            # clean up the libvirt event handler as we failed synchronously
            self._device_event_handler.delete_waiter(waiter)
            raise

        LOG.debug(
            'Start waiting for the detach event from libvirt for '
            'device %s with device alias %s for instance %s',
            device_name, dev.alias, instance_uuid)
        # We issued the detach without any exception so we can wait for
        # a libvirt event to arrive to notify us about the result
        # NOTE(gibi): we expect that this call will be unblocked by an
        # incoming libvirt DeviceRemovedEvent or DeviceRemovalFailedEvent
        event = self._device_event_handler.wait(
            waiter, timeout=CONF.vm_settings.device_detach_timeout)

        if not event:
            # This should not happen based on information from the libvirt
            # developers. But it does at least during the cleanup of the
            # tempest test case
            # ServerRescueNegativeTestJSON.test_rescued_vm_detach_volume
            # Log a warning and let the upper layer detect that the device is
            # still attached and retry
            LOG.error(
                'Waiting for libvirt event about the detach of '
                'device %s with device alias %s from instance %s is timed '
                'out.', device_name, dev.alias, instance_uuid)

        if isinstance(event, libvirtevent.DeviceRemovalFailedEvent):
            # Based on the libvirt developers this signals a permanent failure
            LOG.error(
                'Received DeviceRemovalFailedEvent from libvirt for the '
                'detach of device %s with device alias %s from instance %s ',
                device_name, dev.alias, instance_uuid)
            raise exceptions.DeviceDetachFailed(
                device=device_name,
                reason="DeviceRemovalFailedEvent received from libvirt")

    @staticmethod
    def _detach_sync(
        dev: ty.Union[
            vconfig.LibvirtConfigGuestDisk,
            vconfig.LibvirtConfigGuestInterface],
        guest: libvirt_guest.Guest,
        instance_uuid: str,
        device_name: str,
        persistent: bool,
        live: bool,
    ):
        """Detaches a device from the guest without waiting for libvirt events

        It only handles synchronous errors (i.e. exceptions) but does not wait
        for any event from libvirt.

        :param dev: the device configuration to be detached
        :param guest: the guest we are detach the device from
        :param instance_uuid: the UUID of the instance we are detaching the
            device from
        :param device_name: This is the name of the device used solely for
            error messages.
        :param live: detach the device from the live domain config only
        :param persistent: detach the device from the persistent domain config
            only
        :raises exception.DeviceNotFound: if libvirt reported that the device
            is missing from the domain synchronously.
        :raises libvirt.libvirtError: for any other errors reported by libvirt
            synchronously.
        """
        try:
            guest.detach_device(dev, persistent=persistent, live=live)
        except libvirt.libvirtError as ex:
            code = ex.get_error_code()
            msg = ex.get_error_message()
            LOG.debug(
                "Libvirt returned error while detaching device %s from "
                "instance %s. Libvirt error code: %d, error message: %s.",
                device_name, instance_uuid, code, msg
            )
            if (code == libvirt.VIR_ERR_DEVICE_MISSING or
                # Libvirt 4.1 improved error code usage but OPERATION_FAILED
                # still used in one case during detach:
                # https://github.com/libvirt/libvirt/blob/55ea45acc99c549c7757efe954aacc33ad30a8ef/src/qemu/qemu_hotplug.c#L5324-L5328
                # TODO(gibi): remove this when a future version of libvirt
                # transform this error to VIR_ERR_DEVICE_MISSING too.
                    (code == libvirt.VIR_ERR_OPERATION_FAILED and
                     'not found' in msg)):
                LOG.debug(
                    'Libvirt failed to detach device %s from instance %s '
                    'synchronously (persistent=%s, live=%s) with error: %s.',
                    device_name, instance_uuid, persistent, live, str(ex))
                raise exceptions.DeviceNotFound(device=device_name,
                                                id='') from ex

            # NOTE(lyarwood): https://bugzilla.redhat.com/1878659
            # Ignore this known QEMU bug for the time being allowing
            # our retry logic to handle it.
            # NOTE(gibi): This can only happen in case of detaching from the
            # live domain as we never retry a detach from the persistent
            # domain so we cannot hit an already running detach there.
            # In case of detaching from the live domain this error can happen
            # if the caller timed out during the first detach attempt then saw
            # that the device is still attached and therefore looped over and
            # and retried the detach. In this case the previous attempt stopped
            # waiting for the libvirt event. Also libvirt reports that there is
            # a detach ongoing, so the current attempt expects that a
            # libvirt event will be still emitted. Therefore we simply return
            # from here. Then the caller will wait for such event.
            if (code == libvirt.VIR_ERR_INTERNAL_ERROR and msg and
                    'already in the process of unplug' in msg):
                LOG.debug(
                    'Ignoring QEMU rejecting our request to detach device %s '
                    'from instance %s as it is caused by a previous request '
                    'still being in progress.', device_name, instance_uuid)
                return

            if code == libvirt.VIR_ERR_NO_DOMAIN:
                LOG.warning(
                    "During device detach, instance disappeared.",
                    instance_uuid=instance_uuid)
                # if the domain has disappeared then we have nothing to detach
                return

            LOG.warning(
                'Unexpected libvirt error while detaching device %s from '
                'instance %s: %s', device_name, instance_uuid, str(ex))
            raise

    def get_capabilities(self):
        """Returns the host capabilities information

        Returns an instance of config.LibvirtConfigCaps representing
        the capabilities of the host.

        Note: The result is cached in the member attribute _caps.

        :returns: a config.LibvirtConfigCaps object
        """
        xmlstr = self.get_connection().getCapabilities()
        self._caps = vconfig.LibvirtConfigCaps()
        self._caps.parse_str(xmlstr)

        # NOTE(mriedem): Don't attempt to get baseline CPU features
        # if libvirt can't determine the host cpu model.
        if (
            hasattr(libvirt, 'VIR_CONNECT_BASELINE_CPU_EXPAND_FEATURES') and
            self._caps.host.cpu.model is not None
        ):
            try:
                xml_str = self._caps.host.cpu.to_xml()
                if isinstance(xml_str, bytes):
                    xml_str = xml_str.decode('utf-8')
                # NOTE(kevinz): The baseline CPU info on Aarch64 will not
                # include any features. So on Aarch64, we use the original
                # features from LibvirtConfigCaps.
                if self._caps.host.cpu.arch != "aarch64":
                    features = self.get_connection().baselineCPU(
                        [xml_str],
                        libvirt.VIR_CONNECT_BASELINE_CPU_EXPAND_FEATURES)
                    if features:
                        cpu = vconfig.LibvirtConfigCPU()
                        cpu.parse_str(features)
                        self._caps.host.cpu.features = cpu.features
            except libvirt.libvirtError as ex:
                error_code = ex.get_error_code()
                if error_code == libvirt.VIR_ERR_NO_SUPPORT:
                    LOG.warning(
                        "URI %(uri)s does not support full set of host "
                        "capabilities: %(error)s",
                        {'uri': self._uri, 'error': ex})
                else:
                    raise

        return self._caps


class AsyncDeviceEventsHandler:
    """AsyncDeviceEventsHandler

    A synchornization point between libvirt events an clients waiting for
    such events.

    It provides an interface for the clients to wait for one or more libvirt
    event types. It implements event delivery by expecting the libvirt driver
    to forward libvirt specific events to notify_waiters()

    It handles multiple clients for the same instance, device and event
    type and delivers the event to each clients.
    """

    class Waiter:
        def __init__(
            self,
            vm_uuid: str,
            device_name: str,
            event_types: ty.Set[ty.Type[libvirtevent.DeviceEvent]]
        ):
            self.vm_uuid = vm_uuid
            self.device_name = device_name
            self.event_types = event_types
            self.threading_event = threading.Event()
            self.result: ty.Optional[libvirtevent.DeviceEvent] = None

        def matches(self, event: libvirtevent.DeviceEvent) -> bool:
            """matches

            Returns true if the event is one of the expected event types
            for the given instance and device.
            """
            return (
                self.vm_uuid == event.uuid and
                self.device_name == event.dev and
                isinstance(event, tuple(self.event_types)))

        def __repr__(self) -> str:
            return (
                "AsyncDeviceEventsHandler.Waiter("
                f"vm_uuid={self.vm_uuid}, "
                f"device_name={self.device_name}, "
                f"event_types={self.event_types})")

    def __init__(self):
        self._lock = threading.Lock()
        # Ongoing device operations in libvirt where we wait for the events
        # about success or failure.
        self._waiters: ty.Set[AsyncDeviceEventsHandler.Waiter] = set()

    def create_waiter(
        self,
        vm_uuid: str,
        device_name: str,
        event_types: ty.Set[ty.Type[libvirtevent.DeviceEvent]]
    ) -> 'AsyncDeviceEventsHandler.Waiter':
        """create_waiter

        Returns an opaque token the caller can use in wait() to
        wait for the libvirt event

        :param vm_uuid: The UUID of the VM.
        :param device_name: The device name alias used by libvirt for this
            device.
        :param event_type: A set of classes derived from DeviceEvent
            specifying which event types the caller waits for. Specifying more
            than one event type means waiting for either of the events to be
            received.
        :returns: an opaque token to be used with wait_for_event().
        """
        waiter = AsyncDeviceEventsHandler.Waiter(
            vm_uuid, device_name, event_types)
        with self._lock:
            self._waiters.add(waiter)

        return waiter

    def delete_waiter(self, token: 'AsyncDeviceEventsHandler.Waiter'):
        """Deletes the waiter

        :param token: the opaque token returned by create_waiter() to be
            deleted
        """
        with self._lock:
            self._waiters.remove(token)

    def wait(
        self, token: 'AsyncDeviceEventsHandler.Waiter', timeout: float,
    ) -> ty.Optional[libvirtevent.DeviceEvent]:
        """Blocks waiting for the libvirt event represented by the opaque token

        :param token: A token created by calling create_waiter()
        :param timeout: Maximum number of seconds this call blocks waiting for
            the event to be received
        :returns: The received libvirt event, or None in case of timeout
        """
        token.threading_event.wait(timeout)

        with self._lock:
            self._waiters.remove(token)

        return token.result

    def notify_waiters(self, event: libvirtevent.DeviceEvent) -> bool:
        """Unblocks the client waiting for this event.

        :param event: the libvirt event that is received
        :returns: True if there was a client waiting and False otherwise.
        """
        dispatched = False
        with self._lock:
            for waiter in self._waiters:
                if waiter.matches(event):
                    waiter.result = event
                    waiter.threading_event.set()
                    dispatched = True

        return dispatched

    def cleanup_waiters(self, vm_uuid: str) -> None:
        """cleanup_waiters

        Deletes all waiters and unblock all clients related to the specific
        VM.

        param vm_uuid: The VM UUID for which the cleanup is
            requested
        """
        with self._lock:
            vm_waiters = set()
            for waiter in self._waiters:
                if waiter.vm_uuid == vm_uuid:
                    # unblock any waiting thread
                    waiter.threading_event.set()
                    vm_waiters.add(waiter)

            self._waiters -= vm_waiters

        if vm_waiters:
            LOG.debug(
                'Cleaned up device related libvirt event waiters: %s',
                vm_waiters)
