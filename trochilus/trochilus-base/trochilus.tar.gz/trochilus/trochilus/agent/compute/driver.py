# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from oslo_log import log as logging
from trochilus.agent.compute import event as virtevent


LOG = logging.getLogger(__name__)


class VMDriver():
    def __init__(self):
        self._compute_event_callback = None

    def create_vm(self, vm_obj):
        raise NotImplementedError()

    def delete_vm(self, vm_obj):
        raise NotImplementedError()

    def power_off(self, vm_obj, timeout=0, retry_interval=0):
        raise NotImplementedError()

    def power_on(self, vm_obj, volume_objs):
        raise NotImplementedError()

    def reboot(self, vm_obj, volume_objs, nic_cfgs, reboot_type):
        raise NotImplementedError()

    def register_event_listener(self, callback):
        """Register a callback to receive events.

        Register a callback to receive asynchronous event
        notifications from hypervisors. The callback will
        be invoked with a single parameter, which will be
        an instance of the trochilus.agent.compute.event.Event class.
        """

        self._compute_event_callback = callback

    def emit_event(self, event):
        """Dispatches an event to the VM manager.

        Invokes the event callback registered by the
        VM manager to dispatch the event. This
        must only be invoked from a green thread.
        """

        if not self._compute_event_callback:
            LOG.debug("Discarding event %s", str(event))
            return

        if not isinstance(event, virtevent.Event):
            raise ValueError(
                "Event must be an instance of agent.compute.event.Event")

        try:
            LOG.debug("Emitting event %s", str(event))
            self._compute_event_callback(event)
        except Exception as ex:
            LOG.error("Exception dispatching event %(event)s: %(ex)s",
                      {'event': event, 'ex': ex})
