#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os
import time

from datetime import datetime
from multiprocessing import cpu_count as thread

from oslo_concurrency import processutils
from oslo_config import cfg
from oslo_log import log as logging
from oslo_serialization import jsonutils
from oslo_utils import timeutils

from psutil import boot_time
from psutil import cpu_percent
from psutil import virtual_memory
from trochilus.common import constants
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import resource_provider_repo as rp_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class Node(object):

    def __init__(self):
        self.agent_repo = agent_repo.AgentRepository()
        # Node is a resource provider that provides resources including
        # cpu and memory for vm
        self.init_resource_provider()

    def report_node_state(self):
        LOG.debug("Sync node state to database")
        try:
            session = db_api.get_session(autocommit=False)
            agent_obj = self.agent_repo.get(
                session, hostname=CONF.agent_settings.hostname)

            systems = CONF.agent_settings.system
            versions = CONF.agent_settings.version
            roles = CONF.agent_settings.role
            cpu_dic = self.get_lscpu()
            pci_info = self.get_lspci()

            info = os.statvfs('/')
            total_size = info.f_blocks * info .f_bsize
            free_size = info.f_bavail * info.f_frsize
            used_size = total_size - free_size

            disk_names = self.get_lsblk()

            with session.begin(subtransactions=True):
                ratio_cpu = cpu_percent()
                mem = virtual_memory()
                timestamp = timeutils.utcnow()
                boot_times = boot_time()
                boot_time_obj = datetime.fromtimestamp(boot_times)
                cpu_cores = cpu_dic.get('Core(s) per socket:')
                if not agent_obj:
                    agent_dict = {
                        'hostname': CONF.agent_settings.hostname,
                        'status': constants.AGENT_UP,
                        'heartbeat_timestamp': timestamp,
                        'mgmt_ip': CONF.agent_settings.bind_host,
                        'api_version': 'v1.0',
                        'cpu_used_ratio': ratio_cpu,
                        'total_memory': mem.total,
                        'free_memory': mem.free,
                        'sys_disk_size': total_size,
                        'sys_disk_used_size': used_size,
                        'system': systems,
                        'version': versions,
                        'role': roles,
                        'cpu_thread': thread(),
                        'cpu_socket': cpu_dic.get('Socket(s):'),
                        'cpu_MHZ': cpu_dic.get('CPU MHz:'),
                        'cpu_core': cpu_cores,
                        'stepping': cpu_dic.get('Stepping:'),
                        'model': cpu_dic.get('Model name:'),
                        'boot_time': boot_time_obj,
                        'L2_cache': cpu_dic.get('L2 cache:'),
                        'L3_cache': cpu_dic.get('L3 cache:'),
                        'disk_names': disk_names,
                        'net_pci_info': pci_info,
                        'host_username': CONF.agent_settings.host_username,
                        'host_password': CONF.agent_settings.host_password,
                        'ipmi_address': self.get_ipmi_address(),
                        'ipmi_username': CONF.agent_settings.ipmi_username,
                        'ipmi_password': CONF.agent_settings.ipmi_password,
                        'ipmi_vendor': CONF.agent_settings.ipmi_vendor
                    }
                    self.agent_repo.create(session, **agent_dict)
                else:
                    self.agent_repo.update(session, agent_obj.id,
                                           **{'status': constants.AGENT_UP,
                                              'heartbeat_timestamp': timestamp,
                                              'cpu_used_ratio': ratio_cpu,
                                              'total_memory': mem.total,
                                              'free_memory': mem.free,
                                              'sys_disk_size': total_size,
                                              'sys_disk_used_size': used_size,
                                              'net_pci_info': pci_info})
            session.commit()
        except Exception as e:
            LOG.error('Fail to report node state, exception is %s', e)

    def get_lscpu(self):
        args = ['lscpu', '-J']
        out, _ = processutils.execute(*args)
        monmap = jsonutils.loads(out)
        list_data = monmap['lscpu']
        fields = ['Socket(s):', 'Model name:',
                  'Stepping:', 'CPU MHz:',
                  'L2 cache:', 'L3 cache:', 'Core(s) per socket:']
        cpu_dict = {}
        for i in list_data:
            if i["field"] in fields:
                cpu_dict[i["field"]] = i['data']
        return cpu_dict

    def get_lsblk(self):
        args = ['lsblk', '-J', '-d', '-o', 'NAME,TYPE']
        out, _ = processutils.execute(*args)
        monmap = jsonutils.loads(out)
        list_data = monmap['blockdevices']
        disk_name_list = [data['name'] for data in list_data
                          if 'type' in data and data['type'] == 'disk']
        return ",".join(disk_name_list)

    def get_lspci(self):
        pci = processutils.execute('lspci')[0].split('\n')
        item = 'net'
        pci_list = [a for a in pci if item in a]
        return pci_list

    def shutdown(self):
        # TODO(yangjianfeng) Implement real shutdown codes in future.
        # Currently, just simulate a block task.
        time.sleep(10)
        LOG.info("========================shutdown")

    def init_resource_provider(self):
        # init node info
        self.report_node_state()
        # init node resource info
        with db_api.get_lock_session() as lock_session:
            res_provider_repo = rp_repo.ResourceProviderRepository()
            cur_agent_obj = self.agent_repo.get(
                lock_session, hostname=CONF.agent_settings.hostname)
            res_provider = res_provider_repo.get(
                lock_session, lock=True, agent_id=cur_agent_obj.id)

            config = CONF.scheduler_settings
            if not res_provider:
                param_for_create = {
                    'agent_id': cur_agent_obj.id,
                    'cpu_ratio': config.cpu_allocation_ratio,
                    'reserved_cpu': config.reserved_host_cpus,
                    'memory_ratio': config.memory_allocation_ratio,
                    'reserved_memory_mb': config.reserved_host_memory_mb
                }
                res_provider_repo.create(lock_session, **param_for_create)
            else:
                param_for_update = {}
                if res_provider.cpu_ratio != config.cpu_allocation_ratio:
                    param_for_update['cpu_ratio'] = config.cpu_allocation_ratio
                if res_provider.reserved_cpu != config.reserved_host_cpus:
                    param_for_update['reserved_cpu'] = \
                        config.reserved_host_cpus
                if res_provider.memory_ratio != config.memory_allocation_ratio:
                    param_for_update['memory_ratio'] = \
                        config.memory_allocation_ratio
                if res_provider.reserved_memory_mb != \
                        config.reserved_host_memory_mb:
                    param_for_update['reserved_memory_mb'] = \
                        config.reserved_host_memory_mb
                if param_for_update:
                    res_provider_repo.update(lock_session, res_provider.id,
                                             **param_for_update)

    def get_ipmi_address(self):
        args = ['ipmitool', 'lan', 'print']
        address = ""
        out, _ = processutils.execute(*args, check_exit_code=(0, 1))
        lines = out.split("\n")
        for line in lines:
            if line.split(":")[0].strip() == "IP Address":
                address = line.split(":")[1].strip()
        return address
