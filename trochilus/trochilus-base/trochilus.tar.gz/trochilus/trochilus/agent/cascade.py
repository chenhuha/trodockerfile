# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_config import cfg
from oslo_log import log as logging

from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import image_repo
from trochilus.db import snapshot_group_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import vm_volume_mapping_repo as vvm_repo
from trochilus.db import volume_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class Cascade(object):

    def __init__(
            self,
            volume_manager,
            network_manager,
            snapshot_manager,
            vm_manager,
            snapshot_group_manager):

        # Init repo
        self.volume_repo = volume_repo.VolumeRepository()
        self.image_repo = image_repo.ImageRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.vvm_repo = vvm_repo.VMVolumeMappingRepository()
        self.sg_repo = snapshot_group_repo.SnapshotGroupRepository()

        # Init manager
        self.volume_manager = volume_manager
        self.network_manager = network_manager
        self.snapshot_manager = snapshot_manager
        self.vm_manager = vm_manager
        self.sg_manager = snapshot_group_manager

    def delete_volume(self, id, is_attached, need_delete_snapshot_ids):
        LOG.info("Cascade delete volume %s start", id)
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        # Detach volume
        if is_attached:
            vvm = volume_obj.vm_volume_mapping[0]
            self.vm_manager.detach_volume(
                vvm.virtual_machine_id,
                vvm.volume_id,
                vvm.id
            )
        # Delete volume's snapshots
        if need_delete_snapshot_ids:
            for snap_id in need_delete_snapshot_ids:
                self.snapshot_manager.delete(snap_id)
        # Delete volume
        self.volume_manager.delete(id)
        LOG.info("Cascade delete volume %s successful", id)

    def delete_vm(self, id, need_delete_sg_ids, need_delete_snapshot_ids,
                  need_detach_volume_ids, del_datadisk):
        LOG.info("Cascade delete VM %s start", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id)

        # First force stop vm
        self.vm_manager.driver.power_off(vm_obj)
        # Delete vm's sgs
        for sg_id in need_delete_sg_ids:
            self.sg_manager.delete(sg_id)
        # Delete vm's disk snapshots
        for snapshot_id in need_delete_snapshot_ids:
            self.snapshot_manager.delete(snapshot_id)
        # Detach VM data volume
        for volume_id in need_detach_volume_ids:
            vvm = self.volume_repo.get(
                session, id=volume_id).vm_volume_mapping[0]
            self.vm_manager.detach_volume(id, volume_id, vvm.id)
        # Delete VM
        self.vm_manager.delete(id)
        # Delete data volume
        if del_datadisk:
            for volume_id in need_detach_volume_ids:
                self.volume_manager.delete(volume_id)

        LOG.info("Cascade delete VM %s successful", id)

    def rebuild_vm(self, id, **kwargs):
        need_delete_sgs_ids = kwargs.get('need_delete_sgs_ids', [])
        need_delete_snapshot_ids = kwargs.get('need_delete_snapshot_ids', [])
        LOG.info("Delete all snapshots and snapshot"
                 " groups when rebuilding VM %s", id)
        # Delete snapshot group and Exclude snapshots of
        # system volumes that are not in the snapshot group
        if need_delete_sgs_ids:
            for need_delete_sgs_id in need_delete_sgs_ids:
                self.sg_manager.delete(need_delete_sgs_id)

        # Delete snapshot
        for snapshot in need_delete_snapshot_ids:
            self.snapshot_manager.delete(snapshot)
        self.vm_manager.rebuild(id, **kwargs)
