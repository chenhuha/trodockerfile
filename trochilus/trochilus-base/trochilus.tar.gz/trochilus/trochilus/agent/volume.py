# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import importutils
from oslo_utils import timeutils

from trochilus.agent.common import exceptions
from trochilus.agent.compute.libvirt import driver
from trochilus.common import constants
from trochilus.db import api as db_api
from trochilus.db import image_repo
from trochilus.db import snapshot_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import vm_volume_mapping_repo as vvm_repo
from trochilus.db import volume_repo


CONF = cfg.CONF
LOG = logging.getLogger(__name__)


VOLUME_BACKEND_OPTS = [
    cfg.StrOpt('volume_driver',
               default=None,
               help='Driver to use for volume creation'),
    cfg.StrOpt('volume_name_template',
               default='volume-%s',
               help='Template string to be used to generate volume names'),
]


class Volume(object):

    DRIVERS = {}

    def __init__(self, queue):
        self.drivers = Volume.DRIVERS
        self._init_drivers()
        self.volume_repo = volume_repo.VolumeRepository()
        self.image_repo = image_repo.ImageRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.vvm_repo = vvm_repo.VMVolumeMappingRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.driver = driver.LibvirtDriver(self)
        self.status_queue = queue

    def _init_drivers(self):
        if not CONF.api_settings.enabled_volume_backends:
            LOG.warning("No volume driver will enabled")
            return

        for backend in CONF.api_settings.enabled_volume_backends:
            CONF.register_opts(VOLUME_BACKEND_OPTS, group=backend)
            volume_driver = getattr(CONF, backend).volume_driver
            if not volume_driver:
                raise exceptions.BackendVolumeDriverInvalid(
                    backend=backend, volume_driver=volume_driver)

            if backend not in Volume.DRIVERS:
                driver = importutils.import_object(volume_driver, backend)
                Volume.DRIVERS[backend] = driver

    def create(self, id):
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        backend = volume_obj.backend
        image_id = volume_obj.image_id
        image_obj = None

        if image_id:
            image_obj = self.image_repo.get(session, image_id)

        self.volume_repo.update(session, id, status=constants.CREATING)

        try:
            self.drivers[backend].create_volume(
                volume_obj, image_obj if image_obj else None)
        except Exception as e:
            LOG.error("Create volume %s failed", id)
            """Create failed status error"""
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.CREATING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "create",
                "timestamp": timeutils.utcnow()})
            raise e

        """Successfully created, the status changes to available"""
        self.volume_repo.update(session, id, status=constants.AVAILABLE)

        LOG.info("Create volume %s successful", id)

        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": id,
            "previous_status": constants.CREATING,
            "current_status": constants.AVAILABLE,
            "action": "create",
            "timestamp": timeutils.utcnow()})

    def delete(self, id):
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        backend = volume_obj.backend

        if volume_obj.status == constants.IN_USE:
            raise exceptions.VolumeAttached()

        try:
            self.drivers[backend].delete_volume(volume_obj)
        except Exception as e:
            LOG.error("Delete volume %s failded", id)
            if volume_obj.status in [constants.PREPARE_CREATE,
                                     constants.ERROR]:
                self.volume_repo.update(
                    session, id, status=constants.DELETED)
                return
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.DELETING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "delete",
                "timestamp": timeutils.utcnow()})
            # If the deletion fails, an exception is thrown to prevent
            # other programs from continuing to execute.
            # For example, this method is used in VM delete.
            raise e

        self.volume_repo.update(session, id, status=constants.DELETED)

        LOG.info("Delete volume %s successful", id)

        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": id,
            "previous_status": constants.DELETING,
            "current_status": constants.DELETED,
            "action": "delete",
            "timestamp": timeutils.utcnow()})

    def rebuild(self, id, image_id, snapshot_id):
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        image_obj = self.image_repo.get(
            session, image_id) if image_id else None
        snapshot_obj = self.snapshot_repo.get(session, id=snapshot_id)
        backend = volume_obj.backend

        # We allow the volume to be rebuilt in the in-use state,
        # because the VM is shutdown.
        # TODO(liupeng) Do not set volume to rebuilding state,
        # and do not send webhook after success? maybe right
        # only send webhook when status is error
        try:
            self.drivers[backend].rebuild_volume(
                volume_obj, image_obj, snapshot_obj)
        except Exception as e:
            LOG.error("Rebuild volume %s failded", id)
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.IN_USE,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "rebuild",
                "timestamp": timeutils.utcnow()})
            raise e

        if image_id or snapshot_id:
            # Can only exist one (image_id, snapshot_id, volume_id)
            volume_obj.image_id = image_id
            volume_obj.snapshot_id = snapshot_id
            volume_obj.volume_id = None
            volume_obj.save(session)

        LOG.info("Rebuild volume %s successful", id)

    def clone(self, id, src_vol_id):
        session = db_api.get_session()
        clone_vol_obj = self.volume_repo.get(session, id=id)
        src_vol_obj = self.volume_repo.get(session, id=src_vol_id)
        backend = clone_vol_obj.backend

        try:
            self.drivers[backend].crete_volume_from_volume(
                clone_vol_obj, src_vol_obj)
        except Exception as e:
            LOG.error("Clone volume %(clone_vol)s from the volume "
                      "%(src_vol)s failed",
                      {'clone_vol': id, 'src_vol': src_vol_id})
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.CLONING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "clone",
                "timestamp": timeutils.utcnow()})
            raise e

        self.volume_repo.update(session, id, status=constants.AVAILABLE)
        LOG.info("Clone volume %(clone_vol)s from the volume "
                 "%(src_vol)s successful",
                 {'clone_vol': id, 'src_vol': src_vol_id})
        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": id,
            "previous_status": constants.CLONING,
            "current_status": constants.AVAILABLE,
            "action": "clone",
            "timestamp": timeutils.utcnow()})

    def revert(self, id, snap_id, volume_state):
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        snapshot_obj = self.snapshot_repo.get(session, id=snap_id)
        backend = volume_obj.backend

        try:
            self.drivers[backend].revert_snapshot(
                volume_obj, snapshot_obj)
        except Exception as e:
            LOG.error("Revert volume %(vol_id)s to the snapshot "
                      "%(snap_id)s failed",
                      {'vol_id': id, 'snap_id': snap_id})
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.REVERTING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "revert",
                "timestamp": timeutils.utcnow()})
            raise e

        self.volume_repo.update(session, id, status=volume_state)
        LOG.info("Revert volume %(vol_id)s to the snapshot "
                 "%(snap_id)s successful",
                 {'vol_id': id, 'snap_id': snap_id})
        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": id,
            "previous_status": constants.REVERTING,
            "current_status": volume_state,
            "action": "revert",
            "timestamp": timeutils.utcnow()})

    def update_volume_status(self, session, volume_id, action, update_status,
                             expected_status=None, success=True,
                             error_msg=None, **kwargs):
        if success:
            update_data = kwargs or {}
            update_data['status'] = update_status

            if self.volume_repo.update_vm_volume(
                    session, volume_id, expected_status=expected_status,
                    **update_data) == 1:
                self.status_queue.put(
                    {"resource_type": "volume",
                     "resource_id": volume_id,
                     "previous_status": expected_status,
                     "current_status": update_status,
                     "timestamp": timeutils.utcnow(),
                     "error_msg": error_msg or "",
                     "action": action})
            else:
                LOG.warn('The expected status of volume %(volume_id)s is not '
                         '%(expected_status)s, so update volume status failed',
                         {'volume_id': volume_id,
                          'expected_status': expected_status})
        else:
            LOG.warn("Fail to %(action)s volume %(volume_id)s, so not update "
                     "volume status", {'action': action,
                                       'volume_id': volume_id})

    def flatten(self, id):
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        backend = volume_obj.backend
        try:
            self.drivers[backend].flatten_volume(volume_obj)
        except Exception as e:
            LOG.error("Flatten volume failed")
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.FLATTENING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "flatten",
                "timestamp": timeutils.utcnow()})
            raise e

        LOG.info("Flatten volume %(vol_id)s successful",
                 {'vol_id': id})

        volume_obj.status = constants.IN_USE
        volume_obj.save(session)

        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": id,
            "previous_status": constants.FLATTENING,
            "current_status": constants.IN_USE,
            "action": "flatten",
            "timestamp": timeutils.utcnow()})

    def resize(self, id, volume_size, volume_state):
        session = db_api.get_session()
        volume_obj = self.volume_repo.get(session, id=id)
        db_vvm = self.vvm_repo.get(session, volume_id=id,
                                   attach_status=constants.ATTACHED)
        if db_vvm:
            vm_obj = self.vm_repo.get(session, db_vvm.virtual_machine_id)
        backend = volume_obj.backend

        try:
            self.drivers[backend].extend_volume(volume_obj,
                                                volume_size)
            if db_vvm:
                self.driver.reload_volume_size(vm_obj,
                                               id,
                                               volume_size)
        except Exception as e:
            LOG.error("Volume %(vol_id)s size change failed",
                      {'vol_id': id})
            self.volume_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": id,
                "previous_status": constants.RESIZING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "resize",
                "timestamp": timeutils.utcnow()})
            raise e

        self.volume_repo.update(session,
                                id, status=volume_state,
                                size=volume_size)
        LOG.info("Increasing the size of a volume "
                 "to %(vol_size)sG successful", {'vol_id': id,
                                                 'vol_size': volume_size})

        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": id,
            "previous_status": constants.RESIZING,
            "current_status": volume_state,
            "action": "resize",
            "timestamp": timeutils.utcnow()})
