# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import excutils
from oslo_utils import timeutils

from trochilus.agent.common import exceptions
from trochilus.agent.compute import event as virtevent
from trochilus.agent.compute.libvirt import driver
from trochilus.agent.compute.libvirt import power_state
from trochilus.common import constants
from trochilus.common import exceptions as api_exceptions
from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import image_repo
from trochilus.db import resource_provider_repo as rp_repo
from trochilus.db import snapshot_group_repo
from trochilus.db import snapshot_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import vm_volume_mapping_repo as vvm_repo
from trochilus.db import volume_repo

from trochilus.i18n import _

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class VM(object):

    def __init__(
            self, queue, volume_manager, network_manager, snapshot_manager):
        self.volume_repo = volume_repo.VolumeRepository()
        self.image_repo = image_repo.ImageRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.agent_repo = agent_repo.AgentRepository()
        self.res_alloc_repo = rp_repo.ResourceAllocationRepository()
        self.volume_manager = volume_manager
        self.network_manager = network_manager
        self.snapshot_manager = snapshot_manager
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.snapshot_group = snapshot_group_repo.SnapshotGroupRepository()
        self.driver = driver.LibvirtDriver(self.volume_manager)
        self.vvm_repo = vvm_repo.VMVolumeMappingRepository()
        self.status_queue = queue

    def _get_vm_volumes(self, vm_obj):
        volume_objs = [vvm.volume for vvm in vm_obj.vm_volume_mapping]
        return volume_objs

    def _create_volume(self, vvm_obj):
        LOG.info("Create volume %s for VM %s",
                 vvm_obj.volume_id, vvm_obj.virtual_machine_id)
        volume = vvm_obj.volume
        if volume.status != constants.AVAILABLE:
            if volume.volume_id:
                self.volume_manager.clone(volume.id, volume.volume_id)
            elif volume.snapshot_id:
                self.snapshot_manager.clone(
                    volume.snapshot_id, volume.id, flatten=False)
            else:
                self.volume_manager.create(volume.id)

    def _shutdown_vm(self, vm_obj):
        LOG.info("Shutting down VM %s", vm_obj.id)
        self.driver.destroy_vm(vm_obj)

    def _detach_volume(self, session, vvm_obj):
        """Detach a volume from an VM."""
        LOG.info('[VM %(vm_id)s] Detaching volume %(volume_id)s',
                 {'vm_id': vvm_obj.virtual_machine_id,
                  'volume_id': vvm_obj.volume_id})
        # TODO(liupeng) Call the driver to implement
        # the specific detach volume operation
        vvm_obj.attach_status = constants.DETACHED
        vvm_obj.volume.status = constants.AVAILABLE
        vvm_obj.save(session)

    def _attach_volume(self, session, vvm_obj):
        """Attach a volume to an VM."""
        LOG.info('[VM %s] Attaching volume %s',
                 vvm_obj.virtual_machine_id, vvm_obj.volume_id)
        vvm_obj.attach_status = constants.ATTACHED
        vvm_obj.save(session)

    def _cleanup_attach_info(self, session, vvm):
        volume_status = vvm.volume.status
        if volume_status in [constants.IN_USE, constants.PREPARE_CREATE]:
            self._detach_volume(session, vvm)

    def _cleanup_volumes(self, session, vm_obj, vvm_objs):
        # Delete the system volume which was created
        # by vm automatically and detach other volumes.
        for vvm in vvm_objs:
            auto_delete_volume = vvm.volume.auto_delete
            self._cleanup_attach_info(session, vvm)
            if auto_delete_volume:
                self.volume_manager.delete(vvm.volume_id)

    def _create_nic(self, nic_obj):
        # Nic dose not need to create resource actually
        if nic_obj.status == constants.ATTACHING:
            return self.network_manager.get_nic_config(
                nic_obj, CONF.vm_settings.virt_type)
        raise api_exceptions.NicStatusConflict(nic_id=nic_obj.id,
                                               action='attach',
                                               status=nic_obj.status)

    def get_vm_nics(self, vm_obj):
        nic_cfgs = []
        for nic_obj in sorted(vm_obj.nics,
                              key=lambda x: x.auto_delete,
                              reverse=True):
            nic_cfgs.append(
                self.network_manager.get_nic_config(
                    nic_obj, CONF.vm_settings.virt_type))
        return nic_cfgs

    def _update_nics_status(self, session, nic_ids, action,
                            update_status, expected_status=None,
                            hostname=None):
        for nic_id in nic_ids:
            self.network_manager.update_nic_status(
                session, nic_id, action, update_status,
                expected_status=expected_status, **{'hostname': hostname})

    def _cleanup_nics(self, session, nic_objs):
        # Nics does not need to actually delete resources.
        # Just delete auto-deleted nic and update other nics.
        for nic_obj in nic_objs:
            if nic_obj.auto_delete:
                self.network_manager.delete_nic(session, nic_obj.id)
            else:
                self.network_manager.update_nic_status(
                    session, nic_obj.id, 'detach',
                    constants.DOWN,
                    **{'owner_id': None,
                       'owner_type': constants.NIC_OF_RESERVE,
                       'hostname': None})

    def _flatten_vm(self, vvm_objs):
        for vvm in vvm_objs:
            self.volume_manager.flatten(vvm.volume_id)

    def flatten(self, id, **kwargs):
        LOG.info("[VM %s] flattening VM", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        vvm_objs = vm_obj.vm_volume_mapping
        old_vm_status = kwargs.get("old_vm_status", None)
        try:
            self._flatten_vm(vvm_objs)
        except Exception as e:
            with excutils.save_and_reraise_exception():
                LOG.info("Flatten VM %s failed.", vm_obj.id)
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({
                    "resource_type": "vm",
                    "resource_id": id,
                    "previous_status": constants.FLATTENING,
                    "current_status": constants.ERROR,
                    "error_msg": str(e),
                    "action": "flatten",
                    "timestamp": timeutils.utcnow()})

        LOG.info("Flatten VM %s successful.", vm_obj.id)

        vm_obj.status = old_vm_status
        vm_obj.save(session)

        self.status_queue.put({
            "resource_type": "vm",
            "resource_id": id,
            "previous_status": constants.FLATTENING,
            "current_status": old_vm_status,
            "action": "flatten",
            "timestamp": timeutils.utcnow()})

    def create(self, id):
        LOG.info("[VM %s] Creating VM", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        vvm_objs = vm_obj.vm_volume_mapping
        nic_objs = vm_obj.nics

        volume_objs = []
        nic_cfgs = []

        # Create volume resource
        for vvm in vvm_objs:
            try:
                self._create_volume(vvm)
            except Exception as e:
                with excutils.save_and_reraise_exception():
                    LOG.error('Create VM %s failed, Because volume resource'
                              ' creation failed.', vm_obj.id)
                    self.vm_repo.update(session, vm_obj.id,
                                        status=constants.ERROR)
                    # Delete resource allocation info about this host
                    self.res_alloc_repo.delete_allocations(id)
                    self.status_queue.put({
                        "resource_type": "vm",
                        "resource_id": id,
                        "previous_status": constants.CREATING,
                        "current_status": constants.ERROR,
                        "error_msg": str(e),
                        "action": "create",
                        "timestamp": timeutils.utcnow()})

            # Change volume and volume attach status
            self._attach_volume(session, vvm)
            volume_objs.append(vvm.volume)

        # Create nic resource
        for nic_obj in sorted(nic_objs,
                              key=lambda x: x.auto_delete,
                              reverse=True):
            try:
                nic_cfgs.append(self._create_nic(nic_obj))
            except Exception as e:
                with excutils.save_and_reraise_exception():
                    LOG.error('Create VM %s failed, Because nic resource'
                              ' creation failed', vm_obj.id)
                    self.vm_repo.update(session, vm_obj.id,
                                        status=constants.ERROR)
                    # Delete resource allocation info about this host
                    self.res_alloc_repo.delete_allocations(id)
                    self.status_queue.put({
                        "resource_type": "vm",
                        "resource_id": id,
                        "previous_status": constants.CREATING,
                        "current_status": constants.ERROR,
                        "error_msg": str(e),
                        "action": "create",
                        "timestamp": timeutils.utcnow()})

        try:
            # Create VM with libvirt driver
            self.driver.create_vm(vm_obj, volume_objs, nic_cfgs)
        except Exception:
            with excutils.save_and_reraise_exception():
                LOG.error("Create VM %s failed.", vm_obj.id)
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                # Delete resource allocation info about this host
                self.res_alloc_repo.delete_allocations(id)

        vm_obj.status = constants.ACTIVE
        vm_obj.save(session)

        LOG.info("[VM %s] Create VM successful", id)

        self.status_queue.put({
            "resource_type": "vm",
            "resource_id": id,
            "previous_status": constants.CREATING,
            "current_status": constants.ACTIVE,
            "action": "create",
            "timestamp": timeutils.utcnow()})

        self._update_nics_status(session, [nic_obj.id for nic_obj in nic_objs],
                                 'attach', constants.UP,
                                 expected_status=constants.ATTACHING,
                                 **{'hostname': vm_obj.agent.hostname})
        for vvm in vvm_objs:
            self.volume_manager.update_volume_status(
                session,
                vvm.volume_id,
                'attach', constants.IN_USE,
                expected_status=constants.AVAILABLE)

    def delete(self, id):
        LOG.info("[VM %s] Deleting VM", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        vvm_objs = vm_obj.vm_volume_mapping
        agent_obj = vm_obj.agent
        try:
            # Shut down first before deleting resources
            self._shutdown_vm(vm_obj)
            self._cleanup_volumes(session, vm_obj, vvm_objs)
            self._cleanup_nics(session, vm_obj.nics)
        except Exception as e:
            LOG.error('Delete VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "vm",
                                       "resource_id": id,
                                       "previous_status": constants.DELETING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "delete",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.DELETED
        vm_obj.vnc_address = None
        vm_obj.spice_address = None
        vm_obj.save(session)

        LOG.info("[VM %s] Delete successful", id)

        # Delete resource allocation info about this host
        self.res_alloc_repo.delete_allocations(id, agent_obj)

        self.status_queue.put({
            "resource_type": "vm",
            "resource_id": id,
            "previous_status": constants.DELETING,
            "current_status": constants.DELETED,
            "action": "delete",
            "timestamp": timeutils.utcnow()})

    def _power_on(self, vm_obj, volume_objs, nic_cfgs):
        self.driver.power_on(vm_obj, volume_objs, nic_cfgs)

    def _set_console_address(self, session, vm_power_state, db_vm):
        spice_add = CONF.vm_settings.spice_server_listen
        vnc_add = CONF.vm_settings.vnc_server_listen
        if vm_power_state == power_state.SHUTDOWN:
            db_vm.vnc_address = None
            db_vm.spice_address = None
        else:
            port_dict = self.driver.get_console_port(db_vm)
            if port_dict.get('vnc', None):
                db_vm.vnc_address = vnc_add + ":" + port_dict.get('vnc')
            if port_dict.get('spice', None):
                db_vm.spice_address = spice_add + ":" + port_dict.get('spice')
        db_vm.save(session)

    def start(self, id):
        LOG.info("[VM %s] Starting VM", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)

        volume_objs = self._get_vm_volumes(vm_obj)
        nic_cfgs = self.get_vm_nics(vm_obj)

        try:
            self._power_on(vm_obj, volume_objs, nic_cfgs)
        except Exception as e:
            LOG.error('Start VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "vm",
                                       "resource_id": id,
                                       "previous_status": constants.STARTING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "start",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.ACTIVE
        vm_obj.save(session)

        self.status_queue.put({
            "resource_type": "vm",
            "resource_id": id,
            "previous_status": constants.STARTING,
            "current_status": constants.ACTIVE,
            "action": "start",
            "timestamp": timeutils.utcnow()})

    def _power_off(self, vm_obj, force_stop=False):
        if force_stop:
            self.driver.power_off(vm_obj)
        else:
            timeout = CONF.vm_settings.clean_shutdown_timeout
            retry_interval = CONF.vm_settings.clean_shutdown_retry_interval
            self.driver.power_off(vm_obj, timeout, retry_interval)

    def stop(self, id):
        LOG.info("[VM %s] Stopping", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)

        try:
            self._power_off(vm_obj)
        except Exception as e:
            LOG.error('Stop VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "vm",
                                       "resource_id": id,
                                       "previous_status": constants.STOPPING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "stop",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.STOPPED
        vm_obj.save(session)

        LOG.info("[VM %s] Stop successful", id)

        self.status_queue.put({
            "resource_type": "vm",
            "resource_id": id,
            "previous_status": constants.STOPPING,
            "current_status": constants.STOPPED,
            "action": "stop",
            "timestamp": timeutils.utcnow()})

    def _reboot(self, vm_obj, volume_objs, nic_cfgs, reboot_type='SOFT'):
        self.driver.reboot(vm_obj, volume_objs, nic_cfgs, reboot_type)

    def reboot(self, id, reboot_type='SOFT'):
        """Reboot the given VM."""
        LOG.info("[VM %s] Rebooting", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        volume_objs = self._get_vm_volumes(vm_obj)
        nic_cfgs = self.get_vm_nics(vm_obj)
        try:
            self._reboot(vm_obj, volume_objs, nic_cfgs, reboot_type)
        except Exception as e:
            LOG.error('Reboot VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                self.status_queue.put({"resource_type": "vm",
                                       "resource_id": id,
                                       "previous_status": constants.REBOOTING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "reboot",
                                       "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.ACTIVE
        vm_obj.save(session)

        LOG.info("[VM %s] Reboot successful", id)

        self.status_queue.put({
            "resource_type": "vm",
            "resource_id": id,
            "previous_status": constants.REBOOTING,
            "current_status": constants.ACTIVE,
            "action": "reboot",
            "timestamp": timeutils.utcnow()})

    def _migrate(self, vm_obj, migrate_host):
        # Because it is a cold migration,we only need to
        # clear the residual resources on the source node
        self.driver._undefine_domain(vm_obj)
        # TODO(liupeng) Cleanup nic resource
        # TODO(liupeng) LVM disk migrate

    def migrate(self, id, migrate_host=None):
        """Migrate the given VM."""
        LOG.info("[VM %s] Migrating", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        agent_obj = self.agent_repo.get(session, hostname=migrate_host)

        try:
            self._migrate(vm_obj, migrate_host)
        except Exception as e:
            LOG.error('Migrate VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)

                # Delete resource allocation info about destination host
                self.res_alloc_repo.delete_allocations(id, agent_obj)

                self.status_queue.put({"resource_type": "vm",
                                       "resource_id": id,
                                       "previous_status": constants.MIGRATING,
                                       "current_status": constants.ERROR,
                                       "action": "migrate",
                                       "error_msg": str(e),
                                       "timestamp": timeutils.utcnow()})

        # Modify the agent id after the migration is successful
        vm_obj.agent_id = agent_obj.id
        # Because only cold migration is currently supported,
        # the migration and VM state is stopped
        vm_obj.status = constants.STOPPED
        vm_obj.save(session)

        LOG.info("[VM %s] Migrate successful", id)

        # Delete resource allocation info about this host
        cur_agent_obj = self.agent_repo.get(
            session, hostname=CONF.agent_settings.hostname)
        self.res_alloc_repo.delete_allocations(id, cur_agent_obj)

        self.status_queue.put({"resource_type": "vm",
                               "resource_id": id,
                               "previous_status": constants.MIGRATING,
                               "current_status": constants.STOPPED,
                               "action": "migrate",
                               "timestamp": timeutils.utcnow()})

    def _resize(self, vm_obj, volume_objs, nic_cfgs):
        self.driver.resize(vm_obj, volume_objs, nic_cfgs)
        if vm_obj.root_disk_gb:
            volume_obj = [vol for vol in volume_objs
                          if vol.bootable is True]
            if not volume_obj:
                msg = _("The boot volume of the virtual machine "
                        "%s cannot be found " % vm_obj.id)
                raise api_exceptions.VolumeNotFound(msg=msg)
            self.volume_manager.resize(volume_obj[0].id,
                                       vm_obj.root_disk_gb,
                                       volume_obj[0].status)

    def resize(self, id, vcpu, memory_mb, root_disk_gb):
        """Resize the given VM."""
        LOG.info("[VM %s] Resizing", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        volume_objs = self._get_vm_volumes(vm_obj)
        nic_cfgs = self.get_vm_nics(vm_obj)

        # Reserve old info for allocation info
        old_vcpu = vm_obj.vcpu
        old_memory_mb = vm_obj.memory_mb

        # Set the vm configuration but not save it
        vm_obj.vcpu = vcpu
        vm_obj.memory_mb = memory_mb
        vm_obj.root_disk_gb = root_disk_gb

        try:
            self._resize(vm_obj, volume_objs, nic_cfgs)
        except Exception as e:
            LOG.error('Resize VM %s failed.', vm_obj.id)
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, vm_obj.id,
                                    status=constants.ERROR)
                # Restore old allocation info about the host
                self.res_alloc_repo.update_allocations(
                    id, {constants.VCPU_CLASS_ID: old_vcpu,
                         constants.MEMORY_CLASS_ID: old_memory_mb})

                self.status_queue.put({"resource_type": "vm",
                                       "resource_id": id,
                                       "previous_status": constants.RESIZING,
                                       "current_status": constants.ERROR,
                                       "error_msg": str(e),
                                       "action": "resize",
                                       "timestamp": timeutils.utcnow()})

        # Resize only allows stopped VM operations,
        # so here the stopped state is restored
        vm_obj.status = constants.STOPPED
        vm_obj.save(session)

        LOG.info("[VM %s] Resize successful", id)

        self.status_queue.put({"resource_type": "vm",
                               "resource_id": id,
                               "previous_status": constants.RESIZING,
                               "current_status": constants.STOPPED,
                               "action": "resize",
                               "timestamp": timeutils.utcnow()})

    def _rebuild_from_image_or_snap(
            self, vm_obj, root_disk_id, image_id, snapshot_id, old_vm_status):
        if old_vm_status == constants.ACTIVE:
            self._shutdown_vm(vm_obj)
            self.volume_manager.rebuild(root_disk_id, image_id, snapshot_id)
            self._power_on(vm_obj, self._get_vm_volumes(vm_obj),
                           self.get_vm_nics(vm_obj))
        else:
            self.volume_manager.rebuild(root_disk_id, image_id, snapshot_id)

    def _get_vm_root_disk(self, vm_obj):
        # We don't support root disk detach operations.
        # So attached_index==0 is sys disk volume
        vvm = [vvm for vvm in vm_obj.vm_volume_mapping
               if vvm.attached_index == 0]
        if vvm:
            return vvm[0].volume
        raise exceptions.CanNotFindVMRootDisk(vm_id=vm_obj.id)

    def rebuild(self, id, **kwargs):
        """Rebuild the given VM's root disk."""
        LOG.info("[VM %s] Rebuilding", id)

        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        root_disk = self._get_vm_root_disk(vm_obj)

        old_vm_status = kwargs.get('old_vm_status', None)
        image_id = kwargs.get('image_id', None)
        snapshot_id = kwargs.get('snapshot_id', None)

        if image_id or snapshot_id:
            try:
                self._rebuild_from_image_or_snap(
                    vm_obj, root_disk.id, image_id, snapshot_id, old_vm_status)
            except Exception as e:
                LOG.error('Rebuild VM %s failed.', vm_obj.id)
                with excutils.save_and_reraise_exception():
                    self.vm_repo.update(session, vm_obj.id,
                                        status=constants.ERROR)
                    self.status_queue.put(
                        {"resource_type": "vm",
                         "resource_id": id,
                         "previous_status": constants.REBUILDING,
                         "current_status": constants.ERROR,
                         "error_msg": str(e),
                         "action": "rebuild",
                         "timestamp": timeutils.utcnow()})

        vm_obj.status = old_vm_status
        vm_obj.save(session)

        LOG.info("[VM %s] Rebuild successful", id)

        self.status_queue.put(
            {"resource_type": "vm",
             "resource_id": id,
             "previous_status": constants.REBUILDING,
             "current_status": old_vm_status,
             "action": "rebuild",
             "timestamp": timeutils.utcnow()})

    def unquiesce(self, id):
        """Unquiesce VM."""
        LOG.info("[VM %s] Attempting to unquiesce VM.", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)

        try:
            self.driver.unquiesce(vm_obj)
        except Exception as e:
            LOG.warning('[VM %(id)s] Skipping unquiescing vm: %(reason)s.',
                        {'reason': str(e), "id": id})

    def quiesce(self, id):
        """Quiesce VM."""
        LOG.info("[VM %s] Attempting to quiesce VM.", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)

        try:
            self.driver.quiesce(vm_obj)
        except Exception as e:
            LOG.warning('[VM %s] Skipping quiescing vm: %(reason)s.',
                        {'reason': str(e), "id": id})

    def _sync_vm_power_state(self, session, db_vm, vm_power_state):
        if CONF.agent_settings.hostname != db_vm.agent.hostname:
            LOG.info("During the sync_power process the "
                     "VM has moved from "
                     "host %(src)s to host %(dst)s",
                     {'src': CONF.agent_settings.hostname,
                      'dst': db_vm.agent.hostname})
            return

        if (db_vm.status == constants.ACTIVE and
                vm_power_state == power_state.SHUTDOWN):
            db_vm.status = constants.STOPPED
            db_vm.save(session)
            LOG.warning("The VM shuts down abnormally.")
            self.status_queue.put(
                {"resource_type": "vm",
                 "resource_id": db_vm.id,
                 "previous_status": constants.ACTIVE,
                 "current_status": constants.STOPPED,
                 "action": "stop",
                 "timestamp": timeutils.utcnow()})
        elif db_vm.status == constants.STOPPED:
            if vm_power_state != power_state.SHUTDOWN:
                LOG.warning("[VM %s] VM status is %s, But VM's power status "
                            "is running.", db_vm.id, db_vm.status)
        self._set_console_address(session, vm_power_state, db_vm)

    def handle_lifecycle_event(self, event):
        session = db_api.get_session()
        vm_id = event.get_vm_uuid()
        db_vm = self.vm_repo.get(session, vm_id)
        LOG.info("[VM %(vm_uuid)s] VM %(state)s (Lifecycle Event)",
                 {'vm_uuid': vm_id, 'state': event.get_name()})

        vm_power_state = None
        event_transition = event.get_transition()
        # TODO(liupeng) Handle SUSPENDED, MIGRATE, POSTCOPY event
        if event.get_transition() == virtevent.EVENT_LIFECYCLE_STOPPED:
            vm_power_state = power_state.SHUTDOWN
        elif event.get_transition() == virtevent.EVENT_LIFECYCLE_STARTED:
            vm_power_state = power_state.RUNNING
        elif event.get_transition() == virtevent.EVENT_LIFECYCLE_PAUSED:
            vm_power_state = power_state.PAUSED
        elif event.get_transition() == virtevent.EVENT_LIFECYCLE_RESUMED:
            vm_power_state = power_state.RUNNING
        else:
            LOG.warning("Unexpected lifecycle event: %d", event_transition)

        current_power_state = self.driver.get_info(db_vm).state
        # The event may be delayed, thus not reflecting
        # the current VM power state. In that case, ignore the event.
        if current_power_state == vm_power_state:
            LOG.debug('[VM %(vm_id)s] Synchronizing VM power state after '
                      'lifecycle event "%(event)s"; current vm_state:'
                      ' %(vm_state)s,  VM power_state: %(vm_power_state)s',
                      {'event': event.get_name(),
                       'vm_state': db_vm.status,
                       'vm_power_state': vm_power_state,
                       'vm_id': db_vm.id})
            self._sync_vm_power_state(session, db_vm, vm_power_state)

    def handle_events(self, event):
        if isinstance(event, virtevent.LifecycleEvent):
            try:
                self.handle_lifecycle_event(event)
            except (api_exceptions.NotFound, exceptions.VMNotFound):
                LOG.debug("Event %s arrived for non-existent VM. The "
                          "VM was probably deleted.", event)
        else:
            LOG.debug("Ignoring event %s", event)

    def init_virt_events(self):
        self.driver.register_event_listener(self.handle_events)

    def init_host(self):
        self.driver.initialize()
        self.init_virt_events()

    def attach_nic(self, id, nic_id):
        vm_id = id
        session = db_api.get_session()
        # Check if vm exists
        db_vm = self.vm_repo.get(session, vm_id)
        if not db_vm:
            raise api_exceptions.NotFound(resource='vm', id=vm_id)
        # Check if the status of nic conflicts
        nic = [nic for nic in db_vm.nics if nic_id == nic.id][0]
        if nic_id == nic.id and nic.status != constants.ATTACHING:
            raise api_exceptions.NicStatusConflict(nic_id=nic_id,
                                                   action='attach_nic',
                                                   status=nic.status)
        nic_cfg = self.network_manager.get_nic_config(
            nic, CONF.vm_settings.virt_type)
        try:
            self.driver.attach_nic(db_vm, nic_cfg)
        except Exception as e:
            LOG.error("attach nic failed ,reason: %(msg)s",
                      {'nic_id': nic_id, 'msg': e})
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, db_vm.id,
                                    status=constants.ERROR)
                self.status_queue.put(
                    {"resource_type": "vm",
                     "resource_id": db_vm.id,
                     "previous_status": constants.NIC_ATTACHING,
                     "current_status": constants.ERROR,
                     "error_msg": str(e),
                     "action": "attach_nic",
                     "timestamp": timeutils.utcnow()})
        else:
            db_vm.status = constants.ACTIVE
            db_vm.save(session)
            self.status_queue.put({
                "resource_type": "vm",
                "resource_id": db_vm.id,
                "previous_status": constants.NIC_ATTACHING,
                "current_status": constants.ACTIVE,
                "action": "attach_nic",
                "timestamp": timeutils.utcnow()})

            self.network_manager.update_nic_status(
                session, nic_id, 'attach', constants.UP,
                expected_status=constants.ATTACHING,
                **{'hostname': db_vm.agent.hostname})

    def detach_nic(self, id, nic_id):
        vm_id = id
        session = db_api.get_session()
        db_vm = self.vm_repo.get(session, vm_id)
        # Check if vm exists
        if not db_vm:
            raise api_exceptions.NotFound(resource='vm', id=vm_id)
        # Check if the status of nic conflicts
        nic = [nic for nic in db_vm.nics if nic_id == nic.id][0]
        if nic_id == nic.id and nic.status != constants.DETACHING:
            raise api_exceptions.NicStatusConflict(nic_id=nic_id,
                                                   action='detach_nic',
                                                   status=nic.status)
        nic_cfg = self.network_manager.get_nic_config(
            nic, CONF.vm_settings.virt_type)
        try:
            self.driver.detach_nic(db_vm, nic_cfg)
        except Exception as e:
            LOG.error("detach nic failed ,reason: %(msg)s",
                      {'nic_id': nic_id, 'msg': e})
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, db_vm.id,
                                    status=constants.ERROR)
                self.status_queue.put(
                    {"resource_type": "vm",
                     "resource_id": db_vm.id,
                     "previous_status": constants.NIC_DETACHING,
                     "current_status": constants.ERROR,
                     "error_msg": str(e),
                     "action": "detach_nic",
                     "timestamp": timeutils.utcnow()})
        else:
            db_vm.status = constants.ACTIVE
            db_vm.save(session)
            self.status_queue.put({
                "resource_type": "vm",
                "resource_id": db_vm.id,
                "previous_status": constants.NIC_DETACHING,
                "current_status": constants.ACTIVE,
                "action": "detach_nic",
                "timestamp": timeutils.utcnow()})

            self.network_manager.update_nic_status(
                session, nic_id, 'detach', constants.DOWN,
                expected_status=constants.DETACHING,
                **{'owner_id': None,
                   'owner_type': constants.NIC_OF_RESERVE,
                   'hostname': None})

    def update_vm_status(self, session, vm_id, action, update_status,
                         expected_status=None, success=True, **kwargs):
        if success:
            update_data = kwargs or {}
            update_data['status'] = update_status
            if self.vm_repo.update(session, vm_id,
                                   expected_status=expected_status,
                                   **update_data) == 1:
                self.status_queue.put(
                    {"resource_type": "vm",
                     "resource_id": vm_id,
                     "previous_status": expected_status,
                     "current_status": update_status,
                     "timestamp": timeutils.utcnow(),
                     "action": action})
            else:
                LOG.warn('The expected status of vm %(vm_id)s is not '
                         '%(expected_status)s, so update vm status failed',
                         {'vm_id': vm_id,
                          'expected_status': expected_status})
        else:
            LOG.warn("Fail to %(action)s vm %(vm_id)s, so not update "
                     "vm status", {'action': action, 'vm_id': vm_id})

    def attach_volume(self, id, volume_id, vvm_id):
        session = db_api.get_session()
        db_vm = self.vm_repo.get(session, id)
        db_volume = self.volume_repo.get(session, id=volume_id)

        # Generate volume config info
        backend = db_volume.backend
        volume_cfg = self.volume_manager.drivers[backend].get_disk_config(
            db_volume)

        # Query libvirt driver attach volume
        try:
            self.driver.attach_volume(db_vm, volume_cfg)
        except Exception as e:
            LOG.error("Attach volume %(volume_id)s for VM %(vm_id)s failed:"
                      " %(reason)s", {'volume_id': volume_id,
                                      'vm_id': id, 'reason': str(e)})
            with excutils.save_and_reraise_exception():
                # If attach failed.
                # 1. Delete the vvm record.
                # 2  Change volume status to available.
                # 3. Send volume webhook with error msg in
                #    update_volume_status() method
                self.vvm_repo.delete(session, id=vvm_id)
                self.volume_manager.update_volume_status(
                    session, volume_id, 'attach', constants.AVAILABLE,
                    expected_status=constants.ATTACHING, error_msg=str(e))
        else:
            # We don't send VM webhook. Because attach/detach volume
            # don't effect VM status.
            # If attach success.
            # 1. Update the vvm attach_status to attached.
            # 2. Update the volume status to in-use.
            # 3. Send volume webhook in update_volume_status() method
            self.vvm_repo.update(session, vvm_id,
                                 attach_status=constants.ATTACHED)
            self.volume_manager.update_volume_status(
                session, volume_id, 'attach', constants.IN_USE,
                expected_status=constants.ATTACHING)

        # If the volume has a snapshot group and is attached to other VM,
        # we need to delete all snapshots of the volume.
        # At the same time, the volume is released from the snapshot group.
        db_vvms = self.vvm_repo.get_all(session,
                                        volume_id=volume_id,
                                        attach_status=constants.DETACHED)
        if db_vvms[0]:
            sg_vm = sorted(db_vvms[0],
                           key=lambda x: x.created_at,
                           reverse=True)[0]
            if sg_vm.virtual_machine_id != db_vm.id:
                db_sgs = self.snapshot_group.get_all(
                    session,
                    virtual_machine_id=sg_vm.virtual_machine_id)
                if db_sgs[0]:
                    for db_sg in db_sgs[0]:
                        for db_ss in db_sg.snapshot:
                            if db_ss.volume_id == volume_id:
                                self.snapshot_manager.delete(db_ss.id)
                                db_sg.size = db_sg.size - db_volume.size
                                self.snapshot_group.update(session,
                                                           db_sg.id,
                                                           size=db_sg.size)
                                break

    def detach_volume(self, id, volume_id, vvm_id):
        session = db_api.get_session()
        db_vm = self.vm_repo.get(session, id)
        db_volume = self.volume_repo.get(session, id=volume_id)

        backend = db_volume.backend
        volume_cfg = self.volume_manager.drivers[backend].get_disk_config(
            db_volume)
        try:
            # The detach volume for delete VM does not invoke driver method.
            # Beacuase delete VM operation has poweroff VM, and wile delete.
            if db_vm.status != constants.DELETING:
                self.driver.detach_volume(db_vm, volume_cfg)
        except Exception as e:
            LOG.error("detach volume failed ,reason: %(msg)s",
                      {'volume_id': volume_id, 'msg': e})
            with excutils.save_and_reraise_exception():
                # We don't send VM webhook. Because attach/detach volume
                # don't effect VM status.
                # If detach volume failed.
                # 1. Update the vvm attach_status to attached.
                # 2. Update the volume status to in-use.
                # 3. Send volume webhook with error msg in
                #    update_volume_status() method
                self.vvm_repo.update(session, vvm_id,
                                     attach_status=constants.ATTACHED)
                self.volume_manager.update_volume_status(
                    session, volume_id, 'attach', constants.IN_USE,
                    expected_status=constants.DETACHING, error_msg=str(e))
        else:
            # We don't send VM webhook. Because attach/detach volume
            # don't effect VM status.
            # If detach volume success.
            # 1. Update the vvm attach_status to detached.
            # 2. Update the volume status to available.
            # 3. Send volume webhook in update_volume_status() method
            self.vvm_repo.update(session, vvm_id,
                                 attach_status=constants.DETACHED)
            # If volume status is deleting, it is a cascading deletion of
            # the volume, we do not set the available status of the volume
            # after the detach is successful.
            if db_volume.status == constants.DELETING:
                return
            # If not delete volume, we update volume status to available.
            self.volume_manager.update_volume_status(
                session, volume_id, 'detach', constants.AVAILABLE,
                expected_status=constants.DETACHING)

    def _revert(self, vm_obj, snapshot_obj):
        '''Revert VM

        1. Force stop VM if vm power state is running
        2. Revert system volume
        3. Start VM
        '''
        is_vm_running = self.driver.get_info(
            vm_obj).state == power_state.RUNNING
        if is_vm_running:
            # Force stop
            self.driver.power_off(vm_obj)
        # Revert system volume
        self.volume_manager.revert(
            snapshot_obj.volume.id,
            snapshot_obj.id,
            constants.IN_USE)
        # Power on
        self._power_on(vm_obj,
                       self._get_vm_volumes(vm_obj),
                       self.get_vm_nics(vm_obj))

    def revert(self, id, sys_snapshot_id):
        LOG.info("[VM %s] Reverting", id)
        session = db_api.get_session()
        vm_obj = self.vm_repo.get(session, id=id)
        snapshot_obj = self.snapshot_repo.get(session, id=sys_snapshot_id)

        try:
            self._revert(vm_obj, snapshot_obj)
        except Exception as e:
            LOG.error("revert VM %(vm_id)s failed ,reason: %(msg)s",
                      {'vm_id': id, 'msg': e})
            with excutils.save_and_reraise_exception():
                self.vm_repo.update(session, id,
                                    status=constants.ERROR)
                self.status_queue.put(
                    {"resource_type": "vm",
                     "resource_id": id,
                     "previous_status": constants.REVERTING,
                     "current_status": constants.ERROR,
                     "error_msg": str(e),
                     "action": "revert",
                     "timestamp": timeutils.utcnow()})

        vm_obj.status = constants.ACTIVE
        vm_obj.save(session)

        self.status_queue.put(
            {"resource_type": "vm",
             "resource_id": id,
             "previous_status": constants.REVERTING,
             "current_status": constants.ACTIVE,
             "action": "revert",
             "timestamp": timeutils.utcnow()})
