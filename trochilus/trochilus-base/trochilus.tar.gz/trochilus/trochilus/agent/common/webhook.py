# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import time

import eventlet

from oslo_config import cfg
from oslo_log import log as logging
import requests

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class StatusWebhook(object):

    def __init__(self, queue):
        self._pool = eventlet.GreenPool(size=16)
        self.event_queue = queue
        self.base_url = "http://{}:{}/{}".format(
            CONF.webhook_settings.target_host,
            CONF.webhook_settings.target_port,
            CONF.webhook_settings.target_path)
        self.expected_codes = CONF.webhook_settings.expected_codes
        self.session = requests.Session()
        self.method = CONF.webhook_settings.method.lower()
        self.reqargs = {
            'url': self.base_url,
            'timeout': (CONF.webhook_settings.request_conn_timeout,
                        CONF.webhook_settings.request_read_timeout), }
        self.headers = self.reqargs.setdefault('headers', {})
        if CONF.webhook_settings.auth_token:
            self.headers['X-Auth-Token'] = CONF.webhook_settings.auth_token

    def run_event_listener(self):
        eventlet.spawn_n(self._send_event_loop)

    def _send_event_loop(self):
        while True:
            LOG.debug("Starting a new co-routine to listen and push "
                      "the status event.")
            self._pool.spawn_n(self._wait_and_push_event)

    def _wait_and_push_event(self):
        # The coroutine will be block while the queue has no msg.
        event_data = self.event_queue.get()
        payload = {
            'resource_type': event_data.get('resource_type'),
            'resource_id': event_data.get('resource_id'),
            'current_status': event_data.get('current_status'),
            'previous_status': event_data.get('previous_status', ""),
            'action': event_data.get('action', "unknow"),
            'error_msg': event_data.get('error_msg', ""),
            'timestamp': str(event_data.get('timestamp')),
        }
        # To facilitate debugging, output webhook information before sending
        LOG.debug("Sending webhook to %s: %s", self.base_url, payload)

        _request = getattr(self.session, self.method)
        for dummy in range(CONF.webhook_settings.max_retries):
            try:
                r = _request(json=payload, **self.reqargs)
                if str(r.status_code) not in self.expected_codes:
                    LOG.warning("The status code %s of the targer service "
                                "response is not expected.", r.status_code)
                    exception = "Invalid response status code"
                    time.sleep(CONF.webhook_settings.retry_interval)
                else:
                    return
            except (requests.ConnectionError, requests.Timeout) as e:
                exception = e
                LOG.warning("Could not connect to agent. Retrying.")
                time.sleep(CONF.webhook_settings.retry_interval)
        LOG.error("Push event retries exhausted, the webhook target service "
                  "is abnormal. Reason: %s", exception)
