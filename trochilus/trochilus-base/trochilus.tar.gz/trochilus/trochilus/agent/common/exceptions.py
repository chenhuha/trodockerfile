# Copyright 2014 Rackspace
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from webob import exc

from oslo_log import log as logging
from oslo_serialization import jsonutils

from trochilus.common import exceptions
from trochilus.i18n import _

LOG = logging.getLogger(__name__)


def check_exception(response, ignore=tuple(), log_error=True, agent_id=''):
    status_code = response.status_code
    responses = {
        400: InvalidRequest,
        401: Unauthorized,
        403: Forbidden,
        404: NotFound,
        405: InvalidRequest,
        409: Conflict,
        500: InternalServerError,
        503: ServiceUnavailable
    }
    if (status_code not in ignore) and (status_code in responses):
        try:
            if log_error:
                LOG.error('Trochilus agent returned unexpected result code %s '
                          'with response %s', status_code, response.json())
        except Exception:
            # Handle the odd case where there is no response body
            # like when using requests_mock which doesn't support has_body
            pass
        raise exceptions.AgentClientError(
            agent_id=agent_id, code=status_code,
            msg=response.json())

    return response


class APIException(exc.HTTPClientError):
    msg = "Something unknown went wrong"
    code = 500

    def __init__(self, **kwargs):
        if 'msg' in kwargs:
            msg = kwargs.get("msg")
            if isinstance(msg, dict):
                msg = jsonutils.dumps(msg)
        else:
            msg = self.msg
        self.msg = msg % kwargs
        super().__init__(detail=self.msg)


class InvalidRequest(APIException):
    msg = "Invalid request"
    code = 400


class Unauthorized(APIException):
    msg = "Unauthorized"
    code = 401


class Forbidden(APIException):
    msg = "Forbidden"
    code = 403


class NotFound(APIException):
    msg = "Not Found"
    code = 404


class Conflict(APIException):
    msg = "Conflict"
    code = 409


class InternalServerError(APIException):
    msg = "Internal Server Error"
    code = 500


class ServiceUnavailable(APIException):
    msg = "Service Unavailable"
    code = 503


class BackendVolumeDriverInvalid(InternalServerError):
    msg = ("Volume driver is invalid for backend %(backend)s:"
           " current value is %(volume_driver)s")


class ImageUnacceptable(InvalidRequest):
    msg = _("Image %(image_id)s is unacceptable: %(reason)s")


class VpcDriverInvalid(InternalServerError):
    msg = "Vpc driver is invalid. Please check config file"


class VpcOperationFailded(InternalServerError):
    msg = _("Vpc with id %(vpc_id)s %(action)s failed")


class VlanOperationFailed(InternalServerError):
    msg = _("Vlan with id %(vlan_id)s %(action)s failed")


class BridgeOperationFailed(InternalServerError):
    msg = _("Bridge with name %(name)s %(action)s failed")


class HypervisorUnavailable(InternalServerError):
    msg = _("Connection to the hypervisor is broken on host")


class PciDeviceNotFoundById(NotFound):
    msg = _("PCI device %(id)s not found")


class PciDeviceWrongAddressFormat(InternalServerError):
    msg = _("The PCI address %(address)s has an incorrect format.")


class VMNotFound(NotFound):
    msg = _("VM %(vm_id)s could not be found")


class VMPowerOffFailure(InternalServerError):
    msg = _("Failed to power off instance: %(reason)s")


class VolumeAttached(InternalServerError):
    msg = _("Volume %(volume_id)s is still attached, detach volume first.")


class CanNotFindVMRootDisk(InternalServerError):
    msg = _("Can not find (VM %(vm_id)s)'s root disk")


class DeviceNotFound(InternalServerError):
    msg = _("Device '%(device)s' '%(id)s' not found.")


class ObjectInUse(InternalServerError):
    msg = _("%(object)s %(id)s is in use.")


class NicAttachFailed(InternalServerError):
    msg = _("Failed to attach network adapter device to vm"
            "%(vm_id)s")


class DeviceDetachFailed(InternalServerError):
    msg = _("Device detach failed for %(device)s: %(reason)s")


class SnapshotIsBusy(InternalServerError):
    msg = _("deleting snapshot %(snapshot_name)s that has "
            "dependent volumes")


class VolumeBackendAPIException(InternalServerError):
    msg = _("Bad or unexpected response from the storage volume "
            "backend API: %(data)s")


class SnapRevertFailed(InternalServerError):
    msg = _("Failed revert volume to snapshot %(snapshot_id)s")


class CommitVOIVMFailed(InternalServerError):
    msg = _("Failed to commit vm %(vm_id)s: %(reason)s")


class CommitShareDiskFailed(InternalServerError):
    msg = _("Failed to commit share disk %(path)s: %(reason)s")


class CommitBackupDiskFailed(InternalServerError):
    msg = _("Failed to commit disk %(path)s: %(reason)s")


class VOIVMAddVolumeFailed(InternalServerError):
    msg = _("Failed to add volume for vm %(vm_id)s: %(reason)s")


class VOIVMRemoveVolumeFailed(InternalServerError):
    msg = _("Failed to remove volume for vm %(vm_id)s: %(reason)s")


class VolumeNotFound(NotFound):
    msg = _("Mounted volume %(volume_id)s not found")


class WaitTimeout(InternalServerError):
    msg = _("waits for %(wait_what)s timeout")


class DhcpPackagesUninstall(InternalServerError):
    msg = _("os must install dnsmasq and dnsmasq-utils")


class ActionNotSupport(InternalServerError):
    msg = _('%(resource)s does not support %(action)s')


class InvalidImageFormat(InternalServerError):
    msg = _("The image format %(format)s don't support.")
