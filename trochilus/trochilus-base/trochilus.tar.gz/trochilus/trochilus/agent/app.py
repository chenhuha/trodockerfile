#    Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import queue as event_queue
import sys
import webob

import eventlet
import flask
from oslo_config import cfg
from oslo_log import log as logging
from oslo_serialization import jsonutils
from oslo_service import loopingcall
from oslo_utils import timeutils
from werkzeug import exceptions

from trochilus.agent import cascade
from trochilus.agent.common import resource_processing_queue as queue
from trochilus.agent.common import webhook
from trochilus.agent.inspector import vm_inspector
from trochilus.agent.inspector import voi_inspector
from trochilus.agent import network
from trochilus.agent import network_card
from trochilus.agent import node
from trochilus.agent import snapshot
from trochilus.agent import snapshot_group
from trochilus.agent import vm
from trochilus.agent import voi
from trochilus.agent import volume
from trochilus.common import constants
from trochilus.common import service as trochilus_service
from trochilus.db import api as db_api
from trochilus.db import snapshot_group_repo as sg_repo
from trochilus.db import snapshot_repo
from trochilus.db import virtual_machine_repo as vm_repo
from trochilus.db import vm_volume_mapping_repo as vvm_repo
from trochilus.db import voi_repo
from trochilus.db import volume_repo
from trochilus.db import vpc_repo

LOG = logging.getLogger(__name__)
CONF = cfg.CONF
PATH_PREFIX = '/v1.0'

VM_ACTIONS = ['create', 'delete', 'start',
              'stop', 'reboot', 'migrate', 'resize', 'rebuild',
              'attach_nic', 'detach_nic', 'attach_volume', 'detach_volume',
              'flatten', 'revert', 'replace_iso', 'commit', 'add_volume',
              'remove_volume', 'attach_share_template_volume',
              'detach_share_template_volume']

SNAPSHOT_GROUP_ACTIONS = ['create', 'delete', 'revert']
STORAGE_ACTIONS = ['create', 'delete', 'clone', 'revert', 'resize']
CASCADE_ACTION = ['delete_volume', 'delete_vm', 'rebuild_vm']

ACTION_DICT = {
    'create': constants.CREATING,
    'delete': constants.DELETING,
    'start': constants.STARTING,
    'stop': constants.STOPPING,
    'reboot': constants.REBOOTING,
    'migrate': constants.MIGRATING,
    'resize': constants.RESIZING,
    'rebuild': constants.REBUILDING,
    'attach_nic': constants.NIC_ATTACHING,
    'detach_nic': constants.NIC_DETACHING,
    'attach_volume': constants.VOLUME_ATTACHING,
    'detach_volume': constants.VOLUME_DETACHING,
    'flatten': constants.FLATTENING,
    'revert': constants.REVERTING,
    'clone': constants.CLONING,
    'attach': constants.ATTACHING,
    'detach': constants.DETACHING,
    'delete_volume': constants.DELETING,
    'delete_vm': constants.DELETING,
    'reset': constants.RESETTING,
    'replace_iso': constants.REPLACING_ISO,
    'commit': constants.COMMITTING,
    'add_volume': constants.ADDING_VOLUME,
    'remove_volume': constants.REMOVING_VOLUME,
    'rebuild_vm': constants.REBUILDING,
    'attach_share_template_volume': constants.VOLUME_ATTACHING,
    'detach_share_template_volume': constants.VOLUME_DETACHING
}

EXPECTED_STATUS_MAPPING = {
    'create': constants.PREPARE_CREATE,
    'delete': constants.PREPARE_DELETE,
    'start': constants.PREPARE_START,
    'stop': constants.PREPARE_STOP,
    'reboot': constants.PREPARE_REBOOT,
    'migrate': constants.PREPARE_MIGRATE,
    'resize': constants.PREPARE_RESIZE,
    'rebuild': constants.PREPARE_REBUILD,
    'attach_nic': constants.PREPARE_NIC_ATTACH,
    'detach_nic': constants.PREPARE_NIC_DETACH,
    'revert': constants.PREPARE_REVERT,
    'clone': constants.PREPARE_CLONE,
    'flatten': constants.PREPARE_FLATTEN,
    'attach_volume': constants.PREPARE_VOLUME_ATTACH,
    'detach_volume': constants.PREPARE_VOLUME_DETACH,
    'attach': constants.PREPARE_ATTACH,
    'detach': constants.PREPARE_DETACH,
    'delete_volume': constants.PREPARE_DELETE,
    'delete_vm': constants.PREPARE_DELETE,
    'reset': constants.PREPARE_RESET,
    'replace_iso': constants.PREPARE_REPLACE_ISO,
    'commit': constants.PREPARE_COMMIT,
    'add_volume': constants.PREPARE_ADD_VOLUME,
    'remove_volume': constants.PREPARE_REMOVE_VOLUME,
    'rebuild_vm': constants.PREPARE_REBUILD,
    'attach_share_template_volume': constants.PREPARE_VOLUME_ATTACH,
    'detach_share_template_volume': constants.PREPARE_VOLUME_DETACH
}

PRIORITY_RELATED_NODE = 0

STATUS_EVENT_QUEUE = event_queue.Queue()


def setup_app(argv=None):
    if argv is None:
        argv = sys.argv
    trochilus_service.prepare_service(argv)
    cfg.CONF.log_opt_values(LOG, logging.INFO)

    status_webhook = webhook.StatusWebhook(STATUS_EVENT_QUEUE)
    status_webhook.run_event_listener()
    agent_server = AgentServrer()

    # Agent loop
    report_loop = loopingcall.FixedIntervalLoopingCall(
        agent_server.node.report_node_state)
    report_loop.start(interval=CONF.agent_settings.report_interval,
                      stop_on_exception=False)
    # Vpc loop
    sync_vpc_loop = loopingcall.FixedIntervalLoopingCall(
        agent_server.network.sync_vpc)
    sync_vpc_loop.start(
        interval=CONF.agent_settings.sync_vpc_interval,
        stop_on_exception=False)
    # Dhcp loop
    sync_dhcp_loop = loopingcall.FixedIntervalLoopingCall(
        agent_server.network.sync_dhcp)
    sync_dhcp_loop.start(
        interval=CONF.agent_settings.sync_dhcp_interval,
        stop_on_exception=False)
    # Netcard loop
    netcard_loop = loopingcall.FixedIntervalLoopingCall(
        agent_server.network_card.report_network_info)
    netcard_loop.start(
        interval=CONF.agent_settings.report_network_info_interval,
        stop_on_exception=False)
    # VOI and VDI power status inspect loop
    loopingcall.FixedIntervalLoopingCall(
        agent_server.vm_insp.get_inspector(
            constants.POWER_STATUS_INSPECTOR)).start(
        interval=CONF.agent_settings.power_status_inspector_interval,
        stop_on_exception=False)
    loopingcall.FixedIntervalLoopingCall(
        agent_server.voi_vm_insp.get_inspector(
            constants.POWER_STATUS_INSPECTOR)).start(
        interval=CONF.agent_settings.power_status_inspector_interval,
        stop_on_exception=False)
    # VOI and VDI create timeout inspect loop
    if CONF.agent_settings.vm_create_timeout:
        loopingcall.FixedIntervalLoopingCall(
            agent_server.vm_insp.get_inspector(
                constants.CREATE_TIMEOUT_INSPECTOR)).start(
            interval=CONF.agent_settings.create_timeout_inspector_interval,
            stop_on_exception=False)
    if CONF.agent_settings.voi_vm_create_timeout:
        loopingcall.FixedIntervalLoopingCall(
            agent_server.voi_vm_insp.get_inspector(
                constants.CREATE_TIMEOUT_INSPECTOR)).start(
            interval=CONF.agent_settings.create_timeout_inspector_interval,
            stop_on_exception=False)

    agent_server.run_loop()
    return agent_server.app, agent_server


# make the error pages all json
def make_json_error(ex):
    code = ex.code if isinstance(ex, exceptions.HTTPException) else 500
    response = webob.Response(json={'error': str(ex), 'http_code': code})
    response.status_code = code
    return response


def register_app_error_handler(app):
    for code in exceptions.default_exceptions:
        app.register_error_handler(code, make_json_error)


class AgentServrer(object):

    def __init__(self):
        self._queue = queue.ResourceProcessingQueue()
        self._pool = eventlet.GreenPool(size=8)
        self.app = flask.Flask(__name__)
        self.node = node.Node()
        self.snapshot = snapshot.Snapshot(STATUS_EVENT_QUEUE)
        self.volume = volume.Volume(STATUS_EVENT_QUEUE)
        self.network = network.Network(STATUS_EVENT_QUEUE)
        self.network_card = network_card.Network()
        self.network.init_host()
        self.vm = vm.VM(
            STATUS_EVENT_QUEUE, self.volume, self.network, self.snapshot)
        self.vm.init_host()
        self.snapshot_group = snapshot_group.SnapshotGroup(
            STATUS_EVENT_QUEUE, self.snapshot, self.vm, self.volume)
        self.cascade = cascade.Cascade(
            self.volume, self.network, self.snapshot, self.vm,
            self.snapshot_group)
        self.voi = voi.VOI(STATUS_EVENT_QUEUE, self.network)
        self.share_disk = voi.ShareDisk(STATUS_EVENT_QUEUE)
        self.backup_disk = voi.BackupDisk(STATUS_EVENT_QUEUE)
        self.vm_insp = vm_inspector.VMInspector(self._queue, self.vm)
        self.voi_vm_insp = voi_inspector.VOIInspector(self._queue, self.voi)
        register_app_error_handler(self.app)
        self.app.add_url_rule(rule='/', view_func=self.version_discovery,
                              methods=['GET'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/node/shutdown',
                              view_func=self.put_node_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/volume/create',
                              view_func=self.put_volume_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/volume/delete',
                              view_func=self.put_volume_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/volume/clone',
                              view_func=self.put_volume_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/volume/revert',
                              view_func=self.put_volume_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/volume/resize',
                              view_func=self.put_volume_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/snapshot/clone',
                              view_func=self.put_volume_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/snapshot/create',
                              view_func=self.put_snapshot_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/snapshot/delete',
                              view_func=self.put_snapshot_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vpc/create',
                              view_func=self.put_vpc_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vpc/delete',
                              view_func=self.put_vpc_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/create',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/delete',
                              view_func=self.put_vm_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/start',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/stop',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/reboot',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/migrate',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/resize',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/rebuild',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/attach_nic',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/detach_nic',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/revert',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/snapshot_group/create',
                              view_func=self.put_snapshot_group_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/snapshot_group/delete',
                              view_func=self.put_snapshot_group_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/snapshot_group/revert',
                              view_func=self.put_snapshot_group_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/flatten',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/attach_volume',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/vm/detach_volume',
                              view_func=self.put_vm_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/dhcp/create',
                              view_func=self.put_dhcp_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/dhcp/update',
                              view_func=self.put_dhcp_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/dhcp/delete',
                              view_func=self.put_dhcp_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/cascade/delete_volume',
                              view_func=self.put_cascade_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/cascade/delete_vm',
                              view_func=self.put_cascade_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/cascade/rebuild_vm',
                              view_func=self.put_cascade_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/create',
                              view_func=self.put_voi_event_to_queue,
                              methods=['POST'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/delete',
                              view_func=self.put_voi_event_to_queue,
                              methods=['DELETE'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/stop',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/start',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/reboot',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/migrate',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/reset',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/replace_iso',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/commit',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/add_volume',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/remove_volume',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/attach_share_template_volume',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/voi/detach_share_template_volume',
                              view_func=self.put_voi_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/share_disk/commit',
                              view_func=self.put_share_disk_event_to_queue,
                              methods=['PUT'])
        self.app.add_url_rule(rule=PATH_PREFIX +
                              '/backup_disk/commit',
                              view_func=self.put_backup_disk_event_to_queue,
                              methods=['POST'])
        self.volume_repo = volume_repo.VolumeRepository()
        self.vpc_repo = vpc_repo.VpcRepository()
        self.vm_repo = vm_repo.VirtualMachineRepository()
        self.vvm_repo = vvm_repo.VMVolumeMappingRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.snapshot_group_repo = sg_repo.SnapshotGroupRepository()
        self.voi_vm_repo = voi_repo.VMRepository()

    def run_loop(self):
        eventlet.spawn_n(self._process_loop)

    def _process_loop(self):
        LOG.debug("Starting _process_loop")

        while True:
            self._pool.spawn_n(self._process_resource_action)

    def _process_resource_action(self):
        for rp, update in self._queue.each_update_to_next_resource():
            if hasattr(self, update.resource):
                res_obj = getattr(self, update.resource)
                action_method = getattr(res_obj, update.action)
            else:
                # process resource action for Manager
                if update.resource in ['vpc', 'dhcp']:
                    action_method = getattr(self.network,
                                            update.action + '_' +
                                            update.resource)
                else:
                    LOG.error('There is no %(action)s_%(resource)s() '
                              'method in every manager')
            if update.payload:
                action_method(**update.payload)
            else:
                action_method()

    def _parse_path(self, path):
        res = path.split('/')
        return res[2], res[3]

    def version_discovery(self):
        return webob.Response(json={'api_version': 'v1.0'})

    def put_share_disk_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        update = queue.ResourceUpdate(
            "share_disk", PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_backup_disk_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        update = queue.ResourceUpdate(
            "backup_disk", PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_voi_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")
        if action in VM_ACTIONS:
            update_status = ACTION_DICT.get(action, None)
            self.voi_vm_repo.update(
                db_api.get_session(autocommit=True), id=id,
                **{'status': update_status})
            STATUS_EVENT_QUEUE.put(
                {"resource_type": "voi_vm",
                 "resource_id": id,
                 "current_status": update_status,
                 "timestamp": timeutils.utcnow(),
                 "action": action})

            # Voi have to change vm status to limit operate vm. Because
            # attach/detach not support hot plugin.
            # Update share template volume status.
            if action == 'attach_share_template_volume':
                self.voi.update_share_template_disk_status(
                    db_api.get_session(autocommit=True),
                    payload.get('volume_id'), action, constants.ATTACHING,
                    expected_status=constants.PREPARE_ATTACH)
            elif action == 'detach_share_template_volume':
                self.voi.update_share_template_disk_status(
                    db_api.get_session(autocommit=True),
                    payload.get('volume_id'), action, constants.DETACHING,
                    expected_status=constants.PREPARE_DETACH)

        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_node_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        update = queue.ResourceUpdate(
            'this-node', PRIORITY_RELATED_NODE,
            resource=resource, action=action)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_volume_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")
        if action in STORAGE_ACTIONS:
            with db_api.get_lock_session() as lock_session:
                # This is support snapshot/clone
                if resource == 'snapshot':
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, 'volume', self.volume_repo,
                        payload.get('vol_id'))
                # Update and send volume status
                elif resource == 'volume':
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, resource, self.volume_repo, id)
        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_vpc_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")
        if action in ('create', 'delete'):
            # The request will be received by every agent. This code
            # avoid every agent notify the webhook and guaranteed that
            # only one agent that successfully modifies the database can notify
            # webhook.
            expected_status = constants.PREPARE_CREATE \
                if action == 'create' else constants.PREPARE_DELETE
            update_status = constants.CREATING \
                if action == 'create' else constants.DELETING
            if self.vpc_repo.update(db_api.get_session(autocommit=True),
                                    id=id,
                                    expected_status=expected_status,
                                    **{'status': update_status}):
                STATUS_EVENT_QUEUE.put(
                    {"resource_type": "vpc",
                     "resource_id": id,
                     "current_status": update_status,
                     "timestamp": timeutils.utcnow(),
                     "action": action})
        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_vm_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")
        vvm_id = payload.get("vvm_id")

        if action in VM_ACTIONS:
            session = db_api.get_session(autocommit=True)
            update_status = ACTION_DICT.get(action, None)
            expected_status = EXPECTED_STATUS_MAPPING.get(action, None)

            # We don't change VM status in detach_volume and
            # attach_volume action.
            if action not in ['detach_volume', 'attach_volume']:
                if self.vm_repo.update(session, id=id,
                                       expected_status=expected_status,
                                       **{'status': update_status}) < 1:
                    LOG.warning('The current status of VM %s is not %s '
                                '(expected status), so ignore this request %s',
                                id, expected_status, payload)
                    return webob.Response(json={"accept": True})

                STATUS_EVENT_QUEUE.put(
                    {"resource_type": "vm",
                     "resource_id": id,
                     "current_status": update_status,
                     "timestamp": timeutils.utcnow(),
                     "action": action})

            # update nic status
            if action == 'create':
                db_vm = self.vm_repo.get(session, id)
                nic_ids = [db_nic.id for db_nic in db_vm.nics]
                if nic_ids:
                    for nic_id in nic_ids:
                        self.network.update_nic_status(
                            session, nic_id, 'attach',
                            constants.ATTACHING,
                            expected_status=constants.PREPARE_ATTACH)
            elif action == 'attach_nic':
                nic_id = payload.get('nic_id')
                self.network.update_nic_status(
                    session, nic_id, 'attach',
                    constants.ATTACHING,
                    expected_status=constants.PREPARE_ATTACH)
            elif action == 'detach_nic':
                nic_id = payload.get('nic_id')
                self.network.update_nic_status(
                    session, nic_id, 'detach',
                    constants.DETACHING,
                    expected_status=constants.PREPARE_DETACH)
            elif action == 'flatten':
                db_vm = self.vm_repo.get(session, id)
                volume_ids = [vvm.volume_id for vvm in db_vm.vm_volume_mapping]
                if volume_ids:
                    for vvm_id in volume_ids:
                        self.volume.update_volume_status(
                            session, vvm_id, 'flatten',
                            constants.FLATTENING,
                            expected_status=constants.PREPARE_FLATTEN)
            elif action == 'delete':
                db_vm = self.vm_repo.get(session, id)
                nic_ids = [db_nic.id for db_nic in db_vm.nics]
                if nic_ids:
                    for nic_id in nic_ids:
                        self.network.update_nic_status(
                            session, nic_id, 'detach',
                            constants.DETACHING)
            # update volume status
            elif action == 'attach_volume':
                volume_id = payload.get('volume_id')
                self.volume.update_volume_status(
                    session, volume_id, 'attach',
                    constants.ATTACHING,
                    expected_status=constants.PREPARE_ATTACH)
                self.vvm_repo.update(session, vvm_id,
                                     attach_status=constants.ATTACHING)
            elif action == 'detach_volume':
                volume_id = payload.get('volume_id')
                self.volume.update_volume_status(
                    session, volume_id, 'detach',
                    constants.DETACHING,
                    expected_status=constants.PREPARE_DETACH)
                self.vvm_repo.update(session, vvm_id,
                                     attach_status=constants.DETACHING)

        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_snapshot_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")
        if action in STORAGE_ACTIONS:
            update_status = ACTION_DICT.get(action, None)
            self.snapshot_repo.update(db_api.get_session(autocommit=True),
                                      id=id,
                                      **{'status': update_status})
            STATUS_EVENT_QUEUE.put(
                {"resource_type": "snapshot",
                 "resource_id": id,
                 "current_status": update_status,
                 "timestamp": timeutils.utcnow(),
                 "action": action})

        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_snapshot_group_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")

        if action in SNAPSHOT_GROUP_ACTIONS:
            with db_api.get_lock_session() as lock_session:
                # Sg revert only send vm webhook and volume webhook
                snapshot_group_obj = self.snapshot_group_repo.get(
                    lock_session, id=id)
                # Sg revert action we don't update sg status
                if action != 'revert':

                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, resource,
                        self.snapshot_group_repo, id)

                if action in ['create', 'delete']:
                    for snapshot_obj in snapshot_group_obj.snapshot:
                        self._cascade_update_send_resource_middle_status(
                            lock_session, action, 'snapshot',
                            self.snapshot_repo, snapshot_obj.id)
                elif action == 'revert':
                    # Update revert VM status
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, 'vm',
                        self.vm_repo, snapshot_group_obj.vm.id)
                    # Update revert volumes status
                    for revert_volume_id in payload.get(
                            'need_revert_volume_ids', []):
                        self._cascade_update_send_resource_middle_status(
                            lock_session, action, 'volume',
                            self.volume_repo, revert_volume_id)
                    # Update detach volumes status
                    for detach_volume_id, vvm_id in payload.get(
                            'need_detach_volume_vvm_map', {}).items():
                        self._cascade_update_send_resource_middle_status(
                            lock_session, 'detach', "volume", self.volume_repo,
                            detach_volume_id)
                        self.vvm_repo.update(lock_session,
                                             vvm_id,
                                             attach_status=constants.DETACHING)

        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def _cascade_update_send_resource_middle_status(
            self,
            lock_session,
            action,
            resource_type,
            resource_repo,
            resource_id,
            ignore_expected_status=False):
        update_status = ACTION_DICT.get(action, None)
        expected_status = EXPECTED_STATUS_MAPPING.get(action, None)
        resource_obj = resource_repo.get(lock_session, id=resource_id)

        is_updated = False
        if resource_repo.__class__.__name__ == "VMVolumeMappingRepository":
            if ignore_expected_status or (
                    resource_obj.attach_status == expected_status):
                resource_repo.update(
                    lock_session, resource_id, attach_status=update_status)
                is_updated = True
        else:
            if ignore_expected_status or (
                    resource_obj.status == expected_status):
                resource_repo.update(
                    lock_session, resource_id, status=update_status)
                is_updated = True
        if not is_updated:
            LOG.warning('The %(action)s %(resource_type)s expected status of '
                        '%(resource_type)s  %(resource_id)s is not '
                        '%(expected_status)s, so update %(resource_type)s '
                        'status failed.',
                        {'action': action,
                         'resource_type': resource_type,
                         'resource_id': resource_id,
                         'expected_status': expected_status})
        if is_updated:
            STATUS_EVENT_QUEUE.put(
                {"resource_type": resource_type,
                 "resource_id": resource_id,
                 "previous_status": expected_status,
                 "current_status": update_status,
                 "timestamp": timeutils.utcnow(),
                 "action": action})

    def put_dhcp_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        update = queue.ResourceUpdate(
            'dhcp', PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})

    def put_cascade_event_to_queue(self):
        resource, action = self._parse_path(flask.request.path)
        payload = jsonutils.loads(flask.request.data)
        id = payload.get("id")
        if action == 'delete_volume':
            with db_api.get_lock_session() as lock_session:
                volume_obj = self.volume_repo.get(lock_session, id=id)
                is_attached = payload.get('is_attached', False)

                # If volume is_attached:
                # 1. volume status is prepare_detach
                # 2. vvm status is prepare_detach
                #
                # If volume not is_attached:
                # 1. volume status is prepare_delete.
                #
                # Because this is delete_volume action, we only set volume
                # status to deleting.
                self._cascade_update_send_resource_middle_status(
                    lock_session, action, "volume", self.volume_repo, id,
                    ignore_expected_status=True)

                if is_attached:
                    # If volume is_attached
                    # 1. we set vvm attach_status to detaching.
                    # 2. we don't set volume status to detaching,
                    # keeping the volume state is deleting
                    vvm = volume_obj.vm_volume_mapping[0]
                    self.vvm_repo.update(lock_session,
                                         vvm.id,
                                         attach_status=constants.DETACHING)

                # Update volumes's snapshots to deleting
                for snapshot_id in payload.get('need_delete_snapshot_ids', []):
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, 'snapshot', self.snapshot_repo,
                        snapshot_id)
        elif action == 'delete_vm':
            with db_api.get_lock_session() as lock_session:
                need_delete_sg_ids = payload.get('need_delete_sg_ids', [])
                need_delete_snapshot_ids = payload.get(
                    'need_delete_snapshot_ids', [])
                need_detach_volume_ids = payload.get(
                    'need_detach_volume_ids', [])
                del_datadisk = payload.get('del_datadisk', [])

                # VM status is prepare_delete
                # Update VM status to deleting
                self._cascade_update_send_resource_middle_status(
                    lock_session, action, "vm", self.vm_repo, id)

                # Update vm's sgs to deleting
                for sg_id in need_delete_sg_ids:
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, 'snapshot_group',
                        self.snapshot_group_repo, sg_id)

                # Update vm's disk snapshots(does not belong to sg) to deleting
                for snapshot_id in need_delete_snapshot_ids:
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, 'snapshot', self.snapshot_repo,
                        snapshot_id)

                for volume_id in need_detach_volume_ids:
                    # Update vvm to detaching
                    vvm = self.volume_repo.get(
                        lock_session, id=volume_id).vm_volume_mapping[0]
                    self.vvm_repo.update(
                        lock_session, vvm.id,
                        attach_status=constants.DETACHING)

                    if del_datadisk:
                        # Update volume to deleting
                        self._cascade_update_send_resource_middle_status(
                            lock_session, action, "volume", self.volume_repo,
                            volume_id, ignore_expected_status=True)
                    else:
                        # Update volume to detaching
                        self._cascade_update_send_resource_middle_status(
                            lock_session, 'detach', "volume", self.volume_repo,
                            volume_id, ignore_expected_status=True)
        elif action == 'rebuild_vm':
            with db_api.get_lock_session() as lock_session:
                need_delete_sgs_ids = payload.get('need_delete_sgs_ids', [])
                need_delete_snapshot_ids = payload.get(
                    'need_delete_snapshot_ids', [])

                # Update  sgs to deleting
                if need_delete_sgs_ids:
                    for sgs_id in need_delete_sgs_ids:
                        self._cascade_update_send_resource_middle_status(
                            lock_session, action, 'snapshot_group',
                            self.snapshot_group_repo, sgs_id)
                # Update  snapshot to deleting
                for snapshot_id in need_delete_snapshot_ids:
                    self._cascade_update_send_resource_middle_status(
                        lock_session, action, 'snapshot', self.snapshot_repo,
                        snapshot_id)

        update = queue.ResourceUpdate(
            id, PRIORITY_RELATED_NODE,
            resource=resource, action=action,
            payload=payload)
        self._queue.add(update)
        return webob.Response(json={"accept": True})
