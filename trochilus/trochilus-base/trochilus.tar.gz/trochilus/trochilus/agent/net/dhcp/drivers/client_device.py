# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_log import log as logging
from oslo_utils import timeutils
from scapy.all import AsyncSniffer


LOG = logging.getLogger('__name__')


class DiscoveryClient():

    def __init__(self):
        self.device_info = {}

    def get_sub_ip_mac(self, mac, ip):
        if mac not in self.device_info:
            info = {'mac': mac,
                    'ip': ip,
                    'last_update': timeutils.utcnow()}
            self.device_info[mac] = info

        else:
            self.device_info[mac]['ip'] = ip
            self.device_info[mac]['last_update'] = timeutils.utcnow()

    def arp_monitor_callback(self, pkt):
        if 'ARP' in pkt:
            mac, ip = pkt.hwsrc, pkt.psrc
            self.get_sub_ip_mac(mac, ip)
        else:
            try:
                mac, ip = pkt['Ether'].src, pkt['IP'].src
                self.get_sub_ip_mac(mac, ip)
            except Exception:
                LOG.debug("Not get ip in %s ", pkt['Ether'].src)

    def start(self, iface):
        sniff = AsyncSniffer(prn=self.arp_monitor_callback, iface=iface,
                             filter='(tcp or udp or arp or icmp)', store=0)
        sniff.start()
        LOG.debug('The client device is runing ')
        return sniff
