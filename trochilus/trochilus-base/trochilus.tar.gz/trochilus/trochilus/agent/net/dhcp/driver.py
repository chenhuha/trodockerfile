# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


class DhcpDriver(object):

    def enable(self):
        """Enables DHCP for this vpc."""
        raise NotImplementedError()

    def disable(self, retain_port=False, block=False):
        """Disable dhcp for this vpc."""
        raise NotImplementedError()

    def restart(self):
        """Restart the dhcp service for the vpc."""
        self.disable(retain_port=True, block=True)
        self.enable()

    @property
    def active(self):
        """Boolean representing the running state of the DHCP server."""
        raise NotImplementedError()

    def reload_allocations(self):
        """Force the DHCP server to reload the assignment database."""
        raise NotImplementedError()

    @classmethod
    def existing_dhcp_vpcs(cls, conf):
        """Return a list of existing vpc ids that we have configs for."""
        raise NotImplementedError()

    def get_interface_in_root_namespace(self, nic):
        """Return dhcp interface name in root namespace."""
        raise NotImplementedError()

    def get_all_dhcp_network_namespaces(self):
        """Return all dhcp network namespace."""
        raise NotImplementedError()
