# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


import abc
import io
import os
import re
import shutil
import time

import netaddr

from oslo_concurrency import processutils
from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import excutils
from oslo_utils import fileutils
from oslo_utils import importutils
from oslo_utils import netutils
from oslo_utils import uuidutils
from trochilus.agent.common import exceptions
from trochilus.agent.net.dhcp import driver
from trochilus.agent.net.lib import external_process
from trochilus.agent.net.lib import ip_lib
from trochilus.agent.net.lib import iptables_manager
from trochilus.agent.net.lib import utils
from trochilus.common import constants
from trochilus.common import utils as common_utils
from trochilus.i18n import _


LOG = logging.getLogger(__name__)
CONF = cfg.CONF

DNSMASQ_SERVICE_NAME = 'dnsmasq'
DHCP_RELEASE_TRIES = 3
DHCP_RELEASE_TRIES_SLEEP = 0.3
WIN2k3_STATIC_DNS = 249
DHCP_CLIENT_PORT = 68


class DhcpLocalProcess(driver.DhcpDriver):

    def __init__(self, conf, vpc, process_monitor):
        self.conf = conf
        self.vpc = vpc
        self.process_monitor = process_monitor
        self.device_manager = DeviceManager(self.conf)
        self.confs_dir = self.get_confs_dir(conf)
        self.vpc_conf_dir = os.path.join(self.confs_dir, vpc.id)
        fileutils.ensure_tree(self.vpc_conf_dir, mode=0o755)

    @staticmethod
    def get_confs_dir(conf):
        return os.path.abspath(os.path.normpath(
            conf.network_settings.dhcp_confs))

    def get_conf_file_name(self, kind):
        """Returns the file name for a given kind of config file."""
        return os.path.join(self.vpc_conf_dir, kind)

    def _remove_config_files(self):
        shutil.rmtree(self.vpc_conf_dir, ignore_errors=True)

    def _enable_dhcp(self):
        """check if there is a subnet within the vpc with dhcp enabled."""
        for subnet in self.vpc.subnets:
            if subnet.enable_dhcp:
                return True
        return False

    def enable(self):
        """Enables DHCP for this vpc by spawning a local process."""
        return common_utils.wait_until_true(self._enable, timeout=300)

    def _enable(self):
        try:
            if self.active:
                self.disable(retain_port=True, block=True)
            if self._enable_dhcp():
                fileutils.ensure_tree(self.vpc_conf_dir, mode=0o755)
                interface_name = self.device_manager.setup(self.vpc)
                self.interface_name = interface_name
                self.spawn_process()
            return True
        except Exception as e:
            LOG.error('Spawning DHCP process for vpc'
                      ' %s failed, error: %s', self.vpc.id, e)
            return False

    def _get_process_manager(self, cmd_callback=None):
        return external_process.NetProcessManager(
            conf=self.conf,
            uuid=self.vpc.id,
            namespace=self.vpc.namespace,
            service=DNSMASQ_SERVICE_NAME,
            default_cmd_callback=cmd_callback,
            pid_file=self.get_conf_file_name('pid'))

    def disable(self, retain_port=False, block=False):
        """Disable DHCP for this vpc by killing the local process."""
        self.process_monitor.unregister(self.vpc.id, DNSMASQ_SERVICE_NAME)
        self._get_process_manager().disable()
        if block:
            common_utils.wait_until_true(lambda: not self.active)
        if not retain_port:
            self._destroy_namespace_and_port()
            self._remove_config_files()

    def _destroy_namespace_and_port(self):
        try:
            self.device_manager.destroy(self.vpc, self.interface_name)
        except RuntimeError:
            LOG.warning('Failed trying to delete interface: %s',
                        self.interface_name)

        try:
            ip_lib.delete_network_namespace(self.vpc.namespace)
        except RuntimeError:
            LOG.warning('Failed trying to delete namespace: %s',
                        self.vpc.namespace)

    def _get_value_from_conf_file(self, kind, converter=None):
        """A helper function to read a value from one of the state files."""
        file_name = self.get_conf_file_name(kind)
        msg = None
        try:
            with open(file_name, 'r', encoding='utf-8') as f:
                return converter(f.read()) if converter else f.read()
        except ValueError:
            msg = "Unable to convert value in %s"
        except IOError:
            msg = "Unable to access %s"
        LOG.debug(msg, file_name)
        return None

    @property
    def interface_name(self):
        return self._get_value_from_conf_file('interface')

    @interface_name.setter
    def interface_name(self, value):
        interface_file_path = self.get_conf_file_name('interface')
        utils.replace_file(interface_file_path, value)

    @property
    def active(self):
        return self._get_process_manager().active

    @abc.abstractmethod
    def spawn_process(self):
        pass

    def get_interface_in_root_namespace(self, nic):
        if 'BridgeInterface' in CONF.interface_driver:
            interface_name = self.device_manager.get_interface_name(nic)
            return interface_name.replace('ns-', constants.TAP_DEVICE_PREFIX)
        LOG.error('Dhcp does not support %s interface driver',
                  CONF.interface_driver)
        return None


class Dnsmasq(DhcpLocalProcess):

    _SUBNET_TAG_PREFIX = 'subnet-%s'
    _NIC_TAG_PREFIX = 'port-%s'

    _ID = 'id:'

    @staticmethod
    def validate_os_support_dnsmasq():
        result = processutils.execute(*['dnsmasq', '-v'])
        if 'version' not in result[0]:
            raise exceptions.DhcpPackagesUninstall()
        try:
            processutils.execute(*['dhcp_release'], check_exit_code=False)
        except Exception as e:
            # If exception message dose not conntain 'not found',
            # the dnsmasq-utils installed
            if isinstance(e, FileNotFoundError):
                raise exceptions.DhcpPackagesUninstall()

    @classmethod
    def existing_dhcp_vpcs(cls, conf):
        """Return a list of existing vpcs ids that we have configs for."""
        confs_dir = cls.get_confs_dir(conf)
        try:
            return [
                c for c in os.listdir(confs_dir)
                if uuidutils.is_uuid_like(c)
            ]
        except OSError:
            return []

    def reload_allocations(self):
        """Rebuild the dnsmasq config and signal the dnsmasq to reload."""
        # If all subnets turn off dhcp, kill the process.
        if not self._enable_dhcp():
            self.disable()
            LOG.info('Killing dnsmasq for vpc since all subnets have '
                     'turned off DHCP: %s', self.vpc.id)
            return

        if not self.interface_name:

            # we land here if above has been called and we receive port
            # delete notifications for the vpc
            LOG.info('Agent does not have an interface on this vpc '
                     'anymore, skipping reload: %s', self.vpc.id)
            return
        self._release_unused_leases()
        self._spawn_or_reload_process(reload_with_HUP=True)
        LOG.debug('Reloading allocations for vpc: %s', self.vpc.id)
        # self.device_manager.update(self.vpc, self.interface_name)

    def _release_unused_leases(self):
        filename = self.get_conf_file_name('host')
        old_leases = self._read_hosts_file_leases(filename)
        leases_filename = self.get_conf_file_name('leases')
        cur_leases = self._read_leases_file_leases(leases_filename)
        if not cur_leases:
            return

        v4_leases = set()
        for (k, v) in cur_leases.items():
            # treat '*' as None, see note in _read_leases_file_leases()
            client_id = v['client_id']
            if client_id == '*':
                client_id = None
            v4_leases.add((k, v['iaid'], client_id))

        new_leases = set()
        for nic in self.vpc.nics:
            for alloc in nic.ip_addresses:
                new_leases.add((alloc.ip_address, nic.mac_address, None))

        # If an entry is in the leases or host file(s), but doesn't have
        # a fixed IP on a corresponding neutron port, consider it stale.
        entries_to_release = (v4_leases | old_leases) - new_leases
        if not entries_to_release:
            return

        # If the VM advertises a client ID in its lease, but its not set in
        # the port's Extra DHCP Opts, the lease will not be filtered above.
        # Release the lease only if client ID is set in port DB and a mismatch
        # Otherwise the lease is released when other ports are deleted/updated
        entries_with_no_client_id = set()
        for ip, mac, client_id in entries_to_release:
            if client_id:
                entry_no_client_id = (ip, mac, None)
                if (entry_no_client_id in old_leases and
                        entry_no_client_id in new_leases):
                    entries_with_no_client_id.add((ip, mac, client_id))
        entries_to_release -= entries_with_no_client_id

        # Try DHCP_RELEASE_TRIES times to release a lease, re-reading the
        # file each time to see if it's still there.  We loop +1 times to
        # check the lease file one last time before logging any remaining
        # entries.
        for i in range(DHCP_RELEASE_TRIES + 1):
            entries_not_present = set()
            for ip, mac, client_id in entries_to_release:
                try:
                    cur_leases[ip]
                except KeyError:
                    entries_not_present.add((ip, mac, client_id))
                    continue
                # if not the final loop, try and release
                if i < DHCP_RELEASE_TRIES:
                    self._release_lease(mac, ip, client_id)

            # Remove elements that were not in the current leases file,
            # no need to look for them again, and see if we're done.
            entries_to_release -= entries_not_present
            if not entries_to_release:
                break

            if i < DHCP_RELEASE_TRIES:
                time.sleep(DHCP_RELEASE_TRIES_SLEEP)
                cur_leases = self._read_leases_file_leases(leases_filename)
                if not cur_leases:
                    break
        else:
            LOG.warning("Could not release DHCP leases for these IP "
                        "addresses after %d tries: %s",
                        DHCP_RELEASE_TRIES,
                        ', '.join(ip for ip, m, c in entries_to_release))

    def _release_lease(self, mac_address, ip, client_id=None):
        """Release a DHCP lease."""
        params = {'interface_name': self.interface_name,
                  'ip_address': ip, 'mac_address': mac_address,
                  'client_id': client_id,
                  'namespace': self.vpc.namespace}
        try:
            self._dhcpv4_release(**params)
        except (processutils.ProcessExecutionError, OSError) as e:
            # when failed to release single lease there's
            # no need to propagate error further
            LOG.warning('DHCP release failed for params %(params)s. '
                        'Reason: %(e)s', {'params': params, 'e': e})

    @staticmethod
    def _dhcpv4_release(interface_name, ip_address, mac_address, client_id,
                        namespace=None):
        cmd = []
        if namespace:
            cmd += ['ip', 'netns', 'exec', namespace]
        cmd += ['dhcp_release', interface_name, ip_address, mac_address]
        if client_id:
            cmd.append(client_id)
        log_errors = processutils.LOG_FINAL_ERROR
        return processutils.execute(*cmd, log_errors=log_errors)

    def _read_hosts_file_leases(self, filename):
        leases = set()
        try:
            with open(filename, encoding='utf-8') as f:
                for line in f.readlines():
                    host = line.strip().split(',')
                    mac = host[0]
                    client_id = None
                    if host[1].startswith('set:'):
                        continue
                    if host[1].startswith(self._ID):
                        ips = self._parse_ip_addresses(host[3:])
                        client_id = host[1][len(self._ID):]
                    elif host[1].startswith('tag:'):
                        ips = self._parse_ip_addresses(host[3:])
                    else:
                        ips = self._parse_ip_addresses(host[2:])
                    for ip in ips:
                        leases.add((ip, mac, client_id))
        except (OSError, IOError):
            LOG.debug('Error while reading hosts file %s', filename)
        return leases

    @staticmethod
    def _parse_ip_addresses(ip_list):
        ip_list = [ip.strip('[]') for ip in ip_list]
        return [ip for ip in ip_list if netutils.is_valid_ip(ip)]

    @staticmethod
    def _read_leases_file_leases(filename):
        """Read dnsmasq dhcp leases file"""
        leases = {}
        server_id = None
        if os.path.exists(filename):
            with open(filename, encoding='utf-8') as f:
                for line in f.readlines():
                    if line.startswith('duid'):
                        if not server_id:
                            server_id = line.strip().split()[1]
                        else:
                            LOG.warning('Multiple DUID entries in %s '
                                        'lease file, dnsmasq is possibly '
                                        'not functioning properly',
                                        filename)
                        continue
                    parts = line.strip().split()
                    if len(parts) != 5:
                        LOG.warning('Invalid lease entry %s found in %s '
                                    'lease file, ignoring', parts, filename)
                        continue
                    (iaid, ip, client_id) = parts[1], parts[2], parts[4]
                    ip = ip.strip('[]')
                    leases[ip] = {'iaid': iaid,
                                  'client_id': client_id,
                                  'server_id': server_id
                                  }
        return leases

    def _spawn_or_reload_process(self, reload_with_HUP):
        """Spawns or reloads a Dnsmasq process for the vpc.

        When reload_with_HUP is True, dnsmasq receives a HUP signal,
        or it's reloaded if the process is not running.
        """

        self._output_config_files()

        pm = self._get_process_manager(
            cmd_callback=self._build_cmdline_callback)

        pm.enable(reload_cfg=reload_with_HUP, ensure_active=True)

        self.process_monitor.register(uuid=self.vpc.id,
                                      service_name=DNSMASQ_SERVICE_NAME,
                                      monitored_process=pm)

    def _build_cmdline_callback(self, pid_file):
        # We ignore local resolv.conf if dns servers are specified
        # or if local resolution is explicitly disabled.
        _no_resolv = (
            '--no-resolv' if self.conf.network_settings.dnsmasq_dns_servers or
            not self.conf.dnsmasq_local_resolv else '')
        cmd = [
            'dnsmasq',
            '--no-hosts',
            _no_resolv,
            '--pid-file=%s' % pid_file,
            '--dhcp-hostsfile=%s' % self.get_conf_file_name('host'),
            '--addn-hosts=%s' % self.get_conf_file_name('addn_hosts'),
            '--dhcp-optsfile=%s' % self.get_conf_file_name('opts'),
            '--dhcp-leasefile=%s' % self.get_conf_file_name('leases'),
            '--dhcp-match=set:ipxe,175',
            '--dhcp-userclass=set:ipxe6,iPXE',
            '--local-service',
            '--bind-dynamic',
        ]

        possible_leases = 0
        for subnet in self.vpc.subnets:
            # if a subnet is specified to have dhcp disabled
            if not subnet.enable_dhcp:
                continue
            mode = 'static'
            cidr = netaddr.IPNetwork(subnet.cidr)

            if self.conf.network_settings.dhcp_lease_duration == -1:
                lease = 'infinite'
            else:
                lease = '%ss' % self.conf.network_settings.dhcp_lease_duration

            # mode is optional and is not set - skip it
            if mode:
                cmd.append('--dhcp-range=%s%s,%s,%s,%s,%s' %
                           ('set:', self._SUBNET_TAG_PREFIX % subnet.id,
                            cidr.network, mode, cidr.netmask, lease))
                possible_leases += cidr.size

        mtu = self.vpc.mtu
        # Do not advertise unknown mtu
        if mtu and mtu > 0:
            cmd.append('--dhcp-option-force=option:mtu,%d' % mtu)

        # Cap the limit because creating lots of subnets can inflate
        # this possible lease cap.
        cmd.append('--dhcp-lease-max=%d' %
                   min(possible_leases,
                       self.conf.network_settings.dnsmasq_lease_max))

        if self.conf.network_settings.dhcp_renewal_time > 0:
            cmd.append('--dhcp-option-force=option:T1,%ds' %
                       self.conf.network_settings.dhcp_renewal_time)

        if self.conf.network_settings.dhcp_rebinding_time > 0:
            cmd.append('--dhcp-option-force=option:T2,%ds' %
                       self.conf.network_settings.dhcp_rebinding_time)

        cmd.append('--conf-file=%s' %
                   (self.conf.network_settings.dnsmasq_config_file.strip() or
                    '/dev/null'))

        for server in self.conf.network_settings.dnsmasq_dns_servers:
            cmd.append('--server=%s' % server)

        if self.conf.network_settings.dns_domain:
            cmd.append('--domain=%s' % self.conf.network_settings.dns_domain)

        if self.conf.network_settings.dhcp_broadcast_reply:
            cmd.append('--dhcp-broadcast')

        if self.conf.network_settings.dnsmasq_base_log_dir:
            log_dir = os.path.join(
                self.conf.network_settings.dnsmasq_base_log_dir,
                self.vpc.id)
            try:
                if not os.path.exists(log_dir):
                    os.makedirs(log_dir)
            except OSError:
                LOG.error('Error while create dnsmasq log dir: %s', log_dir)
            else:
                log_filename = os.path.join(log_dir, 'dnsmasq.log')
                cmd.append('--log-queries')
                cmd.append('--log-dhcp')
                cmd.append('--log-facility=%s' % log_filename)
        return cmd

    def _output_config_files(self):
        self._output_hosts_file()
        self._output_addn_hosts_file()
        self._output_opts_file()

    def spawn_process(self):
        """Spawn the process, if it's not spawned already."""
        # we only need to generate the lease file the first time dnsmasq starts
        # rather than on every reload since dnsmasq will keep the file current
        self._output_init_lease_file()
        self._spawn_or_reload_process(reload_with_HUP=False)

    def _output_hosts_file(self):
        """Writes a dnsmasq compatible dhcp hosts file."""
        buf = io.StringIO()
        filename = self.get_conf_file_name('host')

        dhcp_enabled_subnet_ids = [s.id for s in self.vpc.subnets
                                   if s.enable_dhcp]

        for host_tuple in self._iter_hosts():
            port, alloc, hostname, name, no_dhcp, no_opts, tag = host_tuple
            # don't write ip address which belongs to a dhcp disabled subnet.
            if alloc.subnet.id not in dhcp_enabled_subnet_ids:
                continue

            buf.write('%s,%s%s,%s\n' %
                      (port.mac_address, tag, name, alloc.ip_address))

        utils.replace_file(filename, buf.getvalue())
        return filename

    def _output_addn_hosts_file(self):
        """Writes a dnsmasq compatible additional hosts file."""
        buf = io.StringIO()
        for host_tuple in self._iter_hosts():
            port, alloc, hostname, fqdn, no_dhcp, no_opts, tag = host_tuple
            if alloc:
                buf.write('%s\t%s %s\n' % (alloc.ip_address, fqdn, hostname))
        addn_hosts = self.get_conf_file_name('addn_hosts')
        utils.replace_file(addn_hosts, buf.getvalue())
        return addn_hosts

    def _output_opts_file(self):
        """Write a dnsmasq compatible options file."""
        options, subnet_index_map = self._generate_opts_per_subnet()

        name = self.get_conf_file_name('opts')
        utils.replace_file(name, '\n'.join(options))
        return name

    def _output_init_lease_file(self):
        """Write a fake lease file to bootstrap dnsmasq."""
        filename = self.get_conf_file_name('leases')
        buf = io.StringIO()

        # we make up a lease time for the database entry
        if self.conf.network_settings.dhcp_lease_duration == -1:
            timestamp = 0
        else:
            timestamp = int(time.time()) + self.conf.network_settings.\
                dhcp_lease_duration
        dhcpv4_enabled_subnet_ids = [s.id for s
                                     in self.vpc.subnets
                                     if s.enable_dhcp]
        for host_tuple in self._iter_hosts():
            port, alloc, hostname, name, no_dhcp, no_opts, tag = host_tuple

            if no_dhcp:
                continue

            if alloc.subnet.id in dhcpv4_enabled_subnet_ids:
                # all that matters is the mac address and IP. the hostname and
                # client ID will be overwritten on the next renewal.
                buf.write('%s %s %s * *\n' %
                          (timestamp, port.mac_address, alloc.ip_address))

        contents = buf.getvalue()
        utils.replace_file(filename, contents)
        return filename

    def _iter_hosts(self):
        """Iterate over hosts."""
        for nic in self.vpc.nics:
            for alloc in nic.ip_addresses:
                no_dhcp = False
                no_opts = False
                tag = ''
                hostname, fqdn = self._get_dns_assignment(alloc.ip_address)
                yield (nic, alloc, hostname, fqdn, no_dhcp, no_opts, tag)

    def _get_dns_assignment(self, ip_address):
        """Get DNS assignment hostname and fqdn"""
        hostname, fqdn = None, None
        ip_addresses = ip_address.replace('[', '').split(']')

        if hostname is None:
            hostname = ('host-%s' %
                        ip_addresses[0].replace('.', '-').replace(':', '-'))
            fqdn = hostname
            if self.conf.network_settings.dns_domain:
                fqdn = '%s.%s' % (fqdn, self.conf.network_settings.dns_domain)

        return hostname, fqdn

    def _generate_opts_per_subnet(self):
        options = []
        subnets_without_nameservers = set()

        for subnet in self.vpc.subnets:
            if subnet.dns_nameservers:
                dns_address = [nameserver.ip_address
                               for nameserver
                               in subnet.dns_nameservers]
                if self.is_dns_servers_any_address(
                        dns_address):
                    # Special case: Do not announce DNS servers
                    options.append(
                        self._format_option(
                            self._SUBNET_TAG_PREFIX % subnet.id,
                            'dns-server'))
                else:
                    options.append(
                        self._format_option(
                            self._SUBNET_TAG_PREFIX % subnet.id,
                            'dns-server', ','.join(dns_address)))
            else:
                # use the dnsmasq ip as nameservers only if there is no
                # dns-server submitted by the server
                # Here is something to check still
                subnets_without_nameservers.add(subnet.id)

            host_routes = []
            gateway = subnet.gateway
            host_routes.append("%s,%s" % (constants.IPv4_ANY, gateway))
            options.append(
                self._format_option(
                    self._SUBNET_TAG_PREFIX % subnet.id,
                    'classless-static-route',
                    ','.join(host_routes)))
            options.append(
                self._format_option(
                    self._SUBNET_TAG_PREFIX % subnet.id,
                    WIN2k3_STATIC_DNS,
                    ','.join(host_routes)))

            if gateway:
                options.append(self._format_option(
                    self._SUBNET_TAG_PREFIX % subnet.id,
                    'router', gateway))
            else:
                options.append(self._format_option(
                    self._SUBNET_TAG_PREFIX % subnet.id,
                    'router'))

        return options, subnets_without_nameservers

    @staticmethod
    def _format_option(tag, option, *args):
        """Format DHCP option by option name or code."""
        option = str(option)
        option = option.split("\n", 1)[0]
        pattern = "(tag:(.*),)?(.*)$"
        matches = re.match(pattern, option)
        extra_tag = matches.groups()[0]
        option = matches.groups()[2]

        if not option.isdigit():
            option = 'option:%s' % option
        if extra_tag:
            tags = ['tag:' + tag, extra_tag[:-1], '%s' % option]
        else:
            tags = ['tag:' + tag, '%s' % option]

        return ','.join(tags + [v.split("\n", 1)[0] for v in args])

    @staticmethod
    def is_dns_servers_any_address(dns_servers):
        # Checks if DNS server list matches the IP
        # any address '0.0.0.0'/'::'"""
        ip_any = netaddr.IPNetwork(constants.IPv4_ANY).ip
        return (len(dns_servers) == 1 and
                netaddr.IPNetwork(dns_servers[0]).ip == ip_any)

    def _make_subnet_interface_ip_map(self):
        subnet_lookup = dict(
            (netaddr.IPNetwork(subnet.cidr), subnet.id)
            for subnet in self.vpc.subnets
        )

        retval = {}

        for addr in ip_lib.get_devices_with_ip(self.vpc.namespace,
                                               name=self.interface_name):
            ip_net = netaddr.IPNetwork(addr['cidr'])

            if ip_net in subnet_lookup:
                retval[subnet_lookup[ip_net]] = addr['cidr'].split('/')[0]

        return retval

    @staticmethod
    def get_all_dhcp_network_namespaces():
        return [netns for netns in ip_lib.list_netns()
                if netns.startswith(constants.DHCP_NAMESPACE_PREFIX)]


class DeviceManager(object):

    def __init__(self, conf):
        self.conf = conf
        interface_driver_class = importutils.import_class(
            conf.interface_driver)
        self.driver = interface_driver_class()

    def get_interface_name(self, nic):
        """Return interface(device) name for use by the DHCP process."""
        return self.driver.get_device_name(nic.id)

    def _cleanup_stale_devices(self, vpc, dhcp_nic):
        """Unplug any devices found in the namespace except for dhcp_port."""
        LOG.debug("Cleaning stale devices for vpc %s", vpc.id)
        skip_dev_name = (self.driver.get_device_name(dhcp_nic.id)
                         if dhcp_nic else None)
        ns_ip = ip_lib.IPWrapper(namespace=vpc.namespace)
        if not ns_ip.netns.exists(vpc.namespace):
            return
        for d in ns_ip.get_devices():
            # delete all devices except current active DHCP port device
            if d.name != skip_dev_name:
                LOG.debug("Found stale device %s, deleting", d.name)
                try:
                    self.unplug(d.name, vpc)
                except Exception:
                    LOG.exception("Exception during stale "
                                  "dhcp device cleanup")

    def plug(self, vpc, port, interface_name):
        """Plug device settings for the vpc's DHCP on this host."""
        self.driver.plug(vpc.id,
                         port.id,
                         interface_name,
                         port.mac_address,
                         namespace=vpc.namespace,
                         mtu=vpc.mtu)

    def setup(self, vpc):
        """Create and initialize a device for vpc's DHCP on this host."""
        dhcp_nic = None
        nics = vpc.nics
        if nics:
            for nic in nics:
                if nic.hostname == CONF.agent_settings.hostname and \
                        nic.owner_type == constants.NIC_OF_DHCP:
                    dhcp_nic = nic
                    break
        if not dhcp_nic:
            raise DhcpNicNotFound(vpc.id)
        interface_name = self.get_interface_name(dhcp_nic)
        if vpc.namespace:
            ip_lib.IPWrapper().ensure_namespace(vpc.namespace)
            ip_lib.set_ip_nonlocal_bind_for_namespace(vpc.namespace, 1,
                                                      root_namespace=True)
        if ip_lib.ensure_device_is_ready(interface_name,
                                         namespace=vpc.namespace):
            LOG.debug('Reusing existing device: %s.', interface_name)
            # force mtu on the port for in case it was changed for the vpc
            mtu = vpc.mtu
            if mtu:
                self.driver.set_mtu(interface_name, mtu,
                                    namespace=vpc.namespace)
        else:
            try:
                self.plug(vpc, dhcp_nic, interface_name)
            except Exception:
                with excutils.save_and_reraise_exception():
                    LOG.exception('Unable to plug DHCP nic for '
                                  'vpc %s. Releasing port.',
                                  vpc.id)
                    # We should unplug the interface in bridge side.
                    self.unplug(interface_name, vpc)

            self.fill_dhcp_udp_checksums(namespace=vpc.namespace)
        ip_cidrs = []
        for alloc in dhcp_nic.ip_addresses:
            net = netaddr.IPNetwork(alloc.subnet.cidr)
            ip_cidr = '%s/%s' % (alloc.ip_address, net.prefixlen)
            ip_cidrs.append(ip_cidr)
        self.driver.init_l3(interface_name, ip_cidrs,
                            namespace=vpc.namespace)

        self._cleanup_stale_devices(vpc, dhcp_nic)

        return interface_name

    def update(self, vpc, device_name):
        """Update device settings for the vpc's DHCP on this host."""
        # self._set_default_route(vpc, device_name)

    def unplug(self, device_name, vpc):
        """Unplug device settings for the vpc's DHCP on this host."""
        self.driver.unplug(device_name, namespace=vpc.namespace)

    def destroy(self, vpc, device_name):
        """Destroy the device used for the vpc's DHCP on this host."""
        if device_name:
            self.unplug(device_name, vpc)
        else:
            LOG.debug('No interface exists for vpc %s', vpc.id)

    def fill_dhcp_udp_checksums(self, namespace):
        """Ensure DHCP reply packets always have correct UDP checksums."""
        iptables_mgr = iptables_manager.IptablesManager(
            nat=False,
            namespace=namespace,
            external_lock=False)
        ipv4_rule = ('-p udp -m udp --dport %d -j CHECKSUM --checksum-fill'
                     % DHCP_CLIENT_PORT)
        iptables_mgr.ipv4['mangle'].add_rule('POSTROUTING', ipv4_rule)
        iptables_mgr.apply()


class DhcpNicNotFound(RuntimeError):
    msg = _("Dhcp nic in Vpc %(vpc_id)s could not be found.")

    def __init__(self, vpc_id):
        super().__init__(
            self.msg % {'vpc_id': vpc_id})
