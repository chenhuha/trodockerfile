# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


import hashlib

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import encodeutils
from trochilus.agent.common import exceptions
from trochilus.agent.net.lib import bridge_lib
from trochilus.agent.net.lib import ip_lib
from trochilus.agent.net.vpc.driver import VpcDriver
from trochilus.common import constants
from trochilus.common import utils
from trochilus.i18n import _

CONF = cfg.CONF
LOG = logging.getLogger(__name__)

MAX_VLAN_POSTFIX_LEN = 5
BRIDGE_FS = "/sys/class/net/"
BRIDGE_INTERFACE_FS = BRIDGE_FS + "%(bridge)s/brif/%(interface)s"
BRIDGE_INTERFACES_FS = BRIDGE_FS + "%s/brif/"
BRIDGE_PORT_FS_FOR_DEVICE = BRIDGE_FS + "%s/brport"
BRIDGE_PATH_FOR_DEVICE = BRIDGE_PORT_FS_FOR_DEVICE + '/bridge'
INTERFACE_HASH_LEN = 6


class LinuxBridgeVpcDriver(VpcDriver):

    def __init__(self):
        super().__init__()

    def _init_driver(self):
        self.physical_interface_mappings = {}
        for mapping in CONF.network_settings.physical_interface_mappings:
            network_interface_arr = str.split(mapping, ':')
            self.physical_interface_mappings[network_interface_arr[0]]\
                = network_interface_arr[1]

        if self.physical_interface_mappings:
            for physnet, interface in self.physical_interface_mappings.items():
                if not ip_lib.device_exists(interface):
                    LOG.error("Interface %(intf)s for physical network %(net)s"
                              " does not exist.",
                              {'intf': interface, 'net': physnet})
                    raise exceptions.VpcDriverInvalid()
        else:
            LOG.info('Config item "physical_interface_mappings" in config'
                     'file is empty.')

        self.linux_bridge_manager = LinuxBridgeManager()
        LOG.info("vpc driver %(driver)s implemented "
                 "with linux bridge initialization"
                 " completed successfully",
                 {"driver": self.__class__.__name__})
        # dhcp interface use LinuxBridgeInterface
        CONF.register_opt(cfg.StrOpt(
            'interface_driver',
            default='trochilus.agent.net.lib'
                    '.interface.BridgeInterfaceDriver'))

    def create_vpc(self, vpc):
        physical_network = vpc.pop('physical')
        if physical_network not \
                in self.physical_interface_mappings:
            LOG.error("physical_network %(physical_network)s is"
                      " not in  config item named  "
                      "'physical_interface_mappings ' when vpc "
                      "driver is impemented by linux bridge",
                      {'physical_network': physical_network})
            raise exceptions.VpcOperationFailded(vpc_id=vpc['id'],
                                                 action='create')

        vpc['physical_interface'] = self.physical_interface_mappings[
            physical_network]

        if vpc['type'] == constants.VLAN:
            self.linux_bridge_manager.create_vlan_bridge(
                vpc['id'],
                vpc['physical_interface'],
                vpc['vlan_id'])
        else:
            self.linux_bridge_manager.create_flat_bridge(
                vpc['id'],
                vpc['physical_interface'])

    def delete_vpc(self, id):
        bridge_name = utils.get_bridge_name(id)
        self.delete_vpc_by_name(bridge_name)

    def delete_vpc_by_name(self, bridge_name):
        self.linux_bridge_manager. \
            delete_bridge(bridge_name,
                          set(self.physical_interface_mappings.values()))

    def add_interface(self, bridge_name, interface_name):
        if not (ip_lib.device_exists(
                interface_name) and ip_lib.device_exists(bridge_name)):
            return
        if not self.linux_bridge_manager.owns_interface(bridge_name,
                                                        interface_name):
            self.linux_bridge_manager.add_interface(bridge_name,
                                                    interface_name)

    def is_vpc_ready(self, bridge_name):
        return self.linux_bridge_manager.is_ready(bridge_name)

    def get_all_vpc_names(self):
        return self.linux_bridge_manager.get_all_bridge_names()


class LinuxBridgeManager(object):

    def __init__(self):
        self.ip = ip_lib.IPWrapper()

    def create_flat_bridge(self, network_id, physical_interface_name):
        """Create a non-vlan bridge unless it already exists."""
        bridge_name = utils.get_bridge_name(network_id)
        self.create_bridge(bridge_name, physical_interface_name)

    def create_vlan_bridge(self, network_id, physical_interface_name, vlan_id):
        """Create a vlan and bridge unless they already exist."""
        sub_interface_name = self.create_vlan(physical_interface_name, vlan_id)
        bridge_name = utils.get_bridge_name(network_id)
        self.create_bridge(bridge_name, sub_interface_name)

    def create_vlan(self, physical_interface_name, vlan_id):
        """Create a vlan unless it already exists."""
        sub_interface_name = self.get_subinterface_name(
            physical_interface_name,
            vlan_id)
        if not ip_lib.device_exists(sub_interface_name):
            try:
                int_vlan = self.ip.add_vlan(sub_interface_name,
                                            physical_interface_name,
                                            vlan_id)
            except RuntimeError as e:
                if ip_lib.vlan_in_use(vlan_id):
                    LOG.error("Unable to create VLAN interface for "
                              "VLAN ID %s because it is in use by "
                              "another interface.", vlan_id)
                    raise exceptions.VlanOperationFailed(
                        vlan_id=vlan_id) from e
            int_vlan.disable_ipv6()
            int_vlan.link.set_up()

        return sub_interface_name

    @staticmethod
    def get_subinterface_name(physical_interface, vlan_id):
        vlan_postfix = '.%s' % vlan_id
        if (len(physical_interface) + len(vlan_postfix) >
                ip_lib.DEVICE_NAME_MAX_LEN):
            physical_interface = LinuxBridgeManager.get_interface_name(
                physical_interface, max_len=(ip_lib.DEVICE_NAME_MAX_LEN -
                                             MAX_VLAN_POSTFIX_LEN))
        return "%s%s" % (physical_interface, vlan_postfix)

    @staticmethod
    def create_bridge(bridge_name, interface_name):
        if not ip_lib.ensure_device_is_ready(bridge_name):
            """create brige"""
            bridge_device = bridge_lib.BridgeDevice.addbr(bridge_name)
        else:
            bridge_device = bridge_lib.BridgeDevice(bridge_name)

        if not interface_name:
            return

        """Check if the interface is part of the bridge"""
        if not bridge_device.owns_interface(interface_name):
            """Check if the interface is attached to another bridge"""
            anthor_bridge = bridge_lib.BridgeDevice.\
                get_interface_bridge(interface_name)

            if anthor_bridge:
                bridge_device.delif(interface_name)

            if not bridge_device.addif(interface_name):
                LOG.error("Unable to add %(interface)s "
                          "to %(bridge_name)s",
                          {'interface': interface_name,
                           'bridge_name': bridge_name})
                raise exceptions.BridgeOperationFailed(name=bridge_name,
                                                       action='create')

    def delete_bridge(self, bridge_name, physical_interfaces):
        bridge_device = bridge_lib.BridgeDevice(bridge_name)
        if bridge_device.exists():
            interfaces_on_bridge = bridge_device.get_interfaces()
            for interface in interfaces_on_bridge:
                self.remove_interfaces_from_bridge(bridge_name, interface)
                if interface not in physical_interfaces:
                    self.delete_interface(interface)

            try:
                if bridge_device.link.set_down():
                    LOG.error("ip link set %()s down failed",
                              {'bridge_name': bridge_name})
                    raise exceptions.BridgeOperationFailed(name=bridge_name,
                                                           action="delete")
                if bridge_device.delbr():
                    LOG.error("ip link delbr %()s failed",
                              {'bridge_name': bridge_name})
                    raise exceptions.BridgeOperationFailed(name=bridge_name,
                                                           action="delete")
            except RuntimeError:
                if not bridge_device.exists():
                    LOG.debug("Cannot delete bridge %s; it does not exist",
                              bridge_name)
                    return
                raise

    @staticmethod
    def remove_interfaces_from_bridge(bridge_name, interface_name):
        bridge_device = bridge_lib.BridgeDevice(bridge_name)
        if bridge_device.exists():
            if not bridge_device.owns_interface(interface_name):
                return True

            if bridge_device.delif(interface_name):
                return True
            if not bridge_device.owns_interface(interface_name):
                return False
            msg = _("Error deleting %(interface_name)s from bridge "
                    "%(bridge_name)s") % {'interface_name': interface_name,
                                          'bridge_name': bridge_name}
            raise RuntimeError(msg)
        return False

    def delete_interface(self, interface_name):
        device = self.ip.device(interface_name)
        if device.exists():
            device.link.set_down()
            device.link.delete()

    @staticmethod
    def get_interface_name(name, prefix='',
                           max_len=ip_lib.DEVICE_NAME_MAX_LEN):
        """Construct an interface name based on the prefix and name.

        The interface name can not exceed the maximum length passed in. Longer
        names are hashed to help ensure uniqueness.
        """
        requested_name = prefix + name

        if len(requested_name) <= max_len:
            return requested_name

        # We can't just truncate because interfaces may be distinguished
        # by an ident at the end. A hash over the name should be unique.
        # Leave part of the interface name on for easier identification
        if (len(prefix) + INTERFACE_HASH_LEN) > max_len:
            raise ValueError(_("Too long prefix provided. New name would"
                               "exceed given length for an interface name."))

        namelen = max_len - len(prefix) - INTERFACE_HASH_LEN
        hashed_name = hashlib.sha256(encodeutils.to_utf8(name))
        new_name = ('%(prefix)s%(truncated)s%(hash)s' %
                    {'prefix': prefix, 'truncated': name[0:namelen],
                     'hash': hashed_name.hexdigest()[0:INTERFACE_HASH_LEN]})
        LOG.info("The requested interface name %(requested_name)s exceeds the "
                 "%(limit)d character limitation. It was shortened to "
                 "%(new_name)s to fit.",
                 {'requested_name': requested_name,
                  'limit': max_len, 'new_name': new_name})
        return new_name

    @staticmethod
    def add_interface(bridge_name, interface_name):
        bridge_device = bridge_lib.BridgeDevice(bridge_name)
        if not bridge_device.owns_interface(interface_name):
            if not bridge_device.addif(interface_name):
                LOG.error("Unable to add %(interface)s "
                          "to %(bridge_name)s",
                          {'interface': interface_name,
                           'bridge_name': bridge_name})
                raise exceptions.BridgeOperationFailed(name=bridge_name,
                                                       action='add interface')

    @staticmethod
    def is_ready(bridge_name):
        return ip_lib.ensure_device_is_ready(bridge_name)

    @staticmethod
    def owns_interface(bridge_name, interface_name):
        bridge_device = bridge_lib.BridgeDevice(bridge_name)
        return bridge_device.owns_interface(interface_name)

    @staticmethod
    def get_all_bridge_names():
        bridge_names = ip_lib.get_device_names(None)
        return [bridge_name for bridge_name in bridge_names
                if bridge_name.startswith(constants.BRIDGE_DEVICE_PREFIX)]
