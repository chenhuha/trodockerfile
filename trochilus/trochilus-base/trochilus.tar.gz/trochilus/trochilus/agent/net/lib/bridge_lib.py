# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import os
from oslo_log import log as logging
from pyroute2.netlink import exceptions \
    as netlink_exceptions  # pylint: disable=no-name-in-module
from trochilus.agent.net.lib import ip_lib

LOG = logging.getLogger(__name__)

BRIDGE_FS = "/sys/class/net/"
BRIDGE_INTERFACE_FS = BRIDGE_FS + "%(bridge)s/brif/%(interface)s"
BRIDGE_INTERFACES_FS = BRIDGE_FS + "%s/brif/"
BRIDGE_PORT_FS_FOR_DEVICE = BRIDGE_FS + "%s/brport"
BRIDGE_PATH_FOR_DEVICE = BRIDGE_PORT_FS_FOR_DEVICE + '/bridge'

# This file references the code of the neutron project.
# details: neutron/agent/linux/bridge_lib.py


class BridgeDevice(ip_lib.IPDevice):

    @classmethod
    def addbr(cls, name, namespace=None):
        bridge = cls(name, namespace, 'bridge')
        try:
            bridge.link.create()
        except ip_lib.InterfaceAlreadyExists:
            LOG.error('An bridge named %s already exists', name)
        return bridge

    @classmethod
    def get_interface_bridge(cls, interface):
        try:
            path = os.readlink(BRIDGE_PATH_FOR_DEVICE % interface)
        except OSError:
            return None
        else:
            name = path.rpartition('/')[-1]
            return cls(name)

    def delbr(self):
        return self.link.delete()

    def addif(self, interface):
        try:
            ip_lib.set_link_bridge_master(interface, self.name,
                                          namespace=self.namespace)
            return True
        except (RuntimeError, OSError, netlink_exceptions.NetlinkError):
            return False

    def delif(self, interface):
        try:
            ip_lib.set_link_bridge_master(interface, None,
                                          namespace=self.namespace)
            return True
        except (RuntimeError, OSError, netlink_exceptions.NetlinkError):
            return False

    def setfd(self, fd):
        try:
            ip_lib.set_link_bridge_forward_delay(self.name, fd,
                                                 namespace=self.namespace)
            return True
        except (RuntimeError, OSError, netlink_exceptions.NetlinkError):
            return False

    def disable_stp(self):
        try:
            ip_lib.set_link_bridge_stp(self.name, 0, namespace=self.namespace)
            return True
        except (RuntimeError, OSError, netlink_exceptions.NetlinkError):
            return False

    def enable_stp(self):
        try:
            ip_lib.set_link_bridge_stp(self.name, 1, namespace=self.namespace)
            return True
        except (RuntimeError, OSError, netlink_exceptions.NetlinkError):
            return False

    def owns_interface(self, interface):
        return os.path.exists(
            BRIDGE_INTERFACE_FS % {'bridge': self.name,
                                   'interface': interface})

    def get_interfaces(self):
        try:
            return os.listdir(BRIDGE_INTERFACES_FS % self.name)
        except OSError:
            return []
