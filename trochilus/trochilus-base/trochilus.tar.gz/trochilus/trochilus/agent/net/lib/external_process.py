# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import os
import psutil

from oslo_config import cfg
from oslo_log import log as logging
from oslo_utils import fileutils
from trochilus.agent.common.external_process import ProcessManager
from trochilus.agent.net.lib import ip_lib
from trochilus.agent.net.lib import utils
from trochilus.common import utils as common_utils


LOG = logging.getLogger(__name__)


class NetProcessManager(ProcessManager):

    """An external process manager for Neutron spawned processes.

    Note: The manager expects uuid to be in cmdline.
    """
    def __init__(self, conf, uuid, namespace=None, service=None,
                 pids_path=None, default_cmd_callback=None,
                 cmd_addl_env=None, pid_file=None,
                 custom_reload_callback=None):

        self.conf = conf
        self.uuid = uuid
        self.namespace = namespace
        self.default_cmd_callback = default_cmd_callback
        self.cmd_addl_env = cmd_addl_env
        self.pids_path = pids_path or self.conf.agent_settings.external_pids
        self.pid_file = pid_file
        self.custom_reload_callback = custom_reload_callback
        self.kill_scripts_path = cfg.CONF.agent_settings.kill_scripts_path

        if service:
            self.service_pid_fname = 'pid.' + service
            self.service = service
        else:
            self.service_pid_fname = 'pid'
            self.service = 'default-service'

        fileutils.ensure_tree(os.path.dirname(self.get_pid_file_name()),
                              mode=0o755)

    def enable(self, cmd_callback=None, reload_cfg=False, ensure_active=False):
        if not self.active:
            if not cmd_callback:
                cmd_callback = self.default_cmd_callback
            cmd = cmd_callback(self.get_pid_file_name())

            ip_wrapper = ip_lib.IPWrapper(namespace=self.namespace)
            ip_wrapper.netns.execute(cmd, addl_env=self.cmd_addl_env)
        elif reload_cfg:
            self.reload_cfg()
        if ensure_active:
            common_utils.wait_until_true(lambda: self.active)

    def reload_cfg(self):
        if self.custom_reload_callback:
            self.disable(get_stop_command=self.custom_reload_callback)
        else:
            self.disable('HUP')

    def disable(self, sig='9', get_stop_command=None):
        pid = self.pid

        if self.active:
            if get_stop_command:
                cmd = get_stop_command(self.get_pid_file_name())
                ip_wrapper = ip_lib.IPWrapper(namespace=self.namespace)
                ip_wrapper.netns.execute(cmd, addl_env=self.cmd_addl_env)
            else:
                cmd = self.get_kill_cmd(sig, pid)
                utils.execute(cmd)
                # In the case of shutting down, remove the pid file
                if sig == '9':
                    delete_if_exists(self.get_pid_file_name())
        elif pid:
            LOG.debug('%(service)s process for %(uuid)s pid %(pid)d is stale, '
                      'ignoring signal %(signal)s',
                      {'service': self.service, 'uuid': self.uuid,
                       'pid': pid, 'signal': sig})
        else:
            LOG.debug('No %(service)s process started for %(uuid)s',
                      {'service': self.service, 'uuid': self.uuid})

    def get_kill_cmd(self, sig, pid):
        if self.kill_scripts_path:
            kill_file = "%s-kill" % self.service
            kill_file_path = os.path.join(self.kill_scripts_path, kill_file)
            if os.path.isfile(kill_file_path):
                return [kill_file_path, sig, pid]
        return ['kill', '-%s' % (sig), pid]

    def get_pid_file_name(self):
        """Returns the file name for a given kind of config file."""
        if self.pid_file:
            return self.pid_file
        return get_conf_file_name(self.pids_path,
                                  self.uuid,
                                  self.service_pid_fname)

    @property
    def pid(self):
        """Last known pid for this external process spawned for this uuid."""
        filename = self.get_pid_file_name()
        if not os.path.exists(filename):
            return None
        return get_value_from_file(filename, int)

    @property
    def active(self):
        cmdline = self.cmdline
        return self.uuid in cmdline if cmdline else False

    @property
    def cmdline(self):
        pid = self.pid
        if not pid:
            return None
        try:
            return ' '.join(psutil.Process(pid).cmdline())
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None
        return None


def get_conf_file_name(cfg_root, uuid, cfg_file, ensure_conf_dir=False):
    """Returns the file name for a given kind of config file."""
    conf_base = _get_conf_base(cfg_root, uuid, ensure_conf_dir)
    return "%s.%s" % (conf_base, cfg_file)


def _get_conf_base(cfg_root, uuid, ensure_conf_dir):
    conf_dir = os.path.abspath(os.path.normpath(cfg_root))
    conf_base = os.path.join(conf_dir, uuid)
    if ensure_conf_dir:
        fileutils.ensure_tree(conf_dir, mode=0o755)
    return conf_base


def get_value_from_file(filename, converter=None):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            try:
                return converter(f.read()) if converter else f.read()
            except ValueError:
                LOG.error('Unable to convert value in %s', filename)
                raise
    except IOError as error:
        LOG.debug('Unable to access %(filename)s; Error: %(error)s',
                  {'filename': filename, 'error': error})
        return None


def delete_if_exists(path):
    """Delete a path"""
    fileutils.delete_if_exists(path, remove=os.unlink)
