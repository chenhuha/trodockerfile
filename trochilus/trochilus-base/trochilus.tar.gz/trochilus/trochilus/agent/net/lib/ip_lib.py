# Copyright 2022  Troila
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import ctypes
from ctypes import util as ctypes_util

import errno
import os
import re

from os import path

import socket

import netaddr

import pyroute2

from oslo_concurrency import processutils
from oslo_log import log as logging
from oslo_utils import netutils
from pyroute2 import netlink  # pylint: disable=no-name-in-module
from pyroute2.netlink import exceptions \
    as netlink_exceptions  # pylint: disable=no-name-in-module
from pyroute2.netlink import rtnl  # pylint: disable=no-name-in-module
from pyroute2.netlink.rtnl import \
    ifaddrmsg  # pylint: disable=no-name-in-module
from pyroute2 import netns  # pylint: disable=no-name-in-module

from trochilus.common import constants
from trochilus.common import utils as common_utils

from trochilus.i18n import _


LOG = logging.getLogger(__name__)

IP_ADDRESS_SCOPE = {rtnl.rtscopes['RT_SCOPE_UNIVERSE']: 'global',
                    rtnl.rtscopes['RT_SCOPE_SITE']: 'site',
                    rtnl.rtscopes['RT_SCOPE_LINK']: 'link',
                    rtnl.rtscopes['RT_SCOPE_HOST']: 'host'}

IP_ADDRESS_SCOPE_NAME = {v: k for k, v in IP_ADDRESS_SCOPE.items()}

IP_ADDRESS_EVENTS = {'RTM_NEWADDR': 'added',
                     'RTM_DELADDR': 'removed'}

IP_ROUTE_METRIC_DEFAULT = {constants.IP_VERSION_4: 0,
                           constants.IP_VERSION_6: 1024}

IP_RULE_TABLES = {'default': 253,
                  'main': 254,
                  'local': 255}

IP_RULE_TABLES_NAMES = {v: k for k, v in IP_RULE_TABLES.items()}

_IP_VERSION_FAMILY_MAP = {4: socket.AF_INET, 6: socket.AF_INET6}

# Linux interface max length
DEVICE_NAME_MAX_LEN = 15

# Protocol names and numbers for Security Groups/Firewalls
IP_PROTOCOL_MAP = {'ah': 51,
                   'dccp': 33,
                   'egp': 8,
                   'esp': 50,
                   'gre': 47,
                   'hopopt': 0,
                   'icmp': 1,
                   'igmp': 2,
                   'ip': 0,
                   'ipip': 4,
                   'ipv6-encap': 41,
                   'ipv6-frag': 44,
                   'ipv6-icmp': 58,
                   # For backward-compatibility of security group rule API
                   'icmpv6': 58,
                   'ipv6-nonxt': 59,
                   'ipv6-opts': 60,
                   'ipv6-route': 43,
                   'ospf': 89,
                   'pgm': 113,
                   'rsvp': 46,
                   'sctp': 132,
                   'tcp': 6,
                   'udp': 17,
                   'udplite': 136,
                   'vrrp': 112}

# We only want one mapping from '58' to 'ipv6-icmp' since that is the
# normalized string, the name to number mapping can have both
IP_PROTOCOL_NUM_TO_NAME_MAP = ({str(v): k for k, v in IP_PROTOCOL_MAP.items()
                               if k != 'icmpv6'})

LOOPBACK_DEVNAME = 'lo'

FB_TUNNEL_DEVICE_NAMES = ['gre0', 'gretap0', 'tunl0', 'erspan0', 'sit0',
                          'ip6tnl0', 'ip6gre0']

_CDLL = None

IP_NONLOCAL_BIND = 'net.ipv4.ip_nonlocal_bind'

# This file references the code of the neutron project.
# details: neutron/agent/linux/ip_lib.py
#          neutron/privileged/agent/linux/ip_lib.py


class IpDeviceCommandBase(object):

    def __init__(self, parent):
        self._parent = parent

    @property
    def name(self):
        return self._parent.name

    @property
    def kind(self):
        return self._parent.kind


class IpLinkCommand(IpDeviceCommandBase):

    def set_address(self, mac_address):
        return _run_iproute_link("set", self.name, self._parent.namespace,
                                 address=mac_address)

    def create(self):
        if self.kind == 'bridge':
            create_interface(self.name, self._parent.namespace,
                             self.kind,
                             **{'br_forward_delay': 0,
                                'br_stp_state': 1,
                                'state': 'up'})
        else:
            raise NotImplementedError

    def delete(self):
        delete_interface(self.name, self._parent.namespace)

    def set_up(self):
        try:
            _run_iproute_link('set', self.name,
                              self._parent.namespace,
                              state='up')
        except netlink_exceptions.NetlinkError as e:
            if e.code == errno.ENETDOWN:
                if self.kind == 'vlan':
                    LOG.error("Unable to setup VLAN interface named "
                              "%s because physical interface "
                              "%(physical_interface_name)s is down.",
                              self.name)
                    return
            raise

    def set_down(self):
        _run_iproute_link('set', self.name,
                          self._parent.namespace,
                          state='down')

    def set_mtu(self, mtu_size):
        return _run_iproute_link("set", self.name,
                                 self._parent.namespace,
                                 mtu=mtu_size)

    @property
    def exists(self):
        try:
            idx = get_link_id(self.name,
                              self._parent.namespace,
                              raise_exception=False)
            return bool(idx)
        except OSError as e:
            if e.errno == errno.ENOENT:
                return False
            raise

    @property
    def address(self):
        link = _run_iproute_link('get', self.name, self._parent.namespace)
        return link and get_attr(link[0], 'IFLA_ADDRESS')


class IpAddrCommand(IpDeviceCommandBase):

    def add(self, cidr, scope='global', add_broadcast=True):
        add_ip_address(cidr, self.name, self._parent.namespace, scope,
                       add_broadcast)

    def delete(self, cidr):
        delete_ip_address(cidr, self.name, self._parent.namespace)

    def list(self, scope=None, to=None, filters=None, ip_version=None):
        """Get device details of a device named <self.name>."""
        def filter_device(device, filters):
            # Accepted filters: dynamic, permanent, tentative, dadfailed.
            for filter in filters:
                if filter == 'permanent' and device['dynamic']:
                    return False
                if not device[filter]:
                    return False
            return True

        kwargs = {}
        if to:
            cidr = common_utils.ip_to_cidr(to)
            kwargs = {'address': common_utils.cidr_to_ip(cidr)}
            if not common_utils.is_cidr_host(cidr):
                kwargs['mask'] = common_utils.cidr_mask_length(cidr)
        if scope:
            kwargs['scope'] = scope
        if ip_version:
            kwargs['family'] = common_utils.get_socket_address_family(
                ip_version)

        devices = get_devices_with_ip(self._parent.namespace, name=self.name,
                                      **kwargs)
        if not filters:
            return devices

        filtered_devices = []
        for device in (device for device in devices
                       if filter_device(device, filters)):
            filtered_devices.append(device)

        return filtered_devices


class IPDevice(object):
    def __init__(self, name, namespace=None, kind='link'):
        self.name = name
        self.namespace = namespace
        self.kind = kind
        self.link = IpLinkCommand(self)
        self.addr = IpAddrCommand(self)

    def exists(self):
        return self.link.exists

    def disable_ipv6(self):
        if not netutils.is_ipv6_enabled():
            return None
        sysctl_name = re.sub(r'\.', '/', self.name)
        cmd = ['net.ipv6.conf.%s.disable_ipv6=1' % sysctl_name]
        return sysctl(cmd, namespace=self.namespace)

    def delete_addr_and_conntrack_state(self, cidr):
        """Delete an address along with its conntrack state

        This terminates any active connections through an IP.

        :param cidr: the IP address for which state should be removed.
            This can be passed as a string with or without /NN.
            A netaddr.IPAddress or netaddr.Network representing the IP address
            can also be passed.
        """
        self.addr.delete(cidr)
        self.delete_conntrack_state(cidr)

    def delete_conntrack_state(self, cidr):
        """Delete conntrack state rules

        Deletes both rules (if existing), the destination and the reply one.
        """
        ip_str = str(netaddr.IPNetwork(cidr).ip)
        ip_wrapper = IPWrapper(namespace=self.namespace)

        # Delete conntrack state for ingress traffic
        # If 0 flow entries have been deleted
        # conntrack -D will return 1
        try:
            ip_wrapper.netns.execute(["conntrack", "-D", "-d", ip_str])

        except RuntimeError:
            LOG.exception("Failed deleting ingress connection state of"
                          " floatingip %s", ip_str)

        # Delete conntrack state for egress traffic
        try:
            ip_wrapper.netns.execute(["conntrack", "-D", "-q", ip_str])
        except RuntimeError:
            LOG.exception("Failed deleting egress connection state of"
                          " floatingip %s", ip_str)


class IpNetnsCommand(object):

    def __init__(self, parent):
        self._parent = parent

    def execute(self, cmds, addl_env=None):
        ns_params = []
        if self._parent.namespace:
            ns_params = ['ip', 'netns', 'exec', self._parent.namespace]

        env_params = []
        if addl_env:
            env_params = (['env'] +
                          ['%s=%s' % pair for pair in addl_env.items()])
        cmd = ns_params + env_params + list(cmds)
        processutils.execute(*cmd)

    def exists(self, name):
        return network_namespace_exists(name)

    def add(self, name):
        """Create a network namespace."""
        pid = os.fork()
        if pid == 0:
            try:
                netns._create(name, libc=get_cdll())
            except OSError as e:
                if e.errno != errno.EEXIST:
                    os._exit(1)
            except Exception:
                os._exit(1)
            os._exit(0)
        else:
            if os.waitpid(pid, 0)[1]:
                raise RuntimeError(_('Error creating namespace %s' % name))

        wrapper = IPWrapper(namespace=name)
        wrapper.netns.execute(['sysctl', '-w',
                               'net.ipv4.conf.all.promote_secondaries=1'])
        return wrapper


class IPWrapper(object):

    def __init__(self, namespace=None):
        self.namespace = namespace
        self.netns = IpNetnsCommand(self)

    def device(self, name):
        return IPDevice(name, namespace=self.namespace)

    def add_vlan(self, name, physical_interface, vlan_id):
        create_interface(name, self.namespace, "vlan",
                         physical_interface=physical_interface,
                         vlan_id=vlan_id)
        return IPDevice(name, namespace=self.namespace)

    def add_veth(self, name1, name2, namespace2=None):
        peer = {'ifname': name2}

        if namespace2 is None:
            namespace2 = self.namespace
        else:
            self.ensure_namespace(namespace2)
            peer['net_ns_fd'] = namespace2

        create_interface(name1, self.namespace, 'veth', peer=peer)
        return (IPDevice(name1, namespace=self.namespace),
                IPDevice(name2, namespace=namespace2))

    def get_devices(self, exclude_loopback=True, exclude_fb_tun_devices=True):
        retval = []
        try:
            devices = get_device_names(self.namespace)
        except NetworkNamespaceNotFound:
            return retval

        for name in devices:
            if (exclude_loopback and name == LOOPBACK_DEVNAME or
                    exclude_fb_tun_devices and name in FB_TUNNEL_DEVICE_NAMES):
                continue
            retval.append(IPDevice(name, namespace=self.namespace))
        return retval

    def ensure_namespace(self, name):
        if not self.netns.exists(name):
            ip = self.netns.add(name)
            lo = ip.device(LOOPBACK_DEVNAME)
            lo.link.set_up()
        else:
            ip = IPWrapper(namespace=name)
        return ip


def ensure_device_is_ready(device_name, namespace=None):
    dev = IPDevice(device_name, namespace=namespace)
    try:
        # Ensure the device has a MAC address and is up, even if it is already
        # up.
        if not dev.link.exists or not dev.link.address:
            LOG.info("Device %s cannot be used as it has no MAC "
                     "address", device_name)
            return False
        dev.link.set_up()
    except RuntimeError:
        return False
    return True


def get_link_id(device, namespace, raise_exception=True):
    with get_iproute(namespace) as ip:
        link_id = ip.link_lookup(ifname=device)
    if not link_id or len(link_id) < 1:
        if raise_exception:
            raise NetworkInterfaceNotFound(device=device, namespace=namespace)
        LOG.debug('Interface %(dev)s not found in namespace %(namespace)s',
                  {'dev': device, 'namespace': namespace})
        return None
    return link_id[0]


def device_exists(device_name, namespace=None):
    """Return True if the device exists in the namespace."""
    return IPDevice(device_name, namespace=namespace).exists()


def create_interface(ifname, namespace, kind, **kwargs):
    ifname = ifname[:DEVICE_NAME_MAX_LEN]
    try:
        physical_interface = kwargs.pop("physical_interface", None)
        if physical_interface:
            kwargs['link'] = get_link_id(physical_interface, namespace)
        with get_iproute(namespace) as ip:
            return ip.link("add", ifname=ifname, kind=kind, **kwargs)
    except netlink_exceptions.NetlinkError as e:
        if e.code == errno.EEXIST:
            raise InterfaceAlreadyExists(device=ifname) from e
        raise
    except OSError as e:
        if e.errno == errno.ENOENT:
            raise NetworkNamespaceNotFound(netns_name=namespace) from e
        raise


def delete_interface(ifname, namespace, **kwargs):
    _run_iproute_link("del", ifname, namespace, **kwargs)


def vlan_in_use(segmentation_id, namespace=None):
    """Return True if VLAN ID is in use by an interface, else False."""
    interfaces = get_devices_info(namespace)
    vlans = {interface.get('vlan_id') for interface in interfaces
             if interface.get('vlan_id')}
    return segmentation_id in vlans


def get_devices_info(namespace, **kwargs):
    devices = get_link_devices(namespace, **kwargs)
    retval = {}
    for device in devices:
        ret = {'index': device['index'],
               'name': get_attr(device, 'IFLA_IFNAME'),
               'operstate': get_attr(device, 'IFLA_OPERSTATE'),
               'linkmode': get_attr(device, 'IFLA_LINKMODE'),
               'mtu': get_attr(device, 'IFLA_MTU'),
               'promiscuity': get_attr(device, 'IFLA_PROMISCUITY'),
               'mac': get_attr(device, 'IFLA_ADDRESS'),
               'broadcast': get_attr(device, 'IFLA_BROADCAST')}
        ifla_link = get_attr(device, 'IFLA_LINK')
        if ifla_link:
            ret['parent_index'] = ifla_link
        ifla_linkinfo = get_attr(device, 'IFLA_LINKINFO')
        if ifla_linkinfo:
            ret['kind'] = get_attr(ifla_linkinfo, 'IFLA_INFO_KIND')
            ifla_data = get_attr(ifla_linkinfo, 'IFLA_INFO_DATA')
            if ret['kind'] == 'vxlan':
                ret['vxlan_id'] = get_attr(ifla_data, 'IFLA_VXLAN_ID')
                ret['vxlan_group'] = get_attr(ifla_data, 'IFLA_VXLAN_GROUP')
                ret['vxlan_link_index'] = get_attr(ifla_data,
                                                   'IFLA_VXLAN_LINK')
            elif ret['kind'] == 'vlan':
                ret['vlan_id'] = get_attr(ifla_data, 'IFLA_VLAN_ID')
            elif ret['kind'] == 'bridge':
                ret['stp'] = get_attr(ifla_data, 'IFLA_BR_STP_STATE')
                ret['forward_delay'] = get_attr(ifla_data,
                                                'IFLA_BR_FORWARD_DELAY')
        retval[device['index']] = ret

    for device in retval.values():
        if device.get('parent_index'):
            parent_device = retval.get(device['parent_index'])
            if parent_device:
                device['parent_name'] = parent_device['name']
        elif device.get('vxlan_link_index'):
            device['vxlan_link_name'] = (
                retval[device['vxlan_link_index']]['name'])

    return list(retval.values())


def set_link_bridge_master(device, bridge, namespace=None):
    try:
        bridge_idx = get_link_id(bridge, namespace) if bridge else 0
        with get_iproute(namespace) as ip:
            return ip.link('set', ifname=device, **{'master': bridge_idx})
    except netlink.NetlinkError as e:
        _translate_ip_device_exception(e, device, namespace)
        raise
    except OSError as e:
        if e.errno == errno.ENOENT:
            raise NetworkNamespaceNotFound(netns_name=namespace) from e
        raise


def get_link_devices(namespace, **kwargs):
    """List interfaces in a namespace

    :return: (list) interfaces in a namespace
    """
    try:
        with get_iproute(namespace) as ip:
            return make_serializable(ip.get_links(**kwargs))
    except OSError as e:
        if e.errno == errno.ENOENT:
            raise NetworkNamespaceNotFound(netns_name=namespace) from e
        raise


def make_serializable(value):
    """Make a pyroute2 object serializable

    This function converts 'netlink.nla_slot' object (key, value) in a list
    of two elements.
    """
    def _ensure_string(value):
        return value.decode() if isinstance(value, bytes) else value

    if isinstance(value, list):
        return [make_serializable(item) for item in value]
    if isinstance(value, netlink.nla_slot):
        return [_ensure_string(value[0]), make_serializable(value[1])]
    if isinstance(value, netlink.nla_base):
        return make_serializable(value.dump())
    if isinstance(value, dict):
        return {_ensure_string(key): make_serializable(data)
                for key, data in value.items()}
    if isinstance(value, tuple):
        return tuple(make_serializable(item) for item in value)
    return _ensure_string(value)


def get_devices_with_ip(namespace, name=None, **kwargs):
    retval = []
    link_args = {}
    if name:
        link_args['ifname'] = name
    scope = kwargs.pop('scope', None)
    if scope:
        kwargs['scope'] = IP_ADDRESS_SCOPE_NAME[scope]

    if not link_args:
        ip_addresses = get_ip_addresses(namespace, **kwargs)
    else:
        device = get_devices_info(namespace, **link_args)
        if not device:
            return retval
        ip_addresses = get_ip_addresses(
            namespace, index=device[0]['index'], **kwargs)

    devices = {}  # {device index: name}
    for ip_address in ip_addresses:
        index = ip_address['index']
        name = get_attr(ip_address, 'IFA_LABEL') or devices.get(index)
        if not name:
            device = get_devices_info(namespace, index=index)
            if not device:
                continue
            name = device[0]['name']

        retval.append(_parse_ip_address(ip_address, name))
        devices[index] = name

    return retval


def get_ip_addresses(namespace, **kwargs):
    """List of IP addresses in a namespace:

    return: (tuple) IP addresses in a namespace
    """
    try:
        with get_iproute(namespace) as ip:
            return make_serializable(ip.get_addr(**kwargs))
    except OSError as e:
        if e.errno == errno.ENOENT:
            raise NetworkNamespaceNotFound(netns_name=namespace) from e
        raise


def _parse_ip_address(pyroute2_address, device_name):
    ip = get_attr(pyroute2_address, 'IFA_ADDRESS')
    ip_length = pyroute2_address['prefixlen']
    event = IP_ADDRESS_EVENTS.get(pyroute2_address.get('event'))
    cidr = common_utils.ip_to_cidr(ip, prefix=ip_length)
    flags = get_attr(pyroute2_address, 'IFA_FLAGS')
    dynamic = not bool(flags & ifaddrmsg.IFA_F_PERMANENT)
    tentative = bool(flags & ifaddrmsg.IFA_F_TENTATIVE)
    dadfailed = bool(flags & ifaddrmsg.IFA_F_DADFAILED)
    scope = IP_ADDRESS_SCOPE[pyroute2_address['scope']]
    return {'name': device_name,
            'cidr': cidr,
            'scope': scope,
            'broadcast': get_attr(pyroute2_address, 'IFA_BROADCAST'),
            'dynamic': dynamic,
            'tentative': tentative,
            'dadfailed': dadfailed,
            'event': event}


def add_ip_address(cidr, device, namespace=None, scope='global',
                   add_broadcast=True):
    """Add an IP address.

    :param cidr: IP address to add, in CIDR notation
    :param device: Device name to use in adding address
    :param namespace: The name of the namespace in which to add the address
    :param scope: scope of address being added
    :param add_broadcast: should broadcast address be added
    """
    net = netaddr.IPNetwork(cidr)
    broadcast = None
    if add_broadcast and net.version == 4:
        # NOTE(slaweq): in case if cidr is /32 net.broadcast is None so
        # same IP address as cidr should be set as broadcast
        broadcast = str(net.broadcast or net.ip)

    ip_version = net.version
    ip = str(net.ip)
    prefixlen = net.prefixlen
    family = _IP_VERSION_FAMILY_MAP[ip_version]
    try:
        _run_iproute_addr('add',
                          device,
                          namespace,
                          address=ip,
                          mask=prefixlen,
                          family=family,
                          broadcast=broadcast,
                          scope=get_scope_name(scope))
    except netlink_exceptions.NetlinkError as e:
        if e.code == errno.EEXIST:
            raise IpAddressAlreadyExists(ip=ip, device=device) from e
        raise


def delete_ip_address(cidr, device, namespace=None):
    """Delete an IP address.

    :param cidr: IP address to delete, in CIDR notation
    :param device: Device name to use in deleting address
    :param namespace: The name of the namespace in which to delete the address
    """
    net = netaddr.IPNetwork(cidr)
    ip_version = net.version
    ip = str(net.ip)
    prefixlen = net.prefixlen
    family = _IP_VERSION_FAMILY_MAP[ip_version]
    try:
        _run_iproute_addr("delete",
                          device,
                          namespace,
                          address=ip,
                          mask=prefixlen,
                          family=family)
    except netlink_exceptions.NetlinkError as e:
        # when trying to delete a non-existent IP address, pyroute2 raises
        # NetlinkError with code EADDRNOTAVAIL (99, 'Cannot assign requested
        # address')
        # this shouldn't raise an error
        if e.code == errno.EADDRNOTAVAIL:
            return
        raise


def get_scope_name(scope):
    """get scope name

    Return the name of the scope (given as a number), or the scope number
    if the name is unknown.

    For backward compatibility (with "ip" tool) "global" scope is converted to
    "universe" before converting to number
    """
    scope = 'universe' if scope == 'global' else scope
    return rtnl.rt_scope.get(scope, scope)


def sysctl(cmd, namespace=None):
    """Run sysctl command 'cmd'"""
    cmd = ['sysctl', '-w'] + cmd
    ip_wrapper = IPWrapper(namespace=namespace)
    try:
        ip_wrapper.netns.execute(cmd)
    except RuntimeError as rte:
        LOG.warning(
            "Setting %(cmd)s in namespace %(ns)s failed: %(err)s.",
            {'cmd': cmd,
             'ns': namespace,
             'err': rte})
        return 1

    return 0


def get_iproute(namespace):
    # From iproute.py:
    # `IPRoute` -- RTNL API to the current network namespace
    # `NetNS` -- RTNL API to another network namespace
    if namespace:
        # do not try and create the namespace
        return pyroute2.NetNS(namespace, flags=0, libc=get_cdll())
    return pyroute2.IPRoute()


def get_attr(pyroute2_obj, attr_name):
    """Get an attribute from a PyRoute2 object"""
    rule_attrs = pyroute2_obj.get('attrs', [])
    for attr in (attr for attr in rule_attrs if attr[0] == attr_name):
        return attr[1]


def _run_iproute_link(command, device, namespace=None, **kwargs):
    try:
        idx = get_link_id(device, namespace)
        with get_iproute(namespace) as ip:
            return ip.link(command, index=idx, **kwargs)
    except netlink.NetlinkError as e:
        _translate_ip_device_exception(e, device, namespace)
        raise
    except OSError as e:
        if e.errno == errno.ENOENT:
            raise NetworkNamespaceNotFound(netns_name=namespace) from e
        raise


def _run_iproute_addr(command, device, namespace, **kwargs):
    try:
        idx = get_link_id(device, namespace)
        with get_iproute(namespace) as ip:
            return ip.addr(command, index=idx, **kwargs)
    except netlink_exceptions.NetlinkError as e:
        _translate_ip_device_exception(e, device, namespace)
        raise
    except OSError as e:
        if e.errno == errno.ENOENT:
            raise NetworkNamespaceNotFound(netns_name=namespace) from e
        raise


def _translate_ip_device_exception(e, device=None, namespace=None):
    if e.code == errno.ENODEV:
        raise NetworkInterfaceNotFound(device=device, namespace=namespace)
    if e.code == errno.EOPNOTSUPP:
        raise InterfaceOperationNotSupported(device=device,
                                             namespace=namespace)
    if e.code == errno.EINVAL:
        raise InvalidArgument(device=device, namespace=namespace)


def delete_network_namespace(namespace):
    try:
        netns.remove(namespace)
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    LOG.debug("Namespace %s deleted.", namespace)


def network_namespace_exists(namespace, try_is_ready=False, **kwargs):
    """Check if a network namespace exists.

    :param namespace: The name of the namespace to check
    :param try_is_ready: Try to open the namespace to know if the namespace
                         is ready to be operated.
    :param kwargs: Callers add any filters they use as kwargs
    """
    if not namespace:
        return False

    if not try_is_ready:
        nspath = kwargs.get('nspath') or netns.NETNS_RUN_DIR
        nspath += '/' + namespace
        return path.exists(nspath)

    try:
        """Open namespace to test if the namespace is ready to manipulate"""
        with pyroute2.NetNS(namespace, flags=0):
            pass
        return True
    except (RuntimeError, OSError):
        pass
    return False


def get_device_names(namespace, **kwargs):
    """List interface names in a namespace

    :return: a list of strings with the names of the interfaces in a namespace
    """
    devices_attrs = [link['attrs'] for link
                     in get_link_devices(namespace, **kwargs)]
    device_names = []
    for device_attrs in devices_attrs:
        for link_name in (link_attr[1] for link_attr in device_attrs
                          if link_attr[0] == 'IFLA_IFNAME'):
            device_names.append(link_name)
    return device_names


def set_ip_nonlocal_bind_for_namespace(namespace, value, root_namespace=False):
    """Set ip_nonlocal_bind but don't raise exception on failure."""
    failed = set_ip_nonlocal_bind(value, namespace=namespace)
    if failed and root_namespace:
        # Somewhere in the 3.19 kernel timeframe ip_nonlocal_bind was
        # changed to be a per-namespace attribute.  To be backwards
        # compatible we need to try both if at first we fail.
        LOG.debug('Namespace (%s) does not support setting %s, '
                  'trying in root namespace', namespace, IP_NONLOCAL_BIND)
        return set_ip_nonlocal_bind(value)
    if failed:
        LOG.warning(
            "%s will not be set to %d in the root namespace in order to "
            "not break DVR, which requires this value be set to 1. This "
            "may introduce a race between moving a floating IP to a "
            "different network node, and the peer side getting a "
            "populated ARP cache for a given floating IP address.",
            IP_NONLOCAL_BIND, value)
    return None


def set_ip_nonlocal_bind(value, namespace=None):
    """Set sysctl knob of ip_nonlocal_bind to given value."""
    cmd = ['%s=%d' % (IP_NONLOCAL_BIND, value)]
    return sysctl(cmd, namespace=namespace)


def get_ipv6_lladdr(mac_addr):
    return '%s/64' % netaddr.EUI(mac_addr).ipv6_link_local()


def get_cdll():
    global _CDLL
    if not _CDLL:
        # NOTE(ralonsoh): from https://docs.python.org/3.6/library/
        # ctypes.html#ctypes.PyDLL: "Instances of this class behave like CDLL
        # instances, except that the Python GIL is not released during the
        # function call, and after the function execution the Python error
        # flag is checked."
        # Check https://bugs.launchpad.net/neutron/+bug/1870352
        _CDLL = ctypes.PyDLL(ctypes_util.find_library('c'), use_errno=True)
    return _CDLL


def list_netns(**kwargs):
    """List network namespaces.

    Caller requires raised priveleges to list namespaces
    """
    return netns.listnetns(**kwargs)


class NetworkNamespaceNotFound(RuntimeError):
    message = _("Network namespace %(netns_name)s could not be found.")

    def __init__(self, netns_name):
        super().__init__(
            self.message % {'netns_name': netns_name})


class NetworkInterfaceNotFound(RuntimeError):
    message = _("Network interface %(device)s not found in namespace "
                "%(namespace)s.")

    def __init__(self, message=None, device=None, namespace=None):
        message = message or self.message % {
            'device': device, 'namespace': namespace}
        super().__init__(message)


class InterfaceOperationNotSupported(RuntimeError):
    message = _("Operation not supported on interface %(device)s, namespace "
                "%(namespace)s.")

    def __init__(self, message=None, device=None, namespace=None):
        message = message or self.message % {
            'device': device, 'namespace': namespace}
        super().__init__(message)


class InvalidArgument(RuntimeError):
    message = _("Invalid parameter/value used on interface %(device)s, "
                "namespace %(namespace)s.")

    def __init__(self, message=None, device=None, namespace=None):
        message = message or self.message % {'device': device,
                                             'namespace': namespace}
        super().__init__(message)


class IpAddressAlreadyExists(RuntimeError):
    message = _("IP address %(ip)s already configured on %(device)s.")

    def __init__(self, message=None, ip=None, device=None):
        message = message or self.message % {'ip': ip, 'device': device}
        super().__init__(message)


class InterfaceAlreadyExists(RuntimeError):
    message = _("Interface %(device)s already exists.")

    def __init__(self, message=None, device=None):
        message = message or self.message % {'device': device}
        super().__init__(message)
