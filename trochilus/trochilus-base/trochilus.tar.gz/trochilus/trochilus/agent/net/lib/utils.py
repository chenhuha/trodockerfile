# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import os

import tempfile

import time

from eventlet.green import subprocess
from oslo_log import log as logging
from oslo_utils import encodeutils


LOG = logging.getLogger(__name__)


def execute(cmd, process_input=None, addl_env=None,
            check_exit_code=True, return_stderr=False, log_fail_as_error=True,
            extra_ok_codes=None):
    try:
        if process_input is not None:
            _process_input = encodeutils.to_utf8(process_input)
        else:
            _process_input = None

        _stdout, _stderr, returncode = execute_process(
            cmd, _process_input, addl_env)

        extra_ok_codes = extra_ok_codes or []
        if returncode and returncode not in extra_ok_codes:
            msg = ("Exit code: %(returncode)d; "
                   "Cmd: %(cmd)s; "
                   "Stdin: %(stdin)s; "
                   "Stdout: %(stdout)s; "
                   "Stderr: %(stderr)s" % {'returncode': returncode,
                                           'cmd': cmd,
                                           'stdin': process_input or '',
                                           'stdout': _stdout,
                                           'stderr': _stderr})

            if log_fail_as_error:
                LOG.error(msg)
            if check_exit_code:
                raise Exception(msg)
    finally:
        # NOTE(termie): this appears to be necessary to let the subprocess
        #               call clean something up in between calls, without
        #               it two execute calls in a row hangs the second one
        time.sleep(0)

    return (_stdout, _stderr) if return_stderr else _stdout


def execute_process(cmd, _process_input, addl_env):
    obj, cmd = _create_process(cmd, addl_env=addl_env)
    _stdout, _stderr = obj.communicate(_process_input)
    returncode = obj.returncode
    obj.stdin.close()
    _stdout = safe_decode_utf8(_stdout)
    _stderr = safe_decode_utf8(_stderr)
    return _stdout, _stderr, returncode


def _create_process(cmd, addl_env=None):
    """Create a process object for the given command.

    The return value will be a tuple of the process object and the
    list of command arguments used to create it.
    """
    cmd = list(map(str, _addl_env_args(addl_env) + list(cmd)))
    obj = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return obj, cmd


def _addl_env_args(addl_env):
    """Build arguments for adding additional environment vars with env"""

    # NOTE (twilson) If using rootwrap, an EnvFilter should be set up for the
    # command instead of a CommandFilter.
    if addl_env is None:
        return []
    return ['env'] + ['%s=%s' % pair for pair in addl_env.items()]


def safe_decode_utf8(s):
    """Safe decode a str from UTF.

    :param s: The str to decode.
    :returns: The decoded str.
    """
    if isinstance(s, bytes):
        return s.decode('utf-8', 'surrogateescape')
    return s


def replace_file(file_name, data, file_mode=0o666):
    """Replaces the contents of file_name with data in a safe manner.

    First write to a temp file and then rename. Since POSIX renames are
    atomic, the file is unlikely to be corrupted by competing writes.

    We create the tempfile on the same device to ensure that it can be renamed.

    :param file_name: Path to the file to replace.
    :param data: The data to write to the file.
    :param file_mode: The mode to use for the replaced file.
    :returns: None.
    """

    base_dir = os.path.dirname(os.path.abspath(file_name))
    with tempfile.NamedTemporaryFile('w+',
                                     dir=base_dir,
                                     delete=False) as tmp_file:
        tmp_file.write(data)
    os.chmod(tmp_file.name, file_mode)
    os.rename(tmp_file.name, file_name)
