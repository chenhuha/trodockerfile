# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import os

import netifaces

from oslo_concurrency import processutils
from oslo_config import cfg
from oslo_log import log as logging

from trochilus.db import agent_repo
from trochilus.db import api as db_api
from trochilus.db import network_repo

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


class Network(object):

    def __init__(self):
        self.agent_repo = agent_repo.AgentRepository()
        self.network_repo = network_repo.NetworkRepository()

    def report_network_info(self):
        session = db_api.get_session()
        netcard_list = self.get_type()
        vlan_dic = self.get_vlan()
        agent_obj = self.agent_repo.get(
            session, hostname=CONF.agent_settings.hostname)

        if agent_obj:
            net = self.network_repo
            ag_id = agent_obj.id
            network_objs = net.get_all(session, agent_id=ag_id)[0]
            for i in netcard_list:
                ip = i.get('ip_address')
                mask = i.get('netmask')
                name = i.get('name')
                gateway = i.get('gateway')
                bond_name = i.get('bond_name')
                if name != vlan_dic.get('name'):
                    vlan = ''
                else:
                    vlan = vlan_dic.get('range')
                if not network_objs:
                    net_dic = {'agent_id': ag_id,
                               'nic_name': name,
                               'status': i.get('status'),
                               'ip_addresses': ip,
                               'subnet_mask': mask,
                               'gateway': gateway,
                               'speed': i.get('speed'),
                               'vlan': vlan,
                               'bond_name': bond_name,
                               'role': i.get('role'),
                               'type': i.get('type')}
                    self.network_repo.create(session, **net_dic)
                else:
                    net_obj = net.get(session, nic_name=name, agent_id=ag_id)
                    if not net_obj:
                        net_dic = {'agent_id': ag_id,
                                   'nic_name': name,
                                   'status': i.get('status'),
                                   'ip_addresses': ip,
                                   'subnet_mask': mask,
                                   'gateway': gateway,
                                   'speed': i.get('speed'),
                                   'vlan': vlan,
                                   'bond_name': bond_name,
                                   'role': i.get('role'),
                                   'type': i.get('type')}
                        self.network_repo.create(session, **net_dic)
                    else:
                        self.network_repo.update(session, net_obj.id,
                                                 **{'nic_name': name,
                                                    'status': i.get('status'),
                                                    'ip_addresses': ip,
                                                    'subnet_mask': mask,
                                                    'gateway': gateway,
                                                    'speed': i.get('speed'),
                                                    'vlan': vlan,
                                                    'bond_name': bond_name,
                                                    'role': i.get('role'),
                                                    'type': i.get('type')})

    def get_physical_netcard(self):
        netcard = os.listdir("/sys/class/net")
        virtual_netcard = os.listdir("/sys/devices/virtual/net/")
        netcard_all = list(set(netcard) ^ set(virtual_netcard))
        for netcard in netcard_all:
            if netcard == "bonding_masters":
                path = '/sys/' + 'class/' + 'net/' + 'bonding_masters'
                position = os.path.join(path)
                with open(position, encoding='utf-8') as bond_names:
                    bond_name_info = bond_names.read().strip().split(' ')
                    netcard_all.remove('bonding_masters')
                netcard_all.extend(bond_name_info)
        return netcard_all

    def bond_list(self):
        path = '/sys/' + 'class/' + 'net/' + 'bonding_masters'
        position = os.path.join(path)
        bond_name_info = []
        if os.path.exists(position):
            with open(position, encoding='utf-8') as bond_names:
                bond_name_info = bond_names.read().strip().split(' ')
        return bond_name_info

    def _execute_net_cmd(self, cmd):
        try:
            result = processutils.execute(*cmd)[0].replace('\n', '')
        except processutils.ProcessExecutionError:
            return None
        return result

    def netcard_information(self):
        netname_list = self.get_physical_netcard()
        outlist = []

        for name in netname_list:
            innerdict = {}
            if name:
                status = self._execute_net_cmd(['cat', '/sys/class/net/' +
                                                name + '/carrier'])
                speed = self._execute_net_cmd(['cat', '/sys/class/net/' +
                                               name + '/speed'])
                innerdict = {'name': name,
                             'ip_address': [],
                             'netmask': '',
                             'gateway': '',
                             'status': status,
                             'speed': speed}

                net_infos = netifaces.ifaddresses(name).get(
                    netifaces.AF_INET, [])
                if net_infos:
                    innerdict['netmask'] = net_infos[0]['netmask']
                    for netinfo in net_infos:
                        innerdict['ip_address'].append(netinfo['addr'])

                gateway_infos = netifaces.gateways().get(netifaces.AF_INET, [])
                if gateway_infos:
                    gateway = [g[0] for g in gateway_infos if name in g]
                    if gateway:
                        innerdict['gateway'] = gateway[0]

                outlist.append(innerdict)
        return outlist

    def get_vlan(self):
        vlan_ranges = CONF.network_settings.physical_vlan_ranges
        phy_lists = CONF.network_settings.physical_interface_mappings
        if vlan_ranges:
            for vlan_range in vlan_ranges:
                vlan_dic = {}
                name = vlan_range.split(':')[0]
                min = vlan_range.split(':')[1]
                max = vlan_range.split(':')[2]
                for phy_list in phy_lists:
                    phy_name = phy_list.split(':')[0]
                    if phy_name == name:
                        vlan_dic['name'] = phy_list.split(':')[1]
                        vlan_dic['range'] = min + ':' + max
        else:
            vlan_dic = {}
        return vlan_dic

    def get_bond_name(self):
        net_info = self.netcard_information()
        outlist = []
        for net in net_info:
            phy_name = net.get('name')
            path = "/sys/class/net/" + phy_name
            bond_name = os.listdir(path)
            item = "upper_bond"
            net['bond_name'] = ''
            for i in bond_name:
                if item in i:
                    net['bond_name'] = i.replace('upper_', '')
                    break
            outlist.append(net)
        return outlist

    def get_net_role(self):
        net_info = self.get_bond_name()
        outlist = []
        nics = CONF.agent_settings.nic
        for net in net_info:
            net['role'] = ''
            bond_names = net.get('bond_name')
            if bond_names:
                for nic in nics:
                    phy_names = nic.split(':')[-1].split(',')
                    bond_name = nic.split(':')[0]
                    if bond_names == bond_name:
                        for phy_name in phy_names:
                            if net.get('name') == phy_name:
                                net['role'] = nic.split(':')[2]
            else:
                for nic_ in nics:
                    phy = nic_.split(':')[0]
                    if phy == net.get('name'):
                        net['role'] = nic_.split(':')[2]
            outlist.append(net)
        return outlist

    def get_type(self):
        net_info = self.get_net_role()
        outlist = []
        bond = self.bond_list()
        for net in net_info:
            if net.get('name') in bond:
                net['type'] = 'bond'
            else:
                net['type'] = 'physical'
            outlist.append(net)
        return outlist
