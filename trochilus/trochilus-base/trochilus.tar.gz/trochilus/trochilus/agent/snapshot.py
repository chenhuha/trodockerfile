# Copyright 2022 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from oslo_log import log as logging
from oslo_utils import timeutils

from trochilus.agent import volume
from trochilus.common import constants
from trochilus.db import api as db_api
from trochilus.db import snapshot_repo
from trochilus.db import volume_repo


LOG = logging.getLogger(__name__)


class Snapshot(object):

    def __init__(self, queue):
        self.drivers = volume.Volume.DRIVERS
        self.volume_repo = volume_repo.VolumeRepository()
        self.snapshot_repo = snapshot_repo.SnapshotRepository()
        self.status_queue = queue

    def create(self, id):
        session = db_api.get_session()
        snapshot_obj = self.snapshot_repo.get(session, id=id)
        volume_obj = self.volume_repo.get(session,
                                          id=snapshot_obj.volume_id)
        backend = volume_obj.backend

        try:
            self.drivers[backend].create_snapshot(snapshot_obj)
        except Exception as e:
            LOG.error("Create snapshot %s failded", id)
            self.snapshot_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "snapshot",
                "resource_id": id,
                "previous_status": constants.CREATING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "create",
                "timestamp": timeutils.utcnow()})
            raise e

        self.snapshot_repo.update(session, id, status=constants.AVAILABLE)
        LOG.info("Create snapshot %s successful", id)
        self.status_queue.put({
            "resource_type": "snapshot",
            "resource_id": id,
            "previous_status": constants.CREATING,
            "current_status": constants.AVAILABLE,
            "action": "create",
            "timestamp": timeutils.utcnow()})

    def delete(self, id):
        session = db_api.get_session()
        snapshot_obj = self.snapshot_repo.get(session, id=id)
        volume_obj = self.volume_repo.get(session,
                                          id=snapshot_obj.volume_id)
        backend = volume_obj.backend

        try:
            self.drivers[backend].delete_snapshot(snapshot_obj)
        except Exception as e:
            LOG.error("Delete snapshot %s failded", id)
            self.snapshot_repo.update(
                session, id, status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "snapshot",
                "resource_id": id,
                "previous_status": constants.DELETING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "delete",
                "timestamp": timeutils.utcnow()})
            raise e

        self.snapshot_repo.update(session, id, status=constants.DELETED)
        LOG.info("Delete snapshot %s successful", id)
        self.status_queue.put({
            "resource_type": "snapshot",
            "resource_id": id,
            "previous_status": constants.DELETING,
            "current_status": constants.DELETED,
            "action": "delete",
            "timestamp": timeutils.utcnow()})

    def clone(self, snap_id, vol_id, flatten):
        session = db_api.get_session()
        snapshot_obj = self.snapshot_repo.get(session, id=snap_id)
        volume_obj = self.volume_repo.get(session, id=vol_id)
        backend = volume_obj.backend

        try:
            self.drivers[backend].create_volume_from_snapshot(snapshot_obj,
                                                              volume_obj,
                                                              flatten)
        except Exception as e:
            LOG.error("Clone volume %(vol)s from the snapshot "
                      "%(snap)s failded",
                      {'vol': volume_obj.id, 'snap': snapshot_obj.id})
            self.volume_repo.update(session,
                                    vol_id,
                                    status=constants.ERROR)
            self.status_queue.put({
                "resource_type": "volume",
                "resource_id": volume_obj.id,
                "previous_status": constants.CLONING,
                "current_status": constants.ERROR,
                "error_msg": str(e),
                "action": "clone",
                "timestamp": timeutils.utcnow()})
            raise e

        self.volume_repo.update(session,
                                vol_id,
                                status=constants.AVAILABLE)
        LOG.info("Clone volume %(vol)s from the snapshot "
                 "%(snap)s successful",
                 {'vol': volume_obj.id, 'snap': snapshot_obj.id})
        self.status_queue.put({
            "resource_type": "volume",
            "resource_id": volume_obj.id,
            "previous_status": constants.CLONING,
            "current_status": constants.AVAILABLE,
            "action": "clone",
            "timestamp": timeutils.utcnow()})
