# Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import sys

from oslo_config import cfg
from oslo_log import log as logging
from oslo_service import wsgi
from oslo_utils import units

from trochilus.common import constants
from trochilus.common import utils
from trochilus.i18n import _
from trochilus import version

LOG = logging.getLogger(__name__)


api_opts = [
    cfg.IPOpt('bind_host', default='127.0.0.1',
              help=_("The host IP to bind to")),
    cfg.PortOpt('bind_port', default=9906,
                help=_("The port to bind to")),
    cfg.BoolOpt('allow_field_selection', default=True,
                help=_("Allow the usage of field selection")),
    cfg.IntOpt('agent_down_time', default=75,
               help=_("Seconds to regard the agent is down; should be at "
                      "least twice report_interval, to be sure the agent "
                      "is down for good.")),
    cfg.ListOpt('enabled_volume_backends',
                default=[],
                help='A list of backend names to use. These backend names '
                     'should be backed by a unique [CONFIG] group '
                     'with its options. If value is [],'
                     'will not enable any driver.'),
    cfg.ListOpt('supported_instance_metadatas', default=[],
                help=_("List of the virtual machine metadata "
                       "that the current environment supported.")),
    cfg.BoolOpt('allow_pagination', default=True,
                help=_("Allow the usage of pagination")),
    cfg.StrOpt('pagination_max_limit',
               default=str(constants.DEFAULT_PAGE_SIZE),
               help=_("The maximum number of items returned in a single "
                      "response. The string 'infinite' or a negative "
                      "integer value means 'no limit'")),
    cfg.StrOpt('api_base_uri',
               help=_("Base URI for the API for use in pagination links. "
                      "This will be autodetected from the request if not "
                      "overridden here.")),
    cfg.BoolOpt('allow_sorting', default=True,
                help=_("Allow the usage of sorting")),
    cfg.BoolOpt('allow_filtering', default=True,
                help=_("Allow the usage of filtering"))
]

agent_client_opts = [
    cfg.IntOpt('connection_max_retries',
               default=120,
               help=_('Retry threshold for connecting to trochilus agent.')),
    cfg.IntOpt('connection_retry_interval',
               default=5,
               help=_('Retry timeout between connection attempts in '
                      'seconds.')),
    cfg.FloatOpt('rest_request_conn_timeout', default=10,
                 help=_("The time in seconds to wait for a REST API "
                        "to connect.")),
    cfg.FloatOpt('rest_request_read_timeout', default=60,
                 help=_("The time in seconds to wait for a REST API "
                        "response.")),
]

agent_opts = [
    cfg.IPOpt('bind_host', default='127.0.0.1',
              help=_("The host IP to bind to")),
    cfg.PortOpt('bind_port', default=9916,
                help=_("The port to bind to")),
    cfg.HostnameOpt('hostname', default=utils.get_hostname(),
                    sample_default='<server-hostname.example.com>',
                    help=_("The hostname trochilus-agent is running on")),
    cfg.IntOpt("report_interval", default=30,
               help=_('Seconds between nodes reporting state to database; '
                      'should be less than agent_down_time, best if it is '
                      'half or less than agent_down_time.')),
    cfg.IntOpt("sync_vpc_interval", default=120,
               help=_('Seconds between synchronize vpc_node_mapping'
                      ' to database')),
    cfg.IntOpt("sync_dhcp_interval", default=120,
               help=_('Seconds between synchronize dhcp')),
    cfg.IntOpt("report_network_info_interval", default=60,
               help=_('Seconds between report network info')),
    cfg.IntOpt("power_status_inspector_interval", default=600, min=60,
               help=_('Seconds between inspect VM power status')),
    cfg.IntOpt("create_timeout_inspector_interval", default=60, min=0,
               help=_('Seconds between inspect resource create timeout')),
    cfg.IntOpt("vm_create_timeout", default=600, min=0,
               help=_('Seconds for vm create timeout')),
    cfg.IntOpt("voi_vm_create_timeout", default=600, min=0,
               help=_('Seconds for voi vm create timeout')),
    cfg.StrOpt('check_child_processes_action', default='respawn',
               choices=['respawn', 'exit'],
               help=_('Action to be executed when a child process dies')),
    cfg.IntOpt('check_child_processes_interval', default=60,
               help=_('Interval between checks of child process liveness '
                      '(seconds), use 0 to disable')),
    cfg.StrOpt('external_pids',
               default='/var/lib/trochilus/external/pids',
               help=_('Location to store child pid files')),
    cfg.StrOpt('system', default='', help=_('The host system used')),
    cfg.FloatOpt('version', default='', help=_('The host version used')),
    cfg.ListOpt('role', default=['controller'],
                help=_('Multiple roles can be filled in for the host.'
                       'controller: The host is a controller node'
                       'computer: The host is a computer node'
                       'storage: The host is a storage node')),
    cfg.StrOpt('kill_scripts_path', default='/etc/trochilus/kill_scripts/',
               help=_('Location of scripts used to kill external processes. '
                      'Names of scripts here must follow the pattern: '
                      '"<process-name>-kill" where <process-name> is name of '
                      'the process which should be killed using this script. '
                      'For example, kill script for dnsmasq process should be '
                      'named "dnsmasq-kill". '
                      'If path is set to None, then default "kill" command '
                      'will be used to stop processes.')),
    cfg.MultiStrOpt('nic', default=[],
                    help=_('If the nic is bonded.'
                           'specify the name of the physical NIC.'
                           'Assign a role to the NIC.'
                           '<bond_name>:<ip_address>:<role>:<nic_name>.'
                           'Otherwise, the nic role is specified.'
                           '<nic_name>:<ip_address>:<role>.')),
    cfg.StrOpt('ipmi_username', default='', help=_('The ipmi username')),
    cfg.StrOpt('ipmi_password', default='', help=_('The ipmi password')),
    cfg.StrOpt('ipmi_vendor', default='HUAWEI',
               help=_('The ipmi vendor, Brand name of the server')),
    cfg.StrOpt('host_username', default='root', help=_('The host username')),
    cfg.StrOpt('host_password', default='', help=_('The host password'))
]

image_opts = [
    cfg.StrOpt('filesystem_store_datadir',
               default='/var/lib/trochilus/images',
               help=_("The filesystem store image data dir")),
    cfg.IntOpt('image_size_cap',
               default=1099511627776,
               min=1,
               max=9223372036854775808,
               help=_("Maximum size of image a user can upload in bytes")),
    cfg.IntOpt(
        'filesystem_store_chunk_size',
        default=64 * units.Ki,
        min=1,
        help=_('The chunk size used when reading or writing image files.')),
    cfg.StrOpt(
        'enabled_image_store',
        default="filesystem",
        choices=('filesystem', 'rbd'),
        help=_('The default scheme to use for storing images.'
               'Currently, only two types are supported: '
               '"filesystem" "rbd"')),
    cfg.StrOpt(
        'rbd_store_config_file',
        default="/etc/ceph/ceph.conf",
        help=_('Path to the ceph configuration file')),
    cfg.StrOpt(
        'rbd_store_user',
        default="images",
        help=_('RADOS user to authenticate as.')),
    cfg.StrOpt(
        'rbd_store_pool',
        default="images",
        help=_('RADOS pool in which images are stored.')),
    cfg.IntOpt(
        'rbd_store_chunk_size',
        default=8,
        help=_('Size, in megabytes, to chunk RADOS images into.')),
    cfg.IntOpt(
        'rbd_store_conn_timeout',
        default=0,
        help=_('Timeout value for connecting to Ceph cluster.'
               'units are seconds')),
    cfg.BoolOpt('rbd_store_thin_provisioning',
                default=True,
                help=_('Enable or not thin provisioning in rbd store.'
                       'Enabling this feature will also speed up image'
                       ' upload and save network traffic in addition to'
                       ' save space in the backend, as null bytes sequences'
                       ' are not sent over the network.')),
    cfg.StrOpt('tmp_image_dir',
               default='/var/lib/trochilus/images/tmp',
               help=_('The tmp_image_dir is temporary storage of image files '
                      'for format conversion')),
]

network_opts = [
    cfg.ListOpt('physical_vlan_ranges',
                default=[],
                help=_("List of <physical_network>:<vlan_min>:<vlan_max> "
                       "specifying physical_network names usable for VLAN "
                       "provider and tenant networks, as well as ranges of "
                       "VLAN tags on each available for allocation to tenant "
                       "networks.")),
    cfg.ListOpt(
        'support_flat_physicals',
        default=[],
        help=_("List of physical names with which flat vpcs "
               "can be created. Use an empty list means "
               "no supported flat vpcs.")),
    cfg.ListOpt('physical_interface_mappings',
                default=[],
                help=_("Comma-separated list of "
                       "<physical_network>:<physical_interface> tuples "
                       "mapping physical network names to the agent's "
                       "node-specific physical network interfaces to be used "
                       "for flat and VLAN networks. All physical networks "
                       "listed in network_vlan_ranges on the server should "
                       "have mappings to appropriate interfaces on each "
                       "agent.")),
    cfg.StrOpt('base_mac', default="fa:16:3e:00:00:00",
               help=_("The base MAC address Neutron will use for VIFs. "
                      "The first 3 octets will remain unchanged. If the 4th "
                      "octet is not 00, it will also be used. The others "
                      "will be randomly generated.")),
    cfg.StrOpt('dhcp_confs',
               default='/var/lib/trochilus/dhcp',
               help=_('Location to store DHCP server config files.')),
    cfg.IntOpt('dhcp_lease_duration', default=86400,
               help=_("DHCP lease duration (in seconds). Use -1 to tell "
                      "dnsmasq to use infinite lease times.")),
    cfg.BoolOpt('dhcp_broadcast_reply', default=False,
                help=_("Use broadcast in DHCP replies.")),
    cfg.IntOpt('dhcp_renewal_time', default=0,
               help=_("DHCP renewal time T1 (in seconds). If set to 0, it "
                      "will default to half of the lease time.")),
    cfg.IntOpt('dhcp_rebinding_time', default=0,
               help=_("DHCP rebinding time T2 (in seconds). If set to 0, it "
                      "will default to 7/8 of the lease time.")),
    cfg.StrOpt('dns_domain',
               default='trochiluslocal',
               help=_('Domain to use for building the hostnames')),
    cfg.ListOpt('dnsmasq_dns_servers',
                default=['114.114.114.114', '8.8.8.8'],
                help=_('Comma-separated list of the DNS servers which will be '
                       'used as forwarders.')),
    cfg.StrOpt('dnsmasq_base_log_dir',
               default='/var/log/trochilus/dhcp',
               help=_("Base log dir for dnsmasq logging. "
                      "The log contains DHCP and DNS log information and "
                      "is useful for debugging issues with either DHCP or "
                      "DNS. If this section is null, disable dnsmasq log.")),
    cfg.IntOpt(
        'dnsmasq_lease_max',
        default=(2 ** 24),
        help=_('Limit number of leases to prevent a denial-of-service.')),
    cfg.StrOpt('dnsmasq_config_file',
               default='',
               help=_('Override the default dnsmasq settings '
                      'with this file.'))
]

webhook_opts = [
    cfg.IPOpt('target_host', default='127.0.0.1',
              help=_("The IP address of the webhook's target service.")),
    cfg.PortOpt('target_port', default='9082',
                help=_("The port of the webhook's target service")),
    cfg.StrOpt('target_path', default="/v1/webhook",
               help=_("The url path of the webhook's target service")),
    cfg.StrOpt('method', default='put',
               help=_("The http method which send the status event.")),
    cfg.StrOpt('auth_token', default='',
               help=_("The token will be insert to request header, it used "
                      "to identify the client and targent of webhook")),
    cfg.IntOpt('max_retries', default=3,
               help=_("Retry number of send webhook event.")),
    cfg.IntOpt('retry_interval',
               default=5,
               help=_('Retry timeout between connection attempts in '
                      'seconds.')),
    cfg.FloatOpt('request_conn_timeout', default=10,
                 help=_("The time in seconds to wait for a REST request "
                        "to connect.")),
    cfg.FloatOpt('request_read_timeout', default=60,
                 help=_("The time in seconds to wait for a REST request "
                        "response.")),
    cfg.ListOpt('expected_codes', default=['200', '202', '204'],
                help=_("The expected resonse's code range when the event "
                       "send successful.")),
]

example_webhook_service_opts = [
    cfg.IPOpt('bind_host', default='127.0.0.1',
              help=_("The host IP to bind to")),
    cfg.PortOpt('bind_port', default=9082,
                help=_("The port to bind to")),
]

vm_opts = [
    cfg.StrOpt('virt_type',
               default='kvm',
               choices=('kvm', 'qemu'),
               help=_('Describes the virtualization type libvirt should. '
                      'Current support kvm or qemu')),
    cfg.StrOpt('default_root_disk_backend',
               default='',
               help=_('default backend name to use. '
                      'The value should be one of'
                      ' [api_setting]enabled_volume_backends')),
    cfg.StrOpt('vm_name_template',
               default='vm-%s',
               help=_('Template string to be used to generate VM names in '
                      'libvirt. This is *not* the display name you enter '
                      'when creating a VM')),
    cfg.IntOpt('mem_stats_period_seconds',
               default=10,
               help='A number of seconds to memory usage statistics period. '
                    'Zero or negative value mean to disable memory usage '
                    'statistics.'),
    cfg.StrOpt('rbd_secret_uuid',
               help='The libvirt UUID of the secret for the rbd_user.'),
    cfg.BoolOpt('vnc_enabled',
                default=False,
                help='Enable VNC related features.'),
    cfg.StrOpt('vnc_server_listen',
               default='127.0.0.1',
               help='The IP address or hostname on which an VM should'
                    ' listen to for incoming VNC connection requests '
                    'on this node.'),
    cfg.BoolOpt('spice_enabled',
                default=False,
                help='Enable SPICE related features.'),
    cfg.StrOpt('spice_server_listen',
               default='127.0.0.1',
               help='The IP address or hostname on which an VM should'
                    ' listen to for incoming SPICE connection requests '
                    'on this node.'),
    cfg.IntOpt('wait_soft_reboot_seconds',
               default=120,
               help='Number of seconds to wait for VM to shut down after'
                    ' soft reboot request is made. We fall back to hard reboot'
                    ' if VM does not shutdown within this window.'),
    cfg.IntOpt("clean_shutdown_timeout",
               default=60,
               min=0,
               help='Total time to wait in seconds for an VM to'
                    ' perform a clean shutdown.'),
    cfg.IntOpt("clean_shutdown_retry_interval",
               default=10,
               min=1,
               help='Time to wait in seconds before resending an ACPI '
               'shutdown signal to VM. The overall time to wait is set by '
               '``clean_shutdown_timeout``.'),
    cfg.IntOpt('device_detach_attempts',
               default=8,
               min=1,
               help='Maximum number of attempts the driver tries to detach '
                    'a device in libvirt. Related options: oslo.config:option:'
                    '`libvirt.device_detach_timeout`'),
    cfg.IntOpt('device_detach_timeout',
               default=20,
               min=1,
               help='Maximum number of seconds the driver waits for the '
                    'success or the failure event from libvirt for a given '
                    'device detach attempt before it re-trigger the detach.'
                    'Related options: oslo.config:option:'
                    '`libvirt.device_detach_attempts`'),
    cfg.IntOpt('num_pcie_ports',
               default=10,
               min=0,
               max=28,
               help='The number of PCIe ports an VM will get. More info'
                    ': https://github.com/qemu/qemu/blob/master/docs/pcie.txt')
]

voi_opts = [
    cfg.StrOpt("voi_image_base_path", default="/var/lib/trochilus/voi/images",
               help="The voi image base directory."),
    cfg.StrOpt("voi_vm_base_path", default="/var/lib/trochilus/voi/vms",
               help="The voi vm base directory."),
    cfg.StrOpt('vm_name_template',
               default='voi-%s',
               help=_('Template string to be used to generate VM names in '
                      'libvirt. This is *not* the display name you enter '
                      'when creating a VM')),
    cfg.StrOpt('share_template_disk_path',
               default='/var/lib/trochilus/voi/share-template-disks',
               help=_('The voi share template disk base directory.')),
]

scheduler_opts = [
    cfg.IntOpt('reserved_host_cpus',
               default=0,
               min=0,
               help='Number of host CPUs to reserve for host processes.'),
    cfg.IntOpt('reserved_host_memory_mb',
               default=512,
               min=0,
               help='Amount of memory in MB to reserve for the host so that '
                    'it is always available to host processes.'),
    cfg.FloatOpt('cpu_allocation_ratio',
                 default=16.0,
                 min=0.0,
                 help='Virtual CPU to physical CPU allocation ratio. This '
                      'option is used to influence the hosts selected when '
                      'scheduling.'),
    cfg.FloatOpt('memory_allocation_ratio',
                 default=1.5,
                 min=0.0,
                 help='Virtual Memory to physical RAM allocation ratio. This '
                      'option is used to influence the hosts selected when '
                      'scheduling.'),
    cfg.MultiStrOpt('available_filters',
                    default=["trochilus.scheduler.filters.all_filters"],
                    help='Filters that the scheduler can use. An unordered '
                         'list of the filter classes the scheduler may apply. '
                         'Only the filters specified in the enabled_filters '
                         'option will be used, but any filter appearing in '
                         'that option must also be included in this list.'),
    cfg.ListOpt("enabled_filters",
                default=["AgentStatusFilter"],
                help='Filters that the scheduler will use. An ordered list of '
                     'filter class names that will be used for filtering '
                     'hosts. These filters will be applied in the order they '
                     'are listed so place your most restrictive filters first '
                     'to make the filtering process more efficient.'),
    cfg.ListOpt("weight_classes",
                default=["trochilus.scheduler.weights.all_weighers"],
                help='Weighers that the scheduler will use. Only hosts which '
                     'pass the filters are weighed. The weight for any host '
                     'starts at 0, and the weighers order these hosts by '
                     'adding to or subtracting from the weight assigned by '
                     'the previous weigher. Weights may become negative. An '
                     'instance will be scheduled to one of the N '
                     'most-weighted hosts, where N is host_subset_size.'),
    cfg.FloatOpt("cpu_weight_multiplier",
                 default=1.0,
                 help='CPU weight multiplier ratio. Multiplier used for '
                      'weighting free vCPUs. Negative numbers indicate '
                      'stacking rather than spreading. Note that this setting '
                      'only affects scheduling if the CPUWeigher weigher is '
                      'enabled.'),
    cfg.FloatOpt("memory_weight_multiplier",
                 default=1.0,
                 help='Memory weight multipler ratio. This option determines '
                      'how hosts with more or less available memory are '
                      'weighed. A positive value will result in the scheduler '
                      'preferring hosts with more available memory, and a '
                      'negative number will result in the scheduler '
                      'preferring hosts with less available memory.  Note '
                      'that this setting only affects scheduling if the '
                      'MemoryWeigher weigher is enabled.'),
    cfg.IntOpt("host_subset_size",
               default=1,
               min=1,
               help='Size of subset of best hosts selected by scheduler. New '
                    'instances will be scheduled on a host chosen randomly '
                    'from a subset of the N best hosts, where N is the value '
                    'set by this option. Setting this to a value greater than '
                    '1 will reduce the chance that multiple scheduler '
                    'processes handling similar requests will select the same '
                    'host, creating a potential race condition. By selecting '
                    'a host randomly from the N hosts that best fit the '
                    'request, the chance of a conflict is reduced.'),
]

core_cli_opts = []

wsgi.register_opts(cfg.CONF)
cfg.CONF.register_opts(api_opts, group='api_settings')
cfg.CONF.register_opts(agent_client_opts, group='agent_rest_client')
cfg.CONF.register_opts(agent_opts, group='agent_settings')
cfg.CONF.register_opts(image_opts, group='image_settings')
cfg.CONF.register_opts(network_opts, group='network_settings')
cfg.CONF.register_opts(webhook_opts, group='webhook_settings')
cfg.CONF.register_opts(example_webhook_service_opts,
                       group='example_webhook_service_setting')
cfg.CONF.register_opts(vm_opts, group='vm_settings')
cfg.CONF.register_opts(voi_opts, group='voi_setting')
cfg.CONF.register_opts(scheduler_opts, group='scheduler_settings')


def register_cli_opts():
    cfg.CONF.register_cli_opts(core_cli_opts)
    logging.register_options(cfg.CONF)


def init(args, **kwargs):
    register_cli_opts()
    cfg.CONF(args=args, project='trochilus',
             version='%%prog %s' % version.version_info.release_string(),
             **kwargs)


def setup_logging(conf):
    """Sets up the logging options for a log with supplied name.

    :param conf: a cfg.ConfOpts object
    """
    product_name = "trochilus"
    logging.setup(conf, product_name)
    LOG.info("Logging enabled!")
    LOG.info("%(prog)s version %(version)s",
             {'prog': sys.argv[0],
              'version': version.version_info.release_string()})
    LOG.debug("command line: %s", " ".join(sys.argv))
