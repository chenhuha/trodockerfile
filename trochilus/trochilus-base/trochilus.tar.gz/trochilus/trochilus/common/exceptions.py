# Copyright 2021 Troila
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""
Trochilus base exception handling.
"""

from webob import exc

from oslo_serialization import jsonutils
from trochilus.i18n import _


# NOTE(blogan) Using webob exceptions here because WSME exceptions a very
# limited at this point and they do not work well in _lookup methods in the
# controllers
class APIException(exc.HTTPClientError):
    msg = "Something unknown went wrong"
    code = 500

    def __init__(self, **kwargs):
        if 'msg' in kwargs:
            msg = kwargs.get("msg")
            if isinstance(msg, dict):
                msg = jsonutils.dumps(msg)
        else:
            msg = self.msg
        self.msg = msg % kwargs
        super().__init__(detail=self.msg)


class NotFound(APIException):
    msg = _('%(resource)s %(id)s is not found.')
    code = 404


class ObjectInUse(APIException):
    msg = _("%(object)s %(id)s is in use and cannot be modified.")
    code = 409


class AgentStatusConflict(APIException):
    msg = _("The agent %(agent_id)s can not to %(action)s, it's "
            "status is %(status)s.")
    code = 403


class AgentClientError(APIException):
    msg = _("The trochilus api send request to agent %(agent_id)s occur "
            "errror. The reponse's code: %(code)s, msg: %(msg)s")
    code = 500


class AgentRESTClientRetryError(APIException):
    msg = _("The trochilus api failed send request to agent %(agent_id)s "
            " after %(retyr_num)s retries, msg: %(exception)s")
    code = 500


class InvalidRequest(APIException):
    msg = _("Bad request")
    code = 400


class ImageStatusConflict(APIException):
    msg = _(
        "Image current status is %(img_status)s does not allow this operation"
    )
    code = 409


class ImageDuplicate(APIException):
    msg = _("Image %(image)s already exists")
    code = 409


class ImageSizeLimitExceeded(APIException):
    msg = _("The provided image is too large.")
    code = 413


class StorageFull(APIException):
    msg = _("There is not enough disk space on the image storage media.")
    code = 413


class StorageWriteDenied(APIException):
    msg = _("Permission to write image storage media denied.")
    code = 503


class ImageFileNotFound(APIException):
    msg = _("The image file does not exist: %(image)s")
    code = 404


class ImageFileDeleteFaild(APIException):
    msg = _("Cannot delete image %(image)s.")
    code = 500


class ImageStreamingZeroError(APIException):
    msg = _("The streaming of the image is zero")
    code = 400


class ImageFormatError(APIException):
    msg = _("An unrecoverable image format error that aborts the process.")
    code = 400


class ImageFormatNotSupport(APIException):
    msg = _("The image format is not supported")
    code = 403


class ImageFormatCheckFaild(APIException):
    msg = _("The actual format of the image does not match that uploaded")
    code = 400


class ImageConvertFailed(APIException):
    msg = _("Failed to convert image from %(src_format) to %(dst_format)")
    code = 500


class StoreException(APIException):
    msg = _("Storage connection failure")
    code = 500


class InUseByStore(APIException):
    msg = _("The image cannot be deleted because it is in use .")
    code = 500


class HasSnapshot(APIException):
    msg = _("The image cannot be deleted because it has snapshot(s).")
    code = 500


class InvalidImageStatus(APIException):
    msg = _(
        "The image status must be active."
    )
    code = 409


class InvalidVMStatus(APIException):
    msg = _(
        "The VM status must be active."
    )
    code = 403


class ImageSizeExceedsVolume(APIException):
    msg = _("Requested image size %(img_size)fG is larger than "
            "new volume size %(vol_size)fG.")
    code = 403


class ImageDiskFormatError(APIException):
    msg = _("Image %(image_id)s is unacceptable: %(reason)s")
    code = 403


class SourceSnapshotSizeExceedsVolume(APIException):
    msg = _("Requested snapshot size %(size)fG is larger than "
            "new volume size %(vol_size)fG.")
    code = 403


class SourceVolumeSizeExceedsVolume(APIException):
    msg = _("Requested volume size %(size)fG is larger than "
            "new volume size %(vol_size)fG.")
    code = 403


class ValidationException(APIException):
    msg = _("Validation failure: %(detail)s")
    code = 400


class InvalidVlanId(APIException):
    msg = _("The vlan %(vlan_id)s is invalid, %(reason)s.")
    code = 400


class VlanIdExhausted(APIException):
    msg = _("Can't not auto allocate vlan, the physical %(physical)s "
            "already was exhausted.")
    code = 403


class InvalidPhysicalVpcType(APIException):
    msg = _("The physical %(physical)s don't support to create %(type)s vpc.")
    code = 403


class PyhsicalFlatVpcAlreadyExist(APIException):
    msg = _("The physical %(physical)s already exist a Flat VPC.")
    code = 403


class DeleteConflict(APIException):
    msg = _("The %(resource)s %(id)s's status is %(status)s.")
    code = 403


class IPaddressNotInCidr(APIException):
    msg = _("The %(name)s %(addr)s is not in the subnet range "
            "'%(cidr)s' or not available ip address.")
    code = 403


class IPVersionConflict(APIException):
    msg = _("The %(name)s %(addr)s does not match "
            "the ip_version '%(ip_version)s'")
    code = 403


class CidrConflict(APIException):
    msg = _("The cidr %(cidr)s conflict with "
            "the existing subnet of vpc %(vpc)s.")
    code = 403


class InvalidAddressFormat(APIException):
    msg = _("The %(name)s %(addr)s format is invalid on the subnet.")
    code = 403


class VolumeNotFound(APIException):
    msg = _("The %(id)s volume does not exist.")
    code = 404


class VolumeDeleteConflict(APIException):
    msg = _("The volume %(id)s's status is %(status)s.")
    code = 403


class InvalidVolume(APIException):
    msg = _("Volume %(id)s status must be %(status)s, "
            "but current status is: %(cur_status)s. ")
    code = 403


class InvalidVolumeState(APIException):
    msg = _("Volume %(id)s status is %(status)s, "
            "current state cannot change the size. ")
    code = 403


class InvalidVolumeSize(APIException):
    msg = _("Must be greater than the original value")


class VolumeHasSnapshot(APIException):
    msg = _("The Volume %(id)s cannot be deleted, "
            "because it has snapshot(s).")
    code = 403


class InvalidSnapshot(APIException):
    msg = _("Snapshot %(id)s status must be %(status)s, "
            "but current status is: %(cur_status)s. ")
    code = 403


class SnapshotHasSnapshotGroup(APIException):
    msg = _("The snapshot %(id)s cannot be deleted, "
            "because it belong to snapshot group %(sg_id)s.")
    code = 403


class UnsupportVolumeAction(InvalidRequest):
    msg = _("Unsupport Volume action %(action_name)s")


class AddressExist(APIException):
    msg = _("The %(name)s %(addr)s exists.")
    code = 403


class InvalidAddressPool(APIException):
    msg = _("The address pool %(pool)s is not valid.")
    code = 400


class OutOfBoundsAddressPool(APIException):
    msg = _("The address pool %(pool)s spans "
            "beyond the subnet cidr %(subnet_cidr)s.")
    code = 400


class OverlappingAddressPools(APIException):
    msg = _("Found overlapping address pools: "
            "%(pool_1)s %(pool_2)s for subnet %(subnet_cidr)s.")
    code = 400


class GatewayConflictWithAddressPools(APIException):
    msg = _("Gateway ip %(ip_address)s conflicts with "
            "address pool %(pool)s.")
    code = 400


class InvalidAllocationPool(APIException):
    message = _("The allocation pool %(pool)s is not valid.")
    code = 400


class IpExhausted(APIException):
    msg = _("There is no ip in subnet with id %(subnet_id)s .")
    code = 500


class SubnetNotInSameVpc(APIException):
    msg = _("All subnets must be in a same vpc")
    code = 400


class VMInvalidState(InvalidRequest):
    msg = _("VM %(vm_id)s in %(state)s. Cannot "
            "%(method)s while the VM is in this state.")


class VolumeInvalidState(InvalidRequest):
    msg = _("Volume %(volume_id)s in %(state)s. Cannot "
            "%(method)s while the Volume is in this state.")


class UnsupportVMAction(InvalidRequest):
    msg = _("Unsupport VM action %(action_name)s")


class UnsupportDeleteVM(InvalidRequest):
    msg = _("Unsupport delete VM %(vm_id)s: %(msg)s")


class StatusConflict(APIException):
    msg = _("The %(resource)s %(id)s's status is %(status)s.")
    code = 403


class AgentUnavailable(InvalidRequest):
    msg = _("Agent is unavailable at this time.")


class CannotMigrateToSameHost(InvalidRequest):
    msg = _("Cannot migrate to the host where the VM exists")


class CannotResizeToSameVMConfigure(InvalidRequest):
    msg = _("The virtual machine configuration has not changed")


class CannotResizeDisk(InvalidRequest):
    msg = _("Root disk was unable to be resized because: %(reason)s")


class CannotResizeWithNonVMConfigure(InvalidRequest):
    msg = _("Specify at least one of vcpu, memory_mb,"
            " root_disk_gb when resizing")


class CannotRebuildWithNonAttr(InvalidRequest):
    msg = _("Rebuild the VM must specify the relevant properties")


class CannotRebuildWithOwnSnapshot(InvalidRequest):
    msg = _("Can not rebuild VM %(id)s with root disk own snapshot.")


class ImageSizeExceedsRootDisk(InvalidRequest):
    msg = _("Requested image size %(img_size)fG is larger than "
            "root disk size %(root_disk_size)fG.")


class SnapSizeExceedsRootDisk(InvalidRequest):
    msg = ("VM root disk size '%(root_disk_size)s'GB cannot be smaller than"
           " the snapshot size %(snap_size)sGB. "
           "They must be >= original snapshot size.")


class VMRootDiskHasSnapshot(InvalidRequest):
    msg = _("The VM %(id)s root disk has snapshot.")


class VMHasSnapshotGroup(InvalidRequest):
    msg = _("The VM %(id)s has snapshot_group.")


class NicStatusConflict(APIException):
    msg = _("The nic %(nic_id)s can not %(action)s, it's "
            "status is %(status)s.")
    code = 403


class VolumeStatusError(APIException):
    msg = _("The Volume %(volume_id)s can not %(action)s.")
    code = 403


class VolumeStatusConflict(APIException):
    msg = _("The Volume %(volume_id)s can not %(action)s, it's "
            "status is %(status)s.")
    code = 403


class SnapshotIsInUse(InvalidRequest):
    msg = _("The snapshot %(snap_id)s cannot be deleted, because it is"
            " in use")
    code = 403


class SnapshotRollbackError(APIException):
    msg = _("Snapshot %(snap_id)s rollback error,"
            "rollback to the specified volume")
    code = 403


class SubnetDeleteBatchFaild(APIException):
    msg = _("Cannot batch delete subnet(s) %(subnets_id)s within vpc.")
    code = 403


class VOIDiskRequireSize(APIException):
    msg = _("The size param is required for voi disk.")
    code = 400


class VOIRemoveMustVolumeId(APIException):
    msg = _("The volume_id param is required for remove voi disk.")
    code = 400


class RequireRootDiskSize(APIException):
    msg = _("The 'root_disk_gb' param is required for %(format)s image.")
    code = 400


class InvalidPrefixlen(APIException):
    msg = _("The subnet prefix length %(prefixlen)s is invalid, "
            "The useable prefix length ranges in CIDR is: "
            "%(maximum)s~%(minimum)s.")
    code = 403


class VMVolumeListError(APIException):
    msg = _("The VM  volume list parameter is incorrect")
    code = 400


class VMVolumeListEmpty(APIException):
    msg = _("The VM volume list is empty")
    code = 400


class VMSystemVolume(APIException):
    msg = _("The first VM volume must be a bootable volume")
    code = 400


class VMCanNotBootable(APIException):
    msg = _("This VM %(vm_id)s does not have bootable volume.")
    code = 403


class ScheduleVmFailed(APIException):
    msg = _("VM fails to schedule, because %(reason)s.")
    code = 400
