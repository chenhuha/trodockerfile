# Copyright 2021 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

# Agent
AGENT_UP = 'up'
AGENT_DOWN = 'down'

# Agent client
CONN_MAX_RETRIES = 'conn_max_retries'
CONN_RETRY_INTERVAL = 'conn_retry_interval'
REQ_CONN_TIMEOUT = 'req_conn_timeout'
REQ_READ_TIMEOUT = 'req_read_timeout'

# General
PREPARE_CREATE = 'prepare_create'
PREPARE_DELETE = 'prepare_delete'
PREPARE_ATTACH = 'prepare_attach'
PREPARE_DETACH = 'prepare_detach'
CREATING = 'creating'
UPDATING = 'updating'
DELETING = 'deleting'
ATTACHING = 'attaching'
DETACHING = 'detaching'
DELETED = 'deleted'
ACTIVE = 'active'
ERROR = 'error'

# Network
DOWN = 'down'
DOWNGRADE = 'downgrade'
FLAT = 'flat'
VLAN = 'vlan'
SUPPORTED_VPC_TYPES = [FLAT, VLAN]
MAX_VLAN = 4094
MIN_VLAN = 1
IP_VERSION_4 = 4
IP_VERSION_6 = 6
NIC_OF_VDI_VM = 'vdi_vm'
NIC_OF_VOI_VM = 'voi_vm'
NIC_OF_DHCP = 'dhcp'
NIC_OF_RESERVE = 'reserve'
UP = 'up'
TAP_DEVICE_PREFIX = 'tap'
BRIDGE_DEVICE_PREFIX = 'brq'
DHCP_NAMESPACE_PREFIX = 'qdhcp'
LINUX_DEV_LEN = 14
IPv4_ANY = '0.0.0.0/0'
IPv6_ANY = '::/0'
IP_ANY = {IP_VERSION_4: IPv4_ANY, IP_VERSION_6: IPv6_ANY}
CREATE_SUBNET = 'create_subnet'
UPDATE_SUBNET = 'update_subnet'
DELETE_SUBNET = 'delete_subnet'
CREATE_NIC = 'create_nic'
UPDATE_NIC = 'update_nic'
DELETE_NIC = 'delete_nic'
DELETE_VPC = 'delete_vpc'
DHCP_FOR_SUBNET = [CREATE_SUBNET, UPDATE_SUBNET, DELETE_SUBNET]
DHCP_FOR_NIC = [CREATE_NIC, UPDATE_NIC, DELETE_NIC]
DHCP_FOR_VPC = [DELETE_VPC]
MINIMUM_PREFIXLEN = 1
MAXIMUM_PREFIXLEN = 30

# Volume
AVAILABLE = 'available'
ATTACHED = 'attached'
DETACHED = "detached"
IN_USE = 'in-use'
CLONING = 'cloning'
REVERTING = 'reverting'
PREPARE_CLONE = 'prepare_clone'
PREPARE_REVERT = 'prepare_revert'
USEFUL_VOL_STATUS = [AVAILABLE, IN_USE]

# Image
IMAGE_QUEUED = 'queued'
IMAGE_SAVING = 'saving'
IMAGE_ACTIVE = 'active'
IMAGE_DELETED = 'deleted'
IMAGE_ERROR = "error"

# Page
PAGINATION_HELPER = 'pagination_helper'
ASC = 'asc'
DESC = 'desc'
ALLOWED_SORT_DIR = (ASC, DESC)
DEFAULT_SORT_DIR = ASC
DEFAULT_SORT_KEYS = ['created_at', 'id']
DEFAULT_PAGE_SIZE = 1000

# VM
STOPPED = "stopped"
PREPARE_START = "prepare_start"
PREPARE_STOP = "prepare_stop"
PREPARE_RESIZE = "prepare_resize"
PREPARE_REBOOT = "prepare_reboot"
PREPARE_REBUILD = 'prepare_rebuild'
PREPARE_MIGRATE = "prepare_migrate"
PREPARE_RESTORY = 'prepare_restory'
PREPARE_NIC_ATTACH = 'prepare_nic_attach'
PREPARE_NIC_DETACH = 'prepare_nic_detach'
PREPARE_FLATTEN = 'prepare_flatten'
PREPARE_VOLUME_ATTACH = 'prepare_volume_attach'
PREPARE_VOLUME_DETACH = 'prepare_volume_detach'
STARTING = "starting"
STOPPING = "stopping"
REBOOTING = "rebooting"
REBUILDING = 'rebuilding'
RESTORING = 'restoring'
RESIZING = "resizing"
MIGRATING = "migrating"
NIC_ATTACHING = 'nic_attaching'
NIC_DETACHING = 'nic_detaching'
FLATTENING = 'flattening'
VOLUME_ATTACHING = 'volume_attaching'
VOLUME_DETACHING = 'volume_detaching'
CAN_ATTACH_DETACH_VOLUME_STATUS = [ACTIVE, PREPARE_CREATE, STOPPED]

# VOI VM
PREPARE_REPLACE_ISO = "prepare_replace_iso"
REPLACING_ISO = "replacing_iso"
PREPARE_RESET = "prepare_reset"
RESETTING = 'resetting'
PREPARE_COMMIT = 'prepare_commit'
COMMITTING = 'committing'
PREPARE_ADD_VOLUME = 'prepare_add_volume'
PREPARE_REMOVE_VOLUME = 'prepare_remove_volume'
ADDING_VOLUME = 'adding_volume'
REMOVING_VOLUME = 'removing_volume'
# Disk name
BASE_DISK_NAME = 'base'
INCR1_DISK_NAME = 'incr1'
INCR2_DISK_NAME = 'incr2'
CURRENT_DISK_NAME = 'current'
# Prefix name
SYS_DISK_PREFIX_NAME = 'sys'
DATA_DISK_PREFIX_NAME = 'data'
BACKUP_DATA_DISK_PREFIX_NAME = 'data1'
SHARE_DISK_PREFIX_NAME = 'share'
# File extension
VOI_DISK_SUFFIX_NAME = "qcow2"
# Disk middle name list
DISK_MIDDLE_NAME_LIST = [
    BASE_DISK_NAME, INCR1_DISK_NAME, INCR2_DISK_NAME, CURRENT_DISK_NAME]
DATA_DISK_START_INDEX = 1
CDROM_DEFAULT_INDEX = 2
CDROM_DEFAULT_DRIVER_TARGET = "sdc"

# General
DELETE_BAN = [CREATING, UPDATING, DELETING, IN_USE,
              REBUILDING, RESTORING, RESIZING, MIGRATING]

# Schedule
VCPU_CLASS_ID = 0
MEMORY_CLASS_ID = 1

# BOOT TYPE
BIOS = "bios"
UEFI = "uefi"
BOOT_TYPE_ALL = (BIOS, UEFI)
VOI_DEFAULT_BOOT_TYPE = UEFI
VDI_DEFAULT_BOOT_TYPE = BIOS

# Inspector
CREATE_TIMEOUT_INSPECTOR = 'create_timeout_inspector'
POWER_STATUS_INSPECTOR = 'power_status_inspector'
STUCK_ING_STATUS_INSPECTOR = 'stuck_ing_status_inspector'
NEED_PROCESS_ING_STATUS_LIST = [
    CREATING, DELETING, STARTING, STOPPING, REBOOTING]
