#    Copyright 2022 Troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os

from oslo_concurrency import processutils
from oslo_log import log as logging
from oslo_utils import fileutils
from oslo_utils import imageutils

from trochilus.common import constants

LOG = logging.getLogger(__name__)


def copy_image(src: str, dest: str) -> None:
    """Copy a disk image or disk dir to an directory"""
    # For example:
    # 1. Copy the directory and rename, premise dir 222 does not exist
    #    cp -r /voi/vms/111 /voi/vms/222
    # 2. Copy the file and rename, premise dir 222 is exist
    #    cp -r /voi/vms/111/111.qcow2 /voi/vms/222/222.qcow2
    processutils.execute('cp', '-r', src, dest)


def get_qemu_img_info(path):
    """Return an object containing the parsed output from qemu-img info."""
    cmd = ('qemu-img', 'info', path,
           '--force-share', '--output=json')
    out, _ = processutils.execute(*cmd)
    return imageutils.QemuImgInfo(out, format='json')


def create_image(path, size):
    """Create a disk image

    :param path: Desired location of the disk image
    :param size: Desired size of disk image.
    """
    processutils.execute('qemu-img', 'create', '-f', 'qcow2', path, size)


def create_cow_image(backing_file, path):
    """Create COW image

    Creates a COW image with the given backing file

    :param backing_file: Existing image on which to base the COW image
    :param path: Desired location of the COW image
    """
    cmd = [
        'qemu-img', 'create', '-b', backing_file, '-F', 'qcow2',
        '-f', 'qcow2', path
    ]
    processutils.execute(*cmd)


def commit_image(previous_path, path):
    cmd = [
        'qemu-img', 'commit', '-b', previous_path, path
    ]
    processutils.execute(*cmd)


def get_disk_name_and_path(disk_prefix_name,
                           disk_middle_name,
                           share_disk_dirpath):
    disk_uuid = os.path.basename(os.path.normpath(share_disk_dirpath))
    disk_filename = (disk_uuid +
                     "-" +
                     disk_prefix_name +
                     "-" +
                     disk_middle_name +
                     "." +
                     constants.VOI_DISK_SUFFIX_NAME)
    disk_filepath = os.path.join(share_disk_dirpath, disk_filename)
    return disk_filename, disk_filepath


def get_share_disk_name_and_path(disk_middle_name, share_disk_dirpath):
    return get_disk_name_and_path(constants.SHARE_DISK_PREFIX_NAME,
                                  disk_middle_name,
                                  share_disk_dirpath)


def rebase_backing_file(backing_file, path):
    cmd = [
        'qemu-img', 'rebase', '-u', '-f', 'qcow2', '-b',
        backing_file, '-F', 'qcow2', path
    ]
    processutils.execute(*cmd)


def check_and_rebase_backing_file(expected_backing_file, path):
    # Generate origin backing file full path
    image_info = get_qemu_img_info(path)
    image_backing_file = os.path.join(
        os.path.dirname(path), image_info.backing_file)

    # Check origin backing file exists, and rebase backing file
    if not os.path.exists(image_backing_file):
        LOG.info("%s is not exists, so rebase %s backing file to %s",
                 image_backing_file, path, expected_backing_file)
        rebase_backing_file(expected_backing_file, path)


def commit_disk_file(base_filename,
                     incr1_filename, incr1_filepath,
                     incr2_filename, incr2_filepath,
                     curr_filepath):

    # 1. commit incre2 -> incre1
    # Check (incr1 -> base) and (incr2 -> incr1)
    check_and_rebase_backing_file(base_filename, incr1_filepath)
    check_and_rebase_backing_file(incr1_filename, incr2_filepath)
    commit_image(incr1_filepath, incr2_filepath)

    # 2. delete incre2
    fileutils.delete_if_exists(incr2_filepath)

    # 3. rebase current -> incre1
    rebase_backing_file(incr1_filename, curr_filepath)

    # 4. rename current -> incre2
    os.rename(curr_filepath, incr2_filepath)

    # 5. create new current
    create_cow_image(incr2_filename, curr_filepath)


def get_share_tmpl_disk_name_and_path(disk_uuid, template_base_path):
    # Get share template disk name and path
    disk_filename = (disk_uuid + "." + constants.VOI_DISK_SUFFIX_NAME)
    disk_filepath = os.path.join(template_base_path, disk_filename)
    return disk_filename, disk_filepath
