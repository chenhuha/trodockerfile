# Copyright 2021 Troila
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import os
import socket

import eventlet

import netaddr
from oslo_log import log as logging
from trochilus.common import constants
from trochilus.i18n import _

LOG = logging.getLogger(__name__)


def get_hostname():
    return socket.gethostname()


def is_ipv4(ip_address):
    """Check if ip address is IPv4 address."""
    ip = netaddr.IPAddress(ip_address)
    return ip.version == 4


def is_ipv6(ip_address):
    """Check if ip address is IPv6 address."""
    ip = netaddr.IPAddress(ip_address)
    return ip.version == 6


def cidr_to_ip(ip_cidr):
    """Strip the cidr notation from an ip cidr or ip

    :param ip_cidr: An ipv4 or ipv6 address, with or without cidr notation
    """
    net = netaddr.IPNetwork(ip_cidr)
    return str(net.ip)


def cidr_mask_length(cidr):
    """Returns the mask length of a cidr

    :param cidr: (string) either an ipv4 or ipv6 cidr or a host IP.
    :returns: (int) mask length of a cidr; in case of host IP, the mask length
              will be 32 (IPv4) or 128 (IPv6)
    """
    return netaddr.IPNetwork(cidr).netmask.netmask_bits()


def get_socket_address_family(ip_version):
    """Returns the address family depending on the IP version"""
    return (int(socket.AF_INET if ip_version == 4
                else socket.AF_INET6))


def is_cidr_host(cidr):
    """Determines if the cidr passed in represents a single host network

    :param cidr: Either an ipv4 or ipv6 cidr.
    :returns: True if the cidr is /32 for ipv4 or /128 for ipv6.
    :raises ValueError: raises if cidr does not contain a '/'.  This disallows
        plain IP addresses specifically to avoid ambiguity.
    """
    if '/' not in str(cidr):
        raise ValueError("cidr doesn't contain a '/'")
    net = netaddr.IPNetwork(cidr)
    if net.version == 4:
        return net.prefixlen == 32
    return net.prefixlen == 128


def ip_to_cidr(ip, prefix=None):
    """Convert an ip with no prefix to cidr notation

    :param ip: An ipv4 or ipv6 address.  Convertable to netaddr.IPNetwork.
    :param prefix: Optional prefix.  If None, the default 32 will be used for
        ipv4 and 128 for ipv6.
    """
    net = netaddr.IPNetwork(ip)
    if prefix is not None:
        # Can't pass ip and prefix separately.  Must concatenate strings.
        net = netaddr.IPNetwork(str(net.ip) + '/' + str(prefix))
    return str(net)


def create_directorie(datadir):
    """Create some directories to write files if it does not exist."""

    def check_write_permission(datadir):
        if not os.access(datadir, os.W_OK):
            LOG.error("Permission to write in %s denied", datadir)

    if os.path.exists(datadir):
        check_write_permission(datadir)
    else:
        msg = ("Directory to write image files does not exist (%s). Creating."
               ) % datadir
        LOG.info(msg)
        os.makedirs(datadir)
        check_write_permission(datadir)


def get_bridge_name(vpc_id):
    return constants.BRIDGE_DEVICE_PREFIX + vpc_id[:11]


def wait_until_true(predicate, timeout=60, sleep=1, exception=None, **kwargs):
    """Wait until callable predicate is evaluated as True

    :param predicate: Callable deciding whether waiting should continue.
    Best practice is to instantiate predicate with functools.partial()
    :param timeout: Timeout in seconds how long should function wait.
    :param sleep: Polling interval for results in seconds.
    :param exception: Exception instance to raise on timeout. If None is passed
                      (default) then WaitTimeout exception is raised.
    """
    try:
        with eventlet.Timeout(timeout):
            while not predicate(**kwargs):
                eventlet.sleep(sleep)
    except eventlet.Timeout as e:
        if exception is not None:
            # pylint: disable=raising-bad-type
            raise exception from e
        raise Exception(_("Timed out after %d seconds") % timeout) from e
