#    Copyright 2021 troila
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import eventlet
from eventlet import wsgi
from oslo_config import cfg
from oslo_log import log as logging

from trochilus.agent import app as agent_app
from trochilus.common import constants

CONF = cfg.CONF
LOG = logging.getLogger(__name__)


def main():
    app, agent_server = agent_app.setup_app()
    host = cfg.CONF.agent_settings.bind_host
    port = cfg.CONF.agent_settings.bind_port
    LOG.info("Starting agent server on %(host)s:%(port)s",
             {"host": host, "port": port})
    sock = eventlet.listen((host, port), reuse_port=False)

    # Check the resource 'ing' status once when the agent starts
    agent_server.vm_insp.get_inspector(
        constants.STUCK_ING_STATUS_INSPECTOR)()
    agent_server.voi_vm_insp.get_inspector(
        constants.STUCK_ING_STATUS_INSPECTOR)()

    wsgi.server(sock, app,
                log=LOG, log_format=CONF.wsgi_log_format,
                max_size=CONF.wsgi_default_pool_size,
                keepalive=CONF.wsgi_keep_alive,
                socket_timeout=CONF.client_socket_timeout or None)
