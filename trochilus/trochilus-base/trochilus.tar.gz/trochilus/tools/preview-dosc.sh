# /usr/bin/bash

set -x
set -e

while [ "$#" -gt 0 ]; do
    case "$1" in
    (--host-ip|-i)
        HOST_IP="$2"
        shift 2
        ;;
    (--work-base-dir|-w)
        WORK_BASE_DIR="$2"
        shift 2
        ;;
    (--theme-dir|-t)
        THEME_DIR="$2"
        shift 2
        ;;
    (--)
        shift
        break
        ;;
    (*)
        echo "错误的参数"
        exit 3
        ;;
esac
done

if [ -z $WORK_BASE_DIR ]; then
    echo "你必须指定 --work-base-dir 参数"
    exit 1
fi
if [ -z $HOST_IP ]; then
    echo "你必须指定 --host-ip 参数"
    exit 1
fi
if [ -z $THEME_DIR ]; then
    echo "你必须 指定 --theme-dir"
    exit 1
fi
mkdir -p $WORK_BASE_DIR

BASE_PATH=$(cd `dirname $0`; pwd)
change_id=$(git log -1|grep "Change-Id"|awk '{print $NF}')
if [ -d $WORK_BASE_DIR/$change_id ]; then
    rm -rf $WORK_BASE_DIR/$change_id/docs
    sleep 10
    cp -rf $BASE_PATH/../docs $WORK_BASE_DIR/$change_id
    listen_port=$(cat $WORK_BASE_DIR/$change_id/listen_port)
else
    mkdir -p $WORK_BASE_DIR/$change_id
    cp -rf $BASE_PATH/../docs $WORK_BASE_DIR/$change_id
    cp -f $BASE_PATH/../docs/config.yaml $WORK_BASE_DIR/$change_id
    max_port=$(ss -ntl|grep "$HOST_IP:"|awk -F"$HOST_IP:" '{print $NF}'|awk '{print $1}'|sort -nr|head -n1)
    listen_port=`expr $max_port + 1`
    echo "$listen_port" > $WORK_BASE_DIR/$change_id/listen_port
fi



cat << EOF > /usr/lib/systemd/system/hugo-$listen_port.service
[Unit]
Description=Trochilus document preview
After=network-online.target

[Service]
Type=simple
User=root
ExecStart=/usr/bin/hugo server -D --minify --baseURL http://$HOST_IP:$listen_port --bind $HOST_IP --port $listen_port --contentDir $WORK_BASE_DIR/$change_id/docs/ --config $WORK_BASE_DIR/$change_id/config.yaml --themesDir $THEME_DIR
ExecReload=/bin/kill -s HUP
Restart=always

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl restart hugo-$listen_port.service

echo "访问后面链接预览文档：http://$HOST_IP:$listen_port"
