.. _trochilus-style-commandments:

Trochilus Style Commandments
============================

- We follow the OpenStack Style Commandments:
  https://docs.openstack.org/hacking/latest

Trochilus Specific Commandments
-------------------------------
- [T312] Validate that jsonutils module is used instead of json
- [T316] Change assertTrue(isinstance(A, B)) by optimal assert like
  assertIsInstance(A, B).
- [T318] Change assert(Not)Equal(A, None) or assert(Not)Equal(None, A)
  by optimal assert like assertIs(Not)None(A).
- [T319] Validate that debug level logs are not translated.
- [T321] Validate that jsonutils module is used instead of json
- [T322] Don't use author tags
- [T323] Change assertEqual(True, A) or assertEqual(False, A) to the more
  specific assertTrue(A) or assertFalse(A)
- [T324] Method's default argument shouldn't be mutable
- [T338] Change assertEqual(A in B, True), assertEqual(True, A in B),
  assertEqual(A in B, False) or assertEqual(False, A in B) to the more
  specific assertIn/NotIn(A, B)
- [T339] LOG.warn() is not allowed. Use LOG.warning()
- [T340] Don't use xrange()
- [T341] Don't translate logs.
- [T342] Exception messages should be translated
- [T343] Python 3: do not use basestring.
- [T344] Python 3: do not use dict.iteritems.
- [T345] Usage of Python eventlet module not allowed
- [T346] Don't use backslashes for line continuation.
- [T347] Taskflow revert methods must have \*\*kwargs.
