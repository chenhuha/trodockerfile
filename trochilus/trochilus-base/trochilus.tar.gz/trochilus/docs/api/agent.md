---
title: "agent"
---


## 属性

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| id | string | agent_id |
| hostname | string | 主机名 |
| description | string | 描述信息 |
| status | string | 状态信息 |
| heartbeat_timestamp | datetime | 心跳时间 |
| mgmt_ip | string | 管理网ip |
| api_version | string | 版本 |
| total_memory | integer | 内存总数(byte) |
| free_memory | integer | 剩余内存数(byte) |
| cpu_used_ratio | float | CPU使用率 |
| sys_disk_size | integer | 根磁盘总数(byte) |
| sys_disk_used_size | integer | 根磁盘使用数(byte) |
| system | string | 主机系统 |
| version | float | 主机系统版本 |
| cpu_thread | integer | cpu线程数 |
| cpu_socket | integer | cpu核数 |
| cpu_MHZ | string | cpu主频（MHz） |
| cpu_core | integer | 每个物理cpu内core的数量 |
| stepping | integer | cpu步长 |
| model | string | cpu型号 |
| boot_time | datetime | 开机时间 |
| L2_cache | string | 二级缓存 |
| L3_cache | string | 三级缓存 |
| role | list | 承担角色，controller，computer或storage |
| networks | list | 网卡信息，列表元素见下表 |
| disk_names| string | 主机磁盘盘符名，多个盘符名用逗号分隔 |
| net_pci_info | list | PCI总线设备信息 |
| host_username | string | 宿主机用户名 |
| host_password | string | 宿主机密码 |
| ipmi_address | string | ipmi 管理口地址 |
| ipmi_username | string | ipmi 管理口用户名 |
| ipmi_password | string | ipmi 管理口密码 |
| ipmi_vendor | string | ipmi 厂商 |


### networks 列表元素字段说明

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| nic_name | string | 物理网卡名称 |
| status | int | 网卡状态（1表示开启，0表示关闭)|
| ip_addresses | list | IP地址 |
| subnet_mask | string | 子网掩码 |
| gateway | string | 网关 |
| speed | integer | 网口速率(Mb/s) |
| vlan | string | vlan范围 |
| bond_name | string | bond的名称 |
| role | string | 网卡角色（管理网，外网，业务网，存储网）有则为1，无则为0|
| type | string | 网卡类型（bond代表该网卡为bond，physical代表该网卡为物理网卡）|


## 获取agent列表信息

GET http://127.0.0.1:9906/v1/agent/


### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/agent
```

返回信息：

```json
{
    "agents": [{
            "id": "07c00ebe-b139-4aa3-a712-2b5f8fe0bc96",
            "hostname": "hostname1",
            "description": "",
            "status": "up",
            "heartbeat_timestamp": "2022-02-24T04:48:36",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755712000,
            "free_memory": 12955234304,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "sda,sdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "9335aeba-6dc8-4de5-93ff-6cf9c42fa2cd",
            "hostname": "hostname2",
            "description": "",
            "status": "up",
            "heartbeat_timestamp": "2022-02-24T04:48:32",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_cpu": 8,
            "total_memory": 16755699712,
            "free_memory": 14810550272,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "sda,sdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        }
    ],
    "agent_links": []
}
```


## 获取单个agent信息

GET http://127.0.0.1:9906/v1/agent/{agent_id}


### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/agent/9335aeba-6dc8-4de5-93ff-6cf9c42fa2cd
```

返回信息：

```json
{
    "agent": {
        "id": "9335aeba-6dc8-4de5-93ff-6cf9c42fa2cd",
        "hostname": "hostname2",
        "description": "",
        "status": "up",
        "heartbeat_timestamp": "2022-02-24T05:06:05",
        "mgmt_ip": "0.0.0.0",
        "api_version": "v1.0",
        "total_cpu": 8,
        "total_memory": 16755699712,
        "free_memory": 14700965888,
        "cpu_used_ratio": 13.0,
        "sys_disk_size": 316998987776,
        "sys_disk_used_size": 22510129152,
        "system": "unbuntu",
        "version": 20.04,
        "cpu_thread": 8,
        "cpu_socket": 8,
        "cpu_MHZ": "2394.444",
        "cpu_core": 1,
        "stepping": 2,
        "model": "Intel Core Processor (Broadwell, IBRS)",
        "boot_time": "2022-03-03T15:39:55",
        "L2_cache": "32 MiB",
        "L3_cache": "128 MiB",
        "role": [
                "controller",
                "computer",
                "storage"
        ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
        "disk_names": "sda,sdb",
        "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
        "host_username": "root",
        "host_password": "123456",
        "ipmi_address": "172.27.122.222",
        "ipmi_vendor": "HUAWEI",
        "ipmi_username": "root",
        "ipmi_password": "Huawei12#$"
    }
}
```


## 更新

PUT http://127.0.0.1:9906/v1/agent/{agent_id}


### 参数

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| description | string | 描述信息 |


### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/agent/9335aeba-6dc8-4de5-93ff-6cf9c42fa2cd -H 'Content-Type: application/json' --data-raw
```

请求参数：

```json
{
    "agent": {
        "description": "test_agent"
    }
}
```

返回信息：

```json
{
    "agent": {
        "id": "9335aeba-6dc8-4de5-93ff-6cf9c42fa2cd",
        "hostname": "hostname2",
        "description": "test_agent",
        "status": "up",
        "heartbeat_timestamp": "2022-02-24T06:35:12",
        "mgmt_ip": "0.0.0.0",
        "api_version": "v1.0",
        "total_memory": 16755699712,
        "free_memory": 14699409408,
        "cpu_used_ratio": 13.0,
        "sys_disk_size": 316998987776,
        "sys_disk_used_size": 22510129152,
        "system": "unbuntu",
        "version": 20.04,
        "cpu_thread": 8,
        "cpu_socket": 8,
        "cpu_MHZ": "2394.444",
        "cpu_core": 1,
        "stepping": 2,
        "model": "Intel Core Processor (Broadwell, IBRS)",
        "boot_time": "2022-03-03T15:39:55",
        "L2_cache": "32 MiB",
        "L3_cache": "128 MiB",
        "role": [
                "controller",
                "computer",
                "storage"
        ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
        "disk_names": "sda,sdb",
        "net_pci_info": [
            "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
            "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
            "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
        "host_username": "root",
        "host_password": "123456",
        "ipmi_address": "172.27.122.222",
        "ipmi_vendor": "HUAWEI",
        "ipmi_username": "root",
        "ipmi_password": "Huawei12#$"
    }
}
```


## 删除

DELETE  http://127.0.0.1:9906/v1/agent/{agent_id}


### 示例

注意事项：

正处于活跃状态的agent端无法被删除

请求命令：

```console
curl -L -X DELETE http://127.0.0.1:9906/v1/agent/07c00ebe-b139-4aa3-a712-2b5f8fe0bc96
```

删除成功无返回值
