---
"title": physical
---

Physical API 不支持分页，排序，参数过滤等功能


## 概念介绍

TODO


## 属性

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| name | string  | physical 名称 |
| support_flat | bool | 该 physical 是否支持创建 flat vpc |
| vlan_ranges | list | 该 physical 支持的 vlan id 的 范围 |


## 获取所有 physical 列表

GET http://127.0.0.1:9906/v1/physical


### 示例

请求命令：

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/physical
```

返回值

```json
{
    "physicals": [{
        "name": "aaa",
        "support_flat": true,
        "vlan_ranges": [{
            "max": 100,
            "min": 3
        }]
    }, {
        "name": "ccc",
        "support_flat": true,
        "vlan_ranges": []
    }, {
        "name": "bbb",
        "support_flat": false,
        "vlan_ranges": [{
            "max": 2,
            "min": 1
        }, {
            "max": 6,
            "min": 4
        }]
    }]
}
```


### 获取单个 physical 信息

GET http://127.0.0.1:9906/v1/physical/{physical name}

请求命令：

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/physical/aaa
```

返回值：

```json
{
    "pyhsical": {
        "name": "aaa",
        "support_flat": true,
        "vlan_ranges": [{
            "max": 100,
            "min": 3
        }]
    }
}
```

