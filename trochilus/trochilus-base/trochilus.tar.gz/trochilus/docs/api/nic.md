---
"title": nic
---


## 属性

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| id | string | nic id |
| name | string | nic 名称 |
| description | string | nic 描述 |
| vpc_id | string | nic 所属 vpc id |
| mac_address | string | nic mac |
| ip_addresses | list | nic ip，是一个列表，列表中元素字段见下表 |
| hostname | string | nic 所在计算节点 |
| owner_id | string | nic 所有者 |
| owner_type | string | nic 类型，取值范围为 dhcp、voi_vm、vdi_vm、reserve |
| auto_delete | bool | 是否随虚拟机一起删除 |
| status | string| nic 状态 |
| user_id | string | 用户id |
| project_id | string | 项目id |
| created_at | string | 创建时间 |
| updated_at | string | 更新时间 |

### ip_addresses 列表元素字段说明

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| ip_address | string | nic 的一个 ip |
| subnet_id | string | ip 所属子网 id |


## 创建 nic

POST http://127.0.0.1:9906/v1/nic

### 参数

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| name | 否 | string | nic 名称 |
| description | 否 |  string | nic 描述 |
| ip_addresses | 是 | list | nic ip，是一个列表，列表中元素字段见下表 |
| mac_address | 否 | string | nic mac，可以不指定，自动生成 |
| hostname | 否 | string | nic 所在计算节点 |
| owner_id | 否 | string | nic 所有者 |
| owner_type | 否 | string | nic 类型，取值范围为 dhcp、voi_vm、vdi_vm |
| project_id |否 | string | 项目 id |
| user_id | 否 | string | 用户 id |

### ip_addresses 列表元素字段说明

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| ip_address | 否 | string | nic 的一个 ip |
| subnet_id | 是 | string | ip 所属子网 id|

如果传入 ip_address，那么 ip_address 必须在子网 cidr 范围内；否则，根据子网地址池自动分配 ip。
ip_addresses 数组中每个元素里的 subnet_id 必须来自同一 vpc。

### 示例

请求命令:

```consle
curl -X post -H 'content-type:application/json' http://127.0.0.1:9906/v1/nic -d
```

请求参数：

```json
{
    "nic": {
        "ip_addresses": [{
            "ip_address": "192.168.0.22",
            "subnet_id": "07a5e911-a47d-4b2e-9ea5-fd0a6e22b3e0"
        }],
        "mac_address": "fa:16:3e:a1:94:99",
        "owner_type": "voi_vm"
    }
}
```

返回参数：

```json
{
    "nic": {
        "id": "0ece0c4f-69e0-41db-9dd0-ee545b942e90",
        "name": "",
        "description": "",
        "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
        "mac_address": "fa:16:3e:a1:94:99",
        "ip_addresses": [{
            "subnet_id": "07a5e911-a47d-4b2e-9ea5-fd0a6e22b3e0",
            "ip_address": "192.168.0.22"
         }],
        "hostname": null,
        "owner_id": null,
        "owner_type": "voi_vm",
        "auto_delete": true,
        "status": "up",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-01T14:02:51",
        "updated_at": null
    }
}
```


## 更新

PUT http://127.0.0.1:9906/v1/nic/{nic id}

### 参数

| 参数名 | 类型 | 说明 |
|:-------|:-----|:-----|
| name | string | nic 名称 |
| description | string | nic 描述 |
| ip_addresses | list |  nic ip，是一个列表，列表中元素字段见下表 |
| hostname | string | nic 所在计算节点 |
| owner_id | string | nic 所有者 |
| owner_type | string | nic 类型，取值范围为 dhcp、voi_vm、vdi_vm、reserve |

如果传入 owner_type 为 dhcp、voi_vm、vdi_vm ，那么 nic 的 owner_type 为 reserve 才能修改成功。
如果传入 owner_type 为 reserve，那么无论 nic 的 owner_type 为何值都能修改成功。

### ip_addresses 列表元素字段说明

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| ip_address | 是 | string | nic 的一个 ip |
| subnet_id | 否 | string | ip 所属子网 id |

如果传入 ip_address，那么 ip_address 必须在子网 cidr 范围内；否则，根据子网地址池自动分配 ip。
如果指定 subnet_id，那么要保证 ip_addresses 数组中每个元素里的 subnet_id 必须来自同一 vpc。

### 示例

请求命令:
```console
curl -X put -H 'content-type:application/json' http://127.0.0.1:9906/v1/nic/b4b1ca89-f41e-4e58-a6b4-d81a912977e3 -d
```

请求参数：

```json
{
    "nic": {
        "ip_addresses": [{
            "ip_address": "192.168.0.23",
            "subnet_id": "07a5e911-a47d-4b2e-9ea5-fd0a6e22b3e0"
        }, {
            "ip_address": "111.222.100.242",
            "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6"
        }],
        "name": "123",
        "description": "123456"
    }
}
```

返回参数：

```json
{
    "nic": {
        "id": "b4b1ca89-f41e-4e58-a6b4-d81a912977e3",
        "name": "123",
        "description": "123456",
        "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
        "mac_address": "fa:16:3e:2c:52:46",
        "ip_addresses": [{
            "ip_address": "192.168.0.23",
            "subnet_id": "07a5e911-a47d-4b2e-9ea5-fd0a6e22b3e0"
        }, {
            "ip_address": "111.222.100.242",
            "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6"
        }],
        "hostname": null,
        "owner_id": null,
        "owner_type": "voi_vm",
        "auto_delete": true,
        "status": "up",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-01T14:02:51",
        "updated_at": null
    }
}
```


## 获取 nic 列表

GET http://127.0.0.1:9906/v1/nic

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/nic?limit=2
```

返回信息：

```json
{
    "nics": [{
        "id": "33775375-c6dc-447f-aafd-e6553b6ad8aa",
        "name": "",
        "description": "",
        "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
        "mac_address": "fa:16:3e:a1:94:f2",
        "ip_addresses": [{
            "ip_address": "111.222.100.130",
            "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6"
        }],
        "hostname": null,
        "owner_id": null,
        "owner_type": "voi_vm",
        "auto_delete": true,
        "status": "up",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-01T10:05:29",
        "updated_at": null
    },{
        "id": "b4b1ca89-f41e-4e58-a6b4-d81a912977e3",
        "name": "123",
        "description": "123456",
        "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
        "mac_address": "fa:16:3e:2c:52:46",
        "ip_addresses": [{
            "ip_address": "192.168.0.23",
            "subnet_id": "07a5e911-a47d-4b2e-9ea5-fd0a6e22b3e0"
        }, {
            "ip_address": "111.222.100.242",
            "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6"
        }],
        "hostname": null,
        "owner_id": null,
        "owner_type": "voi_vm",
        "auto_delete": true,
        "status": "up",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-01T14:02:51",
        "updated_at": null
    }],
    "nic_links": [
        {
            "href": "http://127.0.0.1:9906/v1/nic?limit=2&marker=b4b1ca89-f41e-4e58-a6b4-d81a912977e3",
            "rel": "next"
        }
    ]
}
```


## 获取单个 nic 信息

GET http://127.0.0.1:9906/v1/nic/{nic id}

### 示例

请求命令:

```console
curl -X GET http://127.0.0.1:9906/v1/nic/b4b1ca89-f41e-4e58-a6b4-d81a912977e3
```

返回信息：

```json
{
    "nic": {
        "id": "b4b1ca89-f41e-4e58-a6b4-d81a912977e3",
        "name": "123",
        "description": "123456",
        "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
        "mac_address": "fa:16:3e:2c:52:46",
        "ip_addresses": [{
            "ip_address": "192.168.0.23",
            "subnet_id": "07a5e911-a47d-4b2e-9ea5-fd0a6e22b3e0"
        }, {
            "ip_address": "111.222.100.242",
            "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6"
        }],
        "hostname": null,
        "owner_id": null,
        "owner_type": "voi_vm",
        "auto_delete": true,
        "status": "up",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-01T14:02:51",
        "updated_at": null
    }
}
```


## 删除 nic

DELETE http://127.0.0.1:9906/v1/nic/{nic id}

### 示例

请求命令：

```console
curl -X DELETE http://127.0.0.1:9906/v1/nic/b4b1ca89-f41e-4e58-a6b4-d81a912977e3
```

返回信息：

删除成功无返回信息。
