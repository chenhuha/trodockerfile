---
"title": VOI 相关 API
---


## 镜像属性

| 名称         | 类型     | 说明                     |
| :----------- | :------- | :----------------------- |
| id           | string   | VM id                    |
| name         | string   | VM name                  |
| project_id   | string   | 项目 id                  |
| user_id      | string   | 用户 id                  |
| description  | string   | 描述信息                 |
| status       | string   | VM 状态                  |
| created_at   | datetime | 创建时间                 |
| updated_at   | datetime | 更新时间                 |
| checksum     | string   | 校验和                   |
| size         | integer  | 实际大小                 |
| virtual_size | integer  | 虚拟大小                 |
| disk_format  | string   | 磁盘格式，iso 或者 qcow2 |


## 创建镜像

POST http://127.0.0.1:9906/v1/voi/image

### 参数

| 参数名      | 必选 | 类型   | 说明                                                 |
| :---------- | :--- | :----- | ---------------------------------------------------- |
| name        | 是   | string | image name, 镜像的名称很重要，所以这里就设置为了必填 |
| description | 否   | string | 描述                                                 |
| disk_format | 是   | string | 磁盘格式，只能为 qcow2 或者 iso                      |
| user_id     | 否   | string | 用户id                                               |
| project_id  | 否   | string | 项目id                                               |

注意这里的 disk_format 很重要，如果是 qcow2 的视为可以直接启动虚机，创建虚机时直接把镜像
copy 到虚机目录，如果是 iso 的，创建虚机时需要额外创建一个空白盘作为系统盘。

name 会作为镜像存储的标识，所以这个也是很重要的，这儿要求必传

### 示例

```console
curl -X POST -H "Accept: application/json" -H 'Content-Type: application/json' http://172.18.30.117:9906/v1/voi/image \
    -d '{"image": {"name": "win10", "disk_format": "iso"}}'
```

返回

```json
{
  "image": {
    "id": "0ecdec5c-349e-49ce-a463-4c377a197100",
    "name": "win10",
    "description": "",
    "status": "queued",
    "created_at": "2022-04-08T09:32:11",
    "updated_at": null,
    "user_id": null,
    "project_id": null,
    "checksum": null,
    "location": null,
    "virtual_size": null,
    "size": null,
    "disk_format": "iso"
  }
}
```

## 更新镜像

PUT http://127.0.0.1:9906/v1/voi/image/{image_id}


### 参数

| 参数名      | 必选 | 类型   | 说明                         |
| :---------- | :--- | :----- | ---------------------------- |
| name        | 否   | string | 镜像名称(用于生成镜像文件名) |
| description | 否   | string | 描述信息                     |

### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/voi/image/cef0b7ae-54fc-4e9a-a6bd-22a7e91aaff0 -H 'Content-Type: application/json' --data-raw
```

请求参数：

```json
{
    "image": {
        "name": "wefwef",
        "description": "www"
    }
}
```

返回信息

```json
{
    "image": {
        "id": "cef0b7ae-54fc-4e9a-a6bd-22a7e91aaff0",
        "name": "wefwef",
        "description": "www",
        "status": "active",
        "created_at": "2022-04-26T10:33:22",
        "updated_at": "2022-04-26T10:45:35",
        "user_id": null,
        "project_id": null,
        "checksum": "9941d5c2dc3d5c4fb6a294831c362d51",
        "location": "file:///home/trochilus/voi/images/cef0b7ae-54fc-4e9a-a6bd-22a7e91aaff0/wefwef.qcow2",
        "virtual_size": 46137344,
        "size": 12716061,
        "disk_format": "qcow2"
    }
}
```

## 删除镜像

DELETE http://127.0.0.1:9906/v1/voi/image/{image_id}

### 示例

```
curl -X DELETE http://172.18.30.117:9906/v1/voi/image/0ecdec5c-349e-49ce-a463-4c377a197100
```

## 获取镜像列表

GET http://127.0.0.1:9906/v1/voi/image

### 示例

```
curl -X GET http://172.18.30.117:9906/v1/voi/image
```
返回

```
{
  "images": [
    {
      "id": "c4044ff8-c356-46c2-b1ac-612e4db5501b",
      "name": "cirros1",
      "description": "",
      "status": "active",
      "created_at": "2022-04-08T02:44:00",
      "updated_at": "2022-04-08T02:44:20",
      "user_id": null,
      "project_id": null,
      "checksum": "28feabc987913775d94eaf4f3db594fb",
      "location": "file:///var/lib/trochilus/voi/images/c4044ff8-c356-46c2-b1ac-612e4db5501b/cirros1.qcow2",
      "virtual_size": 2147483648,
      "size": 16384016,
      "disk_format": "qcow2"
    },
    {
      "id": "0ecdec5c-349e-49ce-a463-4c377a197100",
      "name": "win10",
      "description": "",
      "status": "active",
      "created_at": "2022-04-08T09:32:11",
      "updated_at": "2022-04-08T09:36:12",
      "user_id": null,
      "project_id": null,
      "checksum": "f627fc384f1b73fe2745d18f79ae9254",
      "location": "file:///var/lib/trochilus/voi/images/0ecdec5c-349e-49ce-a463-4c377a197100/win10.iso",
      "virtual_size": null,
      "size": 5793814528,
      "disk_format": "iso"
    }
  ],
  "image_links": []
}
```

## 获取单个镜像信息

GET http://127.0.0.1:9906/v1/voi/image/{image_id}

### 示例

```
curl -X GET http://172.18.30.117:9906/v1/voi/image/0ecdec5c-349e-49ce-a463-4c377a197100
```

返回

```
{
  "image": {
    "id": "0ecdec5c-349e-49ce-a463-4c377a197100",
    "name": "win10",
    "description": "",
    "status": "active",
    "created_at": "2022-04-08T09:32:11",
    "updated_at": "2022-04-08T09:36:12",
    "user_id": null,
    "project_id": null,
    "checksum": "f627fc384f1b73fe2745d18f79ae9254",
    "location": "file:///var/lib/trochilus/voi/images/0ecdec5c-349e-49ce-a463-4c377a197100/win10.iso",
    "virtual_size": null,
    "size": 5793814528,
    "disk_format": "iso"
  }
}
```

## 上传镜像

PUT http://127.0.0.1:9906/v1/voi/image/{image_id}/file

### 示例

```console
curl -X PUT -H 'Content-Type: application/octet-stream' \
    http://172.18.30.117:9906/v1/voi/image/0ecdec5c-349e-49ce-a463-4c377a197100/file \
    --data-binary '@win10.iso'
```

## 下载镜像

GET http://127.0.0.1:9906/v1/voi/image/{image_id}/file

### 示例

```
curl -L -X GET -o test.iso http://172.18.30.117:9906/v1/voi/image/3046473e-a65d-4809-b0e4-90e5f316b132/file
```

## 虚机属性

| 名称                | 类型     | 说明                                                          |
| :------------------ | :------- | :------------------------------------------------------------ |
| id                  | string   | VM id                                                         |
| name                | string   | VM name                                                       |
| project_id          | string   | 项目 id                                                       |
| user_id             | string   | 用户 id                                                       |
| description         | string   | 描述信息                                                      |
| status              | string   | VM 状态                                                       |
| created_at          | datetime | 创建时间                                                      |
| updated_at          | datetime | 更新时间                                                      |
| image_id            | string   | 镜像 id                                                       |
| vcpu                | integer  | VM CPU 数量                                                   |
| vnc_address         | string   | VM vnc 地址（IP +端口号）                                     |
| spice_address       | string   | VM spice 地址（IP +端口号）                                   |
| memory_mb           | integer  | VM 内存大小(MB)                                               |
| root_disk_gb        | integer  | VM 系统盘大小(GB)                                             |
| hostname            | string   | 虚机启动的节点                                                |
| nics                | array    | 虚机网卡列表，网卡详细属性见下表                              |
| disks               | array    | 虚机硬盘列表，硬盘详细属性见下表，这里的 voi 的硬盘只是数据盘 |
| cd_drivers          | array    | 虚机光驱列表，光驱详细属性见下表                              |
| copy_from_vm_id     | string   | 复制模板机时需传入被复制机器ID                                |
| copy_data_disk      | bool     | 复制模板机时是否复制数据盘                                    |
| data_disk_new_size  | integer  | 复制模板机时复制数据盘并传入的新大小(原大小与新大小取最大值)  |
| create_from_vm_path | string   | 基于路径创建模板机时需传入磁盘文件所在的路径                  |
| metadata            | dict     | 元数据                                                        |

### 网卡属性

| 名称         | 类型   | 说明                                           |
| :----------- | :----- | :--------------------------------------------- |
| id           | string | 网卡 ID                                        |
| vpc_id       | string | 网卡所属 vpc id                                |
| ip_addresses | array  | 网卡 ip 地址列表，包含 ip_address 和 subnet_id |
| mac_address  | string | 网卡的 mac 地址                                |

### 硬盘属性

| 名称       | 类型    | 说明                                   |
| :--------- | :------ | :------------------------------------- |
| id         | string  | 硬盘 ID                                |
| size       | integer | 硬盘大小，单位是 G                     |
| created_at | date    | 硬盘创建时间                           |
| updated_at | date    | 目前不支持跟新硬盘，所以这个值始终为空 |
| status     | string  | 硬盘状态信息                           |

### 光驱属性

| 名称     | 类型    | 说明                                                                           |
| :------- | :------ | :----------------------------------------------------------------------------- |
| id       | string  | 硬盘 ID                                                                        |
| is_sys   | boolean | 是否包含系统镜像，如果在创建虚机是指定的 image 为 iso，这个值会自动设置为 True |
| image_id | string  | 光驱中包含的镜像 ID，只能是 iso 格式的                                         |

## 创建虚机

POST http://127.0.0.1:9906/v1/voi/vm

如果是复制模板机:
1. 需传入 copy_from_vm_id 和 copy_data_disk(默认为 False).
2. 必选项 image_id、vcpu、memory_mb 可不传

### 参数

| 名称                | 必选 | 类型    | 说明                                                                  |
| :------------------ | :--- | :------ | :-------------------------------------------------------------------- |
| name                | 否   | string  | VM name                                                               |
| project_id          | 否   | string  | 项目 id                                                               |
| user_id             | 否   | string  | 用户 id                                                               |
| description         | 否   | string  | 描述信息                                                              |
| image_id            | 是   | string  | 镜像 id                                                               |
| vcpu                | 是   | integer | VM CPU 数量                                                           |
| memory_mb           | 是   | integer | VM 内存大小(MB)                                                       |
| root_disk_gb        | 否   | integer | VM 系统盘大小(GB)                                                     |
| disks               | 否   | list    | 数据盘列表，示例：[{"size": 5}, {"size": 8}]                          |
| nics                | 否   | list    | 网卡列表，voi 的网卡都会在删除虚机时自动删除，参数参考 VDI 虚机的创建 |
| copy_from_vm_id     | 否   | string  | 复制模板机时需传入被复制机器ID                                        |
| copy_data_disk      | 否   | bool    | 复制模板机时是否复制数据盘                                            |
| data_disk_new_size  | 否   | integer | 复制模板机时复制数据盘并传入的新大小(原大小与新大小取最大值)          |
| create_from_vm_path | 否   | string  | 基于路径创建模板机时需传入磁盘文件所在的路径                          |
| metadata            | 否   | dict    | 元数据                                                                |

#### metadata 参数

- boot_type: VOI VM 启动类型, 默认为 'uefi'
  - 'uefi': UEFI 模式启动,
  - 'bios': BIOS 模式启动

### 示例

```console
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" \
    http://172.18.30.117:9906/v1/voi/vm -d
```

请求参数(正常创建):

```json
{
    "vm": {
        "image_id": "0ecdec5c-349e-49ce-a463-4c377a197100",
        "vcpu": 1,
        "memory_mb": 2048,
        "root_disk_gb": 20,
        "metadata": {
            "boot_type": "uefi"
        },
        "nics": [{
            "subnet_id": "3ce2bc57-3996-4fb3-a87e-6a412796cf73"
        }],
        "disks": [{
            "size": 5
        }, {
            "size": 10
        }]
    }
}
```

请求参数(复制模板机):

```json
{
    "vm": {
        "name": "I am copy",
        "copy_from_vm_id": "4968a233-adc2-4d99-9853-a7720ec93d2c",
        "copy_data_disk": true,
        "data_disk_new_size": 10
        "nics": [{
            "subnet_id": "3ce2bc57-3996-4fb3-a87e-6a412796cf73"
        }],
        "disks": [{
            "size": 5
        }, {
            "size": 10
        }]
    }
}
```

请求参数(基于路径创建):

```json
{
    "vm": {
        "name": "I am create from path",
        "create_from_vm_path": "/mnt/voi/upload_vms/4968a233-adc2-4d99-9853-a7720ec93d2c)",
        "vcpu": 2,
        "memory_mb": 2048,
        "nics": [{
            "subnet_id": "3ce2bc57-3996-4fb3-a87e-6a412796cf73"
        }]
    }
}
```

返回(复制模板机/基于路径创建返回同下)

Note: 基于路径创建的 VOI VM 的 image_id 为空

```json
{
  "vm": {
    "id": "84884342-b0bf-4faf-aab4-41a15f5c955e",
    "name": "",
    "description": "",
    "status": "prepare_create",
    "created_at": "2022-04-08T09:40:17",
    "updated_at": null,
    "user_id": null,
    "project_id": null,
    "image_id": "0ecdec5c-349e-49ce-a463-4c377a197100",
    "vcpu": 2,
    "memory_mb": 2048,
    "root_disk_gb": 20,
    "vnc_address": null,
    "spice_address": null,
    "nics": [
      {
        "id": "180606d1-0f7d-42a6-bbb0-61081abea91e",
        "vpc_id": "ec21e66e-3924-448d-a34e-14e3ba2ee749",
        "ip_addresses": [
          {
            "ip_address": "192.168.0.248",
            "subnet_id": "3ce2bc57-3996-4fb3-a87e-6a412796cf73"
          }
        ],
        "mac_address": "fa:16:3e:ab:6b:36"
      }
    ],
    "disks": [
      {
        "id": "83d27639-7c75-4aa9-b7da-d33e30adf7bb",
        "size": 5,
        "created_at": "2022-04-08T09:40:18",
        "updated_at": null,
        "status": "prepare_create"
      },
      {
        "id": "4da1cf08-77bb-4dd2-bee0-8b8bd371830d",
        "size": 10,
        "created_at": "2022-04-08T09:40:18",
        "updated_at": null,
        "status": "prepare_create"
      }
    ],
    "cd_drivers": [],
    "hostname": "controller"
  }
}
```

## 更新虚机

PUT http://127.0.0.1:9906/v1/voi/vm/{vm_id}

### 参数

| 名称        | 必选 | 类型   | 说明     |
| :---------- | :--- | :----- | :------- |
| name        | 否   | string | VM name  |
| project_id  | 否   | string | 项目 id  |
| user_id     | 否   | string | 用户 id  |
| description | 否   | string | 描述信息 |
| metadata    | 否   | dict   | 元数据   |

### 示例


请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/voi/vm/a5a1f43a-1814-459c-8616-1cee60027d55 -H 'Content-Type: application/json' --data-raw
```

请求参数：

```json
{
    "vm": {
        "name": "1231241",
        "description": "2222222222"
    }
}
```

返回信息

```json
{
    "vm": {
        "id": "a5a1f43a-1814-459c-8616-1cee60027d55",
        "name": "1231241",
        "description": "2222222222",
        "status": "active",
        "created_at": "2022-04-26T11:23:17",
        "updated_at": "2022-04-27T06:47:52",
        "user_id": null,
        "project_id": null,
        "image_id": "6e1f19e2-f42a-4186-8886-c5ce11a8d0df",
        "agent_id": "1f72b8e2-fd18-4f26-97ce-e87e4b5ad1c0",
        "vcpu": 1,
        "memory_mb": 256,
        "root_disk_gb": 1,
        "vnc_address": "192.168.110.118:5902",
        "spice_address": "192.168.110.118:5903",
        "nics": [],
        "disks": [
            {
                "id": "68be3120-5f78-4e74-b261-86c6ec5bff91",
                "size": 1,
                "created_at": "2022-04-26T11:23:17",
                "updated_at": "2022-04-26T11:23:20",
                "status": "in-use",
                "index": 1
            }
        ],
        "cd_drivers": [
            {
                "id": "6915adb0-de61-4de7-8952-743872718cbe",
                "is_sys": true,
                "image_id": "6e1f19e2-f42a-4186-8886-c5ce11a8d0df"
            }
        ],
        "hostname": "agent-1"
    }
}
```

## 删除虚机

DELETE http://127.0.0.1:9906/v1/voi/vm/{vm_id}

### 示例

```
curl -X DELETE http://172.18.30.117:9906/v1/voi/vm/46d8e1f7-6fd6-4658-873b-c02259df0d4f
```

## 获取虚机列表

GET http://127.0.0.1:9906/v1/voi/vm

### 示例

```
curl -X GET http://172.18.30.117:9906/v1/voi/vm
```

返回

```json
{
  "vms": [
    {
      "id": "c407875f-0774-4126-8531-d52fe1274603",
      "name": "",
      "description": "",
      "status": "active",
      "created_at": "2022-04-10T05:53:04",
      "updated_at": "2022-04-10T05:53:08",
      "user_id": null,
      "project_id": null,
      "image_id": "302d073b-818f-4e0a-8e4c-d58ce9422b3e",
      "vcpu": 1,
      "memory_mb": 2048,
      "root_disk_gb": 50,
      "vnc_address": "172.18.30.117:5904",
      "spice_address": "172.18.30.117:5905",
      "nics": [
        {
          "id": "748ee01d-cf7b-46db-b889-e27b2876fb2d",
          "vpc_id": "ec21e66e-3924-448d-a34e-14e3ba2ee749",
          "ip_addresses": [
            {
              "ip_address": "192.168.0.164",
              "subnet_id": "3ce2bc57-3996-4fb3-a87e-6a412796cf73"
            }
          ],
          "mac_address": "fa:16:3e:6f:be:28"
        }
      ],
      "disks": [
        {
          "id": "7ab8b96d-fef2-4d55-a733-9a8d022c809c",
          "size": 10,
          "created_at": "2022-04-10T05:53:04",
          "updated_at": null,
          "status": "prepare_create"
        },
        {
          "id": "fb20a2f4-71ba-42a5-a7f1-ccd313ca2e2f",
          "size": 5,
          "created_at": "2022-04-10T05:53:04",
          "updated_at": null,
          "status": "prepare_create"
        }
      ],
      "cd_drivers": [],
      "hostname": "controller"
    }
  ],
  "vm_links": []
}
```

## 获取单个虚机

GET http://127.0.0.1:9906/v1/voi/vm/{vm_id}

### 示例

```
curl -X GET http://172.18.30.117:9906/v1/voi/vm/c407875f-0774-4126-8531-d52fe1274603
```

返回

```json
{
  "vm": {
    "id": "c407875f-0774-4126-8531-d52fe1274603",
    "name": "",
    "description": "",
    "status": "active",
    "created_at": "2022-04-10T05:53:04",
    "updated_at": "2022-04-10T05:53:08",
    "user_id": null,
    "project_id": null,
    "image_id": "302d073b-818f-4e0a-8e4c-d58ce9422b3e",
    "vcpu": 1,
    "memory_mb": 2048,
    "root_disk_gb": 50,
    "vnc_address": "172.18.30.117:5904",
    "spice_address": "172.18.30.117:5905",
    "nics": [
      {
        "id": "748ee01d-cf7b-46db-b889-e27b2876fb2d",
        "vpc_id": "ec21e66e-3924-448d-a34e-14e3ba2ee749",
        "ip_addresses": [
          {
            "ip_address": "192.168.0.164",
            "subnet_id": "3ce2bc57-3996-4fb3-a87e-6a412796cf73"
          }
        ],
        "mac_address": "fa:16:3e:6f:be:28"
      }
    ],
    "disks": [
      {
        "id": "7ab8b96d-fef2-4d55-a733-9a8d022c809c",
        "size": 10,
        "created_at": "2022-04-10T05:53:04",
        "updated_at": null,
        "status": "prepare_create"
      },
      {
        "id": "fb20a2f4-71ba-42a5-a7f1-ccd313ca2e2f",
        "size": 5,
        "created_at": "2022-04-10T05:53:04",
        "updated_at": null,
        "status": "prepare_create"
      }
    ],
    "cd_drivers": [],
    "hostname": "controller"
  }
}
```

## 获取单个虚机磁盘详细信息

GET http://127.0.0.1:9906/v1/voi/vm/{vm_id}/disk_detail

### 属性

| 名称  | 类型   | 说明                                                 |
| :---- | :----- | :--------------------------------------------------- |
| index | int    | 磁盘的挂载顺序, 0为系统盘, 非0为数据盘               |
| path  | string | 磁盘文件所在的绝对路径                               |
| size  | int    | 磁盘的真实大小(字节)                                 |
| name  | string | 磁盘文件名                                           |
| type  | string | 磁盘类型: base(基础镜像)、incr1(差分1)、incr2(差分2) |

### 示例

```
curl -X GET http://172.18.30.117:9906/v1/voi/vm/35658fc9-a235-46a4-b132-c54671c1f560/disk_detail
```

返回

```json
{
    "disk_details": [
        {
            "index": 0,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/35658fc9-a235-46a4-b132-c54671c1f560-sys-base.qcow2",
            "size": 12722176,
            "name": "35658fc9-a235-46a4-b132-c54671c1f560-sys-base.qcow2",
            "type": "base"
        },
        {
            "index": 0,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/35658fc9-a235-46a4-b132-c54671c1f560-sys-incr1.qcow2",
            "size": 200704,
            "name": "35658fc9-a235-46a4-b132-c54671c1f560-sys-incr1.qcow2",
            "type": "incr1"
        },
        {
            "index": 0,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/35658fc9-a235-46a4-b132-c54671c1f560-sys-incr2.qcow2",
            "size": 200704,
            "name": "35658fc9-a235-46a4-b132-c54671c1f560-sys-incr2.qcow2",
            "type": "incr2"
        },
        {
            "index": 2,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/7c6e82a8-bb31-4326-8889-ed47969d5bfa-data2-base.qcow2",
            "size": 200704,
            "name": "7c6e82a8-bb31-4326-8889-ed47969d5bfa-data2-base.qcow2",
            "type": "base"
        },
        {
            "index": 2,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/7c6e82a8-bb31-4326-8889-ed47969d5bfa-data2-incr1.qcow2",
            "size": 200704,
            "name": "7c6e82a8-bb31-4326-8889-ed47969d5bfa-data2-incr1.qcow2",
            "type": "incr1"
        },
        {
            "index": 2,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/7c6e82a8-bb31-4326-8889-ed47969d5bfa-data2-incr2.qcow2",
            "size": 200704,
            "name": "7c6e82a8-bb31-4326-8889-ed47969d5bfa-data2-incr2.qcow2",
            "type": "incr2"
        },
        {
            "index": 1,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/8e0bc5fd-a44e-4fc4-b33e-cf97c1690e4a-data1-base.qcow2",
            "size": 200704,
            "name": "8e0bc5fd-a44e-4fc4-b33e-cf97c1690e4a-data1-base.qcow2",
            "type": "base"
        },
        {
            "index": 1,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/8e0bc5fd-a44e-4fc4-b33e-cf97c1690e4a-data1-incr1.qcow2",
            "size": 200704,
            "name": "8e0bc5fd-a44e-4fc4-b33e-cf97c1690e4a-data1-incr1.qcow2",
            "type": "incr1"
        },
        {
            "index": 1,
            "path": "/home/trochilus/voi/vms/35658fc9-a235-46a4-b132-c54671c1f560/8e0bc5fd-a44e-4fc4-b33e-cf97c1690e4a-data1-incr2.qcow2",
            "size": 200704,
            "name": "8e0bc5fd-a44e-4fc4-b33e-cf97c1690e4a-data1-incr2.qcow2",
            "type": "incr2"
        }
    ]
}
```

## VM action 操作

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

### 参数

| 参数名        | 必选 | 类型   | 说明        |
| :------------ | :--- | :----- | ----------- |
| name          | 是   | string | action name |
| extended_attr | 否   | dict   | action 参数 |

### 开机

#### 示例

```
curl -L -X POST http://172.18.30.117:9906/v1/voi/vm/572f575f-4516-4f55-b9d4-2ade3dddd953/action \
    -H 'Content-Type: application/json' -d '{"action": {"name": "start"}}'
```

### 关机

分为强制关机和关机

#### 示例(关机-操作系统内关机)

```
curl -L -X POST http://172.18.30.117:9906/v1/voi/vm/572f575f-4516-4f55-b9d4-2ade3dddd953/action \
    -H 'Content-Type: application/json' -d '{"action": {"name": "stop"}}'
```

#### 示例(强制关机-直接断电):

```
curl -L -X POST http://172.18.30.117:9906/v1/voi/vm/572f575f-4516-4f55-b9d4-2ade3dddd953/action \
    -H 'Content-Type: application/json' -d '{
    "action": {
        "name": "stop",
        "extended_attr": {
            "force": true
        }
    }
}'
```

### 重启

#### 示例(软重启)

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"reboot",
        "extended_attr": {
            "type": "soft"
        }
    }
}'
```

#### 示例(硬重启)

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"reboot",
        "extended_attr": {
            "type": "hard"
        }
    }
}'
```

### 冷迁移

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"migrate",
        "extended_attr": {
            "host": "agent-2"
        }
    }
}'
```

请求参数(通过 host 指定主机)：

```json
{
    "action":{
        "name":"migrate",
        "extended_attr": {
            "host": "agent-2"
        }
    }
}
```

请求参数(通过 agent_id 指定主机)：

```json
{
    "action":{
        "name":"migrate",
        "extended_attr": {
            "agent_id": "57fd671e-5bd1-44ab-90ca-d9c7e6140cc0"
        }
    }
}
```

### 合并(commit)

* Note: 仅支持关机状态下commit, 这个接口的具体实现方式待定。

可能有两种情况：

1、在创建虚机时，两个增量盘连带都创建好（这种目前我们已经实现了，而且是最简单的）

base.qcow2 -> incre1.qcow2 -> incre2.qcow2 -> current.qcow2

在调用该接口时会做四个操作：
* 把 incre2.qcow2 commit 到 incre1.qcow2
* 删除 incre2.qcow2
* current.qcow2 重命名为 incre2.qcow2, incre1.qcow2 作为 backingfile
* 创建一个新的 current.qcow2

2、创建虚机时不创建增量盘（这时需要额外一个创建快照的接口）（这种情况非常复杂，需要单独讨论）

base.cow2 -> current.qcow2

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"commit"
    }
}'
```

### reset

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"reset"
    }
}'
```

### 切换光盘

如不传 extended_attr 则光驱内光盘置为空, image_id 必须是 iso 格式的镜像

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "replace_iso",
        "extended_attr": {
            "image_id": "{{image_uuid}}"
        }
    }
}
```

### 添加数据盘

目前仅支持关机状态下添加数据盘

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "attach_volume",
        "extended_attr": {
            "size": 1
        }
    }
}
```

### 移除数据盘

目前仅支持关机状态下移除数据盘

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "remove_volume",
        "extended_attr": {
            "volume_id": "3ffdf72b-de6c-4ee9-b69d-b68b6d5161c7"
        }
    }
}
```

### 挂载共享盘模板

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "attach_share_template_volume",
        "extended_attr": {
            "volume_id": "3ffdf72b-de6c-4ee9-b69d-b68b6d5161c7"
        }
    }
}'
```

### 卸载共享盘模板

#### 示例

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "detach_share_template_volume",
        "extended_attr": {
            "volume_id": "3ffdf72b-de6c-4ee9-b69d-b68b6d5161c7"
        }
    }
}'
```

### 转镜像/下载(只做一个)

#### 示例

TODO

## 备份盘属性

| 名称               | 类型   | 说明                                 |
| :----------------- | :----- | :----------------------------------- |
| disk_base_filepath | string | 备份盘的 base 文件所在路径           |
| disk_dirpath       | string | 存放备份盘文件的目录                 |
| disk_type          | string | 备份盘类型, 目前仅支持 "sys", "data" |
| index              | int    | 磁盘的挂载顺序, 0为系统盘, 1为数据盘 |
| path               | string | 磁盘文件所在的绝对路径               |
| size               | int    | 磁盘的真实大小(字节)                 |
| name               | string | 磁盘文件名                           |
| type               | string | 磁盘类型: incr1(差分1)、incr2(差分2) |

## 备份盘合并

### 参数

| 参数名             | 必选 | 类型   | 说明                                 |
| :----------------- | :--- | :----- | ------------------------------------ |
| disk_base_filepath | 否   | string | 备份盘的 base 文件所在路径           |
| disk_dirpath       | 是   | string | 备份盘所在文件夹路径                 |
| disk_type          | 是   | string | 备份盘类型, 目前仅支持 "sys", "data" |

disk_base_filepath: 因 base 盘可能会很大, 平台做备份的时候不对 base 进行拷贝(仅拷贝 incr1, incr2),
                    该参数用来支持备份盘不存在 base 文件的情况.
disk_type: 如传入 "data", 则只合并第一个数据盘, 因为从需求上来说仅存在一块数据盘.

### 示例

```bash
curl --location --request POST '192.168.110.118:9906/v1/voi/backup_disk' \
--header 'Content-Type: application/json' \
--data-raw '{
    "disk_base_filepath": "/home/trochilus/voi/vms/920bd0aa-0f04-479f-a020-b6444bebd1b5/874c5952-1db8-4c69-a5c5-5c983a5ba2b8-data1-base.qcow2",
    "disk_dirpath": "/home/trochilus/voi/backup_disk/cd4d0fc6-4c0b-4ba4-bb2f-c21a9e7a7c28",
    "disk_type": "data"
}'
```

返回

```json
{"status": "ok"}
```

## 获取备份盘详情

仅返回备份盘的 incr1, incr2 文件的详细信息

### 参数

| 参数名       | 必选 | 类型   | 说明                 |
| :----------- | :--- | :----- | -------------------- |
| disk_dirpath | 是   | string | 存放备份盘文件的目录 |

### 示例

```
curl --location --request GET '192.168.110.118:9906/v1/voi/backup_disk?disk_dirpath=/home/trochilus/voi/backup_disk/cd4d0fc6-4c0b-4ba4-bb2f-c21a9e7a7c28'
```

返回

```json
{
    "disk_details": [
        {
            "index": 1,
            "path": "/home/trochilus/voi/backup_disk/cd4d0fc6-4c0b-4ba4-bb2f-c21a9e7a7c28/874c5952-1db8-4c69-a5c5-5c983a5ba2b8-data1-incr1.qcow2",
            "size": 200704,
            "name": "874c5952-1db8-4c69-a5c5-5c983a5ba2b8-data1-incr1.qcow2",
            "type": "incr1"
        },
        {
            "index": 1,
            "path": "/home/trochilus/voi/backup_disk/cd4d0fc6-4c0b-4ba4-bb2f-c21a9e7a7c28/874c5952-1db8-4c69-a5c5-5c983a5ba2b8-data1-incr2.qcow2",
            "size": 200704,
            "name": "874c5952-1db8-4c69-a5c5-5c983a5ba2b8-data1-incr2.qcow2",
            "type": "incr2"
        },
        {
            "index": 0,
            "path": "/home/trochilus/voi/backup_disk/cd4d0fc6-4c0b-4ba4-bb2f-c21a9e7a7c28/920bd0aa-0f04-479f-a020-b6444bebd1b5-sys-incr2.qcow2",
            "size": 397312,
            "name": "920bd0aa-0f04-479f-a020-b6444bebd1b5-sys-incr2.qcow2",
            "type": "incr2"
        },
        {
            "index": 0,
            "path": "/home/trochilus/voi/backup_disk/cd4d0fc6-4c0b-4ba4-bb2f-c21a9e7a7c28/920bd0aa-0f04-479f-a020-b6444bebd1b5-sys-incr1.qcow2",
            "size": 200704,
            "name": "920bd0aa-0f04-479f-a020-b6444bebd1b5-sys-incr1.qcow2",
            "type": "incr1"
        }
    ]
}
```

## 共享盘属性

| 名称           | 类型   | 说明                                                 |
| :------------- | :----- | :--------------------------------------------------- |
| image_filepath | string | 镜像文件所在路径                                     |
| base_dirpath   | string | 存放共享盘目录的目录(顶级目录)                       |
| disk_dirpath   | string | 存放共享盘文件的目录                                 |
| id             | string | 共享盘 uuid 用于平台记录                             |
| path           | string | 磁盘文件绝对路径                                     |
| name           | string | 磁盘文件名                                           |
| type           | string | 磁盘类型: base(基础镜像)、incr1(差分1)、incr2(差分2) |

## 创建共享盘

### 参数


| 参数名         | 必选 | 类型   | 说明                                  |
| :------------- | :--- | :----- | ------------------------------------- |
| image_filepath | 是   | string | 镜像文件所在路径                      |
| base_dirpath   | 是   | string | 存放共享盘目录的目录(顶级目录)        |
| id             | 否   | string | 创建共享盘指定 id, 如不指定则随机生成 |

### 示例

```
curl -L -X POST 'http://172.18.30.117:9906/v1/voi/share_disk' -H 'Content-Type: application/json' \
--data-raw '{
    "image_filepath": "/home/trochilus/voi/share_image/100GDISK.qcow2",
    "base_dirpath": "/mnt/voi/share_disk",
    "id": "8dbe9493-4292-43fb-a434-3b5b0eea59bf"
}'
```

返回

```json
{
    "share_disk": {
        "id": "8dbe9493-4292-43fb-a434-3b5b0eea59bf"
    }
}
```

## 删除共享盘

### 参数

| 参数名       | 必选 | 类型   | 说明                 |
| :----------- | :--- | :----- | -------------------- |
| disk_dirpath | 是   | string | 存放共享盘文件的目录 |

### 示例

```
curl -L -X DELETE 'http://172.18.30.117:9906/v1/voi/share_disk' -H 'Content-Type: application/json' \
--data-raw '{
    "disk_dirpath": "/mnt/voi/share_disk/8684a0bb-54fa-481a-84bd-4eed58dc3572"
}'
```

## 合并共享盘(commit)

### 参数

| 参数名       | 必选 | 类型   | 说明                 |
| :----------- | :--- | :----- | -------------------- |
| disk_dirpath | 是   | string | 存放共享盘文件的目录 |

### 示例

```
curl -L -X PUT 'http://172.18.30.117:9906/v1/voi/share_disk' -H 'Content-Type: application/json' \
--data-raw '{
    "disk_dirpath": "/mnt/voi/share_disk/8684a0bb-54fa-481a-84bd-4eed58dc3572"
}'
```

## 获取共享盘详情

### 参数

| 参数名       | 必选 | 类型   | 说明                 |
| :----------- | :--- | :----- | -------------------- |
| disk_dirpath | 是   | string | 存放共享盘文件的目录 |

### 示例

```
curl -L -X GET '192.168.110.118:9906/v1/voi/share_disk?disk_dirpath=/mnt/voi/share_disk/408bacc5-4bd5-4d47-8b8c-abd5520df9d7'
```

返回

```json
{
    "disk_details": [
        {
            "path": "/mnt/voi/share_disk/39f71189-bd29-4c0a-83d4-139b95bc7c41/39f71189-bd29-4c0a-83d4-139b95bc7c41-share-base.qcow2",
            "size": 786432,
            "name": "39f71189-bd29-4c0a-83d4-139b95bc7c41-share-base.qcow2",
            "type": "base"
        },
        {
            "path": "/mnt/voi/share_disk/39f71189-bd29-4c0a-83d4-139b95bc7c41/39f71189-bd29-4c0a-83d4-139b95bc7c41-share-incr1.qcow2",
            "size": 200704,
            "name": "39f71189-bd29-4c0a-83d4-139b95bc7c41-share-incr1.qcow2",
            "type": "incr1"
        },
        {
            "path": "/mnt/voi/share_disk/39f71189-bd29-4c0a-83d4-139b95bc7c41/39f71189-bd29-4c0a-83d4-139b95bc7c41-share-incr2.qcow2",
            "size": 200704,
            "name": "39f71189-bd29-4c0a-83d4-139b95bc7c41-share-incr2.qcow2",
            "type": "incr2"
        }
    ]
}
```

## 共享盘模板属性

| 名称   | 类型   | 说明                           |
| :----- | :----- | :----------------------------- |
| id     | string | 共享盘模板 id                  |
| size   | int    | 共享盘模板大小， 单位 G        |
| vm_id  | string | 共享盘模板挂载的模板机 id      |
| path   | string | 共享盘模板磁盘镜像文件所在路径 |
| status | string | 共享盘模板状态                 |

## 创建共享盘模板

### 参数

| 参数名 | 必选 | 类型 | 说明                    |
| :----- | :--- | :--- | ----------------------- |
| size   | 是   | int  | 共享盘模板大小， 单位 G |

### 示例

```
curl -L -X POST HTTP://127.0.0.1:9906/v1/voi/share_template_disk -H 'Content-Type: application/json' \
--data-raw '{
   "size": 1
}'
```

返回

```json
{
    "share_template_disk":{
        "id":"a6473344-6d2c-4cb2-9030-19fd1c13c606",
        "size":1,
        "vm_id":null,
        "path":"/var/lib/trochilus/voi/share-template-disks/c825c412-1a5b-43df-9daa-e39db874430a.qcow2",
        "status": "available"
    }
}
```

## 删除共享盘模板

### 参数

| 参数名 | 必选 | 类型   | 说明          |
| :----- | :--- | :----- | ------------- |
| id     | 是   | string | 共享盘模板 id |

### 示例

```
curl -L -X DELETE HTTP://127.0.0.1:9906/v1/voi/share_template_disk/a6473344-6d2c-4cb2-9030-19fd1c13c606
```

## 获取单个共享盘模板


### 示例

```
curl -L -X GET HTTP://127.0.0.1:9906/v1/voi/share_template_disk/2bcd11ae-54aa-4fb1-b774-c0125b84d792
```

返回

```json
{
    "share_template_disk":{
        "id":"2bcd11ae-54aa-4fb1-b774-c0125b84d792",
        "size":1,
        "vm_id":null,
        "path":"/var/lib/trochilus/voi/share-template-disks/c825c412-1a5b-43df-9daa-e39db874430a.qcow2",
        "status": "available"
    }
}
```
