---
"title": VPC
---


## 属性

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| id | string | vpc id |
| name | string | vpc name |
| type | string | vpc 类型，flat 或者 vlan |
| physical | string | 支撑该 vpc 的 physical 网络 |
| vlan_id | integer | vlan id |
| description | string | 描述 |
| status | string | vpc 状态 |
| project_id | string ||
| user_id | string ||
| created_at | string | 创建时间 |
| updated_at | string | 更新时间 |


## 创建

POST http://127.0.0.1:9906/v1/vpc


### 参数

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| name | 否 | string | VPC 名称 |
| type | 是 | string | 只能是 flat 或者 vlan |
| physical |是 | string | VPC 底层网络 |
| vlan_id |否 | integer | 当 type 为 vlan 时该值才生效 |
| description | 否 |  string | 对 vpc 的一下备注 |
| user_id | 否 | string ||
| project_id |否 | string ||


### 示例

请求命令：

```console
curl -X POST  -H "Content-Type: application/json" http://127.0.0.1:9906/v1/vpc -d
```

请求参数：

```json
{
    "vpc": {
        "name": "v1",
        "type": "vlan",
        "physical": "aaa"
    }
}
```

返回参数：

```json
{
    "vpc": {
        "id": "22053836-c4f4-4d2c-a1ed-444427bb8206",
        "name": "v1",
        "description": "",
        "type": "vlan",
        "vlan_id": 5,
        "physical": "aaa",
        "status": "prepare_create",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-02-11T07:12:52",
        "updated_at": null
    }
}
```


## 更新

PUT http://127.0.0.1:9906/v1/vpc/{vpc_id}


### 参数

| 参数名 | 类型 | 说明 |
|:-------|:-----|:-----|
| name | string | VPC 名称 |
| description | string | vpc 描述 |
| project_id | string ||
| user_id | string ||


### 示例

请求命令：

```console
curl -X POST -H "Content-Type: application/json" http://127.0.0.1:9906/v1/vpc/22053836-c4f4-4d2c-a1ed-444427bb8206 -d
```

请求参数：

```json
{
    "vpc": {
        "name": "new_name"
    }
}
```

返回参数：

```json
{
    "vpc": {
        "id": "22053836-c4f4-4d2c-a1ed-444427bb8206",
        "name": "new_name",
        "description": "",
        "type": "vlan",
        "vlan_id": 5,
        "physical": "aaa",
        "status": "prepare_create",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-02-11T07:12:52",
        "updated_at": "2022-02-11T07:25:56"
    }
}
```


## 获取 VPC 列表

GET http://127.0.0.1:9906/v1/vpc


### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/vpc?limit=2\&sort=id:asc\&fields=id\&fields=name
```

返回信息：

```json
{
    "vpcs": [{
        "id": "17e7af87-0139-4edd-9fae-c543b8b13b87",
        "name": "v1"
    }, {
        "id": "22053836-c4f4-4d2c-a1ed-444427bb8206",
        "name": "new_name"
    }],
    "vpc_links": [{
        "href": "http://127.0.0.1:9906/v1/vpc?limit=2&sort=id:asc&marker=22053836-c4f4-4d2c-a1ed-444427bb8206",
        "rel": "next"
    }]
}
```


## 获取单个 VPC 信息

GET http://127.0.0.1:9906/v1/vpc/{vpc_id}


### 示例

请求命令

```console
curl -X GET http://127.0.0.1:9906/v1/vpc/17e7af87-0139-4edd-9fae-c543b8b13b87?fields=id\&fields=name
```

返回信息：

```json
{
    "vpc": {
        "id": "17e7af87-0139-4edd-9fae-c543b8b13b87",
        "name": "v1"
    }
}
```


### 删除 VPC

DELETE http://127.0.0.1:9906/v1/vpc/{vpc_id}


### 示例

请求命令：

```console
curl -X DELETE http://127.0.0.1:9906/v1/vpc/22053836-c4f4-4d2c-a1ed-444427bb8206
```

删除成功无返回信息


## 获取单个 VPC 在所有计算节点上的状态

GET http://127.0.0.1:9906/v1/vpc/{vpc_id}/agents

### 示例

请求命令

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/vpc/6ad95fc9-731c-433d-a831-93adf95bedb5/agents
```

返回信息：

```json
{
    "statuses": [{
        "agent_id": "d3679f75-7968-4103-82ca-994074cc3ece",
        "status": "active"
    }],
    "status_links": []
}
```
