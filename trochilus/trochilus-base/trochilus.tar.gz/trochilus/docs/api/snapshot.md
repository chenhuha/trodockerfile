---
title: "snapshot"
---

## 属性

| 名称              | 类型     | 说明                       |
| :---------------- | :------- | :------------------------- |
| id                | string   | snapshot id                |
| name              | string   | snapshot name              |
| description       | string   | 描述信息                   |
| size              | integer  | snapshot 大小（G）         |
| status            | string   | snapshot 状态              |
| volume_id         | string   | 卷 id                      |
| current           | string   | 标识该快照是否为最新快照点 |
| previous          | string   | 当前快照的上游快照 id      |
| project_id        | string   | 项目id                     |
| user_id           | string   | 用户id                     |
| created_at        | datetime | 创建时间                   |
| updated_at        | datetime | 更新时间                   |
| snapshot_group_id | string   | 所属快照组 ID              |


## 创建

POST http://127.0.0.1:9906/v1/snapshot

### 参数

| 参数名      | 必选 | 类型   | 说明           |
| :---------- | :--- | :----- | -------------- |
| name        | 否   | string | 快照名称       |
| description | 否   | string | 快照的描述信息 |
| volume_id   | 是   | uuid   | 卷 id          |
| project_id  | 否   | string | 项目id         |
| user_id     | 否   | string | 用户id         |

### 示例

请求命令：

```console
curl -L -X POST http://127.0.0.1:9906/v1/snapshot -H 'Content-Type: application/json' -d
```

请求参数:

 ```json
{
    "snapshot": {
        "name": "snapshot1",
        "description": "test snapshot",
        "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf"
    }
}

```

返回参数:

```json
{
    "snapshot": {
        "id": "536e9e3a-2b3a-4138-956f-535c6feac2a6",
        "name": "snapshot1",
        "size": 1,
        "status": "prepare_create",
        "description": "this is test snapshot1",
        "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf",
        "current": "True",
        "previous": null,
        "user_id": null,
        "project_id": null,
        "created_at": "2022-03-22T07:25:20",
        "updated_at": null,
        "snapshot_group_id": null
    }
}
```

## 更新

PUT http://127.0.0.1:9906/v1/snapshot/{snapshot_id}

### 参数

| 参数名      | 类型   | 说明        |
| :---------- | :----- | :---------- |
| name        | string | Volume 名称 |
| description | string | Volume 描述 |

### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/snapshot/536e9e3a-2b3a-4138-956f-535c6feac2a6 -H 'Content-Type: application/json' -d
```

请求参数：

```json
{
    "snapshot": {
        "name": "test_snap",
        "description": "TEST"
    }
}
```

返回参数：

```json
{
    "snapshot": {
        "id": "536e9e3a-2b3a-4138-956f-535c6feac2a6",
        "name": "test_snap",
        "size": 1,
        "status": "available",
        "description": "TEST",
        "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf",
        "current": "True",
        "previous": null,
        "user_id": null,
        "project_id": null,
        "created_at": "2022-03-22T07:25:20",
        "updated_at": "2022-03-22T07:26:15",
        "snapshot_group_id": null
    }
}
```

## 获取快照列表信息

GET http://127.0.0.1:9906/v1/snapshot

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/snapshot
```

返回信息:

```json
{
    "snapshots": [
        {
            "id": "c0434af9-7388-42ae-8878-a0a8da4ca5ba",
            "name": "snapshot-1",
            "size": 5,
            "status": "active",
            "description": "this is test snapshot1",
            "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf",
            "current": "True",
            "previous": null,
            "user_id": null,
            "project_id": null,
            "created_at": "2022-03-22T06:08:05",
            "updated_at": "2022-03-22T06:08:07",
            "snapshot_group_id": "b58e495f-d8fb-4ae8-8e21-15872dbc9973"
        },
        {
            "id": "1eb33430-4c64-4396-b6ce-51b39ce11758",
            "name": "snapshot-2",
            "size": 5,
            "status": "active",
            "description": "this is test snapshot2",
            "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf",
            "current": "True",
            "previous": null,
            "user_id": null,
            "project_id": null,
            "created_at": "2022-03-22T07:25:20",
            "updated_at": "2022-03-22T07:26:15",
            "snapshot_group_id": null
        }
    ],
    "snapshot_links": []
}
```

## 获取单个快照信息

GET http://127.0.0.1:9906/v1/snapshot/{snapshot_id}

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/snapshot/1eb33430-4c64-4396-b6ce-51b39ce11758
```

返回信息：

```json
{
    "snapshot": {
        "id": "1eb33430-4c64-4396-b6ce-51b39ce11758",
        "name": "snapshot-2",
        "size": 5,
        "status": "active",
        "description": "this is test snapshot2",
        "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf",
        "current": "True",
        "previous": null,
        "user_id": null,
        "project_id": null,
        "created_at": "2022-03-22T06:08:05",
        "updated_at": "2022-03-22T06:08:06",
        "snapshot_group_id": "b58e495f-d8fb-4ae8-8e21-15872dbc9973"
    }
}
```

## 删除

DELETE http://127.0.0.1:9906/v1/snapshot/{snapshot_id}

### 示例

请求命令：

```console
curl http://127.0.0.1:9906/v1/snapshot/1eb33430-4c64-4396-b6ce-51b39ce11758 -X delete
```

删除成功无返回值
