---
"title": Subnet
---


## 属性

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| id | string | subnet id |
| name | string | subnet名称 |
| description | string | 对subnet的描述 |
| vpc_id | string | subnet所属的vpc id |
| cidr | string | subnet CIDR |
| gateway | string | 网关地址 |
| address_pools | list | 地址池, 是一个列表，列表中元素字段见下表  |
| address_details | dict | IP地址详情，列表中元素字段见下表  |
| enable_dhcp | bool | 是否开启 dhcp |
| dns_nameservers| list | dns ip 列表|
| user_id | string | 用户id |
| project_id | string | 项目id |
| created_at | string | 创建时间 |
| updated_at | string | 更新时间 |

### address_pools 列表元素字段说明

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| start_ip | string | 地址池起始 ip |
| end_id | string | 地址池结束 ip |

### address_details 列表元素字段说明

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| total_ip | integer | 子网中可用的IP地址总数 |
| used_ip | integer | 子网中已使用的IP地址数 |
| allocate_pool_ip | integer | 地址池中可用的IP地址数 |
| allocable_ip | integer | 地址池中剩余可分配的IP地址数 |

`total_ip`: 子网的IP地址总数中包含两个不可用地址：网络地址和广播地址(即主机位全零和全一)
`used_ip`: 新建的子网used_ip为1，这是因为网关地址占用了一个IP地址
`cidr`: cidr的网络前缀长度限制为1~30


## 创建subnet

POST http://127.0.0.1:9906/v1/subnet

### 参数

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| name | 否 | string | subnet名称 |
| description | 否 |  string | 对subnet的描述 |
| vpc_id | 是 | string | subnet所属的vpc id |
| cidr | 是 | string | subnet的CIDR |
| gateway | 否 | string | 网关地址, 如果未指定gateway,会自动从子网的CIDR中分配第一个有效地址作为网关地址 |
| address_pools | 否 | list | 地址池, 是一个列表，列表中元素字段见下表 |
| enable_dhcp | 否 | bool | 是否开启 dhcp |
| dns_nameservers| 否 | list | dns ip 列表 |
| user_id | 否 | string | 用户id |
| project_id |否 | string | 项目id |

### address_pools 列表元素字段说明

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| start_ip | 是 | string |地址池起始 ip |
| end_ip | 是 | string | 地址池结束 ip |


### 示例

请求命令:

```consle
curl -X POST -H "Content-Type: application/json" http://127.0.0.1:9906/v1/subnet -d
```

请求参数：

```json
{
    "subnet": {
        "vpc_id": "598df29a-0a89-48c2-b1f7-54f720bc9109",
        "cidr": "192.168.0.0/24",
        "address_pools": [{
            "start_ip": "192.168.0.10",
            "end_ip": "192.168.0.20"
        },{
            "start_ip": "192.168.0.30",
            "end_ip": "192.168.0.40"
        }],
        "enable_dhcp": true,
        "dns_nameservers": ["114.114.114.114","8.8.8.8"]
    }
}
```

返回参数：

```json
{
    "subnet": {
        "id": "faf85347-3395-4633-9aae-ef1c1eaaa9b8",
        "name": "",
        "description": "",
        "vpc_id": "7da011d3-36bb-4f82-9e8d-19ae9b966b94",
        "cidr": "192.168.0.0/24",
        "gateway": "192.168.0.1",
        "address_pools": [{
            "start_ip": "192.168.0.10",
            "end_ip": "192.168.0.20"
        },{
            "start_ip": "192.168.0.30",
            "end_ip": "192.168.0.40"
        }],
        "address_details": {
                "total_ip": 254,
                "used_ip": 1,
                "allocate_pool_ip": 22,
                "allocable_ip": 22
        },
        "enable_dhcp": true,
        "dns_nameservers": ["114.114.114.114","8.8.8.8"],
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-31T07:05:44",
        "updated_at": null
    }
}
```


## 更新

PUT http://127.0.0.1:9906/v1/subnet/{subnet id}

### 参数

| 参数名 | 类型 | 说明 |
|:-------|:-----|:-----|
| name | string | subnet名称 |
| description | string | 对subnet的描述 |
| address_pools | list | 地址池, 是一个列表，列表中元素字段见下表 |
| enable_dhcp | bool | 是否开启 dhcp |
| dns_nameservers| list | dns ip 列表 |
| project_id | string | 项目id |
| user_id | string | 用户id |

### address_pools 列表元素字段说明

| 参数名 | 必选 | 类型 | 说明 |
|:-------|:-----|:-----|:-----|
| start_ip | 是 | string |地址池起始 ip |
| end_ip | 是 | string | 地址池结束 ip |


### 示例

请求命令:
```console
curl -X PUT -H "Content-Type: application/json" http://127.0.0.1:9906/v1/subnet/0bcbe488-8bf6-4135-a111-8bae12b73db9 -d
```

请求参数：

```json
{
    "subnet": {
        "name": "subnet-1",
        "description": "this is description",
        "address_pools": [{
            "start_ip": "192.168.0.10",
            "end_ip": "192.168.0.20"
        }]
    }
}
```

返回参数：

```json

{
    "subnet": {
        "id": "faf85347-3395-4633-9aae-ef1c1eaaa9b8",
        "name": "subnet-1",
        "description": "this is description",
        "vpc_id": "7da011d3-36bb-4f82-9e8d-19ae9b966b94",
        "cidr": "192.168.0.0/24",
        "gateway": "192.168.0.1",
        "address_pools": [{
            "start_ip": "192.168.0.10",
            "end_ip": "192.168.0.20"
        }],
        "address_details": {
                "total_ip": 254,
                "used_ip": 1,
                "allocate_pool_ip": 11,
                "allocable_ip": 11
        },
        "enable_dhcp": true,
        "dns_nameservers": ["114.114.114.114","8.8.8.8"],
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-31T07:05:44",
        "updated_at": "2022-03-31T07:06:57"
    }
}
```


## 获取 Subnet 列表

GET http://127.0.0.1:9906/v1/subnet

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/subnet?limit=2\&sort=id:asc\&fields=id\&fields=name
```

返回信息：

```json
{
    "subnets": [
        {
            "id": "0857e3cd-eb3e-46e3-bc21-3190c9d8a903",
            "name": "subnet-2"
        },
        {
            "id": "0bcbe488-8bf6-4135-a111-8bae12b73db9",
            "name": "subnet-1"
        }
    ],
    "subnet_links": [
        {
            "href": "http://127.0.0.1:9906/v1/subnet?limit=2&sort=id:asc&marker=0bcbe488-8bf6-4135-a111-8bae12b73db9",
            "rel": "next"
        }
    ]
}
```


## 获取单个 Subnet 信息

GET http://127.0.0.1:9906/v1/subnet/{subnet id}

### 示例

请求命令:

```console
curl -X GET http://127.0.0.1:9906/v1/subnet/0bcbe488-8bf6-4135-a111-8bae12b73db9?fields=id\&fields=name
```

返回信息：

```json
{
    "subnet": {
        "id": "0bcbe488-8bf6-4135-a111-8bae12b73db9",
        "name": "subnet-1"
    }
}
```


## 删除 Subnet

DELETE http://127.0.0.1:9906/v1/subnet/{subnet id}

### 示例

请求命令：

```console
curl -X DELETE http://127.0.0.1:9906/v1/subnet/0bcbe488-8bf6-4135-a111-8bae12b73db9
```

返回信息：

删除成功无返回信息。
