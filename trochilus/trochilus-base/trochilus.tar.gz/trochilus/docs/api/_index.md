---
title: "Trochilus API 文档"
---

Troichilus 为上游应用提供了 restful API，其接口风格模仿了 openstack。一共支持四
种请求类型的请求：`POST`，`PUT`，`GET`，`DELETE`，在使用 `GET` 请求获取资源列表
时我们还支持分页，排序，过滤和参数选择等功能。

请求参数和返回参数我们只支持 json 格式（上传和下载镜像除外），因此在每次请求中我
们都期望有下面的请求头。

对于 post 和 put：

```text
"Content-Type: application/json"
"Accept: application/json"
```

对于 GET：

```text
"Accept: application/json"
```


## 分页

| 参数名       | 说明                          |
|:-------------| :-----------------------------|
| limit        | 页大小                        |
| marker       | 页标识 （ 上一页的最后一项 ） |
| page_reverse | 是否向前翻页                  |

**示例**

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/agent?limit=5
```

```json
{
    "agents": [{
            "id": "912f7928-b839-45bc-bb3d-6400347d504a",
            "hostname": "wxj-pc1",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504b",
            "hostname": "wxj-pc2",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504c",
            "hostname": "wxj-pc3",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504d",
            "hostname": "wxj-pc4",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ]
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504e",
            "hostname": "wxj-pc",
            "description": "",
            "status": "up",
            "heartbeat_timestamp": "2022-02-07T07:27:50",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        }
    ],
    "agent_links": [{
        "href": "http://127.0.0.1:9906/v1/agent?limit=5&marker=912f7928-b839-45bc-bb3d-6400347d504e",
        "rel": "next"
    }]
}
```

agent_linsk 中的 href 是具有以当前页的最后一项为标识的下一页
或者上一页的 URL， 其中上一页或下一页由 rel 指定 。 注意 : 
最后一页不会有下一页 , 第一页不会有上一页 。下一个请求我们设
置页大小为 3， 以 912f7928-b839-45bc-bb3d-6400347d504d 为标识 ，
向前翻页：

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/agent?limit=3\&marker=912f7928-b839-45bc-bb3d-6400347d504d\&page_reverse=True
```

```json
{
    "agents": [{
            "id": "912f7928-b839-45bc-bb3d-6400347d504a",
            "hostname": "wxj-pc1",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504b",
            "hostname": "wxj-pc2",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504c",
            "hostname": "wxj-pc3",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        }
    ],
    "agent_links": [{
            "href": "http://127.0.0.1:9906/v1/agent?limit=3&sort=id:asc&marker=912f7928-b839-45bc-bb3d-6400347d504a&page_reverse=True",
            "rel": "previous"
        },
        {
            "href": "http://127.0.0.1:9906/v1/agent?limit=3&sort=id:asc&marker=912f7928-b839-45bc-bb3d-6400347d504c",
            "rel": "next"
        }
    ]
}
```


## 排序

| 参数名    | 说明                                |
|:----------|:------------------------------------|
| sort      | 排序                                |
| sort_key  | 排序关键字                          |
| sort_dir  | 排序方式 （asc 升序 ， desc 降序 ） |

**示例**

升序

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/agent?sort=hostname:asc
```

```json
{
    "agents": [{
            "id": "912f7928-b839-45bc-bb3d-6400347d504e",
            "hostname": "wxj-pc",
            "description": "",
            "status": "up",
            "heartbeat_timestamp": "2022-02-07T07:59:52",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504a",
            "hostname": "wxj-pc1",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504b",
            "hostname": "wxj-pc2",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504c",
            "hostname": "wxj-pc3",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504d",
            "hostname": "wxj-pc4",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        }
    ],
    "agent_links": []
}
```

降序

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/agent?sort=hostname:desc
```

```json
{
    "agents": [{
            "id": "912f7928-b839-45bc-bb3d-6400347d504d",
            "hostname": "wxj-pc4",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504c",
            "hostname": "wxj-pc3",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0001"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "",
                    "role": "0011"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504b",
            "hostname": "wxj-pc2",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
        "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504a",
            "hostname": "wxj-pc1",
            "description": "NULL",
            "status": "down",
            "heartbeat_timestamp": "2022-02-07T01:51:07",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        },
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504e",
            "hostname": "wxj-pc",
            "description": "",
            "status": "up",
            "heartbeat_timestamp": "2022-02-07T08:03:22",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        }
    ],
    "agent_links": []
}
```


## 过滤

**示例**

保留hostname为wxj-pc，过滤掉不符合要求的

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/agent?hostname=wxj-pc
```

```json
{
    "agents": [
        {
            "id": "912f7928-b839-45bc-bb3d-6400347d504e",
            "hostname": "wxj-pc",
            "description": "",
            "status": "up",
            "heartbeat_timestamp": "2022-02-07T08:03:22",
            "mgmt_ip": "0.0.0.0",
            "api_version": "v1.0",
            "total_memory": 16755699712,
            "free_memory": 14748643328,
            "cpu_used_ratio": 13.0,
            "sys_disk_size": 316998987776,
            "sys_disk_used_size": 22510129152,
            "system": "unbuntu",
            "version": 20.04,
            "cpu_thread": 8,
            "cpu_socket": 8,
            "cpu_MHZ": "2394.444",
            "cpu_core": 1,
            "stepping": 2,
            "model": "Intel Core Processor (Broadwell, IBRS)",
            "boot_time": "2022-03-03T15:39:55",
            "L2_cache": "32 MiB",
            "L3_cache": "128 MiB",
            "role": [
                "controller",
                "computer",
                "storage"
            ],
            "networks": [
                {
                    "nic_name": "ens5",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens4",
                    "status": 1,
                    "ip_addresses": [],
                    "subnet_mask": "",
                    "gateway": "",
                    "speed": -1,
                    "vlan": "100:1000",
                    "bond_name": "bond0",
                    "role": "0011",
                    "type": "physical"
                },
                {
                    "nic_name": "ens3",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.79"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "1100",
                    "type": "physical"
                },
                {
                    "nic_name": "bond0",
                    "status": 1,
                    "ip_addresses": [
                        "172.18.29.59"
                    ],
                    "subnet_mask": "255.255.252.0",
                    "gateway": "172.18.31.254",
                    "speed": -1,
                    "vlan": "",
                    "bond_name": "",
                    "role": "0011",
                    "type": "bond"
                }
            ],
            "disk_names": "vda,vdb",
            "net_pci_info": [
                "00:03.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:04.0 Ethernet controller: Red Hat, Inc. Virtio network device",
                "00:05.0 Ethernet controller: Red Hat, Inc. Virtio network device"
            ],
            "host_username": "root",
            "host_password": "123456",
            "ipmi_address": "172.27.122.222",
            "ipmi_vendor": "HUAWEI",
            "ipmi_username": "root",
            "ipmi_password": "Huawei12#$"
        }
    ],
    "agent_links": []
}
```

## 参数选择

| 参数名    | 说明                                |
|:----------|:------------------------------------|
| fields    | 保留的参数                                |

**示例**

选择保留 hostname 参数

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/agent?fields=hostname
```

```json
{
    "agents": [{
            "hostname": "wxj-pc1"
        },
        {
            "hostname": "wxj-pc2"
        },
        {
            "hostname": "wxj-pc3"
        },
        {
            "hostname": "wxj-pc4"
        },
        {
            "hostname": "wxj-pc"
        }
    ],
    "agent_links": []
}
```
