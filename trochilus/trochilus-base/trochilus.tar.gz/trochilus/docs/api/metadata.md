---
title: "metadata"
---


## 属性

| 名称 | 类型 | 说明 |
|:-----|:-----|:-----|
| key | string | 键名称 |
| type | string | 传入类型 |
| description | string | 描述信息 |
| enum | list | 元数据取值范围 |


## 获取元数据列表信息

GET http://127.0.0.1:9906/v1/metadata/


### 示例

请求命令:

```console
curl -X GET http://127.0.0.1:9906/v1/metadata/
```

返回信息：

```json
{
    "metadatas": [{
        "key": "k1",
        "type": "string",
        "description": "Check field K1",
        "enum": ["k1_v1", "k1_v2", "k1_v3"]
    }, {
        "key": "k3",
        "type": "string",
        "description": "Check field K2",
        "enum": ["k1_v1", "k1_v2", "k1_v3"]
    }]
}
```


## 获取单个元数据信息

GET http://127.0.0.1:9906/v1/metadata/{metadata_key}


### 示例

请求命令:

```console
curl -L -X GET http://127.0.0.1:9906/v1/metadata/k1
```

返回信息：

```json
{
    "metadata": {
        "key": "k1",
        "type": "string",
        "description": "Check field K1",
        "enum": ["k1_v1", "k1_v2", "k1_v3"]
    }
}
```
