---
title: "volume"
---

## 属性

| 名称           | 类型     | 说明                                             |
| :------------- | :------- | :----------------------------------------------- |
| id             | string   | volume id                                        |
| name           | string   | volume name                                      |
| size           | integer  | 卷大小（G）                                      |
| status         | string   | volume 状态                                      |
| backend        | string   | 后端存储                                         |
| description    | string   | 描述信息                                         |
| hostname       | string   | 主机名                                           |
| project_id     | string   | 项目id                                           |
| user_id        | string   | 用户id                                           |
| bootable       | boolean  | 是否为可启动卷                                   |
| created_at     | datetime | 创建时间                                         |
| updated_at     | datetime | 更新时间                                         |
| image_id       | string   | image id                                         |
| volume_id      | string   | volume id                                        |
| snapshot_id    | string   | snapshot id (由快照创建出的卷与快照是父子关系)   |
| flatten        | boolean  | 标识在使用快照创建卷时是否斩断卷与快照的依赖关系 |
| auto_delete    | boolean  | 标识是否在删除虚拟机时删除该卷                   |
| attached_to    | string   | 标识该卷挂载到的虚拟机的 id                      |
| attached_index | integer  | 标识卷的挂载的先后顺序                           |

`auto_delete`: 默认值为 False, 只有当平台创建虚拟机时, 该虚拟机的系统盘(镜像卷)的
 auto_delete 值为创建虚拟机时传入的 `del_root_disk_on_termination` 的值

`attached_index`: index 为 0 的一般为系统盘, 数据盘依次递增, 如创建了带有 2 个数据盘的
虚拟机挂载顺序为 0(系统盘) 1(数据盘1) 2(数据盘2)

`flatten`: 和 snapshot_id 捆绑使用，默认值为 False

## 创建

POST http://127.0.0.1:9906/v1/volume

### 参数

| 参数名      | 必选         | 类型    | 说明                                     |
| :---------- | :----------- | :------ | ---------------------------------------- |
| name        | 否           | string  | 卷名称                                   |
| size        | 是(仅数据卷) | integer | 卷大小(G)                                |
| backend     | 否           | string  | 后端存储                                 |
| description | 否           | string  | 卷的描述信息                             |
| project_id  | 否           | string  | 项目 id                                  |
| user_id     | 否           | string  | 用户 id                                  |
| image_id    | 否           | string  | image id                                 |
| volume_id   | 否           | string  | volume id                                |
| snapshot_id | 否           | string  | snapshot id                              |
| flatten     | 否           | boolean | 是否解除与快照的依赖关系 (默认值为False) |

`size`: 如果是数据卷则必选, 如果是通过 (image_id, volume_id, snapshot_id) 创建卷并未传 size 的话,
则后台自动设置 size 为相应资源(镜像、快照、卷)的大小, 如传入 size 则必须大于等于相应资源的大小.

`backend`: 如不传, 默认为 `[api_settings]enabled_volume_backends` 所配置的唯一值(只有一个 backend),
如果 `enabled_volume_backends` 存在多个则必须选择一个 backend 作为 volume 的后端

### 示例

请求命令：

```console
curl -L -X POST http://127.0.0.1:9906/v1/volume -H 'Content-Type: application/json' -d
```

#### 创建新卷

请求参数:

 ```json
{
    "volume": {
        "name": "volume1",
        "size": 5
    }
}

```

返回参数:

```json
{
    "volume": {
        "id": "6155d7e6-1890-4b04-80c8-4d9e846948ff",
        "name": "volume1",
        "size": 5,
        "status": "prepare_create",
        "backend": "rbd1",
        "description": "",
        "hostname": "pxe-centos8",
        "user_id": null,
        "project_id": null,
        "bootable":  true,
        "created_at": "2022-02-11T08:53:42",
        "updated_at": null,
        "image_id": null,
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null,
        "snapshot_id": null,
        "volume_id": null
    }
}

```

#### 使用镜像克隆新卷

请求参数:

 ```json
{
    "volume": {
        "name": "clone_volume_from_image_1",
        "size": 10,
        "image_id": "3781bd1d-db9c-4732-b770-a567a7233bea"
    }
}

```

返回参数:

```json
{
    "volume": {
        "id": "ed1fa4c5-ea99-4001-8889-32b93c6d516f",
        "name": "clone_volume_from_image_1",
        "size": 10,
        "status": "prepare_create",
        "backend": "rbd1",
        "description": "",
        "hostname": "pxe-centos8",
        "user_id": null,
        "project_id": null,
        "bootable": true,
        "created_at": "2022-03-23T09:33:59",
        "updated_at": null,
        "image_id": "3781bd1d-db9c-4732-b770-a567a7233bea",
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null,
        "snapshot_id": null,
        "volume_id": null
    }
}

```

#### 使用卷克隆新卷

请求参数:

 ```json
{
    "volume": {
        "name": "clone_volume_from_vol_1",
        "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf"
    }
}

```

返回参数

```json
{
    "volume": {
        "id": "f1076a12-7a5c-4088-8828-9e2da581bb1e",
        "name": "clone_volume_from_vol_1",
        "size": 10,
        "status": "prepare_create",
        "backend": "rbd1",
        "description": "",
        "hostname": "pxe-centos8",
        "user_id": null,
        "project_id": null,
        "bootable": false,
        "created_at": "2022-03-18T09:18:55",
        "updated_at": null,
        "image_id": null,
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null,
        "snapshot_id": null,
        "volume_id": "f99ad102-1aa9-484b-b9e4-c14de096dbbf"
    }
}

```

#### 使用快照克隆新卷

请求参数:

 ```json
{
    "volume": {
        "name": "clone_volume_from_snap_1",
        "size": 10,
        "snapshot_id": "ffb9708d-7195-42dc-832d-6f33b656d437",
        "flatten": "true"
    }
}

```

返回参数:

```json
{
    "volume": {
        "id": "d97a8f36-94b8-4766-aa27-35125965460b",
        "name": "clone_volume_from_snap_1",
        "size": 10,
        "status": "prepare_create",
        "backend": "rbd1",
        "description": "",
        "hostname": "pxe-centos8",
        "user_id": null,
        "project_id": null,
        "bootable": false,
        "created_at": "2022-03-18T09:18:55",
        "updated_at": null,
        "image_id": null,
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null,
        "snapshot_id": "fd8736cb-ee97-4894-811b-3c952d161212",
        "volume_id": null
    }
}

```

## 更新

PUT http://127.0.0.1:9906/v1/volume/{volume_id}

### 参数

| 参数名      | 类型   | 说明        |
| :---------- | :----- | :---------- |
| name        | string | Volume 名称 |
| description | string | Volume 描述 |

### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/volume/143edf33-1abc-49ca-978c-d2301d7e6801 -H 'Content-Type: application/json' --data-raw
```

请求参数：

```json
{
    "volume": {
        "name": "ggg1",
        "description": "ggg2"
    }
}
```

返回参数：

```json
{
    "volume": {
        "id": "143edf33-1abc-49ca-978c-d2301d7e6801",
        "name": "ggg1",
        "size": 5,
        "status": "available",
        "backend": "lvm1",
        "description": "ggg2",
        "hostname": "wxj-pc",
        "user_id": "13db1153-f6a9-47c9-b471-c58d3a74b834",
        "project_id": "860da371-5069-4230-adae-8dc83e93f715",
        "bootable": false,
        "created_at": "2022-02-10T02:30:12",
        "updated_at": "2022-02-16T09:54:26",
        "image_id": null,
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null,
        "snapshot_id": "fd8736cb-ee97-4894-811b-3c952d161212",
        "volume_id": null
    }
}
```

## 获取卷列表信息

GET http://127.0.0.1:9906/v1/volume

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/volume
```

返回信息:

```json
{
    "volumes": [
        {
            "id": "90f4d933-a4f6-4d87-b185-89a01228e5cd",
            "name": "",
            "size": 1,
            "status": "available",
            "backend": "rbd1",
            "description": "",
            "hostname": "lplearn",
            "user_id": null,
            "project_id": null,
            "bootable": false,
            "created_at": "2022-03-04T07:04:47",
            "updated_at": "2022-03-04T07:05:01",
            "image_id": null,
            "auto_delete": false,
            "attached_to": null,
            "attached_index": null,
            "snapshot_id": null,
            "volume_id": null
        },
        {
            "id": "cf5ce460-c349-4542-95fa-01f38336e94d",
            "name": "",
            "size": 10,
            "status": "error",
            "backend": "rbd1",
            "description": "",
            "hostname": "lplearn",
            "user_id": null,
            "project_id": null,
            "bootable": true,
            "created_at": "2022-03-04T07:21:14",
            "updated_at": "2022-03-04T07:21:14",
            "image_id": "3107e570-020f-433c-9b3f-8331155ca042",
            "auto_delete": false,
            "attached_to": null,
            "attached_index": null,
            "snapshot_id": "fd8736cb-ee97-4894-811b-3c952d161212",
            "volume_id": null
        }
    ],
    "volume_links": []
}
```

## 获取单个卷信息

GET http://127.0.0.1:9906/v1/volume/{volume_id}

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/volume/6155d7e6-1890-4b04-80c8-4d9e846948ff
```

返回信息：

```json
{
    "volume": {
        "id": "6155d7e6-1890-4b04-80c8-4d9e846948ff",
        "name": "volume1",
        "size": 5,
        "status": "available",
        "backend": "rbd1",
        "description": "",
        "hostname": "hostname",
        "user_id": null,
        "project_id": null,
        "bootable":  true,
        "created_at": "2022-02-11T08:53:42",
        "updated_at": "2022-02-11T08:53:42",
        "image_id": null,
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null,
        "snapshot_id": null,
        "volume_id": null
    }
}
```

## 删除

DELETE http://127.0.0.1:9906/v1/volume/{volume_id}

### 示例

请求命令：

```console
curl http://127.0.0.1:9906/v1/volume/9f000577-b1ea-4b3e-84f9-89ee1ba09e22 -X delete
```

删除成功无返回值


## 删除(级联)

DELETE http://127.0.0.1:9906/v1/volume/{volume_id}?cascade=true

级联删除包括卸载卷, 删除快照(当删除快照时该快照也就从快照组中移除了), 最后再删除卷

### 示例

请求命令：

```console
curl http://127.0.0.1:9906/v1/volume/9f000577-b1ea-4b3e-84f9-89ee1ba09e22?cascade=true -X delete
```

删除成功无返回值


## Volume action 操作

### 参数

| 参数名        | 必选 | 类型   | 说明        |
| :------------ | :--- | :----- | ----------- |
| name          | 是   | string | action name |
| extended_attr | 否   | dict   | action 参数 |

### 回滚

POST http://127.0.0.1:9906/v1/volume/{volume_id}/action

#### 示例

请求命令:

```bash
curl -X POST HTTP://127.0.0.1:9906/v1/volume/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' -d
```

请求参数：

```json
{
    "action":{
        "name": "revert"
        "extended_attr": {
            "snapshot_id": "76f5e45e-cf8e-45a1-9f53-3c2a412743a2"
        }
    }
}
```

正常响应码: 201


### 调整卷大小

POST http://127.0.0.1:9906/v1/volume/{volume_id}/action

extended_attr 中要传入卷大小

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/volume/a7858cff-9a5c-4a85-9b75-9a2e50142dac/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "resize",
        "extended_attr": {
            "size": 10
        }
    }
}'
```

请求参数:

```json
{
    "action": {
        "name": "resize",
        "extended_attr": {
            "size": 10
        }
    }
}
```
