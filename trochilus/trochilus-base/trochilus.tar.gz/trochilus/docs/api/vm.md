---
title: "VM"
---

## 属性

| 名称                         | 类型     | 说明                        |
| :--------------------------- | :------- | :-------------------------- |
| id                           | string   | VM id                       |
| name                         | string   | VM name                     |
| project_id                   | string   | 项目 id                     |
| user_id                      | string   | 用户 id                     |
| agent_id                     | string   | agent id                    |
| description                  | string   | 描述信息                    |
| status                       | string   | VM 状态                     |
| created_at                   | datetime | 创建时间                    |
| updated_at                   | datetime | 更新时间                    |
| image_id                     | string   | 镜像 id                     |
| vcpu                         | integer  | VM CPU 数量                 |
| vnc_address                  | string   | VM vnc 地址（IP +端口号）   |
| spice_address                | string   | VM spice 地址（IP +端口号） |
| memory_mb                    | integer  | VM 内存大小(MB)             |
| root_disk_gb                 | integer  | VM 系统盘大小(GB)           |
| metadata                     | dict     | 元数据                      |
| tags                         | list     | 标签                        |
| volumes                      | list     | 卷列表(包括系统卷和数据卷)  |
| nics                         | list     | 网卡列表                    |
| del_root_disk_on_termination | boolean  | 虚拟机删除时是否删除系统盘  |
| hostname                     | string   | 当前虚拟机所在节点的主机名  |


`del_root_disk_on_termination`: 是否在删除虚拟机时删除该虚拟机系统卷(该卷指的是创建 VM 传
入 image_id 时自动创建出来的镜像卷(系统), 并不是数据卷)(默认为 True)

volumes 列表的返回值与 [Volume API文档](/api/volume)  中的属性一致
nics 列表的返回值与 [Nic API文档](/api/nic)  中的属性一致

## 创建 VM

POST http://127.0.0.1:9906/v1/vm

### 参数

| 名称                         | 必选 | 类型    | 说明                           |
| :--------------------------- | :--- | :------ | :----------------------------- |
| name                         | 否   | string  | VM name                        |
| project_id                   | 否   | string  | 项目 id                        |
| user_id                      | 否   | string  | 用户 id                        |
| description                  | 否   | string  | 描述信息                       |
| image_id                     | 否   | string  | 镜像 id                        |
| vcpu                         | 是   | integer | VM CPU 数量                    |
| memory_mb                    | 是   | integer | VM 内存大小(MB)                |
| root_disk_gb                 | 否   | integer | VM 系统盘大小(GB)              |
| metadata                     | 否   | dict    | 元数据                         |
| tags                         | 否   | list    | 标签                           |
| volumes                      | 否   | list    | 卷列表(包括系统卷和数据卷)     |
| nics                         | 否   | list    | 网卡列表(包括要创建和已存在的) |
| del_root_disk_on_termination | 否   | boolean | 删除时是否删除系统盘           |

#### metadata 参数

- boot_type: VDI VM 启动类型, 默认为 'bios'
  - 'uefi': UEFI 模式启动,
  - 'bios': BIOS 模式启动

### volumes 列表元素字段说明

| 名称        | 必选              | 类型    | 说明        |
| :---------- | :---------------- | :------ | :---------- |
| id          | 是(size 不存在时) | string  | volume id   |
| name        | 否                | string  | volume name |
| size        | 是(id 不存在时)   | integer | 卷大小（G） |
| backend     | 否                | string  | 后端存储    |
| description | 否                | string  | 描述信息    |
| image_id    | 是(size 不存在时) | string  | image id    |
| volume_id   | 是(size 不存在时) | string  | volume id   |
| snapshot_id | 是(size 不存在时) | string  | snapshot id |

对于平台需求来说:

1. 通过镜像创建 VM 如果不需要额外的数据卷则不需要传 volumes 列表
2. 克隆 VM 需传入的 volumes 列表示例如下:
    ```json
    "volumes":[
        {
            "name": "用于说明: 被克隆 VM 的系统卷 ID",
            "volume_id": "c0900c93-e7a7-4289-8480-51bff23f2a59"
        },
        {
            "name": "用于说明: 被克隆 VM 的第一个数据卷 ID",
            "volume_id": "c0900c93-e7a7-4289-8480-51bff23f2a58"
        },
        {
            "name": "用于说明: 被克隆 VM 的第二个数据卷 ID",
            "volume_id": "c0900c93-e7a7-4289-8480-51bff23f2a57"
        }
    ]
    ```
3. 通过 模板机/快照 创建 VM 需传入的 volumes 列表示例如下:
    ```json
    "volumes":[
        {
            "name": "用于说明: 模板机/快照 的系统卷的快照 ID",
            "snapshot_id": "c0900c93-e7a7-4289-8480-51bff23f2a56"
        },
        {
            "name": "用于说明: 第一个数据卷",
            "size": 10
        },
        {
            "name": "用于说明: 第二个数据卷",
            "size": 10
        }
    ]
    ```

可启动卷: volume 参数中 bootable 为 1 的卷是可启动卷, 基于该卷的快照所创建的卷也是可启动的.

接口本身来说如果没有传入 image_id 那么 volumes 列表中第一个卷作为该 VM 的系统卷并且它必须是一个可启动卷

### nics 列表元素字段说明

| 名称       | 必选 | 类型   | 说明                      |
| :--------- | :--- | :----- | :------------------------ |
| nic_id     | 否   | string | nic id                    |
| subnet_id  | 否   | string | subnet id                 |
| ip_address | 否   | string | 创建网卡时，指定网卡的 ip |

已存在的网卡传 nic_id ；要创建的网卡传 subnet_id， ip_address 用于指定要创建网卡的 ip，可传可不传。


### 示例

创建虚拟机:
1. 包括1个系统盘(image_id)，和3个数据盘，第一个数据盘是镜像卷, 第二个是空白卷, 第三个是已经存
在的卷
2. 如果 volume 参数同时存在 id 和 size 以 id 为主。

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm -H 'Content-Type: application/json' -d
```

请求参数：

 ```json
{
    "vm":{
        "vcpu": 1,
        "memory_mb": 100,
        "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
        "root_disk_gb": 1,
        "volumes":[
            {
                "backend": "rbd1",
                "size": "1",
                "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59"
            },
            {
                "name": "v2",
                "backend": "rbd1",
                "size": 2
            },
            {
                "id": "22e29d52-3962-4478-beb0-310144b514a0"
            }
        ],
        "metadata":{
            "key1": 1,
            "key2": true,
            "key3": "ok"
        },
        "tags":[
            "1",
            "2",
            "aaaa"
        ],
        "nics": [
           {
               "subnet_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14"
           },
           {
               "nic_id": "7644e13-35a1-4aa7-8b15-fd0e406bab17"
            }
         ]
    }
}

```

返回参数：

```json
{
    "vm": {
        "id": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
        "name": "",
        "description": "",
        "status": "prepare_create",
        "created_at": "2022-03-07T09:07:16",
        "updated_at": null,
        "user_id": null,
        "project_id": null,
        "agent_id": "a1e1804a-aa3e-409f-b886-6e60eb94eb41",
        "vcpu": 1,
        "vnc_address": "127.0.0.1:5913",
        "spice_address": "127.0.0.1:5914",
        "memory_mb": 100,
        "root_disk_gb": 1,
        "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
        "metadata": {
            "key1": 1,
            "key2": true,
            "key3": "ok"
        },
        "tags": [
            "1",
            "2",
            "aaaa"
        ],
        "volumes": [
            {
                "id": "56059180-fbba-40bb-89eb-8142435a1466",
                "name": "",
                "size": 1,
                "status": "prepare_create",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": true,
                "created_at": "2022-03-07T09:07:16",
                "updated_at": null,
                "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                "auto_delete": true,
                "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                "attached_index": 0
            },
            {
                "id": "3552f08c-e8ad-4b4e-b697-3d05a9100422",
                "name": "v2",
                "size": 2,
                "status": "prepare_create",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": false,
                "created_at": "2022-03-07T09:07:16",
                "updated_at": null,
                "image_id": null,
                "auto_delete": false,
                "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                "attached_index": 2
            },
            {
                "id": "b85b14fe-270f-458d-a09d-d4ffb75b1de3",
                "name": "",
                "size": 1,
                "status": "prepare_create",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": true,
                "created_at": "2022-03-07T09:07:16",
                "updated_at": null,
                "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                "auto_delete": false,
                "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                "attached_index": 1
            },
            {
                "id": "22e29d52-3962-4478-beb0-310144b514a0",
                "name": "volume22",
                "size": 1,
                "status": "available",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": true,
                "created_at": "2022-03-07T09:06:45",
                "updated_at": "2022-03-07T09:06:45",
                "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                "auto_delete": false,
                "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                "attached_index": 3
            }
        ],
        "hostname": "agent-2",
        "nics": [
            {
                "id": "a6ddeafc-3eed-4e97-95ef-81ae2580f619",
                "name": "",
                "description": "",
                "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                "mac_address": "fa:16:3e:a1:97:fc",
                "ip_addresses": [
                      {
                           "subnet_id": "b3795692-6735-4b44-b314-9f8cb19692f0",
                           "ip_address": "172.168.100.137"
                       }
                ],
                "hostname": "agent-2",
                "owner_id": "a3284bc6-0e37-4fce-af32-b24d2d8885a9",
                "owner_type": "vdi_vm",
                "auto_delete": true,
                "status": "up",
                "project_id": null,
                "user_id": null,
                "created_at": "2022-03-11T01:40:53",
                "updated_at": "2022-03-11T02:21:07"
           },
           {
                "id": "7644e13-35a1-4aa7-8b15-fd0e406bab17",
                "name": "",
                "description": "",
                "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                "mac_address": "fa:16:3e:a1:97:fc",
                "ip_addresses": [
                       {
                           "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6",
                           "ip_address": "111.222.100.247"
                       }
                ],
                "hostname": "agent-2",
                "owner_id": "a3284bc6-0e37-4fce-af32-b24d2d8885a9",
                "owner_type": "vdi_vm",
                "auto_delete": false,
                "status": "up",
                "project_id": null,
                "user_id": null,
                "created_at": "2022-03-11T01:40:53",
                "updated_at": "2022-03-11T02:21:07"
           }
        ]
    }
}
```

## 获取 VM 列表

GET http://127.0.0.1:9906/v1/vm

### 示例

请求命令：

```console
curl -L -X GET HTTP://127.0.0.1:9906/v1/vm?limit=2&sort=created_at:desc
```

返回信息：

```json
{
    "vms": [
        {
            "id": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
            "name": "",
            "description": "",
            "status": "active",
            "created_at": "2022-03-07T09:09:25",
            "updated_at": "2022-03-07T09:09:26",
            "user_id": null,
            "project_id": null,
            "agent_id": "a1e1804a-aa3e-409f-b886-6e60eb94eb41",
            "vcpu": 1,
            "vnc_address": "127.0.0.1:5913",
            "spice_address": "127.0.0.1:5914",
            "memory_mb": 100,
            "root_disk_gb": 10,
            "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
            "metadata": {
                "key1": 1,
                "key2": true,
                "key3": "ok"
            },
            "tags": [
                "1",
                "2",
                "aaaa"
            ],
            "volumes": [
                {
                    "id": "248e3cf0-e27d-42e1-a126-d66be000cacc",
                    "name": "",
                    "size": 1,
                    "status": "in-use",
                    "backend": "rbd1",
                    "description": "",
                    "hostname": "lplearn",
                    "user_id": null,
                    "project_id": null,
                    "bootable": false,
                    "created_at": "2022-03-07T09:09:25",
                    "updated_at": "2022-03-07T09:09:25",
                    "image_id": null,
                    "auto_delete": false,
                    "attached_to": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                    "attached_index": 1
                },
                {
                    "id": "870d6371-e581-4f1b-9dba-48892b8c7799",
                    "name": "",
                    "size": 10,
                    "status": "in-use",
                    "backend": "rbd1",
                    "description": "",
                    "hostname": "lplearn",
                    "user_id": null,
                    "project_id": null,
                    "bootable": true,
                    "created_at": "2022-03-07T09:09:25",
                    "updated_at": "2022-03-07T09:09:25",
                    "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                    "auto_delete": true,
                    "attached_to": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                    "attached_index": 0
                }
            ],
            "nics": [
                {
                    "id": "a6ddeafc-3eed-4e97-95ef-81ae2580f619",
                    "name": "",
                    "description": "",
                    "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                    "mac_address": "fa:16:3e:a1:97:fc",
                    "ip_addresses": [
                         {
                              "subnet_id": "b3795692-6735-4b44-b314-9f8cb19692f0",
                              "ip_address": "172.168.100.137"
                         }
                    ],
                    "hostname": "dev",
                    "owner_id": "a3284bc6-0e37-4fce-af32-b24d2d8885a9",
                    "owner_type": "vdi_vm",
                    "auto_delete": true,
                    "status": "up",
                    "project_id": null,
                    "user_id": null,
                    "created_at": "2022-03-11T01:40:53",
                    "updated_at": "2022-03-11T02:21:07"
                },
                {
                    "id": "7644e13-35a1-4aa7-8b15-fd0e406bab17",
                    "name": "",
                    "description": "",
                    "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                    "mac_address": "fa:16:3e:a1:97:fc",
                    "ip_addresses": [
                         {
                              "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6",
                              "ip_address": "111.222.100.247"
                         }
                    ],
                    "hostname": "dev",
                    "owner_id": "a3284bc6-0e37-4fce-af32-b24d2d8885a9",
                    "owner_type": "vdi_vm",
                    "auto_delete": false,
                    "status": "up",
                    "project_id": null,
                    "user_id": null,
                    "created_at": "2022-03-11T01:40:53",
                    "updated_at": "2022-03-11T02:21:07"
                }
            ]
        },
        {
            "id": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
            "name": "",
            "description": "",
            "status": "active",
            "created_at": "2022-03-07T09:07:16",
            "updated_at": "2022-03-07T09:07:20",
            "user_id": null,
            "project_id": null,
            "agent_id": "a1e1804a-aa3e-409f-b886-6e60eb94eb41",
            "vcpu": 1,
            "vnc_address": "127.0.0.1:5915",
            "spice_address": "127.0.0.1:5916",
            "memory_mb": 100,
            "root_disk_gb": 1,
            "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
            "metadata": {
                "key1": 1,
                "key2": true,
                "key3": "ok"
            },
            "tags": [
                "1",
                "2",
                "aaaa"
            ],
            "volumes": [
                {
                    "id": "56059180-fbba-40bb-89eb-8142435a1466",
                    "name": "",
                    "size": 1,
                    "status": "in-use",
                    "backend": "rbd1",
                    "description": "",
                    "hostname": "lplearn",
                    "user_id": null,
                    "project_id": null,
                    "bootable": true,
                    "created_at": "2022-03-07T09:07:16",
                    "updated_at": "2022-03-07T09:07:16",
                    "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                    "auto_delete": true,
                    "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                    "attached_index": 0
                },
                {
                    "id": "3552f08c-e8ad-4b4e-b697-3d05a9100422",
                    "name": "v2",
                    "size": 2,
                    "status": "in-use",
                    "backend": "rbd1",
                    "description": "",
                    "hostname": "lplearn",
                    "user_id": null,
                    "project_id": null,
                    "bootable": false,
                    "created_at": "2022-03-07T09:07:16",
                    "updated_at": "2022-03-07T09:07:16",
                    "image_id": null,
                    "auto_delete": false,
                    "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                    "attached_index": 2
                },
                {
                    "id": "b85b14fe-270f-458d-a09d-d4ffb75b1de3",
                    "name": "",
                    "size": 1,
                    "status": "in-use",
                    "backend": "rbd1",
                    "description": "",
                    "hostname": "lplearn",
                    "user_id": null,
                    "project_id": null,
                    "bootable": true,
                    "created_at": "2022-03-07T09:07:16",
                    "updated_at": "2022-03-07T09:07:17",
                    "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                    "auto_delete": false,
                    "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                    "attached_index": 1
                },
                {
                    "id": "22e29d52-3962-4478-beb0-310144b514a0",
                    "name": "volume22",
                    "size": 1,
                    "status": "in-use",
                    "backend": "rbd1",
                    "description": "",
                    "hostname": "lplearn",
                    "user_id": null,
                    "project_id": null,
                    "bootable": true,
                    "created_at": "2022-03-07T09:06:45",
                    "updated_at": "2022-03-07T09:07:17",
                    "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                    "auto_delete": false,
                    "attached_to": "3f16f102-d516-42c4-86fb-b4b56804e6ec",
                    "attached_index": 3
                }
            ],
        "hostname": "agent-2"
        }
    ],
    "vm_links": [
        {
            "href": "http://192.168.189.2:9906/v1/vm?limit=2&sort=created_at:desc&marker=3f16f102-d516-42c4-86fb-b4b56804e6ec",
            "rel": "next"
        }
    ]
}
```

## 获取单个 VM 信息

GET http://127.0.0.1:9906/v1/vm/{vm_id}

### 示例

请求命令：

```console
curl -L -X GET HTTP://127.0.0.1:9906/v1/vm/a9fc0f33-6852-41b9-9e75-2a10460e08fc
```

返回信息：

```json
{
    "vm": {
        "id": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
        "name": "",
        "description": "",
        "status": "active",
        "created_at": "2022-03-07T09:09:25",
        "updated_at": "2022-03-07T09:09:26",
        "user_id": null,
        "project_id": null,
        "agent_id": "a1e1804a-aa3e-409f-b886-6e60eb94eb41",
        "vcpu": 1,
        "vnc_address": "127.0.0.1:5913",
        "spice_address": "127.0.0.1:5914",
        "memory_mb": 100,
        "root_disk_gb": 10,
        "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
        "metadata": {
            "key1": 1,
            "key2": true,
            "key3": "ok"
        },
        "tags": [
            "1",
            "2",
            "aaaa"
        ],
        "volumes": [
            {
                "id": "248e3cf0-e27d-42e1-a126-d66be000cacc",
                "name": "",
                "size": 1,
                "status": "in-use",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": false,
                "created_at": "2022-03-07T09:09:25",
                "updated_at": "2022-03-07T09:09:25",
                "image_id": null,
                "auto_delete": false,
                "attached_to": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                "attached_index": 1
            },
            {
                "id": "870d6371-e581-4f1b-9dba-48892b8c7799",
                "name": "",
                "size": 10,
                "status": "in-use",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": true,
                "created_at": "2022-03-07T09:09:25",
                "updated_at": "2022-03-07T09:09:25",
                "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                "auto_delete": true,
                "attached_to": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                "attached_index": 0
            }
        ],
        "hostname": "agent-2",
        "nics": [
            {
                "id": "a6ddeafc-3eed-4e97-95ef-81ae2580f619",
                "name": "",
                "description": "",
                "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                "mac_address": "fa:16:3e:a1:97:fc",
                "ip_addresses": [
                     {
                         "subnet_id": "b3795692-6735-4b44-b314-9f8cb19692f0",
                         "ip_address": "172.168.100.137"
                     }
                ],
                "hostname": "agent-2",
                "owner_id": "a3284bc6-0e37-4fce-af32-b24d2d8885a9",
                "owner_type": "vdi_vm",
                "auto_delete": true,
                "status": "up",
                "project_id": null,
                "user_id": null,
                "created_at": "2022-03-11T01:40:53",
                "updated_at": "2022-03-11T02:21:07"
            },
            {
                "id": "7644e13-35a1-4aa7-8b15-fd0e406bab17",
                "name": "",
                "description": "",
                "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                "mac_address": "fa:16:3e:a1:97:fc",
                "ip_addresses": [
                      {
                           "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6",
                           "ip_address": "111.222.100.247"
                      }
                ],
                "hostname": "agent-2",
                "owner_id": "a3284bc6-0e37-4fce-af32-b24d2d8885a9",
                "owner_type": "vdi_vm",
                "auto_delete": false,
                "status": "up",
                "project_id": null,
                "user_id": null,
                "created_at": "2022-03-11T01:40:53",
                "updated_at": "2022-03-11T02:21:07"
            }
        ]
    }
}
```

## 更新

PUT http://127.0.0.1:9906/v1/vm/{vm_id}

### 参数

| 参数名      | 必选 | 类型   | 说明     |
| :---------- | :--- | :----- | -------- |
| name        | 否   | string | vm name  |
| description | 否   | string | 描述信息 |
| metadata    | 否   | dict   | 元数据   |
| tags        | 否   | list   | 标签     |

### 示例

请求命令:

```bash
curl -L -X PUT HTTP://127.0.0.1:9906/v1/vm/9bfc9ca8-6396-43dc-9ded-0a2656fa12f5 -H 'Content-Type: application/json' --data-raw '{
    "vm": {
        "name": "test2",
        "description": "test_image2",
        "metadata": {
            "key1": "value1"
        },
        "tags": ["11", "22", "33"]
    }
}'
```

请求参数：

```json
{
    "vm": {
        "name": "test2",
        "description": "test_image2",
        "metadata": {
            "key1": "value1"
        },
        "tags": ["11", "22", "33"]
    }
}
```

返回信息：

```json
{
    "vm": {
        "id": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
        "name": "test2",
        "description": "test_image2",
        "status": "active",
        "created_at": "2022-03-07T09:09:25",
        "updated_at": "2022-03-07T09:11:59",
        "user_id": null,
        "project_id": null,
        "agent_id": "a1e1804a-aa3e-409f-b886-6e60eb94eb41",
        "vcpu": 1,
        "vnc_address": "127.0.0.1:5913",
        "spice_address": "127.0.0.1:5914",
        "memory_mb": 100,
        "root_disk_gb": 10,
        "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
        "metadata": {
            "key1": "value1"
        },
        "tags": [
            "11",
            "22",
            "33"
        ],
        "volumes": [
            {
                "id": "248e3cf0-e27d-42e1-a126-d66be000cacc",
                "name": "",
                "size": 1,
                "status": "in-use",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": false,
                "created_at": "2022-03-07T09:09:25",
                "updated_at": "2022-03-07T09:09:25",
                "image_id": null,
                "auto_delete": false,
                "attached_to": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                "attached_index": 1
            },
            {
                "id": "870d6371-e581-4f1b-9dba-48892b8c7799",
                "name": "",
                "size": 10,
                "status": "in-use",
                "backend": "rbd1",
                "description": "",
                "hostname": "lplearn",
                "user_id": null,
                "project_id": null,
                "bootable": true,
                "created_at": "2022-03-07T09:09:25",
                "updated_at": "2022-03-07T09:09:25",
                "image_id": "c0900c93-e7a7-4289-8480-51bff23f2a59",
                "auto_delete": true,
                "attached_to": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                "attached_index": 0
            }
        ],
        "nics": [
            {
                "id": "a6ddeafc-3eed-4e97-95ef-81ae2580f619",
                "name": "",
                "description": "",
                "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                "mac_address": "fa:16:3e:a1:97:fc",
                "ip_addresses": [
                      {
                           "subnet_id": "b3795692-6735-4b44-b314-9f8cb19692f0",
                           "ip_address": "172.168.100.137"
                       }
                ],
                "hostname": "agent-2",
                "owner_id": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                "owner_type": "vdi_vm",
                "auto_delete": true,
                "status": "up",
                "project_id": null,
                "user_id": null,
                "created_at": "2022-03-11T01:40:53",
                "updated_at": "2022-03-11T02:21:07"
           },
           {
                "id": "7644e13-35a1-4aa7-8b15-fd0e406bab17",
                "name": "",
                "description": "",
                "vpc_id": "d5644e13-35a1-4aa7-8b15-fd0e406bab14",
                "mac_address": "fa:16:3e:a1:97:fc",
                "ip_addresses": [
                       {
                           "subnet_id": "b681a0ae-8586-483a-b117-9377aff49db6",
                           "ip_address": "111.222.100.247"
                       }
                ],
                "hostname": "agent-2",
                "owner_id": "a9fc0f33-6852-41b9-9e75-2a10460e08fc",
                "owner_type": "vdi_vm",
                "auto_delete": false,
                "status": "up",
                "project_id": null,
                "user_id": null,
                "created_at": "2022-03-11T01:40:53",
                "updated_at": "2022-03-11T02:21:07"
           }
        ],
        "hostname": "agent-2"
    }
}
```

## 删除

DELETE  http://127.0.0.1:9906/v1/vm/{vm_id}

### 示例

请求命令：

```console
curl -L -X DELETE HTTP://127.0.0.1:9906/v1/vm/a9fc0f33-6852-41b9-9e75-2a10460e08fc
```

删除成功无返回值

## 删除(级联)

级联删除虚拟机及其相关的资源(系统卷、网卡、快照、快照组), 不包括数据卷(保留数据卷非快照组快照)

DELETE  http://127.0.0.1:9906/v1/image/{vm_id}?cascade=true

### 示例

请求命令：

```console
curl -L -X DELETE HTTP://127.0.0.1:9906/v1/vm/a9fc0f33-6852-41b9-9e75-2a10460e08fc?cascade=true
```

删除成功无返回值

## 删除(级联+删数据卷)

级联删除虚拟机及其相关的资源(系统卷、数据卷、网卡、快照、快照组)

DELETE  http://127.0.0.1:9906/v1/image/{vm_id}?cascade=true&datadisk=true

### 示例

请求命令：

```console
curl -L -X DELETE HTTP://127.0.0.1:9906/v1/vm/a9fc0f33-6852-41b9-9e75-2a10460e08fc?cascade=true&datadisk=true
```

删除成功无返回值

## VM action 操作

### 参数

| 参数名        | 必选 | 类型   | 说明        |
| :------------ | :--- | :----- | ----------- |
| name          | 是   | string | action name |
| extended_attr | 否   | dict   | action 参数 |

### 开机

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"start"
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"start"
    }
}
```

正常响应码: 201

### 关机

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"stop"
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"stop"
    }
}
```

正常响应码: 201

### 软重启

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

如不传 extended_attr 默认就是软重启

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"reboot",
        "extended_attr": {
            "type": "soft"
        }
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"reboot",
        "extended_attr": {
            "type": "soft"
        }
    }
}
```

正常响应码: 201

### 硬重启

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"reboot",
        "extended_attr": {
            "type": "hard"
        }
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"reboot",
        "extended_attr": {
            "type": "hard"
        }
    }
}
```

正常响应码: 201

### 冷迁移

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

如不传 extended_attr 默认随机迁移到一个节点, 如同时传 host 和 agent_id 则 host 优先.

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"migrate",
        "extended_attr": {
            "host": "agent-2"
        }
    }
}'
```

请求参数(通过 host 指定主机)：

```json
{
    "action":{
        "name":"migrate",
        "extended_attr": {
            "host": "agent-2"
        }
    }
}
```

请求参数(通过 agent_id 指定主机)：

```json
{
    "action":{
        "name":"migrate",
        "extended_attr": {
            "agent_id": "57fd671e-5bd1-44ab-90ca-d9c7e6140cc0"
        }
    }
}
```

正常响应码: 201

### 调整 VM 配置大小

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

extended_attr 中至少传入 vcpu、 memory_mb、 root_disk_gb 中的一个

如传入了 root_disk_gb 那么该值必须大于当前 VM 的 root_disk_gb 大小
vm的root_disk_gb目前仅支持冷扩容，请关闭vm，确保vm状态为stopped后再执行此操作

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"resize",
        "extended_attr": {
            "vcpu": 2,
            "memory_mb": 200,
            "root_disk_gb": 11
        }
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"resize",
        "extended_attr": {
            "vcpu": 2,
            "memory_mb": 200,
            "root_disk_gb": 11
        }
    }
}
```

正常响应码: 201

### 重建

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

如果 extended_attr 传入 force:true 则强制删除所有系统盘快照, 默认为 false
不支持使用当前 VM 的系统盘快照进行重建, 这个功能可以通过快照回滚实现

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"rebuild",
        "extended_attr": {
            "image_id": "17ce43a1-79b7-4c65-a343-adf09c170bb4"
        }
    }
}'
```

请求参数(基于镜像的重建)：

```json
{
    "action":{
        "name":"rebuild",
        "extended_attr": {
            "image_id": "17ce43a1-79b7-4c65-a343-adf09c170bb4"
        }
    }
}
```

请求参数(基于快照的重建)：

```json
{
    "action":{
        "name":"rebuild",
        "extended_attr": {
            "snapshot_id": "86f716e4-c3b7-4237-8f87-7188ee9a4843",
            "force": true
        }
    }
}
```

正常响应码: 201


### 挂载网卡

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

extended_attr 中要传入网卡 id

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"attach_nic",
        "extended_attr": {
            "nic_id": "70f4c0ef-a635-4845-be48-527f046e8f22"
        }
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"attach_nic",
        "extended_attr": {
            "nic_id": "70f4c0ef-a635-4845-be48-527f046e8f22"
        }
    }
}
```

正常响应码: 201


### 卸载网卡

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

extended_attr 中要传入网卡 id

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"detach_nic",
        "extended_attr": {
            "nic_id": "70f4c0ef-a635-4845-be48-527f046e8f22"
        }
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"detach_nic",
        "extended_attr": {
            "nic_id": "70f4c0ef-a635-4845-be48-527f046e8f22"
        }
    }
}
```

正常响应码: 201


### 挂载卷

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

extended_attr 中要传入卷 id

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "attach_volume",
        "extended_attr": {
            "volume_id": "76f5e45e-cf8e-45a1-9f53-3c2a412743a2"
        }
    }
}'
```

请求参数:

```json
{
    "action": {
        "name": "attach_volume",
        "extended_attr": {
            "volume_id": "76f5e45e-cf8e-45a1-9f53-3c2a412743a2"
        }
    }
}
```

正常响应码：201


### 卸载卷

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

extended_attr 中要传入卷 id

#### 示例

请求命令:

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "detach_volume",
        "extended_attr": {
            "volume_id": "76f5e45e-cf8e-45a1-9f53-3c2a412743a2"
        }
    }
}'
```

请求参数:

```json
{
    "action": {
        "name": "detach_volume",
        "extended_attr": {
            "volume_id": "76f5e45e-cf8e-45a1-9f53-3c2a412743a2"
        }
    }
}
```

正常响应码：201


### 拍扁

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action


#### 示例

请求命令：

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action":{
        "name":"flatten"
    }
}'
```

请求参数：

```json
{
    "action":{
        "name":"flatten"
    }
}
```

正常响应码: 201

### 回滚(revert)

POST http://127.0.0.1:9906/v1/vm/{vm_id}/action

支持 VM 还原模式(业务):

1. 强制关机
2. 仅根据快照还原系统盘
3. 开机

#### 示例

请求命令：

```bash
curl -L -X POST HTTP://127.0.0.1:9906/v1/vm/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' --data-raw '{
    "action": {
        "name": "revert",
        "extended_attr": {
            "snapshot_id":"a7858cff-9a5c-4a85-9b75-9a2e50142dbc"
        }
    }
}'
```

请求参数：

```json
{
    "action": {
        "name": "revert",
        "extended_attr": {
            "snapshot_id":"a7858cff-9a5c-4a85-9b75-9a2e50142dbc"
        }
    }
}
```

正常响应码: 201
