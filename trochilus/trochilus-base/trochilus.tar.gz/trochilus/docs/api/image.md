---
title: "image"
---


## 属性

| 名称         | 类型     | 说明                                         |
| :----------- | :------- | :------------------------------------------- |
| id           | string   | image id                                     |
| name         | string   | image name                                   |
| checksum     | string   | 校验和                                       |
| description  | string   | 描述信息                                     |
| disk_format  | string   | 磁盘格式，qcow2、raw、vhd、vhdx、vmdk或者vdi |
| status       | string   | image 状态                                   |
| created_at   | datetime | 创建时间                                     |
| updated_at   | datetime | 更新时间                                     |
| location     | string   | 本地位置                                     |
| project_id   | string   | 项目id                                       |
| user_id      | string   | 用户id                                       |
| size         | integer  | 实际大小                                     |
| virtual_size | integer  | 虚拟大小                                     |
| metadata     | dict     | 元数据                                       |
| tags         | list     | 标签                                         |


## 创建

POST http://127.0.0.1:9906/v1/image


### 参数

| 参数名      | 必选 | 类型   | 说明                                               |
| :---------- | :--- | :----- | -------------------------------------------------- |
| name        | 否   | string | image name                                         |
| description | 否   | string | 描述                                               |
| disk_format | 是   | string | 磁盘格式，只能为qcow2、raw、vhd、vhdx、vmdk或者vdi |
| user_id     | 否   | string | 用户id                                             |
| project_id  | 否   | string | 项目id                                             |
| metadata    | 否   | dict   | 元数据                                             |
| tags        | 否   | list   | 标签                                               |


### 示例

请求命令：

```console
curl -L -X POST http://127.0.0.1:9906/v1/image -H 'Content-Type: application/json' --data-raw
```

请求参数：

 ```json
{
    "image": {
        "name": "test",
        "description": "test_image",
        "disk_format": "raw",
        "metadata": {
          "key1": "value1",
          "key2": "value2"
        },
         "tags": ["33", "11", "22"]
    }
}

```

返回参数：

```json
{
    "image": {
        "id": "8db4be59-b3a2-4bef-9913-e12cb06c1116",
        "name": "test",
        "checksum": null,
        "description": "test_image",
        "disk_format": "raw",
        "status": "queued",
        "created_at": "2022-02-11T04:55:15",
        "updated_at": null,
        "location": null,
        "user_id": null,
        "project_id": null,
        "size": null,
        "virtual_size": null,
        "metadata": {
            "key1": "value1",
            "key2": "value2"
        },
        "tags": ["33", "11", "22"]
    }
}
```


## 获取镜像列表信息

GET http://127.0.0.1:9906/v1/image

请求命令：

```console
curl -L -X GET http://127.0.0.1:9906/v1/image
```

返回信息：

```json
{
    "images": [{
        "id": "4b337d08-942b-47f4-89b9-4a28727d2f1d",
        "name": "test",
        "checksum": null,
        "description": "test_image",
        "disk_format": "raw",
        "status": "queued",
        "created_at": "2022-02-11T08:27:12",
        "updated_at": null,
        "location": null,
        "user_id": null,
        "project_id": null,
        "size": null,
        "virtual_size": null,
        "metadata": {
            "key1": "value1",
            "key2": "value2"
        },
        "tags": ["33", "11", "22"]
    }, {
        "id": "8db4be59-b3a2-4bef-9913-e12cb06c1116",
        "name": "test2",
        "checksum": "35cadb3cc5458a9c7a1fa4d08ba9e593",
        "description": "test_image2",
        "disk_format": "raw",
        "status": "active",
        "created_at": "2022-02-11T04:55:15",
        "updated_at": "2022-02-11T05:02:43",
        "location": "rbd://116d4de8-fd14-491f-811f-c1bdd8fac132/images/8db4be59-b3a2-4bef-9913-e12cb06c1116/snap",
        "user_id": null,
        "project_id": null,
        "size": 41126400,
        "virtual_size": 41126400,
        "metadata": {
            "key1": "value1"
        },
        "tags": ["11", "22", "33"]
    }]
}
```


## 获取单个镜像信息

GET http://127.0.0.1:9906/v1/image/{image_id}


### 示例

请求命令：

```console
curl -L -X GET http://127.0.0.1:9906/v1/image/8db4be59-b3a2-4bef-9913-e12cb06c1116
```

返回信息：

```json
{
    "image": {
        "id": "8db4be59-b3a2-4bef-9913-e12cb06c1116",
        "name": "test",
        "checksum": null,
        "description": "test_image",
        "disk_format": "raw",
        "status": "queued",
        "created_at": "2022-02-11T04:55:15",
        "updated_at": null,
        "location": null,
        "user_id": null,
        "project_id": null,
        "size": null,
        "virtual_size": null,
        "metadata": {
            "key1": "value1",
            "key2": "value2"
        },
        "tags": ["33", "11", "22"]
    }
}

```


## 更新

PUT http://127.0.0.1:9906/v1/image/{image_id}


### 参数

| 参数名      | 必选 | 类型   | 说明       |
| :---------- | :--- | :----- | ---------- |
| name        | 否   | string | image name |
| description | 否   | string | 描述信息   |
| metadata    | 否   | dict   | 元数据     |
| tags        | 否   | list   | 标签       |


### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/image/8db4be59-b3a2-4bef-9913-e12cb06c1116 -H 'Content-Type: application/json' --data-raw
```

请求参数：

```json
{
    "image": {
        "name": "test2",
        "description": "test_image2",
        "metadata": {
            "key1": "value1"
        },
        "tags": ["11", "22", "33"]
    }
}
```

返回信息：

```json
{
    "image": {
        "id": "8db4be59-b3a2-4bef-9913-e12cb06c1116",
        "name": "test2",
        "checksum": null,
        "description": "test_image2",
        "disk_format": "raw",
        "status": "queued",
        "created_at": "2022-02-11T04:55:15",
        "updated_at": "2022-02-11T05:00:38",
        "location": null,
        "user_id": null,
        "project_id": null,
        "size": null,
        "virtual_size": null,
        "metadata": {
            "key1": "value1"
        },
        "tags": ["11", "22", "33"]
     }
}
```


## 上传镜像

PUT http://127.0.0.1:9906/v1/image/{image_id}/file


### 参数

| 参数名       | 必选 | 类型   | 说明       |
| :---------- | :--- | :----- | ---------- |
| X-Image-Auto-Convert | 否   | bool |是否进行镜像格式转换，默认为 false。仅支持 qcow2 转 raw。此参数是请求头参数。 |


### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/image/8db4be59-b3a2-4bef-9913-e12cb06c1116/file -H 'Content-Type: application/octet-stream' \
-H 'X-Image-Auto-Convert:ture' --data-binary '@/root/image/cirros-0.3.0-x86_64-disk.raw'
```

上传成功无返回值


## 删除

DELETE  http://127.0.0.1:9906/v1/image/{image_id}


### 示例

请求命令：

```console
curl -L -X DELETE http://127.0.0.1:9906/v1/image/8db4be59-b3a2-4bef-9913-e12cb06c1116
```

删除成功无返回值


## 下载镜像

GET  http://127.0.0.1:9906/v1/image/{image_id}/file


### 示例

```console
curl -L -X GET -o /home/images/80cfb894-c02c-4b22-bf6f-4e8324b25d59 \
     http://127.0.0.1:9906/v1/image/80cfb894-c02c-4b22-bf6f-4e8324b25d59/file
```

下载成功无返回值，镜像文件格式为 raw。
