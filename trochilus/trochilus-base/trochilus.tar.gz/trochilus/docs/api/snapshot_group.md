---
title: "snapshot_group"
---

## 属性

| 名称               | 类型     | 说明                                          |
| :----------------- | :------- | :-------------------------------------------- |
| id                 | string   | snapshot_group ID                             |
| name               | string   | snapshot_group name                           |
| description        | string   | 描述信息                                      |
| size               | integer  | snapshot_group 大小(GB)(所有组内快照大小之和) |
| status             | string   | snapshot_group 状态                           |
| project_id         | string   | 项目 ID                                       |
| user_id            | string   | 用户 ID                                       |
| created_at         | datetime | 创建时间                                      |
| updated_at         | datetime | 更新时间                                      |
| current            | boolean  | 标记是否是当前快照组                          |
| previous           | string   | 上一个快照组                                  |
| virtual_machine_id | string   | 该快照组所属的 VM ID                          |
| snapshots          | list     | 属于该快照组的快照列表                        |

`current`: 如果 VM 存在多个快照组, 并且第一个快照组的 current 值为 true
这个时候如果删除了第一个快照组, 那么该 VM 就会不存在 current 值为 true 的快照组了.

snapshots 列表的返回值与 [Snapshot API文档](/api/snapshot)  中的属性一致

## 创建

POST http://127.0.0.1:9906/v1/snapshot_group

### 参数

| 参数名             | 必选 | 类型   | 说明             |
| :----------------- | :--- | :----- | ---------------- |
| name               | 否   | string | 快照组名称       |
| description        | 否   | string | 快照组的描述信息 |
| virtual_machine_id | 是   | uuid   | VM ID            |
| project_id         | 否   | string | 项目 ID          |
| user_id            | 否   | string | 用户 ID          |

### 示例

请求命令：

```console
curl -L -X POST http://127.0.0.1:9906/v1/snapshot_group -H 'Content-Type: application/json' -d
```

请求参数:

 ```json
{
   "snapshot_group": {
       "name": "snapshot_group1",
       "description": "test snapshot_group1",
       "virtual_machine_id": "e19c3613-723e-4245-adb2-7e6171584bbc"
   }
}
```

返回参数:

```json
{
    "snapshot_group": {
        "id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150",
        "name": "snapshot_group1",
        "size": 3,
        "status": "prepare_create",
        "description": "test snapshot_group1",
        "user_id": null,
        "project_id": null,
        "created_at": "2022-03-28T07:48:47",
        "updated_at": null,
        "current": true,
        "previous": "5b6fda78-09d4-4788-99d4-bc992ccd82a0",
        "virtual_machine_id": "e19c3613-723e-4245-adb2-7e6171584bbc",
        "snapshots": [
            {
                "id": "4ba92c46-0654-438b-b581-a4f469163b0b",
                "name": "snapshot for volume-a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                "size": 2,
                "status": "prepare_create",
                "description": "Auto create by snapshot group",
                "volume_id": "a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                "current": true,
                "previous": "70e2632b-3fc9-41d1-8e98-b4d8631d0bb4",
                "user_id": null,
                "project_id": null,
                "created_at": "2022-03-28T07:48:47",
                "updated_at": null,
                "snapshot_group_id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150"
            },
            {
                "id": "5f03430a-394a-4343-aedb-ce9ded30e136",
                "name": "snapshot for volume-df3feb4b-f26a-4be6-afe0-652b92f93a53",
                "size": 1,
                "status": "prepare_create",
                "description": "Auto create by snapshot group",
                "volume_id": "df3feb4b-f26a-4be6-afe0-652b92f93a53",
                "current": true,
                "previous": "32a9fa4a-08ae-4a88-9a34-98fa856890c2",
                "user_id": null,
                "project_id": null,
                "created_at": "2022-03-28T07:48:47",
                "updated_at": null,
                "snapshot_group_id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150"
            }
        ]
    }
}
```

## 更新

PUT http://127.0.0.1:9906/v1/snapshot_group/{snapshot_group_id}

### 参数

| 参数名      | 类型   | 说明                |
| :---------- | :----- | :------------------ |
| name        | string | Snapshot_group 名称 |
| description | string | Snapshot_group 描述 |

### 示例

请求命令：

```console
curl -L -X PUT http://127.0.0.1:9906/v1/snapshot_group/532a5b5b-bcba-4a9f-8c22-3e1d8d93b150 -H 'Content-Type: application/json' -d
```

请求参数：

```json
{
   "snapshot_group": {
       "name": "snapshot_group2",
       "description": "test snapshot_group12"
   }
}
```

返回参数：

```json
{
    "snapshot_group": {
        "id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150",
        "name": "snapshot_group2",
        "size": 3,
        "status": "prepare_create",
        "description": "test snapshot_group12",
        "user_id": null,
        "project_id": null,
        "created_at": "2022-03-28T07:48:47",
        "updated_at": "2022-03-28T07:49:15",
        "current": true,
        "previous": "5b6fda78-09d4-4788-99d4-bc992ccd82a0",
        "virtual_machine_id": "e19c3613-723e-4245-adb2-7e6171584bbc",
        "snapshots": [
            {
                "id": "4ba92c46-0654-438b-b581-a4f469163b0b",
                "name": "snapshot for volume-a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                "size": 2,
                "status": "available",
                "description": "Auto create by snapshot group",
                "volume_id": "a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                "current": true,
                "previous": "70e2632b-3fc9-41d1-8e98-b4d8631d0bb4",
                "user_id": null,
                "project_id": null,
                "created_at": "2022-03-28T07:48:47",
                "updated_at": "2022-03-28T07:48:56",
                "snapshot_group_id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150"
            },
            {
                "id": "5f03430a-394a-4343-aedb-ce9ded30e136",
                "name": "snapshot for volume-df3feb4b-f26a-4be6-afe0-652b92f93a53",
                "size": 1,
                "status": "prepare_create",
                "description": "Auto create by snapshot group",
                "volume_id": "df3feb4b-f26a-4be6-afe0-652b92f93a53",
                "current": true,
                "previous": "32a9fa4a-08ae-4a88-9a34-98fa856890c2",
                "user_id": null,
                "project_id": null,
                "created_at": "2022-03-28T07:48:47",
                "updated_at": null,
                "snapshot_group_id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150"
            }
        ]
    }
}
```

## 获取快照组列表信息

GET http://127.0.0.1:9906/v1/snapshot_group

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/snapshot_group
```

返回信息:

```json
{
    "snapshot_groups": [
        {
            "id": "b4c8a23e-7c01-4ece-bb1f-6fc8ea055b78",
            "name": "snapshot1",
            "size": 10,
            "status": "available",
            "description": "test snapshot",
            "user_id": null,
            "project_id": null,
            "created_at": "2022-03-28T07:27:16",
            "updated_at": "2022-03-28T07:27:18",
            "current": true,
            "previous": null,
            "virtual_machine_id": "ca7da0df-c7ad-49b1-bf3e-2fef371c8759",
            "snapshots": [
                {
                    "id": "8f409164-12b6-49b2-8c70-c566181e2f3c",
                    "name": "snapshot for volume-6fdad617-2c8b-4661-b4bf-232c14addabb",
                    "size": 10,
                    "status": "available",
                    "description": "Auto create by snapshot group",
                    "volume_id": "6fdad617-2c8b-4661-b4bf-232c14addabb",
                    "current": true,
                    "previous": null,
                    "user_id": null,
                    "project_id": null,
                    "created_at": "2022-03-28T07:27:16",
                    "updated_at": "2022-03-28T07:27:18",
                    "snapshot_group_id": "b4c8a23e-7c01-4ece-bb1f-6fc8ea055b78"
                }
            ]
        },
        {
            "id": "5b6fda78-09d4-4788-99d4-bc992ccd82a0",
            "name": "snapshot1",
            "size": 3,
            "status": "available",
            "description": "test snapshot",
            "user_id": null,
            "project_id": null,
            "created_at": "2022-03-28T07:48:02",
            "updated_at": "2022-03-28T07:48:47",
            "current": false,
            "previous": null,
            "virtual_machine_id": "e19c3613-723e-4245-adb2-7e6171584bbc",
            "snapshots": [
                {
                    "id": "32a9fa4a-08ae-4a88-9a34-98fa856890c2",
                    "name": "snapshot for volume-df3feb4b-f26a-4be6-afe0-652b92f93a53",
                    "size": 1,
                    "status": "available",
                    "description": "Auto create by snapshot group",
                    "volume_id": "df3feb4b-f26a-4be6-afe0-652b92f93a53",
                    "current": false,
                    "previous": null,
                    "user_id": null,
                    "project_id": null,
                    "created_at": "2022-03-28T07:48:02",
                    "updated_at": "2022-03-28T07:48:47",
                    "snapshot_group_id": "5b6fda78-09d4-4788-99d4-bc992ccd82a0"
                },
                {
                    "id": "70e2632b-3fc9-41d1-8e98-b4d8631d0bb4",
                    "name": "snapshot for volume-a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                    "size": 2,
                    "status": "available",
                    "description": "Auto create by snapshot group",
                    "volume_id": "a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                    "current": false,
                    "previous": null,
                    "user_id": null,
                    "project_id": null,
                    "created_at": "2022-03-28T07:48:02",
                    "updated_at": "2022-03-28T07:48:47",
                    "snapshot_group_id": "5b6fda78-09d4-4788-99d4-bc992ccd82a0"
                }
            ]
        }
    ],
    "snapshot_group_links": []
}
```

## 获取单个快照组信息

GET http://127.0.0.1:9906/v1/snapshot_group/{snapshot_group_id}

### 示例

请求命令：

```console
curl -X GET http://127.0.0.1:9906/v1/snapshot_group/532a5b5b-bcba-4a9f-8c22-3e1d8d93b150
```

返回信息：

```json
{
    "snapshot_group": {
        "id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150",
        "name": "snapshot_group2",
        "size": 3,
        "status": "available",
        "description": "test snapshot_group12",
        "user_id": null,
        "project_id": null,
        "created_at": "2022-03-28T07:48:47",
        "updated_at": "2022-03-28T07:49:17",
        "current": true,
        "previous": "5b6fda78-09d4-4788-99d4-bc992ccd82a0",
        "virtual_machine_id": "e19c3613-723e-4245-adb2-7e6171584bbc",
        "snapshots": [
            {
                "id": "4ba92c46-0654-438b-b581-a4f469163b0b",
                "name": "snapshot for volume-a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                "size": 2,
                "status": "available",
                "description": "Auto create by snapshot group",
                "volume_id": "a5b292ac-302a-4c26-9e1c-bcf3d1cc986e",
                "current": true,
                "previous": "70e2632b-3fc9-41d1-8e98-b4d8631d0bb4",
                "user_id": null,
                "project_id": null,
                "created_at": "2022-03-28T07:48:47",
                "updated_at": "2022-03-28T07:48:56",
                "snapshot_group_id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150"
            },
            {
                "id": "5f03430a-394a-4343-aedb-ce9ded30e136",
                "name": "snapshot for volume-df3feb4b-f26a-4be6-afe0-652b92f93a53",
                "size": 1,
                "status": "available",
                "description": "Auto create by snapshot group",
                "volume_id": "df3feb4b-f26a-4be6-afe0-652b92f93a53",
                "current": true,
                "previous": "32a9fa4a-08ae-4a88-9a34-98fa856890c2",
                "user_id": null,
                "project_id": null,
                "created_at": "2022-03-28T07:48:47",
                "updated_at": "2022-03-28T07:49:16",
                "snapshot_group_id": "532a5b5b-bcba-4a9f-8c22-3e1d8d93b150"
            }
        ]
    }
}
```

## 删除

DELETE http://127.0.0.1:9906/v1/snapshot_group/{snapshot_group_id}

### 示例

请求命令：

```console
curl http://127.0.0.1:9906/v1/snapshot_group/861fcc10-3ee1-4228-9c5a-d580acd2d6ac -X delete
```

删除成功无返回值

## 快照组 action 操作

### 参数

| 参数名        | 必选 | 类型   | 说明        |
| :------------ | :--- | :----- | ----------- |
| name          | 是   | string | action name |
| extended_attr | 否   | dict   | action 参数 |

### 回滚

POST http://127.0.0.1:9906/v1/snapshot_group/{snapshot_group_id}/action

#### 示例

请求命令:

```bash
curl -X POST HTTP://127.0.0.1:9906/v1/snapshot_group/a7858cff-9a5c-4a85-9b75-9a2e50142dbe/action -H 'Content-Type: application/json' -d
```

请求参数：

```json
{
    "action":{
        "name": "revert"
    }
}
```

正常响应码: 201
