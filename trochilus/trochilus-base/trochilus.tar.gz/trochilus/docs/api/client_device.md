---
title: "client_device"
---


## 属性

| 名称         | 类型     | 说明                                         |
| :----------- | :------- | :-------------------------------------------|
| id           | string   | 客户端设备 id                                |
| vpc_id       | string   | vpc id                                      |
| mac          | string   | 客户端设备mac地址                            |
| ip           | string   | 客户端设备ip地址                             |
| last_update  | datetime | 客户端设备上次发包时间                        |


## 获取所有客户端设备信息

GET http://127.0.0.1:9906/v1/client_device

### 示例

请求命令：

```console
curl -L -X GET http://127.0.0.1:9906/v1/client_device
```

返回信息：

```json
{
    "client_device": [{
            "id": "17acc0a3-ade2-46ca-970d-00ab6c4a428b",
            "vpc_id": "df70a1a5-d714-432b-b7d6-a8f239a1c818",
            "mac": "fa:16:3e:f7:1c:3d",
            "ip": "192.168.2.15",
            "last_update": "2022-04-08T01:27:31"
        },
        {
            "id": "b29729a6-1998-489a-9027-2403c228b1ab",
            "vpc_id": "61dc72fb-ac33-4d5a-9ebf-5ab20acd5597",
            "mac": "fa:16:3e:80:e4:18",
            "ip": "192.168.2.16",
            "last_update": "2022-04-08T01:26:43"
        },
        {
            "id": "dbf4fb28-3399-4536-bba9-cbf51cf06daa",
            "vpc_id": "df70a1a5-d714-432b-b7d6-a8f239a1c818",
            "mac": "fa:16:3e:91:b5:fd",
            "ip": "192.168.2.17",
            "last_update": "2022-04-08T01:27:30"
        },
        {
            "id": "f3453d58-b5c6-4c91-ae7c-affef7f382cf",
            "vpc_id": "df70a1a5-d714-432b-b7d6-a8f239a1c818",
            "mac": "fa:16:3e:ca:26:96",
            "ip": "192.168.1.12",
            "last_update": "2022-04-08T01:27:31"
        }
    ]
}
```


## 获取单个客户端设备信息

GET http://127.0.0.1:9906/v1/client_device/{id}


### 示例

请求命令：

```console
curl -L -X GET http://127.0.0.1:9906/v1/client_device/17acc0a3-ade2-46ca-970d-00ab6c4a428b
```

返回信息：

```json
{
    "client_device": {
        "id": "17acc0a3-ade2-46ca-970d-00ab6c4a428b",
        "vpc_id": "df70a1a5-d714-432b-b7d6-a8f239a1c818",
        "mac": "fa:16:3e:f7:1c:3d",
        "ip": "192.168.2.15",
        "last_update": "2022-04-08T01:27:31"
    }
}
```


## 删除

DELETE http://127.0.0.1:9906/v1/client_device/{id}


### 示例

请求命令：

```console
curl -L -X DELETE http://127.0.0.1:9906/v1/client_device/17acc0a3-ade2-46ca-970d-00ab6c4a428b
```

删除成功无返回值
