---
title: "Trochilus 文档"
---

## 简介

Trochilus 是一个轻量的虚拟化 IaaS 平台，其功能实现参照 openstack，借鉴了大量的
openstack 代码。

## 为什么不直接使用 openstack

openstack 是当前最流行的开源 IaaS 平台，有大量开发者和使用者，功能丰富。但是由于
openstack 大而全的特点，造成了它结构复杂（需要各种组件协同工作），部署困难，运维
困难，二次开发困难。总结来说 openstakc 适用于那些中大型的的项目，且需要公司有丰
富运维经验的人员。因此为了应对一些小型项目，为了快速满足小型客户的定制化需要，我
们开发了 trochilus 项目。

## trochilus 支持的功能

在项目研讨阶段我们就决定了不想 openstack 一样实现大量的功能，trochilus 仅关注
IaaS 平台最核心的几个功能：计算，网络，存储。甚至人员，认证相关的功能我们也不提
供。
