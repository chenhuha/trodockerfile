---
title: "VM 配置说明"
---


## 配置介绍

虚拟机功能需要在配置文件（trochilus.conf）的 [vm_settings] 下进行配置。

配置项介绍：
- `virt_type`: 指定运行虚拟机的 hypervisor(虚拟机管理器). 当前只支持 qemu 或者 kvm, 当部署
在物理节点上时使用 kvm, 部署在虚拟机上使用 qemu
    - 默认值: kvm
- `default_root_disk_backend`: 指定虚拟机系统盘的默认存储后端, 必须是 [api_settings]
enabled_volume_backends 的其中一个. 当指定镜像创建虚拟机时, 则在该后端创建出镜像卷作为系统盘.
    - 默认值: 无
- `vm_name_template`: 指定 libvirt 中创建的虚拟机名称的模板, 它是通过 `virsh list` 查看时
所展示的名称, 并不是从平台创建虚拟机时输入的名称.
    - 默认值: vm-%s
- `mem_stats_period_seconds`: 设置内存信息的采集周期(秒), 可通过 `virsh dommemstat [domain]`
查看内存使用状态. 设置为 0 或负数则禁用内存信息统计, 该配置一般是提供给监控用于获取虚拟机内存
使用情况.
    - 默认值: 10
- `rbd_secret_uuid`: 指定 libvirt 连接 Ceph 后端镜像时需要提供的密钥的唯一识别符(uuid). 通
过 `virsh secret-list` 可查找当前的密钥 UUID.
    - 默认值: 无
- `vnc_enabled`: 是否开启 VNC 相关功能, 开启后可通过 vnc 客户端访问虚拟机.
    - 默认值: False
- `vnc_server_listen`: VNC 服务监听的 IP 地址. 一般配置为本机的管理网 IP
    - 默认值: '127.0.0.1'
- `spice_enabled`: 是否开启 SPICE 相关功能, 开启后可通过 spice 客户端访问虚拟机.
    - 默认值: False
- `spice_server_listen`: SPICE 服务监听的 IP 地址. 一般配置为本机的管理网 IP
    - 默认值: '127.0.0.1'
- `wait_soft_reboot_seconds`: 设置虚拟机执行软重启(`virsh shutdown` + `virsh start`)时等
待的超时时间(秒), 如果超过该时间则尝试硬重启
(`virsh destroy` + `virsh undefine` + `virsh define` + `virsh start`), 需要注意的是硬重启会重新生成最新的 xml 配置.
    - 默认值: 120
- `clean_shutdown_timeout`: 设置虚拟机关机(`virsh shutdown`)的超时时间(秒), 如果超过该时间
则直接断电(`virsh destroy`).
    - 默认值: 60
- `clean_shutdown_retry_interval`: 重新发送执行关机(`virsh shutdown`)之前的等待时间(秒),
 虚拟机总的等待时间由 `clean_shutdown_timeout` 设置。
    - 默认值: 10
- `num_pcie_ports`: 当使用 UEFI 启动虚拟机时需要配置 PCI-e 控制器(BIOS 为 PCI), 该配置项定义默认添加多少个 PCI-e 插槽
    - 默认值: 10

## 部署 libvirt

我们默认项目运行在 ubuntu-20.04 上

1. 安装软件包

    `apt install qemu-kvm libvirt-daemon-system libvirt-clients python3-libvirt python3-rados python3-rbd ceph-common`

2. 查看 libvirt 服务状态

    `systemctl is-active libvirtd`

## libvirt 连接 Ceph 需要的密钥生成配置

1. 查看 ceph 中密钥列表

    `ceph auth list` 找到 default_root_disk_backend 配置的后端的 rbd_user, 这里是 `client.admin`

2. 获取 client.admin 的 key 并保存在文件中

    `ceph auth get-key client.admin --cluster=ceph > /etc/ceph/client.admin.key`

3. 生成 secret xml 文件

    执行 `uuidgen` 生成 uuid, 替换下面的 $uuid

    ```bash
    cat << EOF > /etc/ceph.xml
    <secret ephemeral="no" private="no">
    <uuid>$uuid</uuid>
    <usage type="ceph">
    <name>client.admin secret</name>
    </usage>
    </secret>
    EOF
    ```

4. 通过 xml 定义密钥

    `virsh secret-define --file /etc/ceph.xml`

5. 给 libvirt 密钥设置值, 该值就是第二步获取的 key, $uuid 就是第三步生成的 uuid. 通过 `virsh secret-list` 可查看

    ```bash
    user_key=`cat /etc/ceph/client.admin.key`
    virsh secret-set-value --secret $uuid  --base64 ${user_key}
    ```

## 示例的配置文件

```ini
[api_settings]
bind_host = 192.168.189.2
enabled_volume_backends = rbd1

[image_settings]
rbd_store_config_file=/home/liupeng/ceph/ceph.conf
enabled_image_store = rbd
rbd_store_user = admin

[vm_settings]
default_root_disk_backend = rbd1
virt_type = kvm
rbd_secret_uuid = 3f74eed6-4f1b-497a-bf3a-833a97aca283
vnc_enabled = true

[rbd1]
rbd_ceph_conf = /home/liupeng/ceph/ceph.conf
rbd_pool = volumes
rbd_user = admin
rbd_keyring_conf = /home/liupeng/ceph/ceph.client.volumes.keyring
rados_connect_timeout = -1
volume_driver = trochilus.agent.storage.volume.drivers.rbd.RBDVolumeDriver
rbd_store_thin_provisioning = False
```

## 创建 VM 说明

因为当前优先支持的是基于 ceph 的后端存储, 所以我们需要先参照文档 [Image 配置](/admin/image_upload_and_download)
 和 [Volume 配置](/admin/create_volume) 进行基于 ceph 存储后端的配置,
并且我们需要参考 [Image API 文档](/api/image) 上传一个 raw 格式的镜像. 最后我们参考 [VM API文档](/api/vm) 进行 VM 创建
等操作

这里有一个 44M 的 raw 格式的 cirros 镜像用于测试 <http://172.18.30.69/cirros.raw>

## VM 支持的操作及其说明

- start(开机)
    - VM 状态要求: (stopped)关机

- stop(关机)
    - VM 状态要求: (active)开机

- reboot(hard)(硬重启)
    - VM 状态要求: (stopped)关机, (active)开机
    - 参考 `wait_soft_reboot_seconds` 配置说明

- reboot(soft)(软重启)
    - VM 状态要求: (active)开机
    - 参考 `wait_soft_reboot_seconds` 配置说明

- migrate(迁移)
    - VM 状态要求: (stopped)关机
    - 当前只支持冷迁移

- resize(调整大小)
    - VM 状态要求: (stopped)关机
    - 修改 VM 的 vcpu, memory, disk(系统盘) 的大小

- rebuild(重建)
    - VM 状态要求: (stopped)关机, (active)开机
    - 重建 VM 指的是根据镜像或卷的快照重新创建 VM 的系统盘, 之前的系统盘数据会被清除,
      但是如果该 VM 存在快照组或系统盘存在快照则不能重建, 需要删除快照组和快照之后才能重建

## VM 状态说明

TODO
