#!/usr/bin/bash
#----------------------------
host_ip=172.18.30.127
host_pass=Klcloud@9000
ceph_public_network=172.18.30.127/32
ceph_cluster_network=172.18.30.127/32
ceph_pool_size=1
ceph_pool_min_size=1
ceph_pg_num=16
ceph_pgp_num=16
ceph_mon_list="172.18.30.127:6789"
ceph_name_list="controller"
osd_disk="vdb vdc vdd"

#########ceph install

###################disable ufw
systemctl disable --now ufw

hostnamectl set-hostname controller
echo "$host_ip controller" >> /etc/hosts
# 自身免密
ssh-keygen -t rsa -P '' <<EOF

EOF

expect <<EOF
        spawn ssh-copy-id -i /root/.ssh/id_rsa.pub root@$host_ip
        expect {
                "yes/no" { send "yes\n";exp_continue}
                "password" { send "$host_pass\n"}
        }
        expect eof
EOF

apt update
apt install -y ubuntu-snappy libleveldb1d gdisk python3-ceph-argparse libgoogle-perftools4
apt install -y ceph radosgw



sed -i.bak 's/Environment=CLUSTER=ceph/Environment=CLUSTER=ceph/g' /usr/lib/systemd/system/ceph-mon@.service
sed -i 's/ExecStart=.*$/ExecStart=\/usr\/bin\/ceph-mon -f --cluster ${CLUSTER} --id %i/g' /usr/lib/systemd/system/ceph-mon@.service
#sed -i.bak 's/Environment=CLUSTER=ceph/Environment=CLUSTER=ceph/g' /usr/lib/systemd/system/ceph-osd@.service
#sed -i 's/ExecStart=.*$/ExecStart=\/usr\/bin\/ceph-osd -f --cluster ${CLUSTER} --id %i/g' /usr/lib/systemd/system/ceph-osd@.service
#sed -i.bak 's/Environment=CLUSTER=ceph/Environment=CLUSTER=ceph/g' /usr/lib/systemd/system/ceph-mds@.service
#sed -i 's/ExecStart=.*$/ExecStart=\/usr\/bin\/ceph-mds -f --cluster ${CLUSTER} --id %i/g' /usr/lib/systemd/system/ceph-mds@.service
#sed -i.bak 's/Environment=CLUSTER=ceph/Environment=CLUSTER=ceph/g' /usr/lib/systemd/system/ceph-mgr@.service
#sed -i 's/ExecStart=.*$/ExecStart=\/usr\/bin\/ceph-mgr -f --cluster ${CLUSTER} --id %i/g' /usr/lib/systemd/system/ceph-mgr@.service
#sed -i.bak 's/Environment=CLUSTER=ceph/Environment=CLUSTER=ceph/g' /usr/lib/systemd/system/ceph-radosgw@.service
#sed -i 's/ExecStart=.*$/ExecStart=\/usr\/bin\/radosgw -f --cluster ${CLUSTER} --name client.%i/g' /usr/lib/systemd/system/ceph-radosgw@.service
sed -i 's/^StartLimitInterval=30min/#&/' /usr/lib/systemd/system/ceph-*@.service
systemctl daemon-reload

mkdir /tmp/mk-ceph-cluster
cd /tmp/mk-ceph-cluster
cat << EOF >/tmp/mk-ceph-cluster/ceph.conf
[global]
    cluster                     = ceph
    fsid                        = 116d4de8-fd14-491f-811f-c1bdd8fac141

    public network              = ${ceph_public_network}
    cluster network             = ${ceph_cluster_network}
    auth cluster required       = cephx
    auth service required       = cephx
    auth client required        = cephx

    osd pool default size       = ${ceph_pool_size}
    osd pool default min size   = ${ceph_pool_min_size}

    osd pool default pg num     = ${ceph_pg_num}
    osd pool default pgp num    = ${ceph_pgp_num}

    osd pool default crush rule = 0
    osd crush chooseleaf type   = 1

    admin socket                = /var/run/ceph/\$cluster-\$name.asock
    pid file                    = /var/run/ceph/\$cluster-\$name.pid
    log file                    = /var/log/ceph/\$cluster-\$name.log
    log to syslog               = false

    max open files              = 131072
    ms bind ipv6                = false

[mon]
    mon initial members = controller
    mon host = ${ceph_mon_list}
    mon data                     = /var/lib/ceph/mon/\$cluster-\$name
    mon clock drift allowed      = 10
    mon clock drift warn backoff = 30

    mon osd full ratio           = .95
    mon osd nearfull ratio       = .85

    mon osd down out interval    = 600
    mon osd report timeout       = 900

    debug ms                     = 20
    debug mon                    = 20
    debug paxos                  = 20
    debug auth                   = 20
    mon allow pool delete      = true  ; without this, you cannot delete pool
[mon.controller]
    host    =    controller
    mon addr   =    ${ceph_mon_list}
[mgr]

    mgr data                     = /var/lib/ceph/mgr/\$cluster-\$name

[osd]

    osd data                     = /var/lib/ceph/osd/\$cluster-\$id
    osd recovery max active      = 3
    osd max backfills            = 5
    osd max scrubs               = 2

    osd mkfs type = xfs
    osd mkfs options xfs = -f -i size=1024
    osd mount options xfs = rw,noatime,inode64,logbsize=256k,delaylog

    filestore max sync interval  = 5
    osd op threads               = 2
EOF


#keyring
ceph-authtool --create-keyring ceph.keyring --gen-key -n mon. --cap mon 'allow *'

ceph-authtool --create-keyring ceph.client.admin.keyring --gen-key -n client.admin  --cap mon 'allow *' --cap osd 'allow *' --cap mds 'allow *' --cap mgr 'allow *'
ceph-authtool --create-keyring ceph.client.bootstrap-osd.keyring --gen-key -n client.bootstrap-osd --cap mon 'allow profile bootstrap-osd'
ceph-authtool --create-keyring ceph.mgr.controller.keyring --gen-key -n mgr.controller --cap mon 'allow profile mgr' --cap osd 'allow *' --cap mds 'allow *'

ceph-authtool ceph.keyring  --import-keyring ceph.client.admin.keyring
ceph-authtool ceph.keyring  --import-keyring ceph.client.bootstrap-osd.keyring
ceph-authtool ceph.keyring  --import-keyring ceph.mgr.controller.keyring
#monmap
monmapcmd="monmaptool --create --add controller ${ceph_mon_list} --fsid 116d4de8-fd14-491f-811f-c1bdd8fac141 monmap"
${monmapcmd}

scp ceph.client.admin.keyring ceph.client.bootstrap-osd.keyring ceph.keyring  ceph.conf monmap controller:/etc/ceph
scp ceph.keyring  controller:/var/lib/ceph/bootstrap-osd/
mkdir /var/lib/ceph/mon/ceph-mon.controller
ceph-mon --cluster ceph --mkfs -i controller --monmap /etc/ceph/monmap --keyring /etc/ceph/ceph.keyring
touch /var/lib/ceph/mon/ceph-mon.controller/done
systemctl restart ceph-mon@controller
systemctl enable ceph-mon@controller


for disk in ${osd_disk}; do
ceph-volume lvm zap /dev/${disk}
ceph-volume lvm  create --data /dev/${disk}
sleep 5
done

ceph-volume lvm activate --all
mkdir /var/lib/ceph/mgr/ceph-mgr.controller

cp ceph.mgr.controller.keyring /var/lib/ceph/mgr/ceph-mgr.controller/keyring
chmod 755 /var/lib/ceph/mgr/ceph-mgr.controller/keyring
ceph config set mon auth_allow_insecure_global_id_reclaim false
ceph config set global mon_warn_on_pool_no_redundancy false
systemctl start ceph-mgr@controller
systemctl enable ceph-mgr@controller
ceph mgr module disable dashboard
ceph mon enable-msgr2
