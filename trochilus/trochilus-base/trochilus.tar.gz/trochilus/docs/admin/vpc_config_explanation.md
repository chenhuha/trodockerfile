---
title: "VPC配置说明"
---

## 配置介绍

网络功能需要在配置文件（trochilus.conf）的 [network_settings] 下进行配置。

配置项介绍：
- `support_flat_physicals`：指定 flat 类型 VPC 可以使用的 physical 。如果有多个 physical，用逗号隔开。
- `physical_vlan_ranges`： 指定 vlan 类型 VPC 可以使用的 physical 和 vlan 范围， vlan 范围必须在 [1:4094]。如果有多个 physical，用逗号隔开。
- `physical_interface_mappings`：指定当前计算节点上物理网卡和 physical 的映射关系。如果有多个映射关系，用逗号隔开。


## 配置示例

假设有一个控制节点 controller 和两个计算节点 compute1 和 compute2。
compute1 上除了用做管理网的网卡外，还有两块网卡：ens3 和 ens5。
compute2 上除了用做管理网的网卡外，还有两块网卡：ens4 和 ens6。

#### controller 的配置文件

```ini
[network_settings]
support_flat_physicals = flat1
physical_vlan_ranges = vlan1:100:1000
```

#### compute1 配置文件

```ini
[network_settings]
physical_interface_mappings = flat1:ens3,vlan1:ens5
```

#### compute2 配置文件

```ini
[network_settings]
physical_interface_mappings = flat1:ens4,vlan1:ens6
```

要保证配置项 support_flat_physicals 和 physical_vlan_ranges 的 physical 值是配置项 physical_interface_mappings 的 physical 值的子集。
假设配置项 support_flat_physicals 和 physical_vlan_ranges 的 physical 值是配置项 physical_interface_mappings 的 physical 值的超集，当
创建 VPC 时指定了一个 physical 值， 而计算节点配置项 physical_interface_mappings 中没有这个 physiacl 值，则这个计算节点上不会创建该 VPC。

#### 查询 physical 的值

controller 配置文件中的配置项 support_flat_physicals 和 physical_vlan_ranges 的值可以通过 physical 接口查询。具体使用方式参考[API文档](/api/physical)。

请求命令

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/physical
```

返回值

```json
{
    "physicals": [{
        "name": "flat1",
        "support_flat": true,
        "vlan_ranges": []
    }, {
        "name": "vlan1",
        "support_flat": false,
        "vlan_ranges": [{
            "max": 1000,
            "min": 100
        }]
    }]
}
```

controller 配置文件中配置项 support_flat_physicals 的值为 flat1，因此通过 physical 接口查到了 name 为 flat1，support_flat 为 true，
vlan_ranges 为[]。配置项 physical_vlan_ranges 的值为 vlan1:100:1000，因此通过 physical 接口查到了 name 为 vlan1，support_flat 为 false，
vlan_ranges 为[1,4094]。

如果修改了配置项 support_flat_physicals 或 physical_vlan_ranges 的值，需要重启 trochilus api 项目，才能通过 physical 接口查到修改后的值。 

#### flat 类型 VPC

创建 flat 类型 VPC，选择 physical 为 flat1。
```
                     compute1                                                   compute2
     +-------------------------------------------+            +-------------------------------------------+
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |   +--------------+                        |            |   +--------------+                        |
     |   |brqac4e0b19-c4|                        |            |   |brqac4e0b19-c4|                        |
     |   +-----+--------+                        |            |   +----+---------+                        |
     |         |                                 |            |        |                                  |
     |         |                                 |            |        |                                  |
     |     +---+---+             +------+        |            |     +--+----+             +------+        |
     |     |ens3   |             | ens5 |        |            |     |ens4   |             |ens6  |        |
     |     +-------+             +------+        |            |     +-------+             +------+        |
     |                                           |            |                                           |
     +-------------------------------------------+            +-------------------------------------------+
```

上图中 brqac4e0b19-c4 是一个 linux bridge。linux bridge 的命名方式为固定前缀 brq ，加上 VPC id 的前11个字符。

创建 flat 类型 VPC，会在 compute1、compute2 节点上都创建一个 linux bridge。因为 compute1 节点上 physical flat1 对应 ens3，所以
linux bridge 和 ens3 绑定。因为 compute2 节点上 physical flat1 对应 ens4，所以 linux bridge 和 ens4 绑定。


#### vlan 类型 VPC

分别创建 vlan id 为 107 和 700 的 vlan 类型 VPC，选择 physical 为 vlan1。

- vlan id 为 107的 VPC
```
                     compute1                                                   compute2
     +-------------------------------------------+            +-------------------------------------------+
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |            +--------------+               |            |             +--------------+              |
     |            |brqe324dac7-8c|               |            |             |brqe324dac7-8c|              |
     |            +---------+----+               |            |             +---------+----+              |
     |                      |                    |            |                       |                   |
     |                      |                    |            |                       |                   |
     |                      |                    |            |                       |                   |
     |                   +--+------+ +---------+ |            |                   +---+-----+ +---------+ |
     |                   |ens5.107 | |ens5.700 | |            |                   |ens6.107 | |ens6.700 | |
     |                   +---------+ +---------+ |            |                   +---------+ +---------+ |
     |                                           |            |                                           |
     |     +-------+             +------+        |            |     +-------+             +------+        |
     |     |ens3   |             | ens5 |        |            |     |ens4   |             |ens6  |        |
     |     +-------+             +------+        |            |     +-------+             +------+        |
     |                                           |            |                                           |
     +-------------------------------------------+            +-------------------------------------------+
```

上图中 brqe324dac7-8c 是一个 linux bridge。

创建 vlan 类型 VPC，会在 compute1、compute2 节点上都创建一个 linux bridge。因为 compute1 节点上 physical vlan1 对应 ens5，所以
会在 ens5 上创建一块子网卡，命名为 ens5.107，然后将 linux bridge 和 ens5.107 绑定。因为 compute2 节点上 physical vlan1 对应 ens6，
所以会在 ens6 上创建一块子网卡，命名为 ens6.107，然后将 linux bridge 和 ens6.107 绑定。

- vlan id 为 700的 VPC
```
                     compute1                                                   compute2
     +-------------------------------------------+            +-------------------------------------------+
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                                           |            |                                           |
     |                          +--------------+ |            |                          +--------------+ |
     |                          |brqb32g1235-2d| |            |                          |brqb32g1235-2d| |
     |                          +--------+-----+ |            |                          +--------+-----+ |
     |                                   |       |            |                                   |       |
     |            +--------------+       |       |            |             +--------------+      |       |
     |            |brqe324dac7-8c|       |       |            |             |brqe324dac7-8c|      |       |
     |            +---------+----+       |       |            |             +---------+----+      |       |
     |                      |            |       |            |                       |           |       |
     |                      |            |       |            |                       |           |       |
     |                      |            |       |            |                       |           |       |
     |                   +--+------+ +---+-----+ |            |                   +---+-----+ +---+-----+ |
     |                   |ens5.107 | |ens5.700 | |            |                   |ens6.107 | |ens6.700 | |
     |                   +---------+ +---------+ |            |                   +---------+ +---------+ |
     |                                           |            |                                           |
     |     +-------+             +------+        |            |     +-------+             +------+        |
     |     |ens3   |             | ens5 |        |            |     |ens4   |             |ens6  |        |
     |     +-------+             +------+        |            |     +-------+             +------+        |
     |                                           |            |                                           |
     +-------------------------------------------+            +-------------------------------------------+
```

#### VPC 状态说明

VPC 整体状态由各个计算节点上的 VPC 状态共同决定。
VPC 整体状态有 prepare_create, prepare_delete, creating, deleting, active, down, downgrade, error, deleted。
计算节点上的 VPC 状态有 active, down, error。
- 当所有计算节点上的 VPC 状态是 active，则 VPC 整体状态是 active。
- 当部分计算节点上的 VPC 状态是 active，则 VPC 整体状态是 downgrade。
- 当所有计算节点上的 VPC 状态全是 down，则 VPC 整体状态是 down。
- 当所有计算节点上的 VPC 状态全是 error，则 VPC 整体状态是 error。
- 当所有计算节点上的 VPC 状态一部分是 down，另一部分是 error， 则 VPC 整体状态是 down。

各个计算节点上的 VPC 状态可以通过 VPC 接口查询。具体使用方式参考[API文档](/api/vpc)。

请求命令

```console
curl -X GET -H "Accept: application/json" http://127.0.0.1:9906/v1/vpc/ac4e0b19-c41c-433d-a831-93adf95bedb5/agents
```

其中：ac4e0b19-c41c-433d-a831-93adf95bedb5 表示 VPC 的 id。

返回信息

```json
{
    "statuses": [{
        "agent_id": "d3679f75-7968-4103-82ca-994074cc3ece",
        "status": "active"
    },{
        "agent_id": "93adf95b-433d-1961-82ca-13adf95bec5a",
        "status": "active"
    }],
    "status_links": []
}
```

statuses 表示该 VPC 在各个计算节点上的状态。agent_id 表示计算节点上 agent 的 id。status 表示该计算节点上 VPC 的状态。

