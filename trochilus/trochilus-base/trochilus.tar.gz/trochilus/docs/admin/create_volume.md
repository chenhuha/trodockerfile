---
title: "创建卷和指定镜像创建卷"
---


创建卷：

- 指定镜像创建 Ceph 卷
  - 优点：安全性高，Agent 可以向任意节点发送请求进行指定镜像创建卷。
  - 缺点：Ceph 部署复杂，出现故障后排查困难，需要更多的硬件资源支持。
- 指定镜像创建 LVM 卷
  - 优点：不需要部署 ceph，使部署更为便捷, 常用于单节点部署。
  - 缺点：可靠性差，如果 API 所在节点系统崩溃，会导致镜像无法下载， 从而导致创建镜像卷失败。
          执行快照还原操作时，实际还原过程可能会锁定存储并消耗很长时间，具体取决于卷的大小。
- 创建普通卷和镜像卷的区别
  - 普通卷(空白卷)的创建是直接在 Ceph 的卷池或 LVM 卷组中直接创建相应的资源
   (Ceph 中是 rbd 镜像、Lvm 中是 lv 逻辑卷)。
  - 镜像卷的创建对于 Ceph 来说需要引用已经上传好的镜像，并对镜像进行 clone 操作，速度很快。
    如果是 lvm 的话需要先把镜像的源文件下载到 lvm 逻辑卷所在的节点上，
    并使用该镜像数据填充该 lvm 逻辑卷，镜像越大耗时越长。
- LVM暂不支持拍扁(flatten),迁移(migrate)操作
- LVM支持两种存储类型
  - 标准逻辑卷
  - 精简逻辑卷
- 精简逻辑卷
  - 优点：可以创建大于可用盘区的逻辑卷，使用前需要预先创建精简池(thin pool)；精简池可以在需要时进行动态扩展以节省成本地分配存储空间。
          在标准的逻辑卷中磁盘空间在创建时就会占用卷组的空间，但是在精简（thin）逻辑卷中只有在写入时才会占用精简存储池中的空间。
  - 缺点：暂不支持快照回滚操作(revert)


## 配置介绍

创建卷的功能需要在配置文件（trochilus.conf）的 [api_settings] 下进行配置。

配置项介绍：

- `enabled_volume_backends` : 卷的配置组名称。例如：enabled_volume_backends = test1,test2,test3。
- `volume_driver` :  指定卷设备驱动。
- `volume_group` :  指定使用卷组的名称。
- `thin_pool_lv` :  指定使用精简池逻辑卷的名称(仅在使用lvm精简卷类型时配置此项)。
- `lv_type` : 指定使用逻辑卷的存储类型(normal:使用lvm普通卷类型， thin:使用lvm精简卷类型)
- `rbd_ceph_conf` : Ceph 配置文件所在的位置。
- `rbd_pool` : 指定 Ceph 中存储卷的池的名称。
- `rbd_keyring_conf` : 指定进行 Ceph 身份验证的秘钥文件，该密钥应该是 rbd_user 所配置的用户的密钥文件。
- `rbd_user` ：指定进行 Ceph 身份验证的用户名， 该用户需要拥有卷池的读写权限，卷池的读写权限。
- `rados_connect_timeout` : 连接 Ceph 的超时时间。

镜像相关配置请参考以下文章：[镜像的上传和下载](/admin/image_upload_and_download/#配置介绍)。


## 后端存储功能一览表
|  功能\driver  |  ceph  |  lvm-thin  |  lvm  |
| :------------ | :----- | :--------- | :---- |
| 创建          |  √     |  √         |  √    |
| 删除          |  √     |  √         |  √    |
| 热扩容        |  √     |  √         |  √    |
| 镜像克隆卷    |  √     |  √         |  √    |
| 卷克隆卷      |  √     |  √         |  √    |
| 快照克隆卷    |  √     |  √         |  √    |
| 回滚          |  √     |  ×         |  √    |
| 冷迁移        |  √     |  ×         |  ×    |
| flatten       |  √     |  ×         |  ×    |
| 重建          |  √     |  √         |  √    |


## 卷的形式


### Ceph 卷


#### 准备事项

创建用于存储镜像文件的 Ceph 池。创建示例如下：

```bash
# ceph osd pool create <pool_name> <pg_num>
ceph osd pool create volume 100
```


#### 配置示例

```ini
[api_settings]
enabled_volume_backends = rbd1

[rbd1]
rbd_ceph_conf = /etc/ceph/ceph.conf
rbd_pool = volume_size3
rbd_user = volumes
rbd_keyring_conf = /etc/ceph/ceph.client.volumes.keyring
rados_connect_timeout = -1
volume_driver = trochilus.agent.storage.volume.drivers.rbd.RBDVolumeDriver
```


### LVM 卷


#### 准备事项

- 1 安装 LVM 命令工具

```bash
apt install lvm2
```

- 2 创建物理卷和卷组

```bash
# 创建物理卷
pvcreate /dev/sdb1
pvcreate /dev/sdb2
# 创建卷组
vgcreate vg_name /dev/sdb1 /dev/sdb2
# 创建thin pool logical volume
lvcreate -l +100%free --thinpool data_pool vg_name
```


#### 配置示例

```ini
[api_settings]
enabled_volume_backends = test1, test2

[test1]
volume_driver = trochilus.agent.storage.volume.drivers.lvm.LVMVolumeDriver
volume_group = vg_name
# 使用lvm精简卷类型
thin_pool_lv = data_pool
lv_type = thin

[test2]
volume_driver = trochilus.agent.storage.volume.drivers.lvm.LVMVolumeDriver
volume_group = vg_name
# 使用lvm精简卷类型
thin_pool_lv = data_pool
lv_type = thin
```


## 使用示例

由于指定镜像创建Ceph 卷 和 LVM 卷的使用方式一样，所以此处示例通用。


#### 创建卷

POST http://127.0.01:9906/v1/volume

请求参数：

```json
{
   "volume": {
       "name": "volume1",
       "size": 5,
       "backend": "test1"
   }
}
```

返回参数：

```json
{
    "volume": {
        "id": "8242d261-efba-45d9-af91-ea682ead513b",
        "name": "volume1",
        "size": 5,
        "status": "creating",
        "backend": "test1",
        "description": "",
        "hostname": "controller1",
        "user_id": null,
        "project_id": null,
        "bootable": false,
        "created_at": "2022-02-24T10:15:02",
        "updated_at": null,
        "image_id": null
    }
}
```


#### 指定镜像创建卷

POST http://127.0.01:9906/v1/volume

请求命令：

```console
curl -L -X POST http://127.0.0.1:9906/v1/volume -H 'Content-Type: application/json' --data-raw
```

请求参数：

```json
{
   "volume": {
       "image_id": "8ec3ae20-3ec7-4e67-84eb-eb86ac9e48b9",
       "name": "volume1",
       "size": 5,
       "backend": "test1"
   }
}
```

返回参数：

```json
{
    "volume": {
        "id": "2c641365-70d1-4108-adaf-158628d45d49",
        "name": "volume1",
        "size": 5,
        "status": "creating",
        "backend": "test1",
        "description": "",
        "hostname": "controller1",
        "user_id": null,
        "project_id": null,
        "bootable": true,
        "created_at": "2022-02-24T05:29:10",
        "updated_at": null,
        "image_id": "8ec3ae20-3ec7-4e67-84eb-eb86ac9e48b9"
    }
}
```

