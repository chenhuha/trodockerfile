---
title: "如何配置 web vnc"
---

由于产品有远程协助用户的需求，为了使远程协助功能使用起来更加方便（不用安装 vnc client）。
因此我们需要提供一个 web 版的 vnc client，改功能的关键使如何把 vnc 的 TCP 流量转为浏览器
能接收的 websocket 流量。 [websockify](https://github.com/novnc/websockify) 为我们提供了
一个灵活强大的解决方案，下面我们就来介绍如何配置使用 [websockify](https://github.com/novnc/websockify)。


## 安装

```
pip install websockify
```

为了适应我们项目的需求，我们自己实现了一些 websockify 的插件，插件代码放在 trochilus 中管理。
所以我们要用安装 trochilus。

目前 trochilus 需要从源码安装：


```
pip install trochilus/
```

下面使用示例中假设管理网 IP 为 10.0.20.20，监听的端口为 56666


## 使用

目前我们实现的 websockify 插件有：Base64TokenApi 和 Base64JsonTokenRemoteApi


### Base64TokenApi

该插件收到的 token 是 base64 编码后的 <vnc ip>:<vnc 端口>， 因此通过 base64 解码后获得
<vnc ip>:<vnc 端口>


#### 示例

启动 websockify

```
websockify  10.0.20.20:56666 --token-plugin trochilus.websockify.token_plugin.Base64TokenApi
```

--token-plugin 指定使用的插件


假如我们知道一个虚机的 vnc 地址是 **172.18.23.46:5906**，首先我们对这个地址进行 base64 加密

```
echo -n "172.18.23.46:5906" | base64
```

我们会得到一个如下的字符串

```
MTcyLjE4LjIzLjQ2OjU5MDY=
```

接着我们需要使用 javascript 一个 web client 并访问如下链接，web client 的实现可参考
[novnc](https://github.com/novnc/noVNC)

```
ws://10.0.20.20:56666?token=MTcyLjE4LjIzLjQ2OjU5MDY=
```

在我们正式 web vnc client 实现之前，trochilus 团队提供了一个简易版的的 web vnc client 方便大家测试

打开浏览器，输入下面地址：

```
http://172.18.30.127/noVNC/vnc_lite.html
```

在左上方输入框中输入 websocket url，在点击 Connect 按钮，即可 vnc 登录虚机。
下面的 websocket url 供大家体验:

```
ws://172.18.30.127:55666?token=MTcyLjE4LjEyLjMxOjU5MDc=
```


### Base64JsonTokenRemoteApi

该插件收到的 token 是 base64 编码后的 json，因此先通过 base64 解码获得 json，json 格式：

```
{"id":"c56ee605-2c27-4cc9-b52b-96192a6ddc0e"}
```

id 是 vdi 虚拟机或 voi 客户机的标识。

然后根据 id 通过 http GET 向 java 端请求 vnc ip 和 vnc 端口，请求 url：

```
http://10.0.20.20:9000/api/v1/desktop/desktop/c56ee605-2c27-4cc9-b52b-96192a6ddc0e/vnc
```

java 端返回结果：

```
{"vncIp": "172.27.125.1", "vncPort": 5901}
```


#### 示例

假设 java 端监听地址是 10.0.20.20:9000

启动 websockify

```
websockify  10.0.20.20:56666 --token-plugin trochilus.websockify.token_plugin.Base64JsonTokenRemoteApi \
--token-source http:/10.0.20.20:9000/api/v1
```

--token-plugin 指定使用的插件，--token-source 指定请求 java 端的url

假如我们知道一个 vdi 虚拟机的 id 是 c56ee605-2c27-4cc9-b52b-96192a6ddc0e， 首先我们构建 json
并进行 base64 加密

```
echo -n '{"id":"c56ee605-2c27-4cc9-b52b-96192a6ddc0e"}'| base64
```

我们会得到一个如下的字符串

```
eyJpZCI6ImM1NmVlNjA1LTJjMjctNGNjOS1iNTJiLTk2MTkyYTZkZGMwZSJ9
```

接着我们需要使用 javascript 一个 web client 并访问如下链接，web client 的实现可参考
[novnc](https://github.com/novnc/noVNC)

```
ws://10.0.20.20:56666?token=eyJpZCI6ImM1NmVlNjA1LTJjMjctNGNjOS1iNTJiLTk2MTkyYTZkZGMwZSJ9
```

在我们正式 web vnc client 实现之前，trochilus 团队提供了一个简易版的的 web vnc client 方便大家测试

打开浏览器，输入下面地址：

```
http://172.18.30.127/noVNC/vnc_lite.html
```

在左上方输入框中输入 websocket url，在点击 Connect 按钮，即可 vnc 登录虚机。
下面的 websocket url 供大家体验:

```
ws://172.18.30.127:55666?token=eyJpZCI6ImM1NmVlNjA1LTJjMjctNGNjOS1iNTJiLTk2MTkyYTZkZGMwZSJ9
```
