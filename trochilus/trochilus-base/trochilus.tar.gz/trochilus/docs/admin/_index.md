---
title: Trochilus 开发与运维
---

该目录下的文档面向的是 trochilus 的开发和运维人员。我们会提供一些开发环境的准备
文档，一些开发注意事项以及各个功能的使用示例。

## 关于开发

Trochilus 是用 python 语言编写的，代码组织结构参考了 openstack，并引入
openstack 提供的很多 oslo 库。同时我们也尽量要求开发人员提交的代码遵守
openstack 规范。Trochilus 使用 [setuptools](https://setuptools.pypa.io/en/latest/)
加 [pbr](https://setuptools.pypa.io/en/latest/) 管理项目代码。trochilus-api 使用
[pecan](https://pecan.readthedocs.io/en/latest/) 框架来编写 api 接口，
trochilus-agent 使用 [flask](https://flask.palletsprojects.com/en/2.0.x/) 框架
编写和 trochilus-api 通信的接口。使用 [oslo.db](https://docs.openstack.org/oslo.db/latest/)
加 [sqlalchemy](https://www.sqlalchemy.org/) 提供 orm 框架对数据库进行读写。使用
[oslo.log](https://docs.openstack.org/oslo.log/latest/) 来管理日志，使用
[oslo.config](https://docs.openstack.org/oslo.config/latest/) 来管理配置。

## 关于运维

TODO
