---
title: "Trochilus部署文档"
---


## 前期准备

- 系统环境

  - ubuntu 20.04 的物理机或虚拟机。
  - 多块物理硬盘或虚拟机硬盘。（ 至少三块，以满足 Ceph 的部署环境 ）。
  - 多张网卡。（具体由配置 Vpc 决定）。

- 软件环境

  - Python 3.8 和 pip3、Git。
  - Ceph 后端存储，Ceph 安装参考[Ceph单机部署脚本](/admin/ceph_deploy)。
  - MySQL 8.0。
  - 安装 libvirt 所需的软件包
    ```bash
    apt install qemu-kvm libvirt-daemon-system libvirt-clients python3-libvirt python3-rados python3-rbd
    ```
  - 安装 dnsmasq 所需的软件包
    ```bash
    apt install dnsmasq dnsmasq-utils
    ```
  - 安装 ipmitool 所需的软件包
    ```bash
    apt install ipmitool
    ```
  - 下载 Trochilus 项目，使用自己的 git 账户拉取。
    ```bash
    git clone "ssh:// 用户名 @172.26.1.8:29418/kunlun/trochilus"
    ```


## 项目配置

### 配置文件

准备配置文件。创建 /etc/trochilus 目录。
把 trocihlus 项目下的 trochilus.conf.sample 复制到 /etc/trochilus 并命名为 trochilus.conf。
命令如下：

```bash
mkdir /etc/trochilus/
cp etc/trochilus/trochilus.conf.sample /etc/trochilus/trochilus.conf
```


### 配置组说明

[DEFAULT]
  - `debug`：调试。

[agent_settings]
  - `bind_port`：绑定端口，为9916。
  - `system`：主机系统。
  - `version`：主机系统版本。
  - `role`：主机角色，controller、computer或storage，可以多选。
  - `nic`: 网卡配置，存在bond时，指定bond名称与对应物理网卡信息；不存在bond时，ip地址后跟随角色
  - `ipmi_username`: ipmi用户名
  - `ipmi_password`: ipmi密码
  - `ipmi_vendor`: ipmi服务器厂商，华为为HUAWEI、安擎为ANQING
  - `host_username`: 宿主机用户名
  - `host_password`: 宿主机密码

[api_settings]
  - `bind_port`：绑定端口，为9906。
  - `supported_instance_metadatas`：当前环境中包含虚拟机支持的元数据的字段。
  - `allow_pagination`：是否允许分页。
  - `pagination_max_limit`：分页的最大值，"infinite"或者负整数值表示无限制。
  - `api_base_uri`：用于分页链接的API的基本URI。如果没有，将从请求中自动检测到，
    这里被推翻。
  - `allow_sorting`：是否允许排序。
  - `allow_filtering`：是否允许过滤。
  - 卷相关配置请参考：[创建卷和指定镜像创建卷](/admin/create_volume)。

[database]
  - `connection`：数据库连接 mysql+pymysql://<数据库用户明>:<数据库密码>@<数据库IP地址>:
<端口号：mysql默认 3306>/数据库名

[image_settings]
  - 镜像相关配置请参考：[镜像的上传和下载](/admin/image_upload_and_download)。

[network_settings]
  - Vpc相关配置请参考：[Vpc 配置说明](/admin/vpc_config_explanation)。

[webhook_settings]
  - Webhook 相关配置请参考：[webhook 配置与使用](/admin/status_webhook)。

[vm_settings]
  - VM 相关配置请参考：[vm 配置说明](/admin/vm_config_explanation)


## 项目运行

### 项目配置示例

```init
[DEFAULT]
debug = True

[agent_settings]

system = unbuntu
version = 20.04
role = controller, computer, storage
nic = bond1:172.18.1.33:0011:ens4,ens5
nic = ens3:172.18.1.28:1100

[api_settings]
# 使用 lvm 后端方式存储时， bind_host 必须为当前节点的 IP 地址， 否则指定镜像创建卷时，
# 其他节点无法找的镜像所在的主机，导致镜像下载失败，无法成功创建镜像卷。
bind_host = 172.18.30.70
enabled_volume_backends = lvm1,rbd1
supported_instance_metadatas = k1, k2

[database]
connection = mysql+pymysql://trochilus:123456@127.0.0.1:3306/trochilus

[image_settings]
enabled_image_store = rbd
rbd_store_thin_provisioning = true
rbd_store_conn_timeout = 0
rbd_store_chunk_size = 8
rbd_store_user = admin
rbd_store_pool = images
rbd_store_config_file = /etc/ceph/ceph.conf

[lvm1]
volume_driver = trochilus.agent.storage.volume.drivers.lvm.LVMVolumeDriver
volume_group = vg0

[rbd1]
rbd_ceph_conf = /etc/ceph/ceph.conf
rbd_pool = volume
rbd_user = admin
rbd_keyring_conf = /etc/ceph/ceph.client.volumes.keyring
rados_connect_timeout = -1
volume_driver = trochilus.agent.storage.volume.drivers.rbd.RBDVolumeDriver

[network_settings]
support_flat_physicals = flat1
physical_vlan_ranges = vlan1:100:1000
physical_interface_mappings = flat1:ens4,vlan1:ens5

[vm_settings]
default_root_disk_backend = rbd1
virt_type = qemu
rbd_secret_uuid = 0e4e7efa-83a3-45cc-9592-2d785fe2932d
vnc_enabled = true

[webhook_settings]
target_host = 127.0.0.1
target_port = 9082
target_path = /v1/webhook
method = put
auth_token = abcd1234
max_retries = 3
retry_interval = 5
request_conn_timeout = 10
request_read_timeout = 60
expected_codes = 200,202,204
```


### 项目安装

#### 安装依赖包

使用 pip3 安装依赖包。命令如下：

```bash
pip3 install -r requirements.txt
```

如没修改pip源，请使用如下命令：

```bash
pip3 install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple
```


#### 安装

安装 trochilus 。命令如下：

```bash
python3 setup.py install
```

查看是否安装成功。命令如下：

```bash
pip3 list | grep trochilus
trochilus              0.0.1.dev30          /root/2.24/trochilus
```

出现上述信息证明安装成功。


### 数据库准备

#### 创建 trochilus 用户

```mysql
create user 'trochilus'@'%' identified with mysql_native_password by '123456';
```


#### 修改授权

修改授权，命令如下：

```mysql
grant all privileges on trochilus.* TO 'trochilus'@'%';
```


#### 刷新MySQL的系统权限相关表

```bash
flush privileges;
```


#### 创建库

创建名为 trochilus 的数据库。使用命令如下：

```mysql
create database trochilus DEFAULT CHARSET utf8 COLLATE utf8_general_ci;
```


### 初始化数据库

执行数据库迁移命令 在 trochilus 数据库中创建数据表。

```bash
trochilus-db-manage upgrade head
```


### 运行项目

#### 运行API

```bash
trochilus-api --config-file /etc/trochilus/trochilus.conf
```


#### 运行agent

```
trochilus-agent --config-file /etc/trochilus/trochilus.conf
```


#### 运行webhook

```bash
trochilus-webhook-server --config-file /etc/trochilus/trochilus.conf
```


### 安装 websockify

安装 websockify 的目的和方法参考[如何配置 web vnc](/admin/websockify)


## 使用示例

### 创建 VPC

POST http://127.0.0.1:9906/v1/vpc


#### 示例

创建 VPC 需要 physical。[physical 详情请见](/api/physical)
创建 VPC 的请求命令：

```bash
curl -X POST  -H "Content-Type: application/json" http://127.0.0.1:9906/v1/vpc -d
```

请求参数：

```json
{
    "vpc": {
        "name": "v1",
        "type": "vlan",
        "physical": "vlan1"
    }
}
```

返回参数：

```bash
{
    "vpc": {
        "id": "61ed0801-e538-41f4-a2bb-89c65f88e611",
        "name": "v1",
        "description": "",
        "type": "vlan",
        "vlan_id": 100,
        "physical": "vlan1",
        "status": "prepare_create",
        "project_id": null,
        "user_id": null,
        "created_at": "2022-03-09T09:15:52",
        "updated_at": null
    }
}
```

对应网桥：

```bash
ens5.100@ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue master brq61ed0801-e5 state UP mode DEFAULT group default qlen 1000
    link/ether fa:16:3e:fe:e5:ab brd ff:ff:ff:ff:ff:ff
brq61ed0801-e5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether fa:16:3e:fe:e5:ab brd ff:ff:ff:ff:ff:ff
```

VPC 具体操作详情见[api文档](/api/vpc)


### 创建 Volume

POST http://127.0.01:9906/v1/volume


#### 示例

创建 Volume 的请求命令：

```bash
curl http://127.0.0.1:9906/v1/volume  -X post -H 'content-type:application/json' -d
```

请求参数：

```bash
{
    "volume": {
        "name": "123",
        "size": 1,
        "backend": "rbd1"
    }
}
```

返回参数：

```bash
{
    "volume": {
        "id": "35dfcea2-860b-4000-8fa0-4c5031e2a7c1",
        "name": "123",
        "size": 1,
        "status": "prepare_create",
        "backend": "rbd1",
        "description": "",
        "hostname": "controller",
        "user_id": null,
        "project_id": null,
        "bootable": false,
        "created_at": "2022-03-10T00:57:41",
        "updated_at": null,
        "image_id": null,
        "auto_delete": false,
        "attached_to": null,
        "attached_index": null
    }
}
```

对应的 ceph rdb：

```bash
# 命令
rbd ls volume
# 结果
volume-35dfcea2-860b-4000-8fa0-4c5031e2a7c1
```

Volume 具体操作详情请见[api文档](/api/volume)


### 创建 VM

创建 VM 首先需要创建镜像、上传镜像、基于镜像创建卷。具体详情请参考
[镜像的上传与下载](/admin/image_upload_and_download)与[基于镜像创建卷](/admin/create_volume)

POST http://127.0.0.1:9906/v1/vm


#### 示例

请求命令：

```bash
curl -L -X POST '127.0.0.1:9906/v1/vm' -H 'Content-Type: application/json' -d
```

请求参数：

```bash
{
    "vm": {
        "vcpu": 1,
        "memory_mb": 100,
        "image_id": "cc6fbcec-7e6f-440f-aea5-8610ebd60425",
        "root_disk_gb": 1,
        "volumes": [{
                "backend": "rbd1",
                "size": "1",
                "image_id": "cc6fbcec-7e6f-440f-aea5-8610ebd60425"
            },
            {
                "name": "v2",
                "backend": "rbd1",
                "size": 2
            },
            {
                "id": "2b7c6750-f87e-4d14-bcd6-66426a383b13"
            }
        ],
        "metadata": {
            "key1": 1,
            "key2": true,
            "key3": "ok"
        },
        "tags": [
            "1",
            "2",
            "aaaa"
        ]
    }
}
```

返回参数：

```bash
{
    "vm": {
        "id": "90bf03fe-060a-4d8b-ad62-5948d3dc2f1d",
        "name": "",
        "description": "",
        "status": "prepare_create",
        "created_at": "2022-03-10T03:26:02",
        "updated_at": null,
        "user_id": null,
        "project_id": null,
        "vcpu": 1,
        "memory_mb": 100,
        "root_disk_gb": 1,
        "image_id": "cc6fbcec-7e6f-440f-aea5-8610ebd60425",
        "metadata": {
            "key1": 1,
            "key2": true,
            "key3": "ok"
        },
        "tags": ["1", "2", "aaaa"],
        "volumes": [{
            "id": "42e838dd-d2b8-441c-9e2a-555be492ef64",
            "name": "v2",
            "size": 2,
            "status": "prepare_create",
            "backend": "rbd1",
            "description": "",
            "hostname": "controller",
            "user_id": null,
            "project_id": null,
            "bootable": false,
            "created_at": "2022-03-10T03:26:02",
            "updated_at": null,
            "image_id": null,
            "auto_delete": false,
            "attached_to": "90bf03fe-060a-4d8b-ad62-5948d3dc2f1d",
            "attached_index": 2
        }, {
            "id": "2a125826-5332-40d7-a5a6-3b4ddd71daa0",
            "name": "",
            "size": 1,
            "status": "prepare_create",
            "backend": "rbd1",
            "description": "",
            "hostname": "controller",
            "user_id": null,
            "project_id": null,
            "bootable": true,
            "created_at": "2022-03-10T03:26:02",
            "updated_at": null,
            "image_id": "cc6fbcec-7e6f-440f-aea5-8610ebd60425",
            "auto_delete": true,
            "attached_to": "90bf03fe-060a-4d8b-ad62-5948d3dc2f1d",
            "attached_index": 0
        }, {
            "id": "2b7c6750-f87e-4d14-bcd6-66426a383b13",
            "name": "volume1",
            "size": 5,
            "status": "available",
            "backend": "rbd1",
            "description": "",
            "hostname": "controller",
            "user_id": null,
            "project_id": null,
            "bootable": true,
            "created_at": "2022-03-10T03:23:13",
            "updated_at": "2022-03-10T03:23:15",
            "image_id": "cc6fbcec-7e6f-440f-aea5-8610ebd60425",
            "auto_delete": false,
            "attached_to": "90bf03fe-060a-4d8b-ad62-5948d3dc2f1d",
            "attached_index": 3
        }, {
            "id": "08a31ab0-2175-44be-a9ca-27dd16cab460",
            "name": "",
            "size": 1,
            "status": "prepare_create",
            "backend": "rbd1",
            "description": "",
            "hostname": "controller",
            "user_id": null,
            "project_id": null,
            "bootable": true,
            "created_at": "2022-03-10T03:26:02",
            "updated_at": null,
            "image_id": "cc6fbcec-7e6f-440f-aea5-8610ebd60425",
            "auto_delete": false,
            "attached_to": "90bf03fe-060a-4d8b-ad62-5948d3dc2f1d",
            "attached_index": 1
        }]
    }
}
```

查看对应的 VM：

```bash
# 命令
virsh list
# 结果
Id   Name                                      State
---------------------------------------------------------
 1    vm-90bf03fe-060a-4d8b-ad62-5948d3dc2f1d   running
```

VM 具体操作详情请见[api文档](/api/vm)
