---
title: "webhook 配置与使用"
---

为尽快让上游应用感知到底层资源状态的变化，减少因上游应用轮询而产生的接口调用
次数，我们引入了 webhook 机制。该机制简单来说就是底层资源有状态变化时，我们
会通过 http 协议向上游应用发送一个 POST 或 PUT 请求。这样上游应用只需要监听
这个请求即可感知到资源状态的变化。

## webhook 配置

* `target_host` 上游服务的地址
* `target_port` 上游服务监听的端口号
* `target_path` webhook 请求路径
* `method` webhook 请求方法，当前仅支持 put 和 post 方法
* `auth_token` 如果该值不为空在请求的时候会携带一个请求头 `X-Auth-Token`，用于
   上游服务验证底层，一般用于防止多套系统中消息错误发送
* `max_retries` webhook 发送失败时，重试次数
* `retry_interval` 重试间隔时间
* `request_conn_timeout` http 请求连接超时时间
* `request_read_timeout` http 请求等待放回的超时时间
* `expected_codes` 上游应用成功接收到请求后返回的状态码，可以是多个，如果状态
   码不匹配则任务发送失败，会尝试重新发送


### 示例配置

```ini
[webhook_settings]
target_host = 127.0.0.1
target_port = 9082
target_path = /v1/webhook
method = put
auth_token = abcd1234
max_retries = 3
retry_interval = 5
request_conn_timeout = 10
request_read_timeout = 60
expected_codes = 200,202,204
```

目前 webhook 是从 agent 端发出的，修改配置后需要重启 agent 服务。


## webhook payload

| 字段            | 强制 | 说明                                               |
| :-------------- | :--- | :------------------------------------------------- |
| resource_type   | 是   | 资源类型，如：vpc，vm，voluem 等                   |
| resource_id     | 是   | 资源 ID                                            |
| current_status  | 是   | 资源当前状态                                       |
| previous_status | 否   | 变成当前状态的前一种状态                           |
| action          | 否   | 导致状态变化的动作，如：create，delete，update     |
| error_msg       | 否   | 如果资源状态变成 error，我们尽可能提供一些错误原因 |
| timestamp       | 是   | 状态变化的时间点                                   |


## trochilus-webhook-server

为了方便测试我们提供一个 webhook-server 用于模拟上游应用。它会监听 trochilus 发出的
请求并把请求携带的数据通过日志打印出来。

启动命令：

```console
trochilus-webhook-server --config-file /etc/trochilus/trochilus.conf
```

接收到请求后，会打印出如下日志：

```console
2022-03-02 10:57:00.784 76933 INFO trochilus.example_webhook_service.app [-] receive_put_event, payload: {'resource_type': 'vpc', 'resource_id': 'd60c6eee-4a6b-45b7-a82a-4acaf7185817', 'current_status': 'deleting', 'previous_status': '', 'event_type': '', 'error_msg': ''}
2022-03-02 10:57:00.784 76933 INFO trochilus.example_webhook_service.app [-] The auth token: abcd1234
2022-03-02 10:57:00.785 76933 INFO werkzeug [-] 127.0.0.1 - - [02/Mar/2022 10:57:00] "PUT /v1/webhook HTTP/1.1" 200 -
```


## VPC 状态变化

### VPC 创建

在创建 VPC 时，VPC 通常会经过两次状态变化

prepare_create -> creating -> active

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vpc',
    'resource_id': 'fda6b427-2980-4961-b660-367960fd74f7',
    'current_status': 'creating',
    'previous_status': '',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-02 05:15:34.301163'
}
```

```json
{
    'resource_type': 'vpc',
    'resource_id': 'fda6b427-2980-4961-b660-367960fd74f7',
    'current_status': 'active',
    'previous_status': 'creating',
    'action': '',
    'error_msg': '',
    'timestamp': '2022-03-02 05:15:34.657939'
}
```


### VPC 删除

在删除 VPC 时其状态也会经历两次变化

prepare_delete -> deleting -> deleted

对应的上游服务也会收到的两次 webhook 请求

```json
{
    'resource_type': 'vpc',
    'resource_id': 'fda6b427-2980-4961-b660-367960fd74f7',
    'current_status': 'deleting',
    'previous_status': '',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-02 05:24:33.202935'
}
```

```json
{
    'resource_type': 'vpc',
    'resource_id': 'fda6b427-2980-4961-b660-367960fd74f7',
    'current_status': 'deleted',
    'previous_status': '',
    'action': '',
    'error_msg': '',
    'timestamp': '2022-03-02 05:24:37.184394'
}
```


## NIC 状态变化

### NIC 挂载

在挂载 NIC 时，NIC 通常会经过两次状态变化

prepare_attach -> attaching -> up

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'nic',
    'resource_id': '7776b427-2980-4961-b660-367960fd74f7',
    'current_status': 'attaching',
    'previous_status': 'prepare_attach',
    'action': 'attach',
    'error_msg': '',
    'timestamp': '2022-03-02 05:15:34.301163'
}
```

```json
{
    'resource_type': 'nic',
    'resource_id': '7776b427-2980-4961-b660-367960fd74f7',
    'current_status': 'up',
    'previous_status': 'attaching',
    'action': 'attach',
    'error_msg': '',
    'timestamp': '2022-03-02 05:15:35.207167'
}
```

NIC 挂载时，同时 VM 的状态也会跟着变化。VM 的状态变化可查看下面的 [VM 挂载 NIC] 和 [VM 创建]。


### NIC 卸载

在卸载 NIC 时，NIC 通常会经过两次状态变化

prepare_detach -> detaching -> down

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'nic',
    'resource_id': '7776b427-2980-4961-b660-367960fd74f7',
    'current_status': 'detaching',
    'previous_status': 'prepare_detach',
    'action': 'detach',
    'error_msg': '',
    'timestamp': '2022-03-02 05:15:34.301163'
}
```

```json
{
    'resource_type': 'nic',
    'resource_id': '7776b427-2980-4961-b660-367960fd74f7',
    'current_status': 'down',
    'previous_status': 'detaching',
    'action': 'detach',
    'error_msg': '',
    'timestamp': '2022-03-02 05:15:35.207167'
}
```

NIC 卸载时，同时 VM 的状态也会跟着变化。 VM 的状态变化可查看下面的 [VM 卸载 NIC] 和 [VM 删除]。


## volume 状态变化

### volume 创建

在创建 volume 时，volume 通常会经过两次状态变化

prepare_create -> creating -> available

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'creating',
    'previous_status': '',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:11:44.867009'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'previous_status': 'creating',
    'current_status': 'available',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:11:45.241968'
}
```

volume 创建失败

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'previous_status': 'creating',
    'current_status': 'error',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:11:45.241968'
}
```

### volume 克隆

克隆 volume 时其状态会经历两次变化

prepare_create -> cloning -> available

对应的上游服务也会收到的两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'cloning',
    'previous_status': '',
    'action': 'clone',
    'error_msg': '',
    'timestamp': '2022-03-10 07:20:21.717779'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'available',
    'previous_status': 'cloning',
    'action': 'clone',
    'error_msg': '',
    'timestamp': '2022-03-10 07:20:21.717779'
}
```

volume 克隆失败

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'previous_status': 'cloning',
    'current_status': 'error',
    'action': 'clone',
    'error_msg': '',
    'timestamp': '2022-03-10 07:11:45.241968'
}
```

### volume 删除

在删除 volume 时其状态也会经历两次变化

prepare_delete -> deleting -> deleted

对应的上游服务也会收到的两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'deleting',
    'previous_status': '',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 07:20:21.717779'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'deleted',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 07:20:21.717779'
}
```

volume 删除失败

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'error',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 07:20:22.034385'
}
```

### volume 删除(级联)

在级联删除 volume 时, 根据当前卷的状态, 以及是否拥有快照会发送多个相关资源的 webhook

首先, 当卷存在快照时, 会删除所有快照, 删除快照状态变化同 (snapshot/删除).

其次, 当卷的状态为 in-use 的情况下, 该操作会隐含卸载卷操作, 会发送 (vm/卸载volume) 状态变化
但是并不发送 (volume/卸载) 状态变化, 而是发送 (volume/删除) 状态变化.

再次, 当卷的状态为 available 的情况下状态变化同 (volume/删除).

### volume 挂载

在挂载 volume 时，volume 通常会经过两次状态变化，同时 mapping 表中也会进行相应状态变化。

prepare_attach -> attaching -> in-use/available(失败时)

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '7a1a1a4f-c2e0-4b40-a16c-e33caa57f1d8',
    'current_status': 'attaching',
    'previous_status': 'prepare_attach',
    'action': 'attach',
    'error_msg': None,
    'timestamp': '2022-03-25 04:47:49.273360'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '7a1a1a4f-c2e0-4b40-a16c-e33caa57f1d8',
    'current_status': 'in-use',
    'previous_status': 'attaching',
    'action': 'attach',
    'error_msg': None,
    'timestamp': '2022-03-25 04:47:50.397023'
}
```

volume 挂载失败

```json
{
    'resource_type': 'volume',
    'resource_id': '066d9a62-c09f-45b7-be66-6d1c3bcd301c',
    'current_status': 'available',
    'previous_status': 'attaching',
    'action': 'attach',
    'error_msg': '举例：相应的错误描述',
    'timestamp': '2022-03-29 05:05:40.000509'
}
```

### volume 卸载

在卸载 volume 时，volume 通常会经过两次状态变化，同时 mapping 表中也会进行相应状态变化。

prepare_detach -> detaching -> available/in-use(失败时)

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '7a1a1a4f-c2e0-4b40-a16c-e33caa57f1d8',
    'current_status': 'detaching',
    'previous_status': 'prepare_detach',
    'action': 'detach',
    'error_msg': None,
    'timestamp': '2022-03-25 04:48:24.751771'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '7a1a1a4f-c2e0-4b40-a16c-e33caa57f1d8',
    'current_status': 'available',
    'previous_status': 'detaching',
    'action': 'detach',
    'error_msg': None,
    'timestamp': '2022-03-25 04:48:25.273763'
}
```

volume 卸载失败

```json
{
    'resource_type': 'volume',
    'resource_id': '066d9a62-c09f-45b7-be66-6d1c3bcd301c',
    'current_status': 'in-use',
    'previous_status': 'detaching',
    'action': 'detach',
    'error_msg': '举例：相应的错误描述',
    'timestamp': '2022-03-29 05:05:40.000509'
}
```

### volume 大小调整

在 Volume 调整大小时，Volume 通常会经过两次状态变化

prepare_resize -> resizing -> available/in-use

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '7a1a1a4f-c2e0-4b40-a16c-e33caa57f1d8',
    'current_status': 'resizing',
    'previous_status': 'prepare_resize',
    'action': 'resize',
    'error_msg': None,
    'timestamp': '2022-03-25 04:48:24.751771'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '7a1a1a4f-c2e0-4b40-a16c-e33caa57f1d8',
    'current_status': 'available/in-use',
    'previous_status': 'resizing',
    'action': 'resize',
    'error_msg': None,
    'timestamp': '2022-03-25 04:48:25.273763'
}
```


### volume 拍扁

在拍扁 VM 时会引起 volume 经历两次变化

并无 volume 拍扁接口

prepare_flatten -> flattening -> in-use

对应的上游服务也会收到的两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '066d9a62-c09f-45b7-be66-6d1c3bcd301c',
    'current_status': 'flattening',
    'previous_status': 'prepare_flatten',
    'action': 'flatten',
    'error_msg': '',
    'timestamp': '2022-03-29 05:05:39.331283'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '066d9a62-c09f-45b7-be66-6d1c3bcd301c',
    'current_status': 'in-use',
    'previous_status': 'flattening',
    'action': 'flatten',
    'error_msg': '',
    'timestamp': '2022-03-29 05:05:40.000509'
}
```

volume 拍扁失败

```json
{
    'resource_type': 'volume',
    'resource_id': '066d9a62-c09f-45b7-be66-6d1c3bcd301c',
    'current_status': 'error',
    'previous_status': 'flattening',
    'action': 'flatten',
    'error_msg': '',
    'timestamp': '2022-03-29 05:05:40.000509'
}
```


### volume 重建失败

因重建虚拟机、 还原模板机操作会调用 volume 的重建方法, 当 volume 的重建发生异常时会发送如下 webhook

```json
{
    'resource_type': 'volume',
    'resource_id': '5822644b-e9a6-4451-b2e1-67f18edc7ff1',
    'current_status': 'error',
    'previous_status': 'in-use',
    'action': "rebuild",
    'error_msg': '',
    'timestamp': '2022-03-10 07:20:22.034385'
}
```


## snapshot 状态变化

### snapshot 创建

在创建 snapshot 时，snapshot 通常会经过两次状态变化

prepare_create -> creating -> active

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'snapshot',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'creating',
    'previous_status': '',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-14 08:11:44.867009'
}
```

```json
{
    'resource_type': 'snapshot',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'previous_status': 'creating',
    'current_status': 'available',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-14 08:11:45.241968'
}
```

snapshot 创建失败

```json
{
    'resource_type': 'snapshot',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'previous_status': 'creating',
    'current_status': 'error',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-14 08:11:45.241968'
}
```


### snapshot 删除

在删除 snapshot 时其状态也会经历两次变化

prepare_delete -> deleting -> deleted

对应的上游服务也会收到的两次 webhook 请求

```json
{
    'resource_type': 'snapshot',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'deleting',
    'previous_status': '',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-14 08:20:21.717779'
}
```

```json
{
    'resource_type': 'snapshot',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'deleted',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-14 08:20:21.717779'
}
```

snapshot 删除失败

```json
{
    'resource_type': 'snapshot',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'error',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-14 08:20:22.034385'
}
```

### snapshot 回滚

在执行快照回滚操作时，Volume 通常会经过两次状态变化

prepare_revert -> reverting -> available/in-use

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'reverting',
    'previous_status': '',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:32.538355'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'available'/'in-use',
    'previous_status': 'reverting',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

快照回滚失败

```json
{
    'resource_type': 'volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'reverting',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```


## VM 状态变化

### VM 创建

在创建 VM 时，VM 通常会经过两次状态变化

prepare_create -> creating -> active

对应的上游服务也会收到两次 webhook 请求

VM 创建时，同时创建三个 volume

创建变化与 volume 状态变化一致

VM 创建时，会创建 NIC 并 挂载 NIC。

创建 NIC，不涉及 NIC 状态变化。挂载 NIC，会涉及 NIC 状态变化。
VM 创建过程中 VM 状态和 NIC 状态的对应关系：
VM 状态： prepare_create -> creating  -> active
NIC 状态：prepare_attach -> attaching -> up

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'creating',
    'previous_status': '',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:16.771126'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'creating',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```

VM 创建失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'creating',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```


### VM 关机

在 VM 关机时，VM 通常会经过两次状态变化

 prepare_stop -> stoping -> stopped

对应的上游服务也会收到两次 webhook 请求

Note:
当用户在虚拟机内部手动关闭虚拟机之后, 上游服务只会收到一次 webhook, 请求如下

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'active',
    'action': 'stop',
    'error_msg': '',
    'timestamp': '2022-03-10 08:06:25.550267'
}
```

通过接口关闭 VM

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopping',
    'previous_status': '',
    'action': 'stop',
    'error_msg': '',
    'timestamp': '2022-03-10 08:05:24.777951'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'stopping',
    'action': 'stop',
    'error_msg': '',
    'timestamp': '2022-03-10 08:06:25.550267'
}
```

VM 关机失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'stopping',
    'action': 'stop',
    'error_msg': '',
    'timestamp': '2022-03-10 08:06:25.550267'
}
```


### VM 开机

在 VM 开机时，VM 通常会经过两次状态变化

 prepare_start -> starting -> active

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'starting',
    'previous_status': '',
    'action': 'start',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:27.781077'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'starting',
    'action': 'start',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:31.170853'
}
```

VM 开机失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'starting',
    'action': 'start',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:31.170853'
}
```


### VM 重启

在 VM 重启时，VM 通常会经过两次状态变化

 prepare_reboot -> rebooting -> active

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'rebooting',
    'previous_status': '',
    'action': 'reboot',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:32.538355'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'rebooting',
    'action': 'reboot',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

VM 重启失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'rebooting',
    'action': 'reboot',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

### VM 回滚

在执行 VM 回滚(还原模式)和快照组回滚操作时会触发 VM 回滚状态变化，VM 通常会经过两次状态变化

prepare_revert -> reverting -> active/stopped

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'reverting',
    'previous_status': '',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:32.538355'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active'/'stopped',
    'previous_status': 'reverting',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

快照组回滚失败, 触发 VM 回滚失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'reverting',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

### VM 迁移

在 VM 迁移时，VM 通常会经过两次状态变化

 prepare_migrate -> migrating -> stopped

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'migrating',
    'previous_status': '',
    'action': 'migrate',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:32.538355'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stoped',
    'previous_status': 'migrating',
    'action': 'migrate',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

VM 迁移失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'migrating',
    'action': 'migrate',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```


### VM 大小调整

在 VM 调整大小时，VM 通常会经过两次状态变化

 prepare_resize -> resizing -> stopped

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'resizing',
    'previous_status': '',
    'action': 'resize',
    'error_msg': '',
    'timestamp': '2022-03-10 09:08:47.466580'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'resizing',
    'action': 'resize',
    'error_msg': '',
    'timestamp': '2022-03-10 09:08:49.587044'
}
```

VM 调整失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'resizing',
    'action': 'resize',
    'error_msg': '',
    'timestamp': '2022-03-10 09:08:49.587044'
}
```


### VM 删除

在删除 VM 时，VM 通常会经过两次状态变化

prepare_delete -> deleting -> deleted

对应的上游服务也会收到两次 webhook 请求

VM 删除时，默认会同时删除系统卷

删除变化与 volume 状态变化一致

VM 删除时，会卸载 NIC 并 删除 NIC。

卸载 NIC，会涉及 NIC 状态变化。删除 NIC，不涉及 NIC 状态变化。
VM 删除过程中 VM 状态和 NIC 状态的对应关系：
VM 状态： prepare_delete -> deleting  -> deleted
NIC 状态：prepare_detach -> detaching -> down

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'deleting',
    'previous_status': '',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'deleted',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VM 删除失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

### VM 删除(级联+数据盘)

在级联删除 VM 时, 同时删除虚拟机相关的所有资源(系统卷、数据卷、网卡、快照、快照组)

1. 当 VM 存在快照组时, 会删除所有快照组, 删除快照组状态变化同 (snapshot_group/删除).

2. 当 VM 系统盘/数据盘删除时, 删除系统盘/数据盘状态变化同 (volume/删除), 如果系统盘/数据盘存在快照,
    会删除所有快照, 删除快照状态变化同 (snapshot/删除).

3. 不删除数据盘时, 默认执行数据盘的卸载操作, 卸载数据盘状态变化同 (volume/卸载), 但是并不发送
    (VM 卸载 Volume) 的状态变化

4. 删除 VM 状态变化同 (vm/删除)

### VM 重建

在重建 VM 时，VM 通常会经过两次状态变化

prepare_rebuild -> rebuilding -> stopped or active(根据重建时 VM 的状态决定)

对应的上游服务也会收到两次 webhook 请求, 一个中间状态, 一个结果状态.

VM 重建时，会针对该 VM 的系统盘进行重建操作, 系统盘重建只有失败的时候发送 `volume 重建失败` 的 webhook

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'rebuilding',
    'previous_status': '',
    'action': 'rebuild',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'rebuilding',
    'action': 'rebuild',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VM 重建失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'rebuilding',
    'action': 'rebuild',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}

```


### VM 挂载 NIC

VM 挂载 NIC 时，VM 通常会经过两次状态变化

 prepare_nic_attach -> nic_attaching -> active

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'nic_attaching',
    'previous_status': '',
    'action': 'attach_nic',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:27.781077'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'nic_attaching',
    'action': 'attach_nic',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:31.170853'
}
```

VM 挂载失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'nic_attaching',
    'action': 'attach_nic',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:31.170853'
}
```


### VM 卸载 NIC

VM 卸载 NIC 时，VM 通常会经过两次状态变化

 prepare_nic_detach -> nic_detaching -> active

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'nic_detaching',
    'previous_status': '',
    'action': 'detach_nic',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:27.781077'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'nic_detaching',
    'action': 'detach_nic',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:31.170853'
}
```

VM 卸载失败

```json
{
    'resource_type': 'vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'nic_detaching',
    'action': 'detach_nic',
    'error_msg': '',
    'timestamp': '2022-03-10 08:16:31.170853'
}
```

### VM 拍扁

VM 拍扁时，VM 通常会经过两次状态变化

 prepare_flatten -> flattening -> active

对应的上游服务也会收到两次 webhook 请求

VM 拍扁时，同时触发 volume

拍扁变化与 volume 状态变化一致

```json
{
    'resource_type': 'vm',
    'resource_id': '3db21b81-f2ce-4d8b-883f-fc1d7115f7a1',
    'current_status': 'flattening',
    'previous_status': '',
    'action': 'flatten',
    'error_msg': '',
    'timestamp': '2022-03-28 05:31:05.544934'
}
```

```json
{
    'resource_type': 'vm',
    'resource_id': '3db21b81-f2ce-4d8b-883f-fc1d7115f7a1',
    'current_status': 'active',
    'previous_status': 'flattening',
    'action': 'flatten',
    'error_msg': '',
    'timestamp': '2022-03-28 05:31:07.400426'
}
```

VM 拍扁失败

```json
{
    'resource_type': 'vm',
    'resource_id': '3db21b81-f2ce-4d8b-883f-fc1d7115f7a1',
    'current_status': 'error',
    'previous_status': 'flattening',
    'action': 'flatten',
    'error_msg': '',
    'timestamp': '2022-03-28 05:31:07.400426'
}
```


## snapshot_group 状态变化

### snapshot_group 创建

在创建 snapshot_group 时，snapshot_group 通常会经过两次状态变化

prepare_create -> creating -> active

对应的上游服务也会收到两次 webhook 请求

snapshot_group 创建时, 会针对 VM 所有卷进行创建 snapshot 操作, webhook 同 snapshot 创建.

```json
{
    'resource_type': 'snapshot_group',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'creating',
    'previous_status': '',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-14 08:11:44.867009'
}
```

```json
{
    'resource_type': 'snapshot_group',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'previous_status': 'creating',
    'current_status': 'available',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-14 08:11:45.241968'
}
```

snapshot_group 创建失败

```json
{
    'resource_type': 'snapshot_group',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'previous_status': 'creating',
    'current_status': 'error',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-14 08:11:45.241968'
}
```


### snapshot_group 删除

在删除 snapshot_group 时其状态也会经历两次变化

prepare_delete -> deleting -> deleted

对应的上游服务也会收到的两次 webhook 请求

snapshot_group 删除时, 会针对 VM 所有卷进行删除 snapshot 操作, webhook 同 snapshot 删除.

```json
{
    'resource_type': 'snapshot_group',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'deleting',
    'previous_status': '',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-14 08:20:21.717779'
}
```

```json
{
    'resource_type': 'snapshot_group',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'deleted',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-14 08:20:21.717779'
}
```

snapshot_group 删除失败

```json
{
    'resource_type': 'snapshot_group',
    'resource_id': 'f99ad102-1aa9-484b-b9e4-c14de096dbbf',
    'current_status': 'error',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-14 08:20:22.034385'
}
```

### snapshot_group 回滚

在执行快照组回滚操作时，属于该快照组的快照的 Volume 通常会经过两次状态变化

同时会触发 VM 的回滚状态变化, 状态变化参考 VM 回滚

prepare_revert -> reverting -> available/in-use

对应的上游服务也会收到两次 webhook 请求

```json
{
    'resource_type': 'volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'reverting',
    'previous_status': '',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:32.538355'
}
```

```json
{
    'resource_type': 'volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'available'/'in-use',
    'previous_status': 'reverting',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

快照组回滚失败

```json
{
    'resource_type': 'volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'reverting',
    'action': 'revert',
    'error_msg': '',
    'timestamp': '2022-03-10 08:21:36.607681'
}
```

## VOI VM 状态变化

### VOI VM 创建

在创建 VOI VM 时，VOI VM 通常会经过两次状态变化

prepare_create -> creating -> active

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'creating',
    'previous_status': '',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:16.771126'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active',
    'previous_status': 'creating',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```

VM 创建失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'creating',
    'action': 'create',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```

### VOI VM 删除

在删除 VOI VM 时，VOI VM 通常会经过两次状态变化

prepare_delete -> deleting -> deleted

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'deleting',
    'previous_status': '',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'deleted',
    'previous_status': 'deleting',
    'action': 'delete',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VM 删除失败(暂未推webhook)

### VOI VM 关机

状态变化同 (VM/关机), 需注意 `resource_type` 为 `voi_vm`

### VOI VM 开机

状态变化同 (VM/开机), 需注意 `resource_type` 为 `voi_vm`

### VOI VM 重启

状态变化同 (VM/重启), 需注意 `resource_type` 为 `voi_vm`

### VOI VM 迁移

状态变化同 (VM/迁移), 需注意 `resource_type` 为 `voi_vm`

### VOI VM commit(合并)

在合并 VOI VM 时，VOI VM 通常会经过两次状态变化

prepare_commit -> committing-> stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'committing',
    'previous_status': '',
    'action': 'commit',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'committing',
    'action': 'commit',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 合并失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'committing',
    'action': 'commit',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```

### VOI VM reset(重置)

在重置 VOI VM 时，VOI VM 通常会经过两次状态变化

prepare_reset -> resetting -> stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'resetting',
    'previous_status': '',
    'action': 'reset',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'resetting',
    'action': 'reset',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 合并失败(暂未推webhook)

### VOI VM 切换光盘

在 VOI VM 切换光盘时，VOI VM 通常会经过两次状态变化

prepare_replace_iso -> replacing_iso -> active/stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'replacing_iso',
    'previous_status': '',
    'action': 'replace_iso',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'active/stopped',
    'previous_status': 'replacing_iso',
    'action': 'replace_iso',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 切换光盘失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'replacing_iso',
    'action': 'replace_iso',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

### VOI VM 添加数据盘

在 VOI VM 添加数据盘时，VOI VM 通常会经过两次状态变化

prepare_add_volume -> adding_volume -> stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'adding_volume',
    'previous_status': '',
    'action': 'add_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'adding_volume',
    'action': 'add_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 添加数据盘失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'adding_volume',
    'action': 'add_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

### VOI VM 删除数据盘

在 VOI VM 删除数据盘时，VOI VM 通常会经过两次状态变化

prepare_remove_volume -> removing_volume -> stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'removing_volume',
    'previous_status': '',
    'action': 'remove_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'removing_volume',
    'action': 'remove_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 删除数据盘失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'removing_volume',
    'action': 'remove_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

## VOI ShareDiak 状态变化

### VOI ShareDisk 合并(commit)

在合并 VOI ShareDisk 时，只发送一次 webhook, 标识合并的结果(error 或者 active)

```json
{
    'resource_type': 'share_disk',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e89',
    'current_status': 'active',
    'previous_status': '',
    'action': 'commit',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI ShareDiak 合并失败

```json
{
    'resource_type': 'share_disk',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e89',
    'current_status': 'error',
    'previous_status': '',
    'action': 'commit',
    'error_msg': '',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```

## VOI BackupDisk 状态变化

### VOI BackupDisk 合并(commit)

在合并 VOI BackupDisk 时，只发送一次 webhook, 标识合并的结果(error 或者 active)

resource_type 存在两种类型 "backup_sys_disk" "backup_data_disk"

```json
{
    'resource_type': 'backup_sys_disk',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e89',
    'current_status': 'active',
    'previous_status': '',
    'action': 'commit',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI BackupDisk 合并失败

```json
{
    'resource_type': 'backup_sys_disk',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e89',
    'current_status': 'error',
    'previous_status': '',
    'action': 'commit',
    'error_msg': 'xxx',
    'timestamp': '2022-03-10 07:27:20.980775'
}
```

## VOI ShareTemplateDisk 状态变化

### VOI VM 挂载共享盘模板

在 VOI VM 挂载共享盘模板时，VOI VM 通常会经过两次状态变化

prepare_attach -> attaching_volume -> stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'attaching_volume',
    'previous_status': '',
    'action': 'attach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'attaching_volume',
    'action': 'attach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 挂载共享盘模板失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'attaching_volume',
    'action': 'attach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

在 VOI VM 挂载共享盘模板时，VOI 共享盘模板通常也会经过两次状态变化

prepare_attach -> attaching -> in-use/available(失败时)

```json
{
    'resource_type': 'voi_share_template_volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'attaching',
    'previous_status': '',
    'action': 'attach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_share_template_volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'in-use',
    'previous_status': 'attaching',
    'action': 'attach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 挂载共享盘模板失败

```json
{
    'resource_type': 'voi_share_template_volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'available',
    'previous_status': 'attaching',
    'action': 'attach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```


### VOI VM 卸载共享盘模板

在 VOI VM 卸载共享盘模板时，VOI VM 通常会经过两次状态变化

prepare_detach -> detaching_volume -> stopped

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'detaching_volume',
    'previous_status': '',
    'action': 'detach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'stopped',
    'previous_status': 'detaching_volume',
    'action': 'detach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 卸载共享盘模板失败

```json
{
    'resource_type': 'voi_vm',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'error',
    'previous_status': 'detaching_volume',
    'action': 'detach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```


在 VOI VM 卸载共享盘模板时，VOI 共享盘模板通常也会经过两次状态变化

prepare_detach -> detaching -> available/in-use(失败时)

```json
{
    'resource_type': 'voi_share_template_volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'detaching',
    'previous_status': '',
    'action': 'detach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:09.459211'
}
```

```json
{
    'resource_type': 'voi_share_template_volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': ' available',
    'previous_status': 'detaching',
    'action': 'detach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```

VOI VM 挂载共享盘模板失败

```json
{
    'resource_type': 'voi_share_template_volume',
    'resource_id': '513325ef-f53a-4a11-9bdb-95eb00324e88',
    'current_status': 'in-use',
    'previous_status': 'detaching',
    'action': 'detach_share_template_volume',
    'error_msg': '',
    'timestamp': '2022-03-10 09:16:10.231647'
}
```
