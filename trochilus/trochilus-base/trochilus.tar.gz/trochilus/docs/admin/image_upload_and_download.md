---
title: "镜像的上传和下载"
---


镜像的上传和下载功能：
- 基于 Ceph 后端存储的镜像上传和下载
  - 优点：可以跨节点下载和上传镜像，Agent 可以向任意节点发送请求进行镜像的上传和下载。
  - 缺点：Ceph 部署复杂，出现故障后排查困难，需要更多的硬件资源支持。
- 基于 filesystem 后端存储的镜像上传和下载
  - 优点：不需要部署 ceph，使部署更为便捷。
  - 缺点：可靠性差，如果 API 所在节点系统崩溃，会导致镜像无法上传和下载，
    创建镜像卷时，会花费大量时间进行镜像的下载。


## 配置介绍

镜像的上传和下载功能需要在配置文件（trochilus.conf）的 [image_settings] 下进行配置。

配置项介绍：

- `enabled_image_store`：镜像后端存储方式，可以配置为 rbd 或者 filesystem。
  rbd 表示使用 Ceph 作为后端存储，filesystem 表示使用文件系统作为后端存储。
- `rbd_store_thin_provisioning`： 启用 rbd 存储中的精简配置，可以配置为 true 或者 false。
  镜像文件中有部分为 0 的字节序列，特别是未经过压缩的 raw 格式镜像，
  在上传的时候并不真正写入这些 0 的字节序列，而是由 ceph 自动解释为空字节，并不会真正的消耗存储空间。
- `rbd_store_conn_timeout`：连接 Ceph 的超时时间，设置为 0 则表示不设置超时时间。
- `rbd_store_chunk_size`：每次读取或写入文件块的大小， 单位 MB。
- `rbd_store_user`：指定进行 Ceph 身份验证的用户名， 该用户需要拥有镜像池的读写权限，卷池的读权限。
- `rbd_store_pool`：指定 Ceph 中存储镜像的池的名称。
- `rbd_store_config_file`：Ceph 配置文件所在的位置。
- `filesystem_store_chunk_size`：每次读取或写入文件块的大小， 单位 B。
- `filesystem_store_datadir`：filesystem 作为后端存储时，镜像文件的所在位置。


## 存储方式


### ceph 后端存储


#### 准备事项

创建用于存储镜像文件的 Ceph 池。创建示例如下：

```bash
# ceph osd pool create <pool_name> <pg_num>
ceph osd pool create images 100
```


#### 配置示例

```ini
[image_settings]
enabled_image_store = rbd
rbd_store_thin_provisioning = true
rbd_store_conn_timeout = 0
rbd_store_chunk_size = 8
rbd_store_user = admin
rbd_store_pool = images
rbd_store_config_file = /etc/ceph/ceph.conf
```


#### 文件存储位置

文件上传成功后，文件会存储以 `rbd_store_pool` 的值命名的 ceph 池中。查看示例如下：

```bash
# rbd ls <pool_name>
rbd ls images
```


### filesystem 后端存储


#### 配置示例

```ini
[image_settings]
enabled_image_store = filesystem
filesystem_store_chunk_size = 65536
filesystem_store_datadir = /var/lib/trochilus/images
```


#### 文件存储位置

文件上传成功后，文件会存储以 `filesystem_store_datadir` 的值命名的目录下。查看示例如下：

```bash
# 查看所有镜像文件
ll -h /var/lib/trochilus/images
```


## 使用示例


### 上传镜像

上传镜像需要两次请求，第一次创建镜像记录请求，获取响应值中的 id，用于第二次上传镜像文件请求的 image_id。

- 创建镜像记录

POST http://127.0.0.1:9906/v1/image

请求命令：

```bash
curl -L -X POST http://127.0.0.1:9906/v1/image -H 'Content-Type: application/json' --data-raw '{
    "image":{
        "name":"test",
        "description": "test_image",
        "disk_format": "qcow2",
        "metadata": {
            "key1": "value1",
            "key2": "value2"
        },
        "tags": ["33","11","22"]
    }
}'
```

返回信息：

```json
{
    "image": {
        "id": "fa98311e-35c4-4660-8f87-fb62b8ab5e7f",
        "name": "test",
        "checksum": null,
        "description": "test_image",
        "disk_format": "qcow2",
        "status": "queued",
        "created_at": "2022-02-15T09:03:44",
        "updated_at": null,
        "location": null,
        "user_id": null,
        "project_id": null,
        "size": null,
        "virtual_size": null,
        "metadata": {
            "key1": "value1",
            "key2": "value2"
        },
        "tags": [
            "33",
            "11",
            "22"
        ]
    }
}
```

- 上传镜像文件


PUT http://127.0.0.1:9906/v1/image/{image_id}/file

请求命令示例：

```bash
curl -L -X PUT http://127.0.0.1:9906/v1/image/fa98311e-35c4-4660-8f87-fb62b8ab5e7f/file \
     -H 'Content-Type: application/octet-stream' \
     --data-binary '@/home/liupeng/images/yourfile.qcow2'
```

上传成功后无具体返回值，接口具体使用方式参考[API文档](/api/image)


### 下载镜像

GET http://127.0.0.1:9906/v1/image/{image_id}/file

请求命令示例：

```bash
curl -L -X GET \
     -o /home/hxc/fa98311e-35c4-4660-8f87-fb62b8ab5e7f \
     http://127.0.0.1:9906/v1/image/fa98311e-35c4-4660-8f87-fb62b8ab5e7f/file
```

下载成功后无具体返回值，接口具体使用方式参考[API文档](/api/image)

