---
title: "Ceph 单机部署脚本 "
---


为了满足项目对 Ceph 环境的需求，我们提供了 Ceph 部署脚本([右击复制下载链接](/admin/scripts/deploy-ceph-singlenode.sh))，
并提供使用说明。如下：


## 环境准备

一台系统为 ubuntu 20.04 的物理机或虚拟机，并具有三块硬盘（sdb sdc sdd 或 vdb vdc vdd）。


## 配置介绍

部署 ceph 脚本需要在 (admin/scripts) 下的 deploy-ceph-singlenode.sh 中进行配置。

- `host_ip` ：当前主机 IP 地址。
- `host_pass` ：当前主机的密码。
- `ceph_public_network` ： Ceph 管理网络。
- `ceph_cluster_network` ： Ceph 集群网络，用于 Ceph 节点之间的通信。
- `ceph_pool_size` ：默认副本数。
- `ceph_pool_min_size` ：最小副本数。
- `ceph_pg_num` ： pg 数。
- `ceph_pgp_num` ： pgp 数。
- `ceph_mon_list` ：ceph 所在宿主机的 mon 地址列表。
- `ceph_name_list` ：ceph 所在宿主机的主机名列表。目前脚本中没有使用此配置，后期可补充优化使用。
- `osd_disk` ： ceph 对应的磁盘。


## 使用示例

```bash
host_ip=172.18.30.127
host_pass=Klcloud@9000
ceph_public_network=172.18.30.127/32
ceph_cluster_network=172.18.30.127/32
ceph_pool_size=1
ceph_pool_min_size=1
ceph_pg_num=16
ceph_pgp_num=16
ceph_mon_list="172.18.30.127:6789"
ceph_name_list="controller"
osd_disk="vdb vdc vdd"
```

该脚本适用于 ubuntu 环境下，因为是单机部署，所以上述的 ceph_cluster_network、
ceph_public_network 都配置成 "host_ip/32" 的形式。副本数量、 pg 和 pgp 数根据需求改变。
ceph_mon_list 应该配置成 "host_ip:6789" 。因为脚本中会自动配置主机名为 controller ，所以 ceph_name_list 必须写成 controller 。
硬盘列表应该为三块，例如 ”vdb vdc vdd“ 也可根据实际情况修改。


### 测试

脚本具有可执行权限的情况下使用命令执行脚本：

赋予可执行权限示例：

```bash
chmod +x deploy-ceph-singlenode.sh
```

执行脚本示例

```bash
source deploy-ceph-singlenode.sh
```

使用命令查询 Ceph 状态：

命令如下：

```bash
ceph -s
```

Ceph 状态如下：

```bash
cluster:
    id:     116d4de8-fd14-491f-811f-c1bdd8fac141
    health: HEALTH_OK
services:
    mon: 1 daemons, quorum controller (age 2d)
    mgr: controller(active, since 2d)
    osd: 3 osds: 3 up (since 2d), 3 in (since 2d)
```

当 health ： HEALTH_OK 证明 ceph 启动成功。


#### 注意事项

该脚本不会创建 ceph 池，需要自己手动创建。

```bash
# ceph osd pool create {pool-name} {pg-num} [{pgp-num}]
ceph osd pool create cephfs_data 128
```

